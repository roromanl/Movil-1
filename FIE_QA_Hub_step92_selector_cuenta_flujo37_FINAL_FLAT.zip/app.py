"""FIE QA Hub v14.
 
UI improvements over v13:
- Fixed-height expandable execution console.
- Spanish execution summary including elapsed time.
- Horizontal screenshot gallery with modal enlargement.
"""
from __future__ import annotations

import base64
import html
import json
import tempfile
import time
from pathlib import Path

import streamlit as st

from framework.core.runner import Runner
from framework.reporting.history import list_runs
from framework.config import settings
from framework.data.excel import make, read
from framework.field_admin import fields_for, load as load_fields, save as save_fields
from framework.flow_activation import active_catalog, load as load_activation, save as save_activation, reconcile as reconcile_activation
from framework.driver.lab import adb, appium, avds, devices, emulator, install_apk, launch, sdk

ROOT = Path(__file__).parent
CATALOG = json.loads((ROOT / "catalog" / "test_catalog.json").read_text(encoding="utf-8"))
SECURITY_QA=json.loads((ROOT/'config/security_questions.json').read_text(encoding='utf-8'))
reconcile_activation(ROOT, CATALOG)
ACTIVE_CATALOG = active_catalog(ROOT, CATALOG)
MODULES = sorted({item["modulo"] for item in ACTIVE_CATALOG if item.get("modulo")})


def configure_page() -> None:
    """Configure layout and reusable visual styles."""
    st.set_page_config(page_title="FIE - Automatizacion de pruebas - Fie Plus", page_icon="🟣", layout="wide")
    st.markdown(
        """
        <style>
        .stApp{background:#f4f6fa}.block-container{max-width:1500px;padding-top:1.4rem}
        [data-testid="stSidebar"]{background:linear-gradient(180deg,#071a36,#0b2750 70%,#671044)}
        [data-testid="stSidebar"] *{color:white}
        .hero{background:linear-gradient(120deg,#073967,#006bb5 55%,#ec1680);color:#fff;padding:24px;border-radius:22px;margin-bottom:18px}
        .card{background:#fff;border:1px solid #e3e8f0;border-radius:18px;padding:18px;min-height:110px;box-shadow:0 5px 18px #16324f10}
        .kpi-card{background:#fff;border:1px solid #e3e8f0;border-radius:18px;padding:17px;box-shadow:0 5px 18px #16324f10;border-top:4px solid #0070ba}.kpi-card.pink{border-top-color:#ec1680}.kpi-card.purple{border-top-color:#783f91}.kpi-n{font-size:30px;font-weight:850;color:#12335b}.kpi-l{font-size:12px;color:#77869a;font-weight:700;text-transform:uppercase}.health{background:#fff;border-radius:16px;border:1px solid #e4e9f0;padding:13px 16px;margin-top:12px}.device-card{background:linear-gradient(135deg,#fff,#f7f9fc);border:1px solid #dfe6ef;border-left:5px solid #0070ba;border-radius:18px;padding:16px;margin-bottom:10px;box-shadow:0 4px 14px #16324f0d}.device-title{font-size:18px;font-weight:800;color:#17365d}.device-meta{color:#68788e;font-size:13px;margin-top:5px}.badge-ok{color:#087f5b;font-weight:800}.history-head{font-size:12px;color:#708198;font-weight:750;text-transform:uppercase;padding:4px 0}.history-name{font-weight:800;color:#17365d}.history-sub{font-size:11px;color:#78879a}.history-grid-head{background:#e7edf5;border-top:1px solid #cbd5e1;border-bottom:2px solid #9aa9bb;padding:9px 8px;color:#344861;font-size:11px;font-weight:850;text-transform:uppercase;letter-spacing:.03em}.history-run{background:transparent;border:0;border-bottom:1px solid #dfe5ec;border-radius:0;padding:9px 7px;margin:0;box-shadow:none;min-height:39px}.history-run.failed,.history-run.ok{border-left:0;border-bottom:1px solid #dfe5ec}.history-value{font-size:13px;font-weight:650;color:#263b53;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.history-label{font-size:10px;color:#7b8998;text-transform:uppercase;font-weight:700}.history-status-ok{color:#137a56;font-weight:800}.history-status-fail{color:#b82d50;font-weight:800}.history-status-warn{color:#956308;font-weight:800}.history-row{padding:3px 0;border-bottom:1px solid #edf0f4}.history-actions button{min-height:34px!important;border-radius:7px!important;font-weight:750!important}.compact-note{font-size:12px;color:#718096}
        [data-testid="stSidebar"] [role="radiogroup"]{gap:10px;display:flex!important;flex-direction:column;margin-top:18px;width:100%!important}[data-testid="stSidebar"] [role="radiogroup"]>label{flex:0 0 48px!important;max-width:none!important}
        [data-testid="stSidebar"] [role="radiogroup"] label{background:#ffffff0d;border:1px solid #ffffff16;border-radius:15px;padding:0 14px!important;transition:.18s ease;cursor:pointer;width:100%!important;min-height:48px!important;height:48px!important;display:flex!important;align-items:center!important;box-sizing:border-box!important}[data-testid="stSidebar"] [role="radiogroup"] label>div:first-child{display:none!important}[data-testid="stSidebar"] [role="radiogroup"] label>div:last-child{width:100%!important;display:flex!important;align-items:center!important;height:48px!important}
        [data-testid="stSidebar"] [role="radiogroup"] label:hover{background:#ffffff1c;border-color:#ffffff42;transform:translateX(3px)}
        [data-testid="stSidebar"] [role="radiogroup"] label:has(input:checked){background:linear-gradient(90deg,#0070ba,#783f91);border-color:#ff4da2;box-shadow:0 7px 18px #0003;transform:translateX(4px)}
        [data-testid="stSidebar"] [role="radiogroup"] label p{font-size:14px!important;font-weight:750!important;white-space:nowrap!important;margin:0!important;line-height:1!important}
        .stButton button[kind="primary"]{background:#ec1680;border-color:#ec1680}
        .launch-step{background:#fff;border:1px solid #e3e8f0;border-radius:18px;padding:14px 16px 10px;box-shadow:0 4px 14px #16324f0b;margin-bottom:8px;border-top:3px solid #0070ba}.launch-step.pink{border-top-color:#ec1680}.launch-step.purple{border-top-color:#783f91}.step-kicker{font-size:11px;text-transform:uppercase;letter-spacing:.08em;color:#78869a;font-weight:700}.step-title{font-size:17px;font-weight:750;color:#152743;margin-top:3px}.step-icon{font-size:22px;float:right}.catalog-card{background:linear-gradient(135deg,#0d315a,#783f91);color:#fff;border-radius:18px;padding:14px 18px;min-height:87px;box-shadow:0 5px 16px #16324f18}.catalog-card .n{font-size:28px;font-weight:850}.catalog-card .l{font-size:12px;opacity:.8}.live-console{height:280px;overflow-y:auto;background:#07111f;color:#d6e2f0;border-radius:12px;padding:12px;font-family:Consolas,monospace;font-size:12px;white-space:pre-wrap;border:1px solid #1f3652}
        
        [data-testid="stSidebar"] div[role="radiogroup"]{width:100%!important}
        [data-testid="stSidebar"] div[role="radiogroup"]>label{width:100%!important;max-width:100%!important;min-width:100%!important;height:48px!important;min-height:48px!important;margin:0!important;box-sizing:border-box!important}
        [data-testid="stSidebar"] div[role="radiogroup"]>label>div{width:100%!important;max-width:100%!important}
        
        [data-testid="stSidebar"] [role="radiogroup"]{display:grid!important;grid-template-columns:minmax(0,1fr)!important;width:100%!important;align-items:stretch!important}
        [data-testid="stSidebar"] [role="radiogroup"] label{display:flex!important;width:100%!important;min-width:0!important;max-width:none!important;height:50px!important;min-height:50px!important;align-self:stretch!important;justify-self:stretch!important;box-sizing:border-box!important}
        [data-testid="stSidebar"] [role="radiogroup"] label>div:last-child{width:100%!important;min-width:0!important;flex:1 1 auto!important}
        
        [data-testid="stTextInput"] input{background:#ffffff!important;border:1px solid #b8c4d3!important;border-radius:8px!important;min-height:38px!important;box-shadow:inset 0 1px 2px #1a365d0d!important}
        [data-testid="stTextInput"] input:focus{border-color:#ec1680!important;box-shadow:0 0 0 1px #ec1680!important}
        [data-testid="stSelectbox"] div[data-baseweb="select"]>div{background:#ffffff!important;border:1px solid #b8c4d3!important;border-radius:8px!important;min-height:38px!important}
        [data-testid="stNumberInput"] input{background:#ffffff!important;border:1px solid #b8c4d3!important}
        </style>
        """,
        unsafe_allow_html=True,
    )


def hero(icon: str, title: str, subtitle: str) -> None:
    st.markdown(f'<div class="hero"><h1>{icon} {title}</h1><p>{subtitle}</p></div>', unsafe_allow_html=True)


def format_seconds(value: float | int | None) -> str:
    """Return a friendly mm:ss display for execution summaries."""
    seconds = float(value or 0)
    minutes = int(seconds // 60)
    remaining = seconds % 60
    return f"{minutes:02d}:{remaining:05.2f}"


def screenshot_gallery(evidence_dir: Path, key_prefix: str) -> None:
    """Render screenshots with browser-native links that never rerun Streamlit."""
    images = sorted((evidence_dir / "screenshots").glob("*.png"))
    if not images:
        st.caption("Sin capturas para este registro.")
        return

    st.markdown("**Capturas de pantalla**")
    for row_start in range(0, len(images), 4):
        columns = st.columns(4)
        for offset, image in enumerate(images[row_start : row_start + 4]):
            with columns[offset]:
                st.image(str(image), caption=image.name, width=150)
                encoded = base64.b64encode(image.read_bytes()).decode("ascii")
                st.markdown(
                    f'<a href="data:image/png;base64,{encoded}" target="_blank" '
                    'style="display:block;text-align:center;padding:7px 10px;'
                    'border:1px solid #d7dde6;border-radius:8px;text-decoration:none;'
                    'color:#24364b;background:#fff">Ver captura</a>',
                    unsafe_allow_html=True,
                )


@st.dialog("Vista de captura", width="large")
def capture_modal() -> None:
    selected=st.session_state.get("modal_capture")
    if not selected:return
    st.image(selected["path"],caption=selected.get("caption",""),use_container_width=True)
    if st.button("Cerrar",use_container_width=True):
        st.session_state.pop("modal_capture",None)
        st.rerun()


def render_capture_modal_if_needed() -> None:
    if st.session_state.get("modal_capture"):
        capture_modal()


@st.fragment
def render_downloads(report: Path | None, log: Path | None, key_prefix: str) -> None:
    """Render download controls without rerunning the full application.

    Streamlit fragments isolate widget reruns. This prevents a file download
    from rebuilding the page and collapsing the surrounding result expander.
    """
    left, right = st.columns(2)

    if report and report.exists():
        left.download_button(
            "⬇ Descargar reporte Word",
            report.read_bytes(),
            file_name=report.name,
            mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            key=f"{key_prefix}_report",
            use_container_width=True,
        )

    if log and log.exists():
        right.download_button(
            "⬇ Descargar log técnico",
            log.read_bytes(),
            file_name=log.name,
            mime="text/plain",
            key=f"{key_prefix}_log",
            use_container_width=True,
        )


def render_artifacts(results: list[dict], key_prefix: str) -> None:
    """Render Spanish summary plus record-level report, log and screenshots."""
    summary_rows = [
        {
            "Prueba": result["name"],
            "Registro": result["record"],
            "Resultado": result["status"],
            "Tiempo de ejecución": format_seconds(result.get("tiempo_segundos")),
            "Detalle": result["detail"],
        }
        for result in results
    ]
    st.dataframe(summary_rows, use_container_width=True, hide_index=True)

    for index, result in enumerate(results):
        label = (
            f"{result['test_id']:03d} · Registro {result['record']} · "
            f"{result['status']} · {format_seconds(result.get('tiempo_segundos'))}"
        )
        with st.expander(label, expanded=result["status"] == "FALLIDO"):
            st.write(f"**Detalle:** {result['detail']}")
            report = Path(result["report"]) if result.get("report") else None
            log = Path(result["log"]) if result.get("log") else None
            evidence = Path(result["evidence"]) if result.get("evidence") else None

            render_downloads(None, log, f"{key_prefix}_{index}")
            if evidence and evidence.exists():
                screenshot_gallery(evidence, f"{key_prefix}_shot_{index}")


def select_tests(mode: str) -> list[dict]:
    """Preserve individual, regression and integral selectors."""
    if mode == "Prueba individual":
        left, right = st.columns(2)
        with left:
            st.markdown('<div class="launch-step purple"><span class="step-icon">🧩</span><div class="step-kicker">Paso 3</div><div class="step-title">Módulo funcional</div></div>', unsafe_allow_html=True)
            module = st.selectbox("Módulo", MODULES, label_visibility="collapsed")
        pool = [item for item in ACTIVE_CATALOG if item["modulo"] == module]
        with right:
            st.markdown('<div class="launch-step pink"><span class="step-icon">🧪</span><div class="step-kicker">Paso 4</div><div class="step-title">Flujo de prueba</div></div>', unsafe_allow_html=True)
            flow = st.selectbox(
                "Flujo",
                pool,
                format_func=lambda item: f"{item['id']:03d} · {item['nombre']}",
                label_visibility="collapsed",
            )
        return [flow]

    modules = st.multiselect("Módulos incluidos", MODULES)
    pool = [item for item in ACTIVE_CATALOG if item["modulo"] in modules]
    default = pool if mode == "Prueba integral" else []
    return st.multiselect(
        "Flujos incluidos",
        pool,
        default=default,
        format_func=lambda item: f"{item['id']:03d} · {item['nombre']}",
    )


def render_home() -> None:
    hero("🤖", "Automatización móvil", "Centro de control operativo · Appium · Android · ejecución y evidencia.")
    connected = devices(); online=[x for x in connected if x["state"]=="device"]; emulator_list=avds()
    values=[len(online),len(emulator_list),len(CATALOG),len(MODULES)];labels=["Dispositivos activos","AVD disponibles","Pruebas catalogadas","Módulos"]
    classes=["kpi-card","kpi-card pink","kpi-card purple","kpi-card"]
    for col,value,label,css in zip(st.columns(4),values,labels,classes):
        col.markdown(f'<div class="{css}"><div class="kpi-l">{label}</div><div class="kpi-n">{value}</div></div>',unsafe_allow_html=True)
    st.markdown("### Estado de la plataforma")
    a,b,c=st.columns(3)
    a.markdown(f'<div class="health"><b>{"✅" if adb() else "❌"} ADB</b><br><small>{adb() or "No detectado"}</small></div>',unsafe_allow_html=True)
    b.markdown(f'<div class="health"><b>{"✅" if appium() else "❌"} Appium</b><br><small>{"Servidor disponible" if appium() else "Servidor no disponible"}</small></div>',unsafe_allow_html=True)
    c.markdown(f'<div class="health"><b>{"✅" if sdk() else "❌"} Android SDK</b><br><small>{sdk() or "No detectado"}</small></div>',unsafe_allow_html=True)
    st.markdown("### Dispositivos disponibles")
    if online:
        for col,item in zip(st.columns(min(3,len(online))),online):col.markdown(f'<div class="device-card"><div class="device-title">📱 {item["model"]}</div><div class="device-meta">{item["kind"]} · {item["udid"]}</div><div class="badge-ok">● ONLINE</div></div>',unsafe_allow_html=True)
    else:st.info("No hay dispositivos Android online. Revisa ADB o inicia un emulador desde Device Lab.")


def render_device_lab() -> None:
    hero("📱", "Laboratorio de dispositivos", "Inventario, conectividad y control de dispositivos Android.")
    connected=devices();online=[x for x in connected if x["state"]=="device"];offline=[x for x in connected if x["state"]!="device"]
    a,b,c,d=st.columns(4);a.metric("En línea",len(online));b.metric("Detectados",len(connected));c.metric("Emuladores AVD",len(avds()));d.metric("Appium","En línea" if appium() else "Sin conexión")
    with st.expander("▸ Diagnóstico y herramientas Android", expanded=False):
        st.caption("Rutas y estado técnico para diagnóstico del entorno de automatización")
        st.code(f"SDK Android: {sdk()}\nADB: {adb()}\nEmulador: {emulator()}\nAppium: {'DISPONIBLE' if appium() else 'NO DISPONIBLE'}")
    device_tab, emulator_tab, install_tab = st.tabs(["📱 Dispositivos", "🖥️ Emuladores", "Instalar APK"])
    with device_tab:
        if not connected:st.info("ADB no reporta dispositivos conectados.")
        for item in connected:
            state='EN LÍNEA' if item['state']=='device' else item['state'].upper();color='badge-ok' if item['state']=='device' else ''
            st.markdown(f'<div class="device-card"><div class="device-title">📱 {item["model"]}</div><div class="device-meta"><b>Tipo:</b> {item["kind"]} &nbsp; · &nbsp; <b>UDID:</b> {item["udid"]}</div><div class="{color}">● {state}</div></div>',unsafe_allow_html=True)
    with emulator_tab:
        available=avds()
        if available:
            chosen=st.selectbox("AVD disponible",available)
            x,y=st.columns([1,3])
            if x.button("▶ Encender emulador",use_container_width=True):launch(chosen);st.success(f"Solicitud de inicio enviada a {chosen}")
            y.caption("El dispositivo aparecerá en la pestaña Dispositivos cuando ADB lo reporte como online.")
        else:st.info("No hay AVD configurados en el Android SDK detectado.")

    with install_tab:
        st.markdown("### Instalar aplicación Android")
        st.caption("Carga un archivo APK y selecciona el dispositivo Android donde deseas instalarlo.")

        online_devices = [item for item in connected if item["state"] == "device"]
        if not online_devices:
            st.warning("No hay dispositivos Android en línea para instalar el APK.")
        else:
            target_label = st.selectbox(
                "Dispositivo de destino",
                [f"{item['model']} · {item['udid']}" for item in online_devices],
                key="apk_target_device",
            )
            target = next(
                item for item in online_devices if item["udid"] in target_label
            )
            apk_file = st.file_uploader(
                "Archivo APK",
                type=["apk"],
                key="apk_file_uploader",
                help="Selecciona el APK que deseas instalar o actualizar.",
            )

            install_disabled = apk_file is None
            if st.button(
                "Instalar APK",
                type="primary",
                use_container_width=True,
                disabled=install_disabled,
            ):
                temp_path = None
                try:
                    # ADB installs from a filesystem path, so the uploaded bytes
                    # are stored only for the duration of this installation.
                    with tempfile.NamedTemporaryFile(
                        suffix=".apk", delete=False
                    ) as temp_apk:
                        temp_apk.write(apk_file.getbuffer())
                        temp_path = Path(temp_apk.name)

                    with st.spinner(
                        f"Instalando {apk_file.name} en {target['model']}..."
                    ):
                        success, message = install_apk(target["udid"], temp_path)

                    if success:
                        st.success(
                            f"APK instalado correctamente en {target['model']} ({target['udid']})."
                        )
                    else:
                        st.error("No se pudo instalar el APK.")
                    if message:
                        with st.expander("Detalle de ADB", expanded=not success):
                            st.code(message)
                finally:
                    if temp_path and temp_path.exists():
                        temp_path.unlink(missing_ok=True)


def render_launch() -> None:
    hero("🚀", "Centro de ejecución", "Mantiene las esperas y muestra en vivo los print() originales.")
    online = [item for item in devices() if item["state"] == "device"]
    # Step cards make the execution setup feel like a guided workspace rather
    # than a conventional form. Native Streamlit controls remain underneath
    # each card to preserve keyboard access and reliable state handling.
    col1, col2, col3 = st.columns([1.15, 1.35, 0.65])
    with col1:
        st.markdown('<div class="launch-step"><span class="step-icon">🧭</span><div class="step-kicker">Paso 1</div><div class="step-title">Modalidad de ejecución</div></div>', unsafe_allow_html=True)
        mode = st.selectbox(
            "Modalidad",
            ["Prueba individual", "Regresión", "Prueba integral"],
            label_visibility="collapsed",
        )
    with col2:
        st.markdown('<div class="launch-step pink"><span class="step-icon">📱</span><div class="step-kicker">Paso 2</div><div class="step-title">Dispositivo de destino</div></div>', unsafe_allow_html=True)
        device_label = st.selectbox(
            "Dispositivo",
            [f"{item['model']} · {item['udid']}" for item in online] or ["Sin dispositivo"],
            disabled=not online,
            label_visibility="collapsed",
        )
        device = next((item for item in online if item["udid"] in device_label), None)
    with col3:
        st.markdown(
            f'<div class="catalog-card"><div class="l">CATÁLOGO ACTIVO</div><div class="n">{len(active_catalog(ROOT, CATALOG))}</div><div class="l">casos activos</div></div>',
            unsafe_allow_html=True,
        )

    st.markdown('<div style="height:8px"></div>', unsafe_allow_html=True)
    tests = select_tests(mode)
    if not tests:
        return

    st.markdown("### Datos de la ejecución")
    input_mode=st.segmented_control("Forma de ingresar datos",["Simple / secuencial","Masiva desde Excel"],selection_mode="single",default=None)
    data={};uploaded=None
    if input_mode=="Simple / secuencial":
        count=st.number_input("Número de ejecuciones secuenciales",1,5,1)
        suite_mode=mode in ("Regresión","Prueba integral");shared_user=shared_password=""
        if suite_mode:
            a,b=st.columns(2);shared_user=a.text_input("Usuario de la suite",key="suite_user");shared_password=b.text_input("Contraseña de la suite",type="password",key="suite_password")
        for test in tests:
            fields=fields_for(ROOT,test);rows=[]
            if suite_mode and test['id']==2:data[test['id']]=[{'username':shared_user,'password':shared_password}];continue
            with st.expander(f"{test['id']:03d} · {test['nombre']}",expanded=len(tests)==1):
                for seq in range(int(count)):
                    row={'username':shared_user,'password':shared_password} if suite_mode else {'username':st.text_input("Usuario",key=f"u_{test['id']}_{seq}"),'password':st.text_input("Contraseña",type="password",key=f"p_{test['id']}_{seq}")}
                    # Flow 021: card selection by last four digits before changing the switch.
                    if test['id']==21:
                        fterm=next(f for f in fields if f['name']=='terminacion_tarjeta');fhab=next(f for f in fields if f['name']=='habilitar');ffec=next(f for f in fields if f['name']=='fecha_hasta')
                        ccard,cswitch=st.columns(2)
                        with ccard:row['terminacion_tarjeta']=st.text_input(fterm['label'],max_chars=4,key=f"f_{test['id']}_{seq}_terminacion_tarjeta",help="Ingresa los últimos 4 dígitos visibles en la tarjeta")
                        with cswitch:row['habilitar']=st.toggle(fhab['label'],value=True,key=f"f_{test['id']}_{seq}_habilitar")
                        if row['habilitar']:
                            row['fecha_hasta']=st.date_input(ffec['label'],format="DD/MM/YYYY",key=f"f_{test['id']}_{seq}_fecha_hasta").strftime("%d/%m/%Y")
                        else:row['fecha_hasta']=None
                        visible_fields=[]
                    else:visible_fields=list(fields)
                    # Flow 022: card selection plus daily-limit combos.
                    if test['id']==22:
                        fterm=next(f for f in fields if f['name']=='terminacion_tarjeta');fr=next(f for f in fields if f['name']=='limite_retiro');fc=next(f for f in fields if f['name']=='limite_compra')
                        row['terminacion_tarjeta']=st.text_input(fterm['label'],max_chars=4,key=f"f_{test['id']}_{seq}_terminacion_tarjeta")
                        cr,cc=st.columns(2)
                        with cr:row['limite_retiro']=st.selectbox(fr['label'],fr['options'],key=f"f_{test['id']}_{seq}_limite_retiro")
                        with cc:row['limite_compra']=st.selectbox(fc['label'],fc['options'],key=f"f_{test['id']}_{seq}_limite_compra")
                        visible_fields=[]
                    elif test['id']!=21:visible_fields=list(fields)
                    # Flow 023: bloqueo/desbloqueo condicional por tarjeta.
                    if test['id']==23:
                        fd={f['name']:f for f in fields}; ccard,caction=st.columns(2)
                        with ccard: row['terminacion_tarjeta']=st.text_input(fd['terminacion_tarjeta']['label'],max_chars=4,key=f"f_{test['id']}_{seq}_terminacion_tarjeta")
                        with caction: row['accion']=st.selectbox(fd['accion']['label'],fd['accion']['options'],key=f"f_{test['id']}_{seq}_accion")
                        if row['accion']=='Bloquear':
                            row['tipo_bloqueo']=st.selectbox(fd['tipo_bloqueo']['label'],fd['tipo_bloqueo']['options'],key=f"f_{test['id']}_{seq}_tipo_bloqueo")
                            if row['tipo_bloqueo']=='Bloqueo definitivo':
                                row['motivo']=st.selectbox(fd['motivo']['label'],fd['motivo']['options'],key=f"f_{test['id']}_{seq}_motivo");row['fecha_hasta']=None;row['periodo_maximo']=None
                            else:
                                row['periodo_maximo']=st.toggle(fd['periodo_maximo']['label'],value=False,key=f"f_{test['id']}_{seq}_periodo_maximo")
                                if row['periodo_maximo']:
                                    row['fecha_hasta']=None
                                else:
                                    row['fecha_hasta']=st.date_input(fd['fecha_hasta']['label'],format="DD/MM/YYYY",key=f"f_{test['id']}_{seq}_fecha_hasta").strftime("%d/%m/%Y")
                                row['motivo']=None
                        else: row['tipo_bloqueo']=None;row['motivo']=None;row['fecha_hasta']=None;row['periodo_maximo']=None
                        visible_fields=[]
                    elif test['id'] not in (21,22): visible_fields=list(fields)
                    # 084/089 pago: monto solo para Otro.
                    if test['id'] in (84,89):
                        fd={f['name']:f for f in fields}
                        if fd.get('numero_cuenta'):row['numero_cuenta']=st.text_input(fd['numero_cuenta']['label'],key=f"f_{test['id']}_{seq}_numero_cuenta")
                        row['tipo_pago']=st.selectbox(fd['tipo_pago']['label'],fd['tipo_pago']['options'],key=f"f_{test['id']}_{seq}_tipo_pago")
                        row['monto']=st.text_input(fd['monto']['label'],key=f"f_{test['id']}_{seq}_monto") if row['tipo_pago']=='Otro' else None
                        visible_fields=[]
                    else:visible_fields=list(fields)
                    # Flow 095: fechas solo para Personalizado.
                    if test['id'] in (13,95):
                        fd={f['name']:f for f in fields}
                        row['opcion_fechas']=st.selectbox(fd['opcion_fechas']['label'],fd['opcion_fechas']['options'],key=f"f_{test['id']}_{seq}_opcion_fechas")
                        if row['opcion_fechas']=='Personalizado':
                            c1,c2=st.columns(2)
                            with c1:row['fecha_desde']=st.date_input('Fecha Desde',format='DD/MM/YYYY',key=f"f_{test['id']}_{seq}_fecha_desde").strftime('%d/%m/%Y')
                            with c2:row['fecha_hasta']=st.date_input('Fecha Hasta',format='DD/MM/YYYY',key=f"f_{test['id']}_{seq}_fecha_hasta").strftime('%d/%m/%Y')
                        else:row['fecha_desde']=None;row['fecha_hasta']=None
                        for f95 in [f for f in fields if f['name'] not in ('opcion_fechas','fecha_desde','fecha_hasta')]:row[f95['name']]=st.text_input(f95['label'],key=f"f_{test['id']}_{seq}_{f95['name']}")
                        visible_fields=[]
                    else:visible_fields=list(fields)
                    # Flow 025: cliente existente usa lupa; no cliente solicita BENEFICIARIO.
                    if test['id']==25:
                        fd={f['name']:f for f in fields}
                        row['tipo_identificacion']=st.selectbox(fd['tipo_identificacion']['label'],fd['tipo_identificacion']['options'],key=f"f_{test['id']}_{seq}_tipo_identificacion")
                        row['numero_identificacion']=st.text_input(fd['numero_identificacion']['label'],key=f"f_{test['id']}_{seq}_numero_identificacion")
                        row['es_cliente']=st.toggle(fd['es_cliente']['label'],value=True,key=f"f_{test['id']}_{seq}_es_cliente")
                        if not row['es_cliente']:
                            st.caption('BENEFICIARIO')
                            for n in ['nombre','apellido','apellido_casada','direccion','telefono']:row[n]=st.text_input(fd[n]['label'],key=f"f_{test['id']}_{seq}_{n}")
                        else:
                            for n in ['nombre','apellido','apellido_casada','direccion','telefono']:row[n]=None
                        rest=['numero_cuenta','monto','departamento','concepto','origen_fondos','destino_fondos']
                        for pos25 in range(0,len(rest),2):
                            cc=st.columns(2)
                            for off,n in enumerate(rest[pos25:pos25+2]):
                                with cc[off]:row[n]=st.selectbox(fd[n]['label'],fd[n]['options'],key=f"f_{test['id']}_{seq}_{n}") if fd[n].get('type')=='combo' else st.text_input(fd[n]['label'],key=f"f_{test['id']}_{seq}_{n}")
                        visible_fields=[]
                    else:visible_fields=list(fields)
                    # Flow 004: preguntas y respuestas dependientes, sin repetir pregunta.
                    if test['id']==4:
                        fd={f['name']:f for f in fields};preguntas=list(SECURITY_QA)
                        row['pregunta_1']=st.selectbox(fd['pregunta_1']['label'],preguntas,key=f"f_{test['id']}_{seq}_pregunta_1")
                        row['respuesta_1']=st.selectbox(fd['respuesta_1']['label'],SECURITY_QA[row['pregunta_1']],key=f"f_{test['id']}_{seq}_respuesta_1")
                        preguntas2=[q for q in preguntas if q!=row['pregunta_1']]
                        row['pregunta_2']=st.selectbox(fd['pregunta_2']['label'],preguntas2,key=f"f_{test['id']}_{seq}_pregunta_2")
                        row['respuesta_2']=st.selectbox(fd['respuesta_2']['label'],SECURITY_QA[row['pregunta_2']],key=f"f_{test['id']}_{seq}_respuesta_2")
                        for n in ('pregunta_personalizada','respuesta_personalizada'):
                            if n in fd:row[n]=st.text_input(fd[n]['label'],key=f"f_{test['id']}_{seq}_{n}")
                        visible_fields=[]
                    else:visible_fields=list(fields)
                    # Flow 001: preguntas dependientes como 004 + Imagen ID bloqueado.
                    if test['id']==1:
                        fd={f['name']:f for f in fields};qs=list(SECURITY_QA)
                        for n in ['usuario_login','nuevo_usuario','nueva_password','confirmar_password']:
                            row[n]=st.text_input(fd[n]['label'],type='password' if 'password' in n else 'default',key=f"f_{test['id']}_{seq}_{n}")
                        row['imagen_id']=st.text_input(fd['imagen_id']['label'],value='firstentry_select_imagen_ent_011',disabled=True,key=f"f_{test['id']}_{seq}_imagen_id")
                        row['pregunta1_seleccionada']=st.selectbox('Pregunta 1',qs,key=f"f_{test['id']}_{seq}_pregunta1")
                        row['respuesta1_seleccionada']=st.selectbox('Respuesta 1',SECURITY_QA[row['pregunta1_seleccionada']],key=f"f_{test['id']}_{seq}_respuesta1")
                        qs2=[q for q in qs if q!=row['pregunta1_seleccionada']]
                        row['pregunta2_seleccionada']=st.selectbox('Pregunta 2',qs2,key=f"f_{test['id']}_{seq}_pregunta2")
                        row['respuesta2_seleccionada']=st.selectbox('Respuesta 2',SECURITY_QA[row['pregunta2_seleccionada']],key=f"f_{test['id']}_{seq}_respuesta2")
                        for n in ['pregunta_personalizada','respuesta_personalizada','nombre_dispositivo']:row[n]=st.text_input(fd[n]['label'],key=f"f_{test['id']}_{seq}_{n}")
                        visible_fields=[]
                    elif test['id']==156:
                        fd={f['name']:f for f in fields};row['numero_cuenta']=st.text_input(fd['numero_cuenta']['label'],key=f"f_{test['id']}_{seq}_numero_cuenta");row['tipo_pago']=st.selectbox(fd['tipo_pago']['label'],fd['tipo_pago']['options'],key=f"f_{test['id']}_{seq}_tipo_pago");row['monto']=st.text_input(fd['monto']['label'],key=f"f_{test['id']}_{seq}_monto") if row['tipo_pago']=='Otro' else None;visible_fields=[]
                    else:visible_fields=list(fields)
                    # Flow 108: cuenta primero, Uso único switch, fecha DD/MM/YYYY.
                    if test['id']==108:
                        fd={f['name']:f for f in fields};row['numero_cuenta']=st.text_input(fd['numero_cuenta']['label'],key=f"f_{test['id']}_{seq}_numero_cuenta")
                        c1,c2=st.columns(2)
                        with c1:row['monto']=st.text_input(fd['monto']['label'],key=f"f_{test['id']}_{seq}_monto")
                        with c2:row['concepto']=st.text_input(fd['concepto']['label'],key=f"f_{test['id']}_{seq}_concepto")
                        row['uso_unico']=st.toggle(fd['uso_unico']['label'],value=False,key=f"f_{test['id']}_{seq}_uso_unico")
                        row['fecha_vencimiento']=st.date_input(fd['fecha_vencimiento']['label'],format='DD/MM/YYYY',key=f"f_{test['id']}_{seq}_fecha_vencimiento").strftime('%d/%m/%Y')
                        visible_fields=[]
                    elif test['id']==111:
                        fd={f['name']:f for f in fields};row['tipo_movimiento']=st.selectbox(fd['tipo_movimiento']['label'],fd['tipo_movimiento']['options'],key=f"f_{test['id']}_{seq}_tipo_movimiento")
                        a,b=st.columns(2)
                        with a:row['fecha_desde']=st.date_input('Fecha Desde',format='DD/MM/YYYY',key=f"f_{test['id']}_{seq}_fecha_desde").strftime('%d/%m/%Y')
                        with b:row['fecha_hasta']=st.date_input('Fecha Hasta',format='DD/MM/YYYY',key=f"f_{test['id']}_{seq}_fecha_hasta").strftime('%d/%m/%Y')
                        for n in ['mov_concepto','mov_monto','mov_signo']:
                            row[n]=st.selectbox(fd[n]['label'],fd[n]['options'],key=f"f_{test['id']}_{seq}_{n}") if fd[n].get('type')=='combo' else st.text_input(fd[n]['label'],key=f"f_{test['id']}_{seq}_{n}")
                        visible_fields=[]
                    else:visible_fields=list(fields)
                    # Flow 014: notifications organized like the mobile screen.
                    if test['id'] in (14,15,97):
                        account14=next((f for f in fields if f['name']=='cuenta'),None)
                        if account14:row['cuenta']=st.text_input(account14['label'],key=f"f_{test['id']}_{seq}_cuenta")
                        for section14 in ['Recepción de abono en cuenta','Retiro en su cuenta','Notificaciones informativas']:
                            with st.container(border=True):
                                st.markdown(f"**{section14}**")
                                items14=[f for f in fields if f.get('section')==section14]
                                # Main section switch first when it exists.
                                main_name='abono_estado' if section14.startswith('Recepción') else ('retiro_estado' if section14.startswith('Retiro') else None)
                                if main_name:
                                    mainf=next(f for f in items14 if f['name']==main_name);row[main_name]=st.toggle(mainf['label'],value=bool(mainf.get('default',True)),key=f"f_{test['id']}_{seq}_{main_name}")
                                rest=[f for f in items14 if f['name']!=main_name]
                                for pos14 in range(0,len(rest),2):
                                    cols14=st.columns(2)
                                    for off14,field in enumerate(rest[pos14:pos14+2]):
                                        with cols14[off14]:
                                            if field['type']=='switch':row[field['name']]=st.toggle(field['label'],value=bool(field.get('default',False)),key=f"f_{test['id']}_{seq}_{field['name']}")
                                            elif field['type']=='combo':row[field['name']]=st.selectbox(field['label'],field['options'],key=f"f_{test['id']}_{seq}_{field['name']}")
                                            else:row[field['name']]=st.text_input(field['label'],key=f"f_{test['id']}_{seq}_{field['name']}")
                        visible_fields=[]
                    elif test['id']!=21:
                        visible_fields=list(fields)
                    # Flow 017: organized profile and custom boolean switches.
                    if test['id']==16:
                        pf=next(f for f in fields if f['name']=='perfil')
                        profile17=st.selectbox(pf['label'],pf['options'],key=f"f_{test['id']}_{seq}_perfil")
                        row['perfil']=profile17
                        if profile17=='Personalizado':
                            custom=[f for f in fields if f['name']!='perfil']
                            sections=[]
                            for f17 in custom:
                                if f17.get('section') not in sections:sections.append(f17.get('section'))
                            for section in sections:
                                with st.container(border=True):
                                    st.markdown(f"**{section}**")
                                    section_fields=[f for f in custom if f.get('section')==section]
                                    cols17=st.columns(min(3,max(1,len(section_fields))))
                                    for idx17,field in enumerate(section_fields):
                                        with cols17[idx17 % len(cols17)]:
                                            row[field['name']]=st.toggle(field['label'],value=bool(field.get('default',False)),key=f"f_{test['id']}_{seq}_{field['name']}")
                        visible_fields=[]
                    elif test['id'] not in (1,4,13,14,15,21,22,23,25,84,89,95,97,108,111,156):
                        visible_fields=list(fields)
                    # Conditional fields for consolidated movement flows.
                    conditional_ids=(46,56,65,75,105)
                    tipo_actual=None
                    if test['id'] in conditional_ids:
                        tipo_field=next((f for f in fields if f['name']=='tipo_movimiento'),None)
                        if tipo_field:
                            tipo_actual=st.selectbox(tipo_field['label'],tipo_field['options'],key=f"f_{test['id']}_{seq}_tipo_movimiento")
                            row['tipo_movimiento']=tipo_actual
                    hidden={'tipo_movimiento'} if test['id'] in conditional_ids else set()
                    if test['id'] in conditional_ids:
                        if tipo_actual=='Estados de cuenta':hidden.update({'fecha_desde','fecha_hasta'})
                        else:hidden.update({'mes_referencia','anio_referencia'})
                    visible_fields=[f for f in visible_fields if f['name'] not in hidden]
                    if test['id'] in (21,22,23):
                        visible_fields=[]
                    if test['id'] in (1,4,13,25,84,89,95,108,111,156): visible_fields=[]
                    for start_field in range(0,len(visible_fields),2):
                        cols=st.columns(2)
                        for offset,field in enumerate(visible_fields[start_field:start_field+2]):
                            with cols[offset]:
                                row[field['name']]=(st.selectbox(field['label'],field['options'],key=f"f_{test['id']}_{seq}_{field['name']}") if field.get('type')=='combo' and field.get('options') else (st.date_input(field['label'],format='DD/MM/YYYY',key=f"f_{test['id']}_{seq}_{field['name']}").strftime('%d/%m/%Y') if field.get('type')=='date' else (st.number_input(field['label'],min_value=int(field.get('min',1)),max_value=int(field.get('max',10)),value=int(field.get('default',1)),step=1,key=f"f_{test['id']}_{seq}_{field['name']}") if field.get('type')=='number' else st.text_input(field['label'],key=f"f_{test['id']}_{seq}_{field['name']}"))))
                    if test['id'] in conditional_ids:
                        if tipo_actual=='Estados de cuenta':
                            row['fecha_desde']=None;row['fecha_hasta']=None
                        else:
                            row['mes_referencia']=None;row['anio_referencia']=None
                    if test['id']==16:
                        if row.get('perfil')=='Personalizado':
                            def v17(name):return bool(row.pop(name,False))
                            row['config']={'asistente_voz':v17('asistente_voz'),'accesos_directos':{'pagar_qr':v17('pagar_qr'),'cripto':v17('cripto'),'recarga':v17('recarga'),'cobrar_qr':v17('cobrar_qr'),'pagos':v17('pagos')},'navegacion':{'transferencias':v17('transferencias'),'pagos_servicios':v17('pagos_servicios')},'productos_mas':{'promociones':v17('promociones'),'limites':v17('limites'),'tarjetas':v17('tarjetas')}}
                        else:row['config']=None
                    if test['id']==-30:
                        help_map={
                            'Manual de usuario':('manual','manual'),
                            'Preguntas frecuentes':('preguntas','preguntas'),
                            'Consejos de seguridad':('consejos','consejos'),
                            'Política de privacidad':('privacidad','privacidad'),
                            'Reclamos':('reclamos','reclamos'),
                        }
                        selected=row.pop('ayuda_opcion',None)
                        if selected in help_map:row['texto_busqueda'],row['opcion']=help_map[selected]
                    if test['id']==-111:
                        # legacy disabled.
                        row['criterio']=''
                    rows.append(row)
            data[test['id']]=rows
        uploaded=True
    elif input_mode=="Masiva desde Excel":
        st.info("Descarga una sola hoja DATOS. Los flujos sin parámetros funcionales no generan filas innecesarias.")
        st.download_button("⬇ Descargar plantilla masiva",make(tests),"datos_suite.xlsx",use_container_width=True)
        uploaded=st.file_uploader("Cargar plantilla completada",type=["xlsx"])
        if uploaded:data=read(uploaded,tests);st.success("Plantilla cargada correctamente")
    else:st.caption("Selecciona una forma de ingreso para mostrar solo los controles necesarios.")
    if not appium():
        st.warning("Appium offline. Ejecute iniciar_appium.bat.")

    if st.button("▶ Iniciar ejecución", type="primary", use_container_width=True, disabled=not (device and uploaded and appium())):
        status = st.status("Ejecutando prueba...", expanded=True)
        lines: list[str] = []
        console = st.empty()

        def on_event(event) -> None:
            lines.append(f"{event.timestamp} | {event.level} | {event.step} | {event.message}")
            safe_text = html.escape("\n".join(lines[-80:]))
            console.markdown(f'<div class="live-console">{safe_text}</div>', unsafe_allow_html=True)

        result_objects, run_dir = Runner(ROOT, device["udid"]).run(tests, data, on_event, execution_mode=mode)
        results = [item.__dict__ for item in result_objects]
        st.session_state["results"] = results
        st.session_state["run"] = str(run_dir)
        status.update(label="Ejecución finalizada", state="complete", expanded=False)

        st.subheader("Resumen de la ejecución")
        consolidated=Path(run_dir)/"reporte_consolidado.docx"
        if consolidated.exists():st.download_button("⬇ Descargar reporte consolidado",consolidated.read_bytes(),file_name=consolidated.name,mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",use_container_width=True)
        render_artifacts(results, "actual")


@st.fragment
def render_history_downloads(report: Path | None, log: Path | None, key_prefix: str) -> None:
    """Download historical artifacts without a full-page rerun."""
    left, right = st.columns(2)
    if report and report.exists():
        left.download_button("▤", report.read_bytes(), report.name, key=f"{key_prefix}_report", help="Descargar informe Word", use_container_width=True)
    if log and log.exists():
        right.download_button("≡", log.read_bytes(), log.name, key=f"{key_prefix}_log", help="Descargar registro de ejecución", use_container_width=True)


def render_results() -> None:
    """Render a compact, paginated execution history with operational context."""
    hero("📈", "Resultados", "Histórico de ejecuciones con modalidad, dispositivo, fecha, duración, estado y evidencias.")
    runs = list_runs(settings(ROOT)["output_dir"])
    if not runs:
        st.info("Aún no existen ejecuciones almacenadas.")
        return

    page_size = 10
    total_pages = max(1, (len(runs) + page_size - 1) // page_size)
    page_col, info_col = st.columns([1, 5])
    page_no = page_col.number_input(
        "Página",
        min_value=1,
        max_value=total_pages,
        value=min(st.session_state.get("history_page", 1), total_pages),
        step=1,
    )
    st.session_state["history_page"] = page_no
    info_col.caption(
        f"{len(runs)} ejecuciones registradas · {page_size} por página · "
        f"página {page_no} de {total_pages}"
    )

    start_index = (page_no - 1) * page_size
    visible = runs[start_index : start_index + page_size]

    # Column header improves scanning when the execution history grows.
    h1, h2, h3, h4, h5, h6 = st.columns([1.45, 1.55, 1.45, 2.1, 1.15, 0.9])
    for column, title in zip(
        (h1, h2, h3, h4, h5, h6),
        ("Tipo de prueba", "Dispositivo", "Fecha", "Estado", "Duración", "Acción"),
    ):
        column.markdown(f'<div class="history-grid-head">{title}</div>', unsafe_allow_html=True)

    for index, (folder, meta) in enumerate(visible):
        global_index = start_index + index
        results = meta.get("resultados", [])
        successful = sum(1 for item in results if item.get("status") == "EXITOSO")
        failed = sum(1 for item in results if item.get("status") in ("FALLIDO", "BLOQUEADO"))
        pending = max(0, len(results) - successful - failed)

        if failed:
            state_label = "FALLIDO"
            state_icon = "■"
            state_class = "history-status-fail"
            row_class = "history-run failed"
        elif results and successful == len(results):
            state_label = "EXITOSO"
            state_icon = "●"
            state_class = "history-status-ok"
            row_class = "history-run ok"
        else:
            state_label = "CON OBSERVACIONES"
            state_icon = "◆"
            state_class = "history-status-warn"
            row_class = "history-run"

        execution_type = meta.get("modalidad") or "Histórico anterior"
        device_name = meta.get("dispositivo") or "No registrado"
        execution_date = str(meta.get("fecha") or folder.name).replace("T", " ")
        duration = format_seconds(meta.get("duracion_segundos", 0))

        c1, c2, c3, c4, c5, c6 = st.columns([1.45, 1.55, 1.45, 2.1, 1.15, 0.9])
        c1.markdown(f'<div class="history-run"><div class="history-value">{execution_type}</div></div>', unsafe_allow_html=True)
        c2.markdown(f'<div class="history-run"><div class="history-value">{device_name}</div></div>', unsafe_allow_html=True)
        c3.markdown(f'<div class="history-run"><div class="history-value">{execution_date}</div></div>', unsafe_allow_html=True)
        state_detail = f"{state_icon} {state_label} · {successful} OK · {failed} Fallos"
        if pending:
            state_detail += f" · {pending} Pend."
        c4.markdown(f'<div class="{row_class}"><div class="{state_class}">{state_detail}</div></div>', unsafe_allow_html=True)
        c5.markdown(f'<div class="history-run"><div class="history-value">{duration}</div></div>', unsafe_allow_html=True)
        if c6.button("Ver", key=f"history_detail_{global_index}", use_container_width=True):
            st.session_state["history_selected"] = str(folder)

        if st.session_state.get("history_selected") == str(folder):
            st.markdown("##### Detalle de la ejecución")
            st.caption(
                f"{execution_type} · {device_name} · {execution_date} · "
                f"{state_label} · {duration}"
            )
            if not results:
                st.caption("Ejecución antigua sin metadatos por prueba disponible.")

            for result_index, result in enumerate(results):
                status = result.get("status", "")
                status_icon = "●" if status == "EXITOSO" else "■" if status in ("FALLIDO", "BLOQUEADO") else "◆"
                name_col, status_col, time_col, report_col, log_col = st.columns([4, 1.1, 1.1, 0.7, 0.7])
                name_col.markdown(
                    f"**{status_icon} {int(result.get('test_id', 0)):03d} · "
                    f"{result.get('nombre_prueba') or result.get('name', '')}**<br>"
                    f"<small>{result.get('modulo', '')} · Registro {result.get('record', 1)}</small>",
                    unsafe_allow_html=True,
                )
                status_col.write(status)
                time_col.write("⏱ " + format_seconds(result.get("tiempo_segundos", 0)))

                report = Path(result["report"]) if result.get("report") else None
                log = Path(result["log"]) if result.get("log") else None
                with report_col:
                    render_history_downloads(report, None, f"hist_{global_index}_{result_index}_word")
                with log_col:
                    render_history_downloads(None, log, f"hist_{global_index}_{result_index}_log")

                with st.expander(
                    f"Detalle y capturas · {int(result.get('test_id', 0)):03d}"
                ):
                    st.write(result.get("detail", ""))
                    evidence = Path(result["evidence"]) if result.get("evidence") else None
                    shots = (
                        sorted((evidence / "screenshots").glob("*.png"))
                        if evidence and (evidence / "screenshots").exists()
                        else []
                    )
                    if shots:
                        for row_start in range(0, len(shots), 4):
                            columns = st.columns(4)
                            for offset, image in enumerate(shots[row_start : row_start + 4]):
                                with columns[offset]:
                                    st.image(str(image), caption=image.name, width=150)
                                    encoded = base64.b64encode(image.read_bytes()).decode("ascii")
                                    st.markdown(
                                        f'<a href="data:image/png;base64,{encoded}" target="_blank" '
                                        'style="display:block;text-align:center;padding:6px;'
                                        'border:1px solid #d7dde6;border-radius:7px;text-decoration:none;'
                                        'color:#24364b">Ver captura</a>',
                                        unsafe_allow_html=True,
                                    )

            if st.button("Cerrar detalle", key=f"close_{global_index}"):
                st.session_state.pop("history_selected", None)
                st.rerun()

        st.markdown(
            "<div style='border-top:1px solid #e4e9f0;margin:3px 0 4px'></div>",
            unsafe_allow_html=True,
        )


def render_admin_fields() -> None:
    hero("⚙", "Administración", "Gestiona campos permitidos y disponibilidad de flujos.")
    tab_fields,tab_flows=st.tabs(["Campos","Flujos activos"])
    with tab_fields:
        definition=load_fields(ROOT);admin_catalog=active_catalog(ROOT,CATALOG);test=st.selectbox("Flujo",admin_catalog,format_func=lambda x:f"{x['id']:03d} · {x['nombre']}",key="admin_flow");tid=str(test['id']);current=definition.get('tests',{}).get(tid,[]);edited=[]
        for start_i in range(0,len(current),2):
            cols=st.columns(2)
            for off,f in enumerate(current[start_i:start_i+2]):
                i=start_i+off
                with cols[off],st.container(border=True):
                    st.markdown(f"**{f.get('label',f['name'])}**");st.caption(f"`{f['name']}` · {'Obligatorio' if f.get('required') else 'Opcional'}")
                    enabled=True if f.get('required') else st.checkbox("Activo",f.get('enabled',True),key=f"ae_{tid}_{i}");label=st.text_input("Etiqueta",f.get('label',''),key=f"al_{tid}_{i}");kind=st.selectbox("Tipo",['text','combo','switch'],index=2 if f.get('type')=='switch' else (1 if f.get('type')=='combo' else 0),key=f"at_{tid}_{i}");opts=[]
                    if kind=='combo':opts=[x.strip() for x in st.text_input("Opciones",'|'.join(f.get('options',[])),key=f"ao_{tid}_{i}").split('|') if x.strip()]
                    edited.append(dict(f,label=label,type=kind,options=opts,enabled=enabled))
        if st.button("Guardar campos",type="primary"):definition.setdefault('tests',{})[tid]=edited;save_fields(ROOT,definition);st.rerun()
    with tab_flows:
        activation=reconcile_activation(ROOT,CATALOG);module=st.selectbox("Módulo",sorted({x['modulo'] for x in CATALOG}),key="activation_module")
        candidates=[x for x in CATALOG if x['modulo']==module]
        st.caption("Un flujo puede activarse cuando el Runner tiene una implementación ejecutable, ya sea integrada (como Login 002) o registrada en flow_registry.")
        for test in candidates:
            item=activation['flows'].setdefault(str(test['id']),{'active':False,'executable':False});disabled=not item.get('executable',False);item['active']=st.checkbox(f"{test['id']:03d} · {test['nombre']}",value=item.get('active',False) and not disabled,disabled=disabled,key=f"flowactive_{test['id']}",help="Sin implementación ejecutable asociada" if disabled else "Visible en selección de pruebas")
        if st.button("Guardar flujos activos",type="primary"):
            save_activation(ROOT,activation);st.success("Disponibilidad actualizada.");st.rerun()

configure_page()
with st.sidebar:
    st.markdown('<div style="font-size:31px;font-weight:900;letter-spacing:-1px;margin:4px 0 13px 5px;line-height:1"><span style="color:#ff2185">Banco</span> <span style="color:#ffffff">FIE</span></div><div style="height:1px;background:linear-gradient(90deg,#ffffff38,#ff2d8f99,#ffffff10);margin:0 2px 17px 2px"></div>', unsafe_allow_html=True)
    page = st.radio("Navegación", ["▦ Centro de control", "▶ Ejecutar pruebas", "▣ Laboratorio de dispositivos", "▤ Resultados", "⚙ Administrador de campos"], label_visibility="collapsed")
    st.markdown("---")
    st.caption(f"📚 {len(active_catalog(ROOT, CATALOG))} casos activos · 🧩 {len({x['modulo'] for x in active_catalog(ROOT,CATALOG)})} módulos")
    st.caption(f"{'🟢' if appium() else '🔴'} Appium · {'🟢' if adb() else '🔴'} ADB")

{
    "▦ Centro de control": render_home,
    "▶ Ejecutar pruebas": render_launch,
    "▣ Laboratorio de dispositivos": render_device_lab,
    "▤ Resultados": render_results,
    "⚙ Administrador de campos": render_admin_fields,
}[page]()
render_capture_modal_if_needed()

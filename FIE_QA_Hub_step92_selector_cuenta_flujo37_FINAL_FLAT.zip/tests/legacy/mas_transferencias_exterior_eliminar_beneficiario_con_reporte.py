"""
Flujo Transferencias al Exterior - Eliminar Beneficiario + reporte Word.
Pasos: Login → Más → Transferencias al exterior → Buscar beneficiario
       → Eliminar → Confirmar modal → Continuar (éxito) → Regresar
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import volver_atras_exterior

def click_mas_menu(driver):
    print('  📝 Click en menú Más...')
    wait = WebDriverWait(driver, 5)
    try:
        mas_btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'home_btn_mas')))
        mas_btn.click()
        print('  ✅ Click en Más (ID)')
        time.sleep(3)
        return True
    except:
        try:
            mas_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Más\nMás']")
            mas_btn.click()
            print('  ✅ Click en Más (content-desc)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Más: {e}')
            return False

def select_transferencias_exterior_mas(driver):
    print('  📝 Seleccionando Transferencias al exterior...')
    wait = WebDriverWait(driver, 5)
    try:
        btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'more_btn_transferenciasExterior')))
        btn.click()
        print('  ✅ Click en Transferencias al exterior (ID)')
        time.sleep(3)
        return True
    except:
        try:
            btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Transferencias al exterior')]")
            btn.click()
            print('  ✅ Click en Transferencias al exterior (content-desc)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al seleccionar Transferencias al exterior: {e}')
            return False

def buscar_beneficiario_exterior(driver, nombre_completo):
    print(f'  📝 Buscando beneficiario: {nombre_completo}...')
    wait = WebDriverWait(driver, 10)
    try:
        try:
            search_parent = wait.until(EC.presence_of_element_located((AppiumBy.ID, 'transfers_abroad_search_field')))
            try:
                search_input = search_parent.find_element(AppiumBy.XPATH, './/android.widget.EditText')
                search_input.click()
            except:
                search_parent.click()
        except:
            search_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='Buscar']")
            search_input.click()
            search_parent = search_input
        time.sleep(0.5)
        try:
            search_parent.clear()
        except:
            pass
        try:
            search_input.clear()
            search_input.send_keys(nombre_completo)
        except:
            search_parent.send_keys(nombre_completo)
        print(f'  ✅ Nombre de búsqueda ingresado: {nombre_completo}')
        try:
            driver.hide_keyboard()
        except:
            pass
        time.sleep(2)
        return True
    except Exception as e:
        print(f'  ❌ Error al buscar beneficiario: {e}')
        return False

def click_eliminar_beneficiario(driver, nombre_completo, timeout=15):
    print(f"  📝 Buscando card y click en 'Eliminar'...")
    wait = WebDriverWait(driver, timeout)
    try:
        card = wait.until(EC.presence_of_element_located((AppiumBy.XPATH, f"//android.widget.Button[contains(@resource-id, 'transfers_abroad_item_') and contains(@content-desc, '{nombre_completo}')]")))
        card_id = card.get_attribute('resource-id')
        print(f'  ✅ Card encontrada (id={card_id})')
    except Exception as e:
        print(f'  ❌ No se encontró la card: {e}')
        try:
            cards = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[contains(@resource-id, 'transfers_abroad_item_')]")
            print(f'  🔍 Beneficiarios disponibles: {len(cards)}')
            for c in cards:
                print(f"     - id={c.get_attribute('resource-id')} | desc={c.get_attribute('content-desc')[:80]!r}...")
        except:
            pass
        return False
    try:
        eliminar_btn = card.find_element(AppiumBy.XPATH, ".//android.widget.Button[@content-desc='Eliminar']")
        eliminar_btn.click()
        print("  ✅ Click en 'Eliminar'")
        time.sleep(2)
        return True
    except Exception as e:
        print(f"  ❌ Error al clickear 'Eliminar': {e}")
        return False

def confirmar_eliminar_beneficiario(driver, timeout=15):
    print('  📝 Confirmando eliminación en el modal...')
    wait = WebDriverWait(driver, timeout)
    try:
        confirmar = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//android.widget.FrameLayout[@pane-title='Alerta']//android.widget.Button[@content-desc='Eliminar']")))
        confirmar.click()
        print("  ✅ Click en 'Eliminar' (modal)")
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al confirmar eliminación: {e}')
        return False

def click_continuar_eliminar_exitoso(driver, timeout=15):
    print("  📝 Click en 'Continuar' (pantalla de éxito)...")
    wait = WebDriverWait(driver, timeout)
    try:
        continuar = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")))
        continuar.click()
        print("  ✅ Click en 'Continuar'")
        time.sleep(2)
        return True
    except Exception as e:
        print(f"  ❌ Error al clickear 'Continuar': {e}")
        return False

def eliminar_beneficiario_exterior(driver, nombre_completo_busqueda, tiempos=None, reporte=None, paso_inicial=6):
    print(f'\n🗑️  INICIANDO ELIMINACIÓN DE BENEFICIARIO')
    print(f'🔍 Buscando: {nombre_completo_busqueda}')
    print('=' * 60)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Ir a Más')
    if not click_mas_menu(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Menú Más abierto', "Se accedió al menú 'Más' desde la barra de navegación inferior.", espera=1.5)
    paso_num += 1
    tiempos.start('2. Transferencias al exterior')
    if not select_transferencias_exterior_mas(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla Transferencias al exterior', "Se accedió a la pantalla de 'Transferencias al exterior'. Se muestra la lista de beneficiarios y el campo de búsqueda.", espera=2.0)
    paso_num += 1
    print('  📝 Esperando carga de pantalla...')
    time.sleep(1)
    tiempos.start('3. Buscar beneficiario')
    if not buscar_beneficiario_exterior(driver, nombre_completo_busqueda):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f"Búsqueda: '{nombre_completo_busqueda}'", f"Se ingresó el nombre '{nombre_completo_busqueda}' en el campo de búsqueda de beneficiarios.", espera=1.5)
    paso_num += 1
    tiempos.start('4. Click en Eliminar')
    if not click_eliminar_beneficiario(driver, nombre_completo_busqueda):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, "Click en 'Eliminar'", f"Se hizo clic en el botón 'Eliminar' de la card del beneficiario '{nombre_completo_busqueda}'.", espera=1.5)
    paso_num += 1
    tiempos.start('5. Confirmar modal')
    if not confirmar_eliminar_beneficiario(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Modal de confirmación - Eliminar', 'Se confirmó la eliminación del beneficiario en el modal de alerta.', espera=1.5)
    paso_num += 1
    tiempos.start('6. Continuar (éxito)')
    if not click_continuar_eliminar_exitoso(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Modal de éxito - Beneficiario eliminado', f"Se mostró el modal de éxito confirmando que el beneficiario '{nombre_completo_busqueda}' fue eliminado correctamente.", espera=1.5)
    paso_num += 1
    tiempos.start('7. Volver atrás')
    if not volver_atras_exterior(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Regreso a pantalla anterior', 'Se regresó a la pantalla anterior (lista de beneficiarios).', espera=1.0)
    paso_num += 1
    print('\n✅ ELIMINACIÓN COMPLETADA EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('mas_transferencias_exterior_eliminar_beneficiario_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO: LOGIN + ELIMINAR BENEFICIARIO (TRANSFERENCIA EXTERIOR) + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    nombre_completo_busqueda = _input_cfg.get('nombre_completo_busqueda', 'Prueba1 Prueba2 Prueba3')
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Eliminar_Beneficiario_Transferencia_Exterior')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f'🗑️  Beneficiario a eliminar: {nombre_completo_busqueda}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Beneficiario eliminado': nombre_completo_busqueda})
    login_ok = _input_cfg.get('login_ok', False)
    eliminar_ok = _input_cfg.get('eliminar_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            eliminar_ok = eliminar_beneficiario_exterior(driver, nombre_completo_busqueda=nombre_completo_busqueda, tiempos=tiempos, reporte=reporte, paso_inicial=6)
            if eliminar_ok:
                print('\n🎉 ELIMINACIÓN COMPLETADA EXITOSAMENTE!')
            else:
                print('\n❌ ELIMINACIÓN FALLIDA')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and eliminar_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login    : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Eliminar : {('✅ OK' if eliminar_ok else '❌ FALLÓ')}")
        print(f'   Carpeta  : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

"""
Flujo Plan de pagos + reporte Word.
Pasos: Login → PRÉSTAMO → Plan de pagos → Verificar pantalla
       → Obtener datos → Scroll + detalles → Regresar → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import volver_atras_detalle__d2aa01012d as volver_atras_detalle, volver_home__ec69435608 as volver_home
from framework.common.ui_helpers import _esta_en_home as _esta_en_home, _seleccionar_opcion_case_insensitive__4318d7731b as _seleccionar_opcion_case_insensitive

def ir_a_prestamo(driver):
    print('  📝 Navegando a PRÉSTAMO...')
    time.sleep(3)
    texto_objetivo = 'PRÉSTAMO'
    texto_lower = texto_objetivo.lower()

    def _buscar_en_lista_actual():
        try:
            prestamo = driver.find_element(AppiumBy.XPATH, f"//android.view.View[@content-desc='{texto_objetivo}']")
            prestamo.click()
            print('  ✅ Click en PRÉSTAMO (content-desc exacto)')
            time.sleep(3)
            return True
        except:
            pass
        try:
            prestamo = driver.find_element(AppiumBy.XPATH, f"//*[contains(translate(@content-desc, 'ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÑ', 'abcdefghijklmnopqrstuvwxyzáéíóúñ'), '{texto_lower}') and @clickable='true']")
            prestamo.click()
            print('  ✅ Click en PRÉSTAMO (case-insensitive)')
            time.sleep(3)
            return True
        except:
            pass
        try:
            prestamo = driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{texto_objetivo}') and @clickable='true']")
            prestamo.click()
            print('  ✅ Click en PRÉSTAMO (texto)')
            time.sleep(3)
            return True
        except:
            pass
        try:
            prestamo = driver.find_element(AppiumBy.XPATH, f"//*[contains(translate(@text, 'ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÑ', 'abcdefghijklmnopqrstuvwxyzáéíóúñ'), '{texto_lower}') and @clickable='true']")
            prestamo.click()
            print('  ✅ Click en PRÉSTAMO (texto case-insensitive)')
            time.sleep(3)
            return True
        except:
            pass
        return False
    if _buscar_en_lista_actual():
        return True
    print('  🔄 Buscando con scroll incremental...')
    for intento in range(5):
        try:
            driver.swipe(500, 1200, 500, 400, 500)
            time.sleep(0.6)
            if _buscar_en_lista_actual():
                return True
        except:
            pass
    for intento in range(3):
        try:
            driver.swipe(500, 400, 500, 1200, 500)
            time.sleep(0.6)
            if _buscar_en_lista_actual():
                return True
        except:
            pass
    print('  ❌ Error al seleccionar PRÉSTAMO')
    try:
        opciones = driver.find_elements(AppiumBy.XPATH, "//*[@clickable='true' and @content-desc and string-length(@content-desc) > 3]")
        print(f'  🔍 Elementos visibles ({len(opciones)}):')
        for o in opciones[:10]:
            desc = (o.get_attribute('content-desc') or '').replace('\n', ' | ')
            if len(desc) < 80:
                print(f'     - {desc}')
    except:
        pass
    return False

def seleccionar_detalle_prestamo(driver):
    print("  📝 Seleccionando 'Plan de pagos'...")
    time.sleep(3)
    if _seleccionar_opcion_case_insensitive(driver, 'Plan de pagos', timeout=5):
        print("  ✅ Click en 'Plan de pagos'")
        time.sleep(3)
        return True
    print("  ❌ Error al seleccionar 'Plan de pagos'")
    try:
        opciones = driver.find_elements(AppiumBy.XPATH, "//*[@clickable='true' and @content-desc and string-length(@content-desc) > 3]")
        print(f'  🔍 Elementos visibles ({len(opciones)}):')
        for o in opciones[:10]:
            desc = (o.get_attribute('content-desc') or '').replace('\n', ' | ')
            if len(desc) < 80:
                print(f'     - {desc}')
    except:
        pass
    return False

def scroll_detalle_prestamo(driver, veces=1):
    print(f'  📝 Haciendo scroll hacia abajo ({veces} vez/veces)...')
    time.sleep(1)
    for i in range(veces):
        scrolleado = False
        try:
            driver.execute_script('mobile: scroll', {'direction': 'down'})
            print(f'  ✅ Scroll {i + 1} completado (mobile:scroll)')
            scrolleado = True
            time.sleep(1)
        except:
            pass
        if not scrolleado:
            try:
                driver.find_element(AppiumBy.ANDROID_UIAUTOMATOR, 'new UiScrollable(new UiSelector().scrollable(true)).scrollForward()')
                print(f'  ✅ Scroll {i + 1} completado (UiScrollable)')
                scrolleado = True
                time.sleep(1)
            except:
                pass
        if not scrolleado:
            try:
                driver.swipe(500, 1500, 500, 500, 500)
                print(f'  ✅ Scroll {i + 1} completado (swipe)')
                scrolleado = True
                time.sleep(1)
            except Exception as e:
                print(f'  ⚠️ Error en scroll {i + 1}: {e}')
                return False
    return True

def verificar_detalle_prestamo(driver):
    print('  📝 Verificando pantalla de detalle de préstamo...')
    time.sleep(1)
    try:
        driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Pago de crédito']")
        print("  ✅ Pantalla verificada (título 'Pago de crédito')")
        return True
    except:
        pass
    try:
        driver.find_element(AppiumBy.XPATH, "//*[contains(translate(@content-desc, 'ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÑ', 'abcdefghijklmnopqrstuvwxyzáéíóúñ'), 'pago de crédito')]")
        print('  ✅ Pantalla verificada (título case-insensitive)')
        return True
    except:
        pass
    try:
        driver.find_element(AppiumBy.ID, 'shared_card_account_product')
        print("  ✅ Pantalla verificada (tarjeta 'shared_card_account_product')")
        return True
    except:
        pass
    try:
        driver.find_element(AppiumBy.ID, 'shared_card_credit_summary')
        print("  ✅ Pantalla verificada (resumen 'shared_card_credit_summary')")
        return True
    except:
        pass
    try:
        driver.find_element(AppiumBy.ID, 'product_loan_detail_pay')
        print("  ✅ Pantalla verificada (botón 'product_loan_detail_pay')")
        return True
    except:
        pass
    print('  ❌ No se pudo verificar la pantalla de detalle')
    return False

def obtener_datos_prestamo(driver):
    print('\n  📋 DATOS DEL PRÉSTAMO:')
    print('  ' + '-' * 50)
    campos_encontrados = 0
    try:
        tarjeta = driver.find_element(AppiumBy.ID, 'shared_card_account_product')
        desc = tarjeta.get_attribute('content-desc')
        if desc:
            print(f"  📌 Tarjeta: {desc.replace(chr(10), ' - ')}")
            campos_encontrados += 1
    except:
        pass
    try:
        resumen = driver.find_element(AppiumBy.ID, 'shared_card_credit_summary')
        desc = resumen.get_attribute('content-desc')
        if desc:
            lineas = desc.split(chr(10))
            print(f'  📊 Resumen ({len(lineas)} líneas):')
            for linea in lineas:
                print(f'     {linea}')
            campos_encontrados += 1
    except:
        pass
    try:
        pagar = driver.find_element(AppiumBy.ID, 'product_loan_detail_pay')
        desc = pagar.get_attribute('content-desc')
        if desc:
            print(f'  🔘 Botón: {desc}')
            campos_encontrados += 1
    except:
        pass
    print('  ' + '-' * 50)
    print(f'  ℹ️ Campos capturados: {campos_encontrados}')
    return campos_encontrados > 0

def scroll_y_mostrar_detalles(driver, scrolls=3):
    print('\n  📋 DETALLES ADICIONALES (con scroll):')
    print('  ' + '-' * 50)
    detalles_buscados = ['Día de pago', 'Estado', 'Tasa de interés corriente', 'Tasa de interés moratorio', 'Saldo capital', 'Fecha de desembolso', 'Número de operación', 'Plazo']
    encontrados = set()
    for intento in range(scrolls):
        for detalle in detalles_buscados:
            if detalle in encontrados:
                continue
            try:
                elemento = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{detalle}')]")
                desc = elemento.get_attribute('content-desc')
                if desc:
                    for linea in desc.split(chr(10)):
                        if detalle.lower() in linea.lower():
                            print(f'  📌 {linea.strip()}')
                            encontrados.add(detalle)
                            break
            except:
                pass
        if intento < scrolls - 1:
            scroll_detalle_prestamo(driver, veces=1)
    print('  ' + '-' * 50)
    print(f'  ℹ️ Detalles capturados: {len(encontrados)}/{len(detalles_buscados)}')
    if not encontrados:
        print('  ⚠️ No se capturó ningún detalle adicional')
        return False
    return True

def realizar_detalle_prestamo(driver, tiempos=None, reporte=None, paso_inicial=6):
    print('\n📋 INICIANDO DETALLE DE PRÉSTAMO')
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Ir a PRÉSTAMO')
    if not ir_a_prestamo(driver):
        print('  ❌ Error al ir a PRÉSTAMO')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla PRÉSTAMO', 'Se accedió a la sección de Préstamo desde el home.', espera=2.0)
    paso_num += 1
    tiempos.start('2. Plan de pagos')
    if not seleccionar_detalle_prestamo(driver):
        print('  ❌ Error al seleccionar Plan de pagos')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Opción Plan de pagos', "Se seleccionó la opción 'Plan de pagos'. Se abre la pantalla con la información del préstamo.", espera=2.0)
    paso_num += 1
    tiempos.start('3. Verificar pantalla')
    if not verificar_detalle_prestamo(driver):
        print('  ⚠️ No se pudo verificar la pantalla de detalle')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla de detalle verificada', "Se verificó la pantalla de detalle del préstamo (contiene tarjeta del préstamo, resumen y botón 'Pagar cuota').", espera=1.5)
    paso_num += 1
    tiempos.start('4. Datos del préstamo')
    if not obtener_datos_prestamo(driver):
        print('  ⚠️ Error al obtener datos del préstamo')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Datos del préstamo capturados', "Se capturaron los datos visibles del préstamo: tarjeta del préstamo, resumen con montos y botón 'Pagar cuota'.", espera=1.0)
    paso_num += 1
    tiempos.start('5. Scroll + detalles')
    if not scroll_y_mostrar_detalles(driver, scrolls=3):
        print('  ⚠️ Error al mostrar detalles adicionales')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Detalles adicionales (post-scroll)', 'Se hizo scroll para visualizar detalles adicionales del préstamo (día de pago, estado, tasas de interés, saldo capital, etc.).', espera=1.5)
    paso_num += 1
    tiempos.start('6. Volver atrás')
    if not volver_atras_detalle(driver):
        print('  ⚠️ Error al volver atrás')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Regreso a pantalla anterior', 'Se regresó a la pantalla anterior.', espera=1.0)
    paso_num += 1
    tiempos.start('7. Volver al home')
    if not volver_home(driver):
        print('  ⚠️ Error al volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Detalle Préstamo finalizado', 'Se regresó exitosamente al home. El flujo de detalle de préstamo ha terminado.', espera=1.5)
    paso_num += 1
    print('\n✅ DETALLE DE PRÉSTAMO COMPLETADO EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('pago_prestamo_detalle_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO COMPLETO: LOGIN + DETALLE DE PRÉSTAMO + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Detalle_Prestamo')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={})
    login_ok = _input_cfg.get('login_ok', False)
    detalle_ok = _input_cfg.get('detalle_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            detalle_ok = realizar_detalle_prestamo(driver, tiempos=tiempos, reporte=reporte, paso_inicial=6)
            if detalle_ok:
                print('\n🎉 DETALLE DE PRÉSTAMO EXITOSO!')
            else:
                print('\n❌ DETALLE DE PRÉSTAMO FALLIDO')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and detalle_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login          : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Detalle        : {('✅ OK' if detalle_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

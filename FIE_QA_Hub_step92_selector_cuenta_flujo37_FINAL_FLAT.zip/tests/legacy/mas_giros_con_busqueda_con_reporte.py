"""
Flujo Giros con búsqueda de beneficiario + reporte Word.
Pasos: Login → Más → Giros → Tipo identificación → Número → Buscar beneficiario
       → Cuenta origen → Monto → Departamento → Concepto → Origen/Destino fondos
       → Continuar → Confirmar → Éxito → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import volver_home_giro
from framework.common.ui_helpers import _ingresar_texto_en_campo as _ingresar_texto_en_campo, _esta_en_home as _esta_en_home

def click_mas_menu(driver, timeout=10):
    print('  📝 Click en menú Más...')
    wait = WebDriverWait(driver, 5)
    try:
        mas_btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'home_btn_mas')))
        mas_btn.click()
        print('  ✅ Click en Más (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        mas_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Más\nMás']")
        mas_btn.click()
        print('  ✅ Click en Más (content-desc)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al clickear Más: {e}')
        return False

def select_giros_mas(driver):
    print('  📝 Seleccionando Giros...')
    wait = WebDriverWait(driver, 5)
    try:
        driver.swipe(500, 1500, 500, 800, 500)
        time.sleep(1)
    except:
        pass
    try:
        giros_btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'more_btn_giros')))
        giros_btn.click()
        print('  ✅ Click en Giros (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        giros_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Giros')]")
        giros_btn.click()
        print('  ✅ Click en Giros (content-desc)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al seleccionar Giros: {e}')
        return False

def seleccionar_tipo_identificacion(driver, tipo_identificacion='Cedula de identidad', timeout=15):
    print(f'  📝 Seleccionando tipo de identificación: {tipo_identificacion}...')
    wait = WebDriverWait(driver, 5)
    try:
        selector = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'giros_select_tipo_identificacion')))
        selector.click()
        print('  ✅ Click en selector (ID)')
        time.sleep(2)
    except:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Tipo de identificación')]")
            selector.click()
            print('  ✅ Click en selector (content-desc)')
            time.sleep(2)
        except Exception as e:
            print(f'  ❌ Error al abrir selector: {e}')
            return False
    time.sleep(1)
    tipo_lower = tipo_identificacion.lower()
    try:
        opcion = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, f"//android.view.View[@content-desc='{tipo_identificacion}' and @clickable='true']")))
        opcion.click()
        print(f'  ✅ Tipo seleccionado (View exacto): {tipo_identificacion}')
        time.sleep(2)
        return True
    except:
        pass
    try:
        opcion = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{tipo_identificacion}') and @clickable='true']")
        opcion.click()
        print(f'  ✅ Tipo seleccionado (contains)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        opcion = driver.find_element(AppiumBy.XPATH, f"//*[contains(translate(@content-desc, 'ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÑ', 'abcdefghijklmnopqrstuvwxyzáéíóúñ'), '{tipo_lower}') and @clickable='true']")
        opcion.click()
        print(f'  ✅ Tipo seleccionado (case-insensitive)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        opcion = driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{tipo_identificacion}') and @clickable='true']")
        opcion.click()
        print(f'  ✅ Tipo seleccionado (texto)')
        time.sleep(2)
        return True
    except Exception as e:
        print(f'  ❌ Error al seleccionar tipo: {e}')
        try:
            opciones = driver.find_elements(AppiumBy.XPATH, "//*[@clickable='true' and @content-desc and string-length(@content-desc) > 3]")
            print(f'  🔍 Opciones visibles ({len(opciones)}):')
            for o in opciones[:15]:
                desc = (o.get_attribute('content-desc') or '').replace('\n', ' | ')
                if len(desc) < 80:
                    print(f'     - {desc}')
        except:
            pass
        return False

def ingresar_numero_identificacion(driver, numero_identificacion='6084670'):
    """Ingresa el número de identificación (múltiples estrategias)"""
    print(f'  📝 Ingresando número de identificación: {numero_identificacion}...')
    wait = WebDriverWait(driver, 5)
    edit_text = None
    try:
        input_field = wait.until(EC.presence_of_element_located((AppiumBy.ID, 'giros_input_identificacion')))
        try:
            edit_text = input_field.find_element(AppiumBy.CLASS_NAME, 'android.widget.EditText')
        except:
            edit_text = input_field
    except:
        pass
    if edit_text is None:
        try:
            edit_text = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@resource-id='giros_input_identificacion']/android.widget.EditText")
        except:
            pass
    if edit_text is None:
        try:
            edit_text = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[contains(@hint, 'número de identificación')]")
        except:
            pass
    if edit_text is None:
        print('  ❌ No se encontró el campo de identificación')
        return False
    try:
        edit_text.click()
        time.sleep(0.5)
        edit_text.clear()
        edit_text.send_keys(numero_identificacion)
        print(f'  ✅ Número de identificación ingresado: {numero_identificacion}')
        try:
            driver.hide_keyboard()
        except:
            pass
        time.sleep(0.5)
        return True
    except Exception as e:
        print(f'  ❌ Error al escribir: {e}')
        return False

def click_buscar_beneficiario(driver):
    print('  📝 Click en Buscar beneficiario...')
    wait = WebDriverWait(driver, 5)
    try:
        buscar_btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'giros_btn_buscar_beneficiario')))
        buscar_btn.click()
        print('  ✅ Click en Buscar beneficiario (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        buscar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Buscar beneficiario']")
        buscar_btn.click()
        print('  ✅ Click en Buscar beneficiario (content-desc)')
        time.sleep(3)
        return True
    except:
        try:
            buscar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Buscar beneficiario') and @clickable='true']")
            buscar_btn.click()
            print('  ✅ Click en Buscar beneficiario (texto)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al buscar beneficiario: {e}')
            return False

def esperar_datos_beneficiario(driver):
    """Espera a que se llenen los datos del beneficiario"""
    print('  📝 Esperando datos del beneficiario...')
    time.sleep(3)
    print('  ✅ Datos del beneficiario procesados')
    return True

def seleccionar_cuenta_origen(driver, numero_cuenta='40-0-2352481-5', timeout=15):
    print(f'  📝 Seleccionando cuenta de origen: {numero_cuenta}...')
    wait = WebDriverWait(driver, 5)
    try:
        driver.swipe(500, 1500, 500, 800, 500)
        time.sleep(1)
    except:
        pass
    try:
        selector = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'giros_select_cuenta_origen')))
        selector.click()
        print('  ✅ Click en selector (ID)')
        time.sleep(2)
    except:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='giros_select_cuenta_origen']")
            selector.click()
            print('  ✅ Click en selector (XPATH)')
            time.sleep(2)
        except:
            try:
                selector = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Selecciona una cuenta')]")
                selector.click()
                print('  ✅ Click en selector (content-desc)')
                time.sleep(2)
            except Exception as e:
                print(f'  ❌ Error al abrir selector: {e}')
                return False
    try:
        cuenta = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, f"//android.widget.Button[contains(@content-desc, '{numero_cuenta}')]")))
        cuenta.click()
        print(f'  ✅ Cuenta seleccionada (completa): {numero_cuenta}')
        time.sleep(2)
        return True
    except:
        pass
    try:
        ultimos = numero_cuenta.replace('-', '')[-6:]
        cuenta = driver.find_element(AppiumBy.XPATH, f"//android.widget.Button[contains(@content-desc, '{ultimos}')]")
        cuenta.click()
        print(f'  ✅ Cuenta seleccionada (últimos: {ultimos})')
        time.sleep(2)
        return True
    except:
        pass
    try:
        cuentas = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[contains(@resource-id, 'giros_select_cuenta_') or contains(@content-desc, 'CUENTA')]")
        if cuentas:
            cuentas[0].click()
            print(f'  ✅ Cuenta seleccionada (primera disponible)')
            time.sleep(2)
            return True
    except:
        pass
    print(f'  ❌ No se encontró cuenta: {numero_cuenta}')
    return False

def ingresar_monto_giro(driver, monto='1.00'):
    """Ingresa el monto del giro (múltiples estrategias)"""
    print(f'  📝 Ingresando monto: {monto}...')
    wait = WebDriverWait(driver, 4)
    try:
        driver.swipe(500, 1200, 500, 700, 500)
        time.sleep(1)
    except:
        pass
    edit_text = None
    try:
        edit_text = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@resource-id='giros_input_monto']/android.widget.EditText")
    except:
        pass
    if edit_text is None:
        try:
            edit_text = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='0.00' or contains(@hint, 'Monto')]")
        except:
            pass
    if edit_text is None:
        try:
            edit_text = driver.find_element(AppiumBy.ID, 'giros_input_monto')
        except:
            pass
    if edit_text is None:
        print(f'  ❌ No se encontró campo de monto')
        return False
    try:
        edit_text.click()
        time.sleep(0.5)
        edit_text.clear()
        edit_text.send_keys(monto)
        print(f'  ✅ Monto ingresado: {monto}')
        try:
            driver.hide_keyboard()
        except:
            pass
        time.sleep(0.5)
        return True
    except Exception as e:
        print(f'  ❌ Error: {e}')
        return False

def seleccionar_departamento(driver, departamento='La paz', timeout=15):
    """Selecciona el departamento (case-insensitive)"""
    print(f'  📝 Seleccionando departamento: {departamento}...')
    wait = WebDriverWait(driver, 3)
    try:
        driver.swipe(500, 1500, 500, 800, 500)
        time.sleep(1)
    except:
        pass
    try:
        selector = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//*[contains(@content-desc, 'Selecciona un departamento')]")))
        selector.click()
        print("  ✅ Click en selector (content-desc 'Selecciona')")
        time.sleep(2)
    except:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Departamento de destino')]")
            selector.click()
            print('  ✅ Click en selector (Departamento de destino)')
            time.sleep(2)
        except Exception as e:
            print(f'  ❌ Error al abrir selector: {e}')
            return False
    time.sleep(1)
    depto_lower = departamento.lower()
    try:
        opcion = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, f"//android.view.View[@content-desc='{departamento}' and @clickable='true']")))
        opcion.click()
        print(f'  ✅ Departamento seleccionado (exacto): {departamento}')
        time.sleep(2)
        return True
    except:
        pass
    try:
        opcion = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{departamento}') and @clickable='true']")
        opcion.click()
        print(f'  ✅ Departamento seleccionado (contains)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        opcion = driver.find_element(AppiumBy.XPATH, f"//*[contains(translate(@content-desc, 'ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÑ', 'abcdefghijklmnopqrstuvwxyzáéíóúñ'), '{depto_lower}') and @clickable='true']")
        opcion.click()
        print(f'  ✅ Departamento seleccionado (case-insensitive)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        opcion = driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{departamento}') and @clickable='true']")
        opcion.click()
        print(f'  ✅ Departamento seleccionado (texto)')
        time.sleep(2)
        return True
    except Exception as e:
        print(f'  ❌ Error al seleccionar departamento: {e}')
        return False

def ingresar_concepto(driver, concepto='PRUEBA 1'):
    """Ingresa el concepto del giro"""
    print(f'  📝 Ingresando concepto: {concepto}...')
    ok = _ingresar_texto_en_campo(driver, 'giros_input_concepto', concepto, hints_alternativos=['Concepto', 'concepto'])
    if ok:
        print(f'  ✅ Concepto ingresado: {concepto}')
    else:
        print(f'  ❌ Error al ingresar concepto')
    return ok

def ingresar_origen_fondos(driver, origen_fondos='PRUEBA 1'):
    """Ingresa el origen de fondos"""
    print(f'  📝 Ingresando origen de fondos: {origen_fondos}...')
    ok = _ingresar_texto_en_campo(driver, 'giros_input_origen_fondos', origen_fondos, hints_alternativos=['Origen de fondos', 'origen'])
    if ok:
        print(f'  ✅ Origen de fondos ingresado: {origen_fondos}')
    else:
        print(f'  ❌ Error al ingresar origen de fondos')
    return ok

def ingresar_destino_fondos(driver, destino_fondos='PRUEBA 1'):
    """Ingresa el destino de fondos"""
    print(f'  📝 Ingresando destino de fondos: {destino_fondos}...')
    ok = _ingresar_texto_en_campo(driver, 'giros_input_destino_fondos', destino_fondos, hints_alternativos=['Destino de fondos', 'destino'])
    if ok:
        print(f'  ✅ Destino de fondos ingresado: {destino_fondos}')
    else:
        print(f'  ❌ Error al ingresar destino de fondos')
    return ok

def click_continuar_giro(driver):
    print('  📝 Click en Continuar (giro)...')
    wait = WebDriverWait(driver, 5)
    try:
        continuar = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")))
        continuar.click()
        print('  ✅ Click en Continuar')
        time.sleep(3)
        return True
    except:
        try:
            continuar = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Continuar')]")
            continuar.click()
            print('  ✅ Click en Continuar (content-desc)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Continuar: {e}')
            return False

def click_confirmar_giro(driver, timeout=15):
    print('  📝 Click en Confirmar...')
    wait = WebDriverWait(driver, 15)
    try:
        confirmar = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'giros_btn_confirmar')))
        confirmar.click()
        print('  ✅ Click en Confirmar (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        confirmar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Confirmar']")
        confirmar.click()
        print('  ✅ Click en Confirmar (content-desc)')
        time.sleep(3)
        return True
    except:
        try:
            confirmar = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Confirmar') and @clickable='true']")
            confirmar.click()
            print('  ✅ Click en Confirmar (contains)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Confirmar: {e}')
            return False

def click_continuar_exito_giro(driver, timeout=10):
    print('  📝 Click en Continuar (éxito)...')
    wait = WebDriverWait(driver, 10)
    try:
        continuar = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'giros_btn_continuar_exito')))
        continuar.click()
        print('  ✅ Click en Continuar (éxito - ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        continuar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")
        continuar.click()
        print('  ✅ Click en Continuar (éxito - content-desc)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ⚠️ No se encontró botón Continuar (éxito): {e}')
        return False

def ingresar_datos_beneficiario(driver, nombre, apellido, apellido_casada='', direccion='', telefono=''):
    campos=[('giros_input_nombre',nombre),('giros_input_apellido',apellido)]
    for rid,val in campos:
        if val:
            e=driver.find_element(AppiumBy.ID,rid);e.click();e.clear();e.send_keys(str(val))
    if any([apellido_casada,direccion,telefono]):
        try: driver.find_element(AppiumBy.ID,'giros_accordion_datos_adicionales').click();time.sleep(1)
        except Exception: pass
        for rid,val in [('giros_input_apellido_casada',apellido_casada),('giros_input_direccion',direccion),('giros_input_telefono',telefono)]:
            if val:
                e=driver.find_element(AppiumBy.ID,rid);e.click();e.clear();e.send_keys(str(val))
    return True

def realizar_giro(driver, tipo_identificacion='Cedula de identidad', numero_identificacion='6084670', es_cliente=True, nombre='', apellido='', apellido_casada='', direccion='', telefono='', numero_cuenta='40-0-2352481-5', monto='1.00', departamento='LA PAZ', concepto='PRUEBA 1', origen_fondos='PRUEBA 1', destino_fondos='PRUEBA 1', clave_temporal='123456', tiempos=None, reporte=None, paso_inicial=6):
    print(f'\n💰 INICIANDO GIRO')
    print(f'📋 Tipo identificación: {tipo_identificacion}')
    print(f'📋 Número identificación: {numero_identificacion}')
    print(f'🏦 Cuenta origen: {numero_cuenta}')
    print(f'💰 Monto: {monto}')
    print(f'📍 Departamento: {departamento}')
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Ir a Más')
    if not click_mas_menu(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Menú Más abierto', "Se accedió al menú 'Más' desde la barra de navegación inferior.", espera=1.5)
    paso_num += 1
    tiempos.start('2. Giros')
    if not select_giros_mas(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla Giros', "Se accedió a la pantalla de 'Giros'. Se muestra el formulario para realizar un giro.", espera=2.0)
    paso_num += 1
    print('  📝 Esperando carga de pantalla de giros...')
    time.sleep(3)
    print('\n📝 PASO 3: Datos del Beneficiario')
    tiempos.start('3. Tipo identificación')
    if not seleccionar_tipo_identificacion(driver, tipo_identificacion):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Tipo identificación: {tipo_identificacion}', f"Se seleccionó el tipo de identificación: '{tipo_identificacion}'.", espera=1.5)
    paso_num += 1
    tiempos.start('4. Número identificación')
    if not ingresar_numero_identificacion(driver, numero_identificacion):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Número identificación: {numero_identificacion}', f'Se ingresó el número de identificación: {numero_identificacion}.', espera=1.0)
    paso_num += 1
    if es_cliente:
        tiempos.start('5. Buscar beneficiario cliente')
        if not click_buscar_beneficiario(driver): tiempos.stop(); return False
        tiempos.stop(); esperar_datos_beneficiario(driver)
        if reporte: reporte.capturar_paso(paso_num,'Beneficiario cliente encontrado',f'Se buscó el beneficiario {numero_identificacion}.',espera=1.5)
    else:
        tiempos.start('5. Registrar beneficiario no cliente')
        if not ingresar_datos_beneficiario(driver,nombre,apellido,apellido_casada,direccion,telefono): tiempos.stop(); return False
        tiempos.stop()
        if reporte: reporte.capturar_paso(paso_num,'Beneficiario no cliente','Se ingresaron los datos del beneficiario sin usar la lupa.',espera=1.5)
    paso_num += 1
    print('\n📝 PASO 4: Datos del Giro')
    tiempos.start('7. Cuenta origen')
    if not seleccionar_cuenta_origen(driver, numero_cuenta):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Cuenta origen: {numero_cuenta}', f'Se seleccionó la cuenta de origen: {numero_cuenta}.', espera=1.5)
    paso_num += 1
    tiempos.start('8. Monto')
    if not ingresar_monto_giro(driver, monto):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Monto: {monto}', f'Se ingresó el monto del giro: {monto}.', espera=1.0)
    paso_num += 1
    tiempos.start('9. Departamento')
    if not seleccionar_departamento(driver, departamento):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Departamento: {departamento}', f'Se seleccionó el departamento de destino: {departamento}.', espera=1.5)
    paso_num += 1
    tiempos.start('10. Concepto')
    if not ingresar_concepto(driver, concepto):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Concepto: {concepto}', f"Se ingresó el concepto del giro: '{concepto}'.", espera=1.0)
    paso_num += 1
    tiempos.start('11. Origen fondos')
    if not ingresar_origen_fondos(driver, origen_fondos):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Origen fondos: {origen_fondos}', f"Se ingresó el origen de fondos: '{origen_fondos}'.", espera=1.0)
    paso_num += 1
    tiempos.start('12. Destino fondos')
    if not ingresar_destino_fondos(driver, destino_fondos):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Destino fondos: {destino_fondos}', f"Se ingresó el destino de fondos: '{destino_fondos}'.", espera=1.0)
    paso_num += 1
    tiempos.start('13. Continuar')
    if not click_continuar_giro(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Continuar (datos completos)', 'Se hizo clic en Continuar. Se avanzó a la pantalla de verificación.', espera=1.5)
    paso_num += 1
    print('\n📝 PASO 5: Verificación')
    tiempos.start('14. Confirmar')
    if not click_confirmar_giro(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Confirmar giro', 'Se confirmó el giro en el modal de verificación.', espera=1.5)
    paso_num += 1
    print('\n📝 PASO 6: Finalizar')
    tiempos.start('15. Continuar (éxito)')
    if not click_continuar_exito_giro(driver):
        print('  ⚠️ Error al clickear Continuar (éxito)')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Modal de éxito - Giro realizado', f'Se mostró el modal de éxito confirmando que el giro por {monto} fue realizado correctamente.', espera=1.5)
    paso_num += 1
    tiempos.start('16. Volver al home')
    if not volver_home_giro(driver):
        print('  ⚠️ Error al volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Giro finalizado', 'Se regresó exitosamente al home. El flujo de giro ha terminado.', espera=1.5)
    paso_num += 1
    print('\n✅ GIRO COMPLETADO EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('mas_giros_con_busqueda_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO COMPLETO: LOGIN + GIROS + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    TIPO_IDENTIFICACION = _input_cfg.get('TIPO_IDENTIFICACION', 'Cedula de identidad')
    NUMERO_IDENTIFICACION = _input_cfg.get('NUMERO_IDENTIFICACION', '6084670')
    NUMERO_CUENTA = _input_cfg.get('NUMERO_CUENTA', '60-2-0006347-6')
    MONTO = _input_cfg.get('MONTO', '1.00')
    DEPARTAMENTO = _input_cfg.get('DEPARTAMENTO', 'La paz')
    CONCEPTO = _input_cfg.get('CONCEPTO', 'PRUEBA 1')
    ORIGEN_FONDOS = _input_cfg.get('ORIGEN_FONDOS', 'PRUEBA 1')
    DESTINO_FONDOS = _input_cfg.get('DESTINO_FONDOS', 'PRUEBA 1')
    CLAVE_TEMPORAL = _input_cfg.get('CLAVE_TEMPORAL', '123456')
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Giros_Busqueda_Beneficiario')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f'📋 Tipo identificación: {TIPO_IDENTIFICACION}')
    print(f'📋 Número identificación: {NUMERO_IDENTIFICACION}')
    print(f'🏦 Cuenta origen: {NUMERO_CUENTA}')
    print(f'💰 Monto: {MONTO}')
    print(f'📍 Departamento: {DEPARTAMENTO}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Tipo identificación': TIPO_IDENTIFICACION, 'Número identificación': NUMERO_IDENTIFICACION, 'Cuenta origen': NUMERO_CUENTA, 'Monto': MONTO, 'Departamento': DEPARTAMENTO, 'Concepto': CONCEPTO, 'Origen fondos': ORIGEN_FONDOS, 'Destino fondos': DESTINO_FONDOS})
    login_ok = _input_cfg.get('login_ok', False)
    giro_ok = _input_cfg.get('giro_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            giro_ok = realizar_giro(driver, tipo_identificacion=TIPO_IDENTIFICACION, numero_identificacion=NUMERO_IDENTIFICACION, numero_cuenta=NUMERO_CUENTA, monto=MONTO, departamento=DEPARTAMENTO, concepto=CONCEPTO, origen_fondos=ORIGEN_FONDOS, destino_fondos=DESTINO_FONDOS, clave_temporal=CLAVE_TEMPORAL, tiempos=tiempos, reporte=reporte, paso_inicial=6)
            if giro_ok:
                print('\n🎉 GIRO EXITOSO!')
            else:
                print('\n❌ GIRO FALLIDO')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and giro_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login          : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Giro           : {('✅ OK' if giro_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

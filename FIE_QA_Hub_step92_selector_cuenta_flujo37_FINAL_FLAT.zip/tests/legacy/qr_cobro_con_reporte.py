"""
Flujo Cobrar QR + reporte Word.
Pasos: Login → QR → Cobrar QR → Seleccionar cuenta → Monto + Concepto
       → Uso único → Fecha vencimiento → Continuar → Confirmar → QR generado → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import re
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import go_back_home_qr
from framework.common.ui_helpers import _esta_en_home as _esta_en_home

def click_qr_menu(driver, timeout=10):
    print('  📝 Click en menú QR...')
    wait_t = time.time() + timeout
    while time.time() < wait_t:
        try:
            qr_btn = driver.find_element(AppiumBy.ID, 'home_btn_qr')
            try:
                hijo = qr_btn.find_element(AppiumBy.XPATH, ".//android.widget.Button[@content-desc='QR']")
                hijo.click()
                print('  ✅ Click en QR (hijo de home_btn_qr)')
                time.sleep(3)
                return True
            except:
                qr_btn.click()
                print('  ✅ Click en QR (home_btn_qr)')
                time.sleep(3)
                return True
        except:
            time.sleep(0.5)
    try:
        qr_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='QR' and @clickable='true']")
        qr_btn.click()
        print('  ✅ Click en QR (content-desc clickable)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        qr_btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='QR' and @clickable='true']")
        qr_btn.click()
        print('  ✅ Click en QR (View clickable)')
        time.sleep(3)
        return True
    except:
        pass
    print('  ❌ Error al clickear QR')
    return False

def select_cobrar_qr(driver):
    print('  📝 Seleccionando Cobrar QR...')
    time.sleep(2)
    try:
        cobrar_btn = driver.find_element(AppiumBy.ID, 'qr_btn_cobrar')
        cobrar_btn.click()
        print('  ✅ Click en Cobrar QR (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        cobrar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Cobrar QR') and @clickable='true']")
        cobrar_btn.click()
        print('  ✅ Click en Cobrar QR (content-desc)')
        time.sleep(3)
        return True
    except:
        try:
            cobrar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Cobrar QR') and @clickable='true']")
            cobrar_btn.click()
            print('  ✅ Click en Cobrar QR (texto)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Cobrar QR: {e}')
            return False

def select_cuenta_qr(driver, numero_cuenta):
    print(f'  📝 Seleccionando cuenta...')
    time.sleep(3)
    cuenta_desc = None
    abierto = False
    try:
        driver.find_element(AppiumBy.ID, 'qr_select_cuenta').click()
        print('  ✅ Click en selector de cuentas (ID)')
        abierto = True
    except:
        pass
    if not abierto:
        try:
            driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Toca para cambiar']").click()
            print("  ✅ Click en 'Toca para cambiar'")
            abierto = True
        except:
            pass
    if not abierto:
        try:
            driver.find_element(AppiumBy.XPATH, "//*[@resource-id='qr_select_cuenta']").click()
            print('  ✅ Click en selector (resource-id XPATH)')
            abierto = True
        except:
            pass
    if not abierto:
        try:
            driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'CUENTA') and contains(@content-desc, 'Bs.')]").click()
            print('  ✅ Click en selector (por contenido)')
            abierto = True
        except:
            pass
    if not abierto:
        print('  ❌ Error al abrir selector de cuentas')
        return False
    time.sleep(2)
    seleccionado = False
    if numero_cuenta:
        sin_guiones = numero_cuenta.replace('-', '')
        try:
            btn = driver.find_element(AppiumBy.ID, f'qr_select_cuenta_{sin_guiones}')
            cuenta_desc = btn.get_attribute('content-desc') or numero_cuenta
            btn.click()
            print(f'  ✅ Cuenta seleccionada: {numero_cuenta} (ID)')
            seleccionado = True
        except:
            pass
        if not seleccionado:
            try:
                btn = driver.find_element(AppiumBy.XPATH, f"//android.widget.Button[contains(@content-desc, '{numero_cuenta}')]")
                cuenta_desc = btn.get_attribute('content-desc') or numero_cuenta
                btn.click()
                print(f'  ✅ Cuenta seleccionada: {numero_cuenta} (content-desc)')
                seleccionado = True
            except:
                pass
    if not seleccionado:
        try:
            btn = driver.find_element(AppiumBy.XPATH, f"//android.widget.Button[contains(@content-desc, '{tipo_cuenta}')]")
            cuenta_desc = btn.get_attribute('content-desc') or tipo_cuenta
            btn.click()
            print(f'  ✅ Cuenta seleccionada: {tipo_cuenta}')
            seleccionado = True
        except:
            pass
    if not seleccionado:
        try:
            cuentas = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[contains(@resource-id, 'qr_select_cuenta_')]")
            if cuentas:
                cuenta_desc = cuentas[0].get_attribute('content-desc') or 'primera'
                cuentas[0].click()
                print('  ✅ Primera cuenta seleccionada')
                seleccionado = True
        except:
            pass
    if not seleccionado:
        print('  ❌ Error al seleccionar cuenta')
        return False
    if cuenta_desc:
        driver._cuenta_seleccionada_desc = cuenta_desc
    time.sleep(2)
    return True

def toggle_uso_unico(driver, activar=True):
    print(f"  📝 Configurando 'Uso único': {('Activar' if activar else 'Desactivar')}...")
    time.sleep(2)
    try:
        switch = driver.find_element(AppiumBy.XPATH, "//android.widget.Switch[@content-desc='Uso único']")
        is_checked = switch.get_attribute('checked') == 'true'
        print(f"  🔄 Estado actual: {('Activado' if is_checked else 'Desactivado')}")
        if is_checked != activar:
            switch.click()
            print(f"  ✅ 'Uso único' {('activado' if activar else 'desactivado')}")
            time.sleep(1)
        else:
            print(f"  ℹ️ Ya está {('activado' if activar else 'desactivado')}")
        return True
    except:
        try:
            switch = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Uso único') and @clickable='true']")
            is_checked = switch.get_attribute('checked') == 'true'
            if is_checked != activar:
                switch.click()
                print(f"  ✅ 'Uso único' {('activado' if activar else 'desactivado')}")
                time.sleep(1)
            else:
                print(f"  ℹ️ Ya está {('activado' if activar else 'desactivado')}")
            return True
        except Exception as e:
            print(f'  ⚠️ No se encontró el Switch: {e}')
            return False

def select_fecha_qr(driver, fecha):
    print(f'  📝 Seleccionando fecha de vencimiento: {fecha}...')
    time.sleep(2)
    dia, mes, anio = fecha.split('/')
    dia_int = int(dia)
    mes_int = int(mes)
    anio_int = int(anio)
    meses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre']
    mes_nombre = meses[mes_int - 1]
    try:
        fecha_field = driver.find_element(AppiumBy.XPATH, "//android.view.View[contains(@text, '/') and string-length(@text) = 10]")
        fecha_field.click()
        print('  ✅ Click en campo de vencimiento')
        time.sleep(2)
    except:
        try:
            fecha_field = driver.find_element(AppiumBy.XPATH, "//android.view.View[@text and contains(@text, '/')]")
            fecha_field.click()
            print('  ✅ Click en campo de vencimiento (alternativo)')
            time.sleep(2)
        except Exception as e:
            print(f'  ❌ No se encontró el campo de vencimiento: {e}')
            return False
    time.sleep(3)

    def obtener_mes_actual():
        try:
            titulo = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Enero') or contains(@content-desc, 'Febrero') or contains(@content-desc, 'Marzo') or contains(@content-desc, 'Abril') or contains(@content-desc, 'Mayo') or contains(@content-desc, 'Junio') or contains(@content-desc, 'Julio') or contains(@content-desc, 'Agosto') or contains(@content-desc, 'Septiembre') or contains(@content-desc, 'Octubre') or contains(@content-desc, 'Noviembre') or contains(@content-desc, 'Diciembre')]")
            return titulo.get_attribute('content-desc') or ''
        except:
            return None
    encontrado = False
    for intento in range(24):
        titulo_actual = obtener_mes_actual()
        print(f'  📅 Mes actual: {titulo_actual}')
        if titulo_actual is None:
            print(f'  ⚠️ No se pudo obtener el mes actual, reintentando...')
            time.sleep(1)
            continue
        if titulo_actual and mes_nombre in titulo_actual and (str(anio_int) in titulo_actual):
            print(f'  ✅ Mes correcto: {mes_nombre} {anio_int}')
            encontrado = True
            break
        try:
            mes_actual = None
            for i, nombre_mes in enumerate(meses, 1):
                if nombre_mes in titulo_actual:
                    mes_actual = i
                    break
            anio_actual = None
            años = re.findall('\\d{4}', titulo_actual)
            if años:
                anio_actual = int(años[0])
            if mes_actual and anio_actual:
                diff_meses = (anio_int - anio_actual) * 12 + (mes_int - mes_actual)
                print(f'  📊 Diferencia de meses: {diff_meses}')
                if diff_meses > 0:
                    try:
                        siguiente_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Mes siguiente']")
                        siguiente_btn.click()
                        time.sleep(1)
                    except:
                        try:
                            siguiente_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@text='>']")
                            siguiente_btn.click()
                            time.sleep(1)
                        except:
                            print(f"  ⚠️ No se encontró el botón 'Mes siguiente'")
                            break
                elif diff_meses < 0:
                    try:
                        anterior_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Mes anterior']")
                        anterior_btn.click()
                        time.sleep(1)
                    except:
                        try:
                            anterior_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@text='<']")
                            anterior_btn.click()
                            time.sleep(1)
                        except:
                            print(f"  ⚠️ No se encontró el botón 'Mes anterior'")
                            break
                else:
                    encontrado = True
                    break
            else:
                print(f'  ⚠️ No se pudo determinar mes/año actual')
                break
        except Exception as e:
            print(f'  ⚠️ Error en navegación: {e}')
            break
    if not encontrado:
        print(f'  ❌ No se encontró el mes {mes_nombre} {anio_int}')
        try:
            driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Cancelar']").click()
            time.sleep(1)
        except:
            pass
        return False
    try:
        driver.swipe(500, 1500, 500, 600, 500)
        time.sleep(1)
    except:
        pass
    time.sleep(1)
    seleccionado = False
    estrategias = [lambda: driver.find_element(AppiumBy.XPATH, f"//android.view.View[@content-desc='{dia_int}' and @clickable='true']"), lambda: driver.find_element(AppiumBy.XPATH, f"//android.view.View[@text='{dia_int}' and @clickable='true']"), lambda: driver.find_element(AppiumBy.XPATH, f"//*[@content-desc='{dia_int}' and @clickable='true']"), lambda: driver.find_element(AppiumBy.XPATH, f"//*[@text='{dia_int}' and @clickable='true']"), lambda: driver.find_element(AppiumBy.XPATH, f"//android.view.View[contains(@content-desc, '{dia_int}') and @clickable='true']")]
    for i, estrategia in enumerate(estrategias, 1):
        try:
            dia_btn = estrategia()
            if dia_btn.is_displayed() and dia_btn.is_enabled():
                dia_btn.click()
                print(f'  ✅ Día {dia} seleccionado (estrategia {i})')
                seleccionado = True
                break
        except:
            pass
    if not seleccionado:
        try:
            dias = driver.find_elements(AppiumBy.XPATH, "//android.view.View[@clickable='true' and @content-desc and string-length(@content-desc) <= 2]")
            for d in dias:
                desc = d.get_attribute('content-desc') or ''
                if desc.isdigit() and int(desc) == dia_int:
                    d.click()
                    print(f'  ✅ Día {dia} seleccionado (búsqueda)')
                    seleccionado = True
                    break
        except:
            pass
    if not seleccionado:
        print(f'  ❌ No se pudo seleccionar el día {dia}')
        try:
            driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Cancelar']").click()
            time.sleep(1)
        except:
            pass
        return False
    time.sleep(1)
    try:
        aceptar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Aceptar']")
        if aceptar_btn.is_displayed() and aceptar_btn.is_enabled():
            aceptar_btn.click()
            print(f'  ✅ Fecha confirmada: {fecha}')
            time.sleep(2)
            return True
    except:
        try:
            aceptar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Aceptar') and @clickable='true']")
            aceptar_btn.click()
            print(f'  ✅ Fecha confirmada: {fecha} (texto)')
            time.sleep(2)
            return True
        except Exception as e:
            print(f'  ❌ No se encontró Aceptar: {e}')
            return False
    return False

def fill_qr_data(driver, monto='', concepto='PRUEBA', uso_unico=False, fecha_vencimiento=None):
    print(f'  📝 Ingresando datos del QR...')
    time.sleep(2)
    if monto:
        try:
            monto_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='0.00' or contains(@hint, 'Monto')]")
            monto_input.click()
            time.sleep(1)
            monto_input.clear()
            monto_input.send_keys(str(monto))
            print(f'  ✅ Monto ingresado: {monto}')
            try:
                driver.hide_keyboard()
                time.sleep(1)
            except:
                pass
        except:
            try:
                monto_input = driver.find_element(AppiumBy.ID, 'qr_input_monto')
                monto_input.click()
                time.sleep(1)
                monto_input.clear()
                monto_input.send_keys(str(monto))
                print(f'  ✅ Monto ingresado: {monto} (ID)')
                try:
                    driver.hide_keyboard()
                    time.sleep(1)
                except:
                    pass
            except Exception as e:
                print(f'  ⚠️ Error al ingresar monto: {e}')
    print(f'  📝 Ingresando concepto: {concepto}...')
    try:
        edit_text = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@resource-id='qr_input_concepto']/android.widget.EditText")
        edit_text.click()
        time.sleep(0.5)
        edit_text.clear()
        edit_text.send_keys(concepto)
        print(f'  ✅ Concepto ingresado: {concepto}')
        try:
            driver.hide_keyboard()
        except:
            pass
        time.sleep(0.5)
    except Exception as e:
        print(f'  ⚠️ Error XPATH concepto: {str(e)[:50]}')
    toggle_uso_unico(driver, uso_unico)
    if fecha_vencimiento:
        select_fecha_qr(driver, fecha_vencimiento)
    return True

def click_continuar_qr(driver):
    print('  📝 Click en Continuar...')
    time.sleep(2)
    try:
        continuar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")
        continuar_btn.click()
        print('  ✅ Click en Continuar')
        time.sleep(3)
        return True
    except:
        try:
            continuar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Continuar') and @clickable='true']")
            continuar_btn.click()
            print('  ✅ Click en Continuar (texto)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Continuar: {e}')
            return False

def click_confirmar_qr(driver):
    print('  📝 Click en Confirmar la transacción...')
    time.sleep(3)
    try:
        confirmar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Confirmar la transacción']")
        confirmar_btn.click()
        print('  ✅ Click en Confirmar la transacción')
        time.sleep(3)
        return True
    except:
        try:
            confirmar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Confirmar') and @clickable='true']")
            confirmar_btn.click()
            print('  ✅ Click en Confirmar (texto)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Confirmar: {e}')
            return False

def verify_qr_generated(driver):
    print('  📝 Verificando QR generado...')
    time.sleep(3)
    try:
        driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Comprobante') or contains(@content-desc, 'QR')]")
        print('  ✅ QR GENERADO EXITOSAMENTE!')
        return True
    except:
        try:
            driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Comprobante') or contains(@text, 'QR')]")
            print('  ✅ QR GENERADO EXITOSAMENTE!')
            return True
        except:
            print('  ⚠️ No se pudo verificar la generación del QR')
            return False

def realizar_qr(driver, numero_cuenta, monto='', concepto='PRUEBA', uso_unico=False, fecha_vencimiento=None, reporte=None, tiempos=None, paso_inicial=6):
    if fecha_vencimiento:
        v=str(fecha_vencimiento).strip().replace('-', '/');q=v.split('/')
        if len(q)==3:
            if len(q[0])==4:y,m,d=q
            else:d,m,y=q
            fecha_vencimiento=f'{int(d):02d}/{int(m):02d}/{int(y):04d}'
    print(f'\n📱 INICIANDO GENERACIÓN DE QR')
    print(f"💰 Monto: {(monto if monto else 'Opcional')}")
    print(f'📝 Concepto: {concepto}')
    print(f'🏦 Cuenta: {numero_cuenta}')
    print(f"🔒 Uso único: {('Sí' if uso_unico else 'No')}")
    print(f'📅 Vencimiento: {fecha_vencimiento}')
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Click en menú QR')
    if not click_qr_menu(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Menú QR abierto', 'Se accedió al menú QR desde el home.', espera=1.5)
    paso_num += 1
    tiempos.start('2. Cobrar QR')
    if not select_cobrar_qr(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla Cobrar QR', 'Se accedió a la pantalla de generación de QR de cobro. Se muestra el formulario con monto, concepto, cuenta, uso único y vencimiento.', espera=1.5)
    paso_num += 1
    tiempos.start('3. Seleccionar cuenta')
    if not select_cuenta_qr(driver, numero_cuenta):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        desc_cuenta = getattr(driver, '_cuenta_seleccionada_desc', '')
        if numero_cuenta:
            reporte.capturar_paso(paso_num, f"Cuenta '{numero_cuenta}' seleccionada", f"Se seleccionó la cuenta '{numero_cuenta}' para el cobro QR.", espera=1.5)
        else:
            reporte.capturar_paso(paso_num, 'Cuenta seleccionada', f"Se seleccionó la cuenta '{desc_cuenta[:100]}' para el cobro QR.", espera=1.5)
    paso_num += 1
    if monto:
        tiempos.start('4a. Monto')
        tiempos.stop()
    tiempos.start('4. Llenar datos QR')
    if not fill_qr_data(driver, monto, concepto, uso_unico, fecha_vencimiento):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Datos del QR completados', f"Se completaron los datos del QR: monto='{monto or 'opcional'}', concepto='{concepto}', uso único={('Sí' if uso_unico else 'No')}.", espera=1.5)
    paso_num += 1
    if fecha_vencimiento:
        if reporte:
            reporte.capturar_paso(paso_num, f'Fecha de vencimiento: {fecha_vencimiento}', f'Se seleccionó la fecha de vencimiento {fecha_vencimiento} en el calendario.', espera=1.0)
        paso_num += 1
    tiempos.start('5. Continuar')
    if not click_continuar_qr(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla de confirmación', 'Se avanzó a la pantalla de confirmación de la transacción QR.', espera=1.5)
    paso_num += 1
    tiempos.start('6. Confirmar transacción')
    if not click_confirmar_qr(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Transacción confirmada', 'Se confirmó la transacción. Se procesa la generación del QR.', espera=2.0)
    paso_num += 1
    tiempos.start('7. Verificar QR')
    success = verify_qr_generated(driver)
    tiempos.stop()
    if reporte:
        if success:
            reporte.capturar_paso(paso_num, 'QR generado exitosamente', f"El QR de cobro se generó correctamente. Monto: {monto or 'opcional'}, Concepto: {concepto}.", espera=2.0)
        else:
            reporte.capturar_paso(paso_num, 'QR generado (verificación no confirmada)', 'No se pudo verificar visualmente la generación del QR.', espera=1.5)
    paso_num += 1
    tiempos.start('8. Volver al home')
    go_back_home_qr(driver)
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Cobrar QR finalizado', 'Se regresó exitosamente al home. El flujo de generación de QR de cobro ha terminado.', espera=1.5)
    paso_num += 1
    if success:
        print('\n✅ QR GENERADO EXITOSAMENTE')
    else:
        print('\n⚠️ QR GENERADO (estado desconocido)')
    return success
if __name__ == '__main__':
    _input_cfg = load_input_defaults('qr_cobro_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO: LOGIN + GENERACIÓN QR + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    MONTO = _input_cfg.get('MONTO', '12')
    CONCEPTO = _input_cfg.get('CONCEPTO', 'PRUEBA QR')
    NUMERO_CUENTA = _input_cfg.get('NUMERO_CUENTA', '40-0-1189577-1')
    TIPO_CUENTA = _input_cfg.get('TIPO_CUENTA', 'CUENTA DE AHORROS')
    USO_UNICO = _input_cfg.get('USO_UNICO', False)
    FECHA_VENCIMIENTO = _input_cfg.get('FECHA_VENCIMIENTO', '18/09/2026')
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Cobrar_QR')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f"💰 Monto: {(MONTO if MONTO else 'Opcional')}")
    print(f'📝 Concepto: {CONCEPTO}')
    print(f'🏦 Cuenta: {(NUMERO_CUENTA if NUMERO_CUENTA else TIPO_CUENTA)}')
    print(f"🔒 Uso único: {('Sí' if USO_UNICO else 'No')}")
    print(f'📅 Vencimiento: {FECHA_VENCIMIENTO}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Monto': MONTO or '(opcional)', 'Concepto': CONCEPTO, 'Número de cuenta': NUMERO_CUENTA or '(no especificado)', 'Tipo de cuenta': TIPO_CUENTA, 'Uso único': 'Sí' if USO_UNICO else 'No', 'Fecha de vencimiento': FECHA_VENCIMIENTO})
    login_ok = _input_cfg.get('login_ok', False)
    qr_ok = _input_cfg.get('qr_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            qr_ok = realizar_qr(driver, monto=MONTO, concepto=CONCEPTO, numero_cuenta=NUMERO_CUENTA, tipo_cuenta=TIPO_CUENTA, uso_unico=USO_UNICO, fecha_vencimiento=FECHA_VENCIMIENTO, reporte=reporte, tiempos=tiempos, paso_inicial=6)
            if qr_ok:
                print('\n🎉 QR GENERADO EXITOSAMENTE!')
            else:
                print('\n❌ GENERACIÓN DE QR FALLIDA')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and qr_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login          : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Generar QR     : {('✅ OK' if qr_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

"""
Flujo Transferencia a Otros Bancos + reporte Word.
Pasos: Login → Transferir → Cuenta otros bancos → Cuenta origen
       → Monto → Concepto → Continuar → Confirmar → Scroll → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
import time
import re
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import go_back_home__c4c30af8eb as go_back_home
from framework.common.ui_helpers import _esta_en_home as _esta_en_home

def navigate_to_transfer(driver):
    print('  📝 Navegando a Transferencias...')
    time.sleep(2)
    try:
        transfer_btn = driver.find_element(AppiumBy.ID, 'home_btn_transferir')
        transfer_btn.click()
        print('  ✅ Click en Transferir (ID)')
        time.sleep(3)
        return True
    except:
        try:
            transfer_btn = driver.find_element(AppiumBy.ACCESSIBILITY_ID, 'Transferir')
            transfer_btn.click()
            print('  ✅ Click en Transferir (Accessibility)')
            time.sleep(3)
            return True
        except:
            try:
                transfer_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Transferir') or contains(@content-desc, 'Transferir')]")
                transfer_btn.click()
                print('  ✅ Click en Transferir (XPATH)')
                time.sleep(3)
                return True
            except Exception as e:
                print(f'  ❌ Error al navegar a transferencias: {e}')
                return False

def select_otros_bancos_account(driver, numero_cuenta, timeout=15, max_scrolls=14):
    """Contrae Propias/Terceros; deja Otros bancos abierto y busca destino con scroll lento."""
    import re
    objetivo = re.sub(r'\D','',str(numero_cuenta or ''))
    print(f'  📝 Cuenta otro banco destino: {numero_cuenta} -> {objetivo}')
    if not objetivo: return False

    # Sólo se permite contraer estos dos grupos. NUNCA se hace click en Otros bancos.
    for rid,label,xp_items in [
        ('transfers_btn_group_P','Cuentas propias',"//android.widget.Button[contains(@content-desc,'Banco FIE (Propia)')]"),
        ('transfers_btn_group_T','Cuentas terceros',"//android.widget.Button[contains(@content-desc,'Banco FIE') and not(contains(@content-desc,'(Propia)'))]")]:
        try:
            items=driver.find_elements(AppiumBy.XPATH,xp_items)
            grupos=driver.find_elements(AppiumBy.XPATH,f"//*[@resource-id='{rid}' or @content-desc='{label}']")
            if items and grupos:
                grupos[0].click(); time.sleep(.6); print(f'  ✅ {label} contraído')
        except Exception as e: print(f'  ⚠️ No se pudo contraer {label}: {e}')

    def buscar(etapa):
        candidatos=driver.find_elements(AppiumBy.XPATH,"//android.widget.Button[@clickable='true' and @content-desc]")
        print(f'  🔎 {etapa}: candidatos={len(candidatos)}')
        for pos,btn in enumerate(candidatos):
            try:
                desc=btn.get_attribute('content-desc') or ''
                if 'Banco FIE (Propia)' in desc: continue
                cuentas=re.findall(r'\d{2,}-\d+-\d{4,}-\d+',desc)
                # Algunos otros bancos usan número sin guiones (ej. 1041150404). Comparar también dígitos del descriptor.
                desc_digitos=re.sub(r'\D','',desc)
                normalizadas=[re.sub(r'\D','',c) for c in cuentas]
                if objetivo in normalizadas or objetivo in desc_digitos:
                    print(f"  🎯 Cuenta otro banco encontrada [{pos}]: {desc.replace(chr(10),' | ')[:200]}")
                    try: btn.click()
                    except Exception:
                        r=btn.rect; driver.execute_script('mobile: clickGesture',{'x':int(r['x']+r['width']/2),'y':int(r['y']+r['height']/2)})
                    driver._last_otro_banco_desc=desc; time.sleep(2); return True
            except Exception as e: print(f'  ⚠️ Candidato {pos}: {e}')
        return False

    # Buscar antes del primer desplazamiento.
    if buscar('antes del primer scroll'): return True

    # Scroll por coordenadas de pantalla: no depende de localizar ScrollView y no toca el header Otros bancos.
    for n in range(1,max_scrolls+1):
        try:
            size=driver.get_window_size(); x=int(size['width']*.5)
            y1=int(size['height']*.72); y2=int(size['height']*.52)
            print(f'  ↕️ Scroll lento {n}/{max_scrolls} (sin click en Otros bancos)')
            driver.swipe(x,y1,x,y2,900); time.sleep(.9)
        except Exception as e:
            print(f'  ⚠️ Falló swipe lento {n}: {e}')
            continue
        # Requisito: buscar inmediatamente después de CADA scroll.
        if buscar(f'después del scroll {n}'): return True

    print(f'  ❌ No se encontró cuenta destino otro banco {numero_cuenta}')
    return False

def select_source_account(driver, numero_cuenta, timeout=15):
    """Selecciona exclusivamente la cuenta origen dentro del modal ya abierto/abrible."""
    import re
    objetivo = re.sub(r'\D', '', str(numero_cuenta or ''))
    print(f'  📝 Seleccionando cuenta origen en modal: {numero_cuenta} -> {objetivo}')
    if not objetivo:
        print('  ❌ Número de cuenta origen vacío')
        return False

    def modal_abierto():
        try:
            return bool(driver.find_elements(AppiumBy.XPATH, "//*[@content-desc='Cuenta de origen']")) and bool(
                driver.find_elements(AppiumBy.XPATH, "//*[@content-desc='Selecciona la cuenta desde la que transferirás.']")
            )
        except Exception:
            return False

    # La pantalla previa tiene un Button cuyo content-desc inicia con 'Selecciona una cuenta'.
    # Solo abrirlo si el modal aún no está presente.
    if not modal_abierto():
        abiertos = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc,'Selecciona una cuenta') and @clickable='true']")
        if not abiertos:
            print('  ❌ No se encontró el selector que abre Cuenta de origen')
            return False
        try:
            abiertos[0].click()
        except Exception:
            r = abiertos[0].rect
            driver.execute_script('mobile: clickGesture', {'x':int(r['x']+r['width']/2),'y':int(r['y']+r['height']/2)})
        time.sleep(1.2)

    if not modal_abierto():
        print('  ❌ El modal Cuenta de origen no quedó visible')
        return False
    print('  ✅ Modal Cuenta de origen detectado')

    # Buscar SOLO dentro del modal: botones con descriptor de tipo de cuenta + número.
    candidatos = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[@clickable='true' and (contains(@content-desc,'CUENTA DE AHORROS') or contains(@content-desc,'CUENTA CORRIENTE'))]")
    print(f'  🔎 Opciones de cuenta origen encontradas: {len(candidatos)}')
    for pos, btn in enumerate(candidatos):
        try:
            desc = btn.get_attribute('content-desc') or ''
            cuentas = re.findall(r'\d{2}-\d-\d{7}-\d', desc)
            print(f"     [{pos}] {desc.replace(chr(10),' | ')}")
            for cuenta in cuentas:
                if re.sub(r'\D','',cuenta) == objetivo:
                    print(f'  🎯 Cuenta origen exacta encontrada: {cuenta}')
                    try:
                        btn.click()
                    except Exception:
                        r=btn.rect
                        driver.execute_script('mobile: clickGesture', {'x':int(r['x']+r['width']/2),'y':int(r['y']+r['height']/2)})
                    driver._last_origen_desc=desc
                    time.sleep(1.2)
                    print(f'  ✅ Cuenta origen seleccionada: {numero_cuenta}')
                    return True
        except Exception as e:
            print(f'  ⚠️ Error leyendo opción origen {pos}: {e}')

    try:
        xml=driver.page_source or ''
        presentes=re.findall(r'\d{2}-\d-\d{7}-\d',xml)
        print(f'  ℹ️ Cuentas visibles en XML del modal: {presentes}')
    except Exception:
        pass
    print(f'  ❌ Cuenta origen {numero_cuenta} no disponible en el modal')
    return False

def enter_amount(driver, monto):
    print(f'  📝 Ingresando monto: {monto}')
    time.sleep(2)
    try:
        amount_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='0.00']")
        amount_input.click()
        time.sleep(1)
        amount_input.clear()
        amount_input.send_keys(str(monto))
        print('  ✅ Monto ingresado')
        try:
            driver.hide_keyboard()
            print('  ✅ Teclado ocultado')
            time.sleep(1)
        except:
            try:
                driver.execute_script('mobile: clickGesture', {'x': 540, 'y': 1500})
                time.sleep(1)
            except:
                pass
        return True
    except:
        try:
            amount_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='Monto']")
            amount_input.click()
            time.sleep(1)
            amount_input.clear()
            amount_input.send_keys(str(monto))
            print('  ✅ Monto ingresado (fallback)')
            try:
                driver.hide_keyboard()
                print('  ✅ Teclado ocultado')
                time.sleep(1)
            except:
                pass
            return True
        except Exception as e:
            print(f'  ❌ Error al ingresar monto: {e}')
            return False

def enter_concept(driver, concepto):
    """Ingresa concepto en el EditText cuyo hint actual es 'Concepto'."""
    print(f'  📝 Ingresando concepto: {concepto}')
    time.sleep(0.7)
    concept_input = None
    estrategias = [
        "//android.widget.EditText[@hint='Concepto']",
        "//android.widget.EditText[@hint='Detalle']",
        "//android.widget.EditText[contains(@hint,'Concepto') or contains(@hint,'Detalle')]",
        "//*[@class='android.widget.EditText' and (@hint='Concepto' or @hint='Detalle')]",
    ]
    for i, xp in enumerate(estrategias, 1):
        try:
            candidatos = driver.find_elements(AppiumBy.XPATH, xp)
            for campo in candidatos:
                if campo.is_displayed() and campo.is_enabled():
                    concept_input = campo
                    print(f'  ✅ Campo Concepto localizado (estrategia {i})')
                    break
            if concept_input:
                break
        except Exception as e:
            print(f'  ⚠️ Estrategia Concepto {i} falló: {e}')
    if concept_input is None:
        # Diagnóstico: listar EditText visibles e hints reales.
        try:
            edits=driver.find_elements(AppiumBy.CLASS_NAME,'android.widget.EditText')
            print(f'  🔎 EditText visibles: {len(edits)}')
            for pos,e in enumerate(edits):
                print(f"     [{pos}] hint={e.get_attribute('hint')} text={e.get_attribute('text')}")
        except Exception:
            pass
        print("  ❌ No se encontró EditText con hint='Concepto' o hint='Detalle'")
        return False
    try:
        concept_input.click(); time.sleep(.3)
        try: concept_input.clear()
        except Exception: pass
        concept_input.send_keys(str(concepto))
        time.sleep(.4)
        valor = concept_input.get_attribute('text') or ''
        print(f'  📝 Valor leído en Concepto: {valor}')
        # La app transforma el concepto a mayúsculas. Comparar sin distinguir mayúsculas/minúsculas
        # y nunca volver a escribir, para evitar duplicar el contenido.
        esperado = str(concepto).strip().casefold()
        actual = str(valor).strip().casefold()
        if actual != esperado:
            print(f'  ❌ Concepto no coincide. Esperado={concepto} Actual={valor}')
            return False
        print('  ✅ Concepto ingresado y verificado (comparación sin distinguir mayúsculas)')
    except Exception as e:
        print(f'  ❌ Error al escribir Concepto: {e}')
        return False
    try:
        driver.hide_keyboard(); time.sleep(.5)
    except Exception:
        try: driver.press_keycode(4); time.sleep(.5)
        except Exception: pass
    return True

def click_continuar_transfer(driver):
    print('  📝 Click en Continuar (transferencia)...')
    time.sleep(1)
    try:
        driver.hide_keyboard()
        time.sleep(1)
    except:
        pass
    try:
        continuar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")
        continuar_btn.click()
        print('  ✅ Click en Continuar')
        time.sleep(3)
        return True
    except:
        try:
            continuar_btn = driver.find_element(AppiumBy.ACCESSIBILITY_ID, 'Continuar')
            continuar_btn.click()
            print('  ✅ Click en Continuar (Accessibility)')
            time.sleep(3)
            return True
        except:
            print('  ❌ Error al clickear Continuar')
            return False

def click_confirmar(driver):
    print('  📝 Click en Confirmar...')
    time.sleep(1)
    try:
        confirmar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Confirmar')]")
        confirmar_btn.click()
        print('  ✅ Click en Confirmar')
        time.sleep(3)
        return True
    except:
        print('  ❌ Error al clickear Confirmar')
        return False

def verify_transfer_success(driver):
    print('  📝 Verificando transferencia...')
    time.sleep(3)
    try:
        driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Transferencia exitosa')]")
        print('  ✅ TRANSFERENCIA EXITOSA!')
        return True
    except:
        pass
    print('  ⚠️ No se pudo verificar el estado de la transferencia')
    return False

def scroll_movimientos(driver, scrolls=3):
    print(f'  📝 Haciendo scroll para ver movimientos...')
    time.sleep(2)
    for i in range(scrolls):
        try:
            driver.swipe(500, 1200, 500, 400, 500)
            time.sleep(1)
            print(f'  🔄 Scroll {i + 1}/{scrolls}')
        except:
            pass
    print('  ✅ Scroll completado')
    return True

def volver_comprobante_a_home(driver, timeout=15):
    """Secuencia real: Comprobante -> Nueva transferencia -> pantalla Transferir -> Inicio -> Home."""
    print("  🔄 Cerrando comprobante mediante 'Nueva transferencia'...")
    nueva = driver.find_elements(AppiumBy.ACCESSIBILITY_ID, 'Nueva transferencia')
    if not nueva:
        nueva = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Nueva transferencia' and @clickable='true']")
    if not nueva:
        print("  ❌ No se encontró 'Nueva transferencia' en el comprobante")
        return False
    try:
        nueva[0].click()
    except Exception:
        r=nueva[0].rect
        driver.execute_script('mobile: clickGesture', {'x':int(r['x']+r['width']/2),'y':int(r['y']+r['height']/2)})
    print("  ✅ Click en Nueva transferencia")
    time.sleep(2)

    # Ahora sí debe existir la barra inferior de navegación.
    for intento in range(1, 8):
        try:
            candidatos = driver.find_elements(AppiumBy.XPATH, "//*[@clickable='true' and contains(@content-desc,'Inicio')]")
            print(f'  🔎 Intento {intento}/7: candidatos Inicio={len(candidatos)}')
            for btn in candidatos:
                desc=(btn.get_attribute('content-desc') or '').replace('\r','')
                lineas=[x.strip() for x in desc.split('\n') if x.strip()]
                # Admite tanto Inicio como Inicio\nInicio, según la jerarquía expuesta por Appium.
                if not lineas or any(x != 'Inicio' for x in lineas):
                    continue
                print(f"  🎯 Botón Inicio localizado: {desc.replace(chr(10),' | ')}")
                try:
                    btn.click()
                except Exception:
                    r=btn.rect
                    driver.execute_script('mobile: clickGesture', {'x':int(r['x']+r['width']/2),'y':int(r['y']+r['height']/2)})
                time.sleep(2)
                # Confirmar que Transferir dejó de estar seleccionado.
                transfer=driver.find_elements(AppiumBy.ID,'home_btn_transferir')
                selected=(transfer[0].get_attribute('selected') or '').lower() if transfer else ''
                if selected != 'true':
                    print('  ✅ Regreso a Home confirmado')
                    return True
                print('  ⚠️ Inicio pulsado, pero Transferir sigue seleccionado')
        except Exception as e:
            print(f'  ⚠️ Error buscando Inicio: {e}')
        time.sleep(1)
    print('  ❌ No fue posible regresar a Home después de Nueva transferencia')
    return False

def realizar_transferencia_otros_bancos(driver, destino_numero_cuenta, origen_numero_cuenta, monto=1, concepto='Transferencia otro banco', tiempos=None, reporte=None, paso_inicial=6):
    if tiempos is None: tiempos=Tiempos()
    paso_num=paso_inicial
    tiempos.start('1. Navegar a Transferencias')
    if not navigate_to_transfer(driver): tiempos.stop(); return False
    tiempos.stop();paso_num+=1
    tiempos.start('2. Seleccionar cuenta otro banco destino')
    if not select_otros_bancos_account(driver,destino_numero_cuenta): tiempos.stop(); return False
    tiempos.stop();paso_num+=1
    tiempos.start('3. Seleccionar cuenta origen')
    if not select_source_account(driver,origen_numero_cuenta): tiempos.stop(); return False
    tiempos.stop();paso_num+=1
    tiempos.start('4. Ingresar monto')
    if not enter_amount(driver,monto): tiempos.stop(); return False
    tiempos.stop();paso_num+=1
    tiempos.start('5. Ingresar concepto')
    if not enter_concept(driver,concepto): tiempos.stop(); return False
    tiempos.stop();paso_num+=1
    tiempos.start('6. Continuar')
    if not click_continuar_transfer(driver): tiempos.stop(); return False
    tiempos.stop();paso_num+=1
    tiempos.start('7. Confirmar')
    if not click_confirmar(driver): tiempos.stop(); return False
    tiempos.stop();paso_num+=1
    tiempos.start('8. Verificar transferencia');success=verify_transfer_success(driver);tiempos.stop();paso_num+=1
    tiempos.start('9. Regresar a Home');home_ok=volver_comprobante_a_home(driver);tiempos.stop()
    if reporte and home_ok:reporte.capturar_paso(paso_num,'Home - Transferencia otro banco finalizada','Se pulsó Nueva transferencia y luego Inicio para regresar al Home.',espera=1.5)
    return bool(success and home_ok)

if __name__ == '__main__':
    _input_cfg = load_input_defaults('transfer_otros_bancos_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO COMPLETO: LOGIN + TRANSFERENCIA A OTROS BANCOS + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    monto = _input_cfg.get('monto', 1)
    concepto = _input_cfg.get('concepto', 'Transferencia a otro banco')
    DESTINO_NUMERO_CUENTA = _input_cfg.get('DESTINO_NUMERO_CUENTA', '10000012345680')
    DESTINO_NOMBRE = _input_cfg.get('DESTINO_NOMBRE', None)
    DESTINO_INDEX = _input_cfg.get('DESTINO_INDEX', 0)
    ORIGEN_NUMERO_CUENTA = _input_cfg.get('ORIGEN_NUMERO_CUENTA', None)
    ORIGEN_TIPO_CUENTA = _input_cfg.get('ORIGEN_TIPO_CUENTA', 'CUENTA DE AHORRO')
    ORIGEN_INDEX = _input_cfg.get('ORIGEN_INDEX', 0)
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Transferencia_Otros_Bancos')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f'💰 Monto: Bs. {monto}')
    print(f'📝 Concepto: {concepto}')
    print(f'🎯 Destino (otros bancos):')
    if DESTINO_NUMERO_CUENTA:
        print(f'     • Por número: {DESTINO_NUMERO_CUENTA}')
    elif DESTINO_NOMBRE:
        print(f'     • Por nombre: {DESTINO_NOMBRE}')
    else:
        print(f'     • Por índice: {DESTINO_INDEX}')
    print(f'🎯 Origen:')
    if ORIGEN_NUMERO_CUENTA:
        print(f'     • Por número: {ORIGEN_NUMERO_CUENTA}')
    elif ORIGEN_TIPO_CUENTA:
        print(f'     • Por tipo: {ORIGEN_TIPO_CUENTA}')
    else:
        print(f'     • Por índice: {ORIGEN_INDEX}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Monto': f'Bs. {monto}', 'Concepto': concepto, 'Destino - Número': DESTINO_NUMERO_CUENTA or 'N/A', 'Destino - Nombre': DESTINO_NOMBRE or 'N/A', 'Destino - Índice': DESTINO_INDEX, 'Origen - Número': ORIGEN_NUMERO_CUENTA or 'N/A', 'Origen - Tipo': ORIGEN_TIPO_CUENTA or 'N/A', 'Origen - Índice': ORIGEN_INDEX})
    login_ok = _input_cfg.get('login_ok', False)
    transfer_ok = _input_cfg.get('transfer_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            transfer_ok = realizar_transferencia_otros_bancos(driver, monto=monto, concepto=concepto, destino_nombre=DESTINO_NOMBRE, destino_numero_cuenta=DESTINO_NUMERO_CUENTA, destino_index=DESTINO_INDEX, origen_numero_cuenta=ORIGEN_NUMERO_CUENTA, origen_tipo_cuenta=ORIGEN_TIPO_CUENTA, origen_index=ORIGEN_INDEX, tiempos=tiempos, reporte=reporte, paso_inicial=6)
            if transfer_ok:
                print('\n🎉 TRANSFERENCIA A OTROS BANCOS EXITOSA!')
            else:
                print('\n❌ TRANSFERENCIA A OTROS BANCOS FALLIDA')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and transfer_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login          : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Transferencia  : {('✅ OK' if transfer_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

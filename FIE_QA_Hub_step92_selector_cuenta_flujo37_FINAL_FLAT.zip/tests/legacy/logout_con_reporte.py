"""
Flujo Login + Logout + reporte Word.
Pasos: Login → Home → Más → Cerrar sesión → Confirmar → Login
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login

def logout(driver, timeout=15, reporte=None, paso_inicial=6):
    print('\n🚪 Iniciando logout...')
    paso_num = paso_inicial
    try:
        print("  📝 Click en botón 'Más'...")
        mas_btn = WebDriverWait(driver, timeout).until(EC.element_to_be_clickable((AppiumBy.ID, 'home_btn_mas')))
        mas_btn.click()
        print("  ✅ Click en 'Más'")
    except:
        try:
            mas_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@resource-id='home_btn_mas']")
            mas_btn.click()
            print("  ✅ Click en 'Más' (XPATH)")
        except Exception as e:
            print(f"  ❌ No se pudo clickear 'Más': {e}")
            return False
    time.sleep(2)
    if reporte:
        reporte.capturar_paso(paso_num, 'Menú Más abierto', "Se accedió al menú 'Más' desde la barra de navegación inferior.", espera=1.5)
    paso_num += 1
    try:
        print("  📝 Click en 'Cerrar sesión'...")
        logout_btn = WebDriverWait(driver, timeout).until(EC.element_to_be_clickable((AppiumBy.ID, 'more_btn_sign_out')))
        logout_btn.click()
        print("  ✅ Click en 'Cerrar sesión'")
    except:
        try:
            logout_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@resource-id='more_btn_sign_out']")
            logout_btn.click()
            print("  ✅ Click en 'Cerrar sesión' (XPATH)")
        except Exception as e:
            print(f"  ❌ No se pudo clickear 'Cerrar sesión': {e}")
            return False
    time.sleep(2)
    if reporte:
        reporte.capturar_paso(paso_num, "Click en 'Cerrar sesión'", "Se hizo clic en la opción 'Cerrar sesión' del menú Más. Se abre el modal de confirmación.", espera=1.5)
    paso_num += 1
    try:
        print("  📝 Confirmando con 'Continuar'...")
        continuar_btn = WebDriverWait(driver, timeout).until(EC.element_to_be_clickable((AppiumBy.XPATH, "//android.widget.FrameLayout[@pane-title='Alerta']//android.widget.Button[@content-desc='Continuar']")))
        continuar_btn.click()
        print("  ✅ Click en 'Continuar' (modal Alerta)")
    except:
        try:
            botones = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")
            if botones:
                botones[-1].click()
                print("  ✅ Click en 'Continuar' (último botón)")
            else:
                raise Exception("No se encontró ningún botón 'Continuar'")
        except Exception as e:
            print(f'  ❌ No se pudo confirmar logout: {e}')
            return False
    time.sleep(3)
    if reporte:
        reporte.capturar_paso(paso_num, 'Modal de confirmación - Cerrar sesión', 'Se confirmó el cierre de sesión en el modal de alerta. Se está procesando el logout.', espera=1.5)
    paso_num += 1
    logout_ok = False
    try:
        print('  📝 Verificando logout...')
        driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='Usuario']")
        print('  ✅ LOGOUT EXITOSO!')
        logout_ok = True
    except:
        try:
            driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Iniciar sesión') or contains(@text, 'Iniciar sesión')]")
            print('  ✅ LOGOUT EXITOSO!')
            logout_ok = True
        except:
            print('  ⚠️ Logout ejecutado, pero no se pudo verificar la pantalla de login')
            logout_ok = True
    if reporte and logout_ok:
        reporte.capturar_paso(paso_num, 'Pantalla de Login - Logout exitoso', 'Se verificó el cierre de sesión. La app regresó a la pantalla de inicio de sesión.', espera=1.5)
    paso_num += 1
    return logout_ok
if __name__ == '__main__':
    _input_cfg = load_input_defaults('logout_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO DE LOGIN + LOGOUT FIE PLUS + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    appium_port = _input_cfg.get('appium_port', 4723)
    username = _input_cfg.get('username', '67018956')
    password = _input_cfg.get('password', 'Abc#1234')
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Login_Logout_FIE')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Conectando a dispositivo: {device_id}')
    print(f'🔌 Puerto Appium: {appium_port}')
    print(f'👤 Usuario: {username}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id, appium_port)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={})
    login_ok = _input_cfg.get('login_ok', False)
    logout_ok = _input_cfg.get('logout_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            tiempos.start('B. Logout')
            logout_ok = logout(driver, reporte=reporte, paso_inicial=6)
            tiempos.stop()
            print(f"  ⏱️  Logout: {format_duration(tiempos.tiempos['B. Logout'])}")
            if logout_ok:
                print('\n✅ LOGOUT COMPLETADO EXITOSAMENTE')
            else:
                print('\n❌ LOGOUT FALLIDO')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and logout_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Logout: {('✅ OK' if logout_ok else '❌ FALLÓ')}")
        print(f'   Carpeta: {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

"""
Flujo Notificaciones (buzón, desde menú Más → Configuraciones → Notificaciones)
+ reporte Word.
Pasos: Login → Más → Configuraciones usuario → Notificaciones
       → Seleccionar notificación por título → Continuar detalle → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import volver_home_notificaciones__2241bc8732 as volver_home_notificaciones
from framework.common.ui_helpers import _esta_en_home as _esta_en_home, select_configuraciones_usuario

def click_mas_menu(driver):
    print('  📝 Click en menú Más...')
    time.sleep(2)
    try:
        mas_btn = driver.find_element(AppiumBy.ID, 'home_btn_mas')
        mas_btn.click()
        print('  ✅ Click en Más (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        mas_btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Más\nMás' and @clickable='true']")
        mas_btn.click()
        print('  ✅ Click en Más (content-desc exacto)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        mas_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Más') and @clickable='true']")
        mas_btn.click()
        print('  ✅ Click en Más (contains)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al clickear Más: {e}')
        return False

def select_notificaciones(driver):
    print('  📝 Seleccionando Notificaciones...')
    time.sleep(2)
    try:
        driver.swipe(500, 1500, 500, 800, 500)
        time.sleep(1)
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.ID, 'notifications_btn_buzon')
        btn.click()
        print('  ✅ Click en Notificaciones (ID: notifications_btn_buzon)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Notificaciones') and @clickable='true']")
        btn.click()
        print('  ✅ Click en Notificaciones (content-desc)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Notificaciones') and @clickable='true']")
        btn.click()
        print('  ✅ Click en Notificaciones (texto)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Mensajes') and @clickable='true']")
        btn.click()
        print('  ✅ Click en Notificaciones (Mensajes)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al seleccionar Notificaciones: {e}')
        return False

def select_notificacion_by_titulo(driver, titulo_busqueda, timeout=15):
    print(f"  📝 Buscando notificación: '{titulo_busqueda}'...")
    time.sleep(2)
    if not titulo_busqueda:
        print('  ❌ Título vacío')
        return False
    titulo_lower = titulo_busqueda.lower()
    desc_notif_encontrada = None

    def buscar():
        nonlocal desc_notif_encontrada
        try:
            notificacion = driver.find_element(AppiumBy.XPATH, f"//android.widget.Button[contains(@content-desc, '{titulo_busqueda}') and @clickable='true']")
            desc_notif_encontrada = notificacion.get_attribute('content-desc')
            notificacion.click()
            print(f'  ✅ Notificación seleccionada (content-desc)')
            time.sleep(3)
            return True
        except:
            pass
        try:
            notificaciones = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[contains(@resource-id, 'notifications_btn_detalle_')]")
            for notif in notificaciones:
                desc = notif.get_attribute('content-desc') or ''
                if titulo_lower in desc.lower():
                    desc_notif_encontrada = desc
                    notif.click()
                    print(f'  ✅ Notificación seleccionada (iteración)')
                    time.sleep(3)
                    return True
        except:
            pass
        try:
            notificacion = driver.find_element(AppiumBy.XPATH, f"//*[contains(translate(@content-desc, 'ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÑ', 'abcdefghijklmnopqrstuvwxyzáéíóúñ'), '{titulo_lower}') and @clickable='true']")
            desc_notif_encontrada = notificacion.get_attribute('content-desc')
            notificacion.click()
            print(f'  ✅ Notificación seleccionada (case-insensitive)')
            time.sleep(3)
            return True
        except:
            pass
        try:
            notificacion = driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{titulo_busqueda}') and @clickable='true']")
            notificacion.click()
            print(f'  ✅ Notificación seleccionada (texto)')
            time.sleep(3)
            return True
        except:
            pass
        return False
    print('  🔍 Buscando sin scroll...')
    if buscar():
        driver._last_notif_desc = desc_notif_encontrada
        return True
    print('  🔄 Scroll hacia abajo...')
    for i in range(3):
        try:
            driver.swipe(500, 1500, 500, 600, 500)
            time.sleep(0.5)
            print(f'  🔍 Buscando después de scroll {i + 1}...')
            if buscar():
                driver._last_notif_desc = desc_notif_encontrada
                return True
        except:
            pass
    print('  🔄 Scroll hacia arriba...')
    for i in range(2):
        try:
            driver.swipe(500, 600, 500, 1500, 500)
            time.sleep(0.5)
            print(f'  🔍 Buscando después de scroll arriba {i + 1}...')
            if buscar():
                driver._last_notif_desc = desc_notif_encontrada
                return True
        except:
            pass
    print(f"  ❌ No se encontró notificación con: '{titulo_busqueda}'")
    try:
        notificaciones = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[contains(@resource-id, 'notifications_btn_detalle_')]")
        print(f'  🔍 Notificaciones visibles ({len(notificaciones)}):')
        for n in notificaciones[:10]:
            desc = (n.get_attribute('content-desc') or '').replace('\n', ' | ')
            print(f'     - {desc[:80]}')
    except:
        pass
    return False

def click_continuar_detalle(driver):
    print('  📝 Click en Continuar (detalle)...')
    time.sleep(3)
    try:
        btn = driver.find_element(AppiumBy.ID, 'notifications_btn_continuar_detalle')
        btn.click()
        print('  ✅ Click en Continuar (ID)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")
        btn.click()
        print('  ✅ Click en Continuar (content-desc)')
        time.sleep(2)
        return True
    except:
        try:
            btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Continuar') and @clickable='true']")
            btn.click()
            print('  ✅ Click en Continuar (texto)')
            time.sleep(2)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Continuar: {e}')
            return False

def realizar_notificaciones(driver, titulo_notificacion='Registro de dispositivo', reporte=None, tiempos=None, paso_inicial=6):
    print(f'\n📬 INICIANDO CONSULTA DE NOTIFICACIONES')
    print(f'📝 Título: {titulo_notificacion}')
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Ir a Más')
    if not click_mas_menu(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Menú Más abierto', "Se accedió al menú 'Más' desde la barra de navegación inferior.", espera=1.5)
    paso_num += 1
    tiempos.start('2. Config. usuario')
    if not select_configuraciones_usuario(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Configuraciones de usuario', 'Se accedió a las Configuraciones de usuario.', espera=1.5)
    paso_num += 1
    tiempos.start('3. Notificaciones')
    if not select_notificaciones(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla de Notificaciones (buzón)', 'Se accedió a la pantalla del buzón de Notificaciones. Se muestra la lista de notificaciones.', espera=2.0)
    paso_num += 1
    tiempos.start('4. Buscar notificación')
    if not select_notificacion_by_titulo(driver, titulo_notificacion):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        desc_notif = getattr(driver, '_last_notif_desc', '') or ''
        reporte.capturar_paso(paso_num, f"Notificación '{titulo_notificacion}' abierta", f"Se abrió la notificación con título '{titulo_notificacion}'. Detalle: {desc_notif[:120]}", espera=2.0)
    paso_num += 1
    tiempos.start('5. Continuar detalle')
    if not click_continuar_detalle(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Detalle de notificación confirmado', 'Se hizo clic en Continuar en el detalle de la notificación.', espera=1.5)
    paso_num += 1
    tiempos.start('6. Volver al home')
    if not volver_home_notificaciones(driver):
        print('  ⚠️ No se pudo volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Notificaciones finalizado', 'Se regresó exitosamente al home. La consulta de notificaciones ha terminado.', espera=1.5)
    paso_num += 1
    print('\n✅ CONSULTA DE NOTIFICACIONES COMPLETADA EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('login_notificaciones_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO: LOGIN + NOTIFICACIONES (buzón) + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    TITULO_NOTIFICACION = _input_cfg.get('TITULO_NOTIFICACION', 'Banco FIE: abono en su cuenta')
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Notificaciones_Buzon')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f'📝 Título: {TITULO_NOTIFICACION}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Título de notificación': TITULO_NOTIFICACION, 'Acceso': 'Menú Más → Configuraciones → Notificaciones (buzón)'})
    login_ok = _input_cfg.get('login_ok', False)
    notif_ok = _input_cfg.get('notif_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            notif_ok = realizar_notificaciones(driver, titulo_notificacion=TITULO_NOTIFICACION, reporte=reporte, tiempos=tiempos, paso_inicial=6)
            if notif_ok:
                print('\n🎉 CONSULTA DE NOTIFICACIONES EXITOSA!')
            else:
                print('\n❌ CONSULTA DE NOTIFICACIONES FALLIDA')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and notif_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login          : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Notificaciones : {('✅ OK' if notif_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

"""
Flujo ATM sin Tarjeta + reporte Word.
Pasos: Login → Más → ATM sin tarjeta → Obtener datos → Generar nueva clave
       → Aceptar modal → Volver → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import volver_atras__99669eabbe as volver_atras, volver_home__96ad0b4a5a as volver_home
from framework.common.ui_helpers import _esta_en_home as _esta_en_home

def click_mas_menu(driver, timeout=10):
    """Click en el menú Más del home"""
    print('  📝 Click en menú Más...')
    time.sleep(2)
    try:
        mas_btn = driver.find_element(AppiumBy.ID, 'home_btn_mas')
        mas_btn.click()
        print('  ✅ Click en Más (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        mas_btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Más\nMás' and @clickable='true']")
        mas_btn.click()
        print('  ✅ Click en Más (content-desc exacto)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        mas_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Más') and @clickable='true']")
        mas_btn.click()
        print('  ✅ Click en Más (content-desc contains)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al clickear Más: {e}')
        return False

def select_atm_sin_tarjeta_mas(driver):
    """Selecciona ATM sin tarjeta"""
    print('  📝 Seleccionando ATM sin tarjeta...')
    time.sleep(2)
    try:
        driver.swipe(500, 1500, 500, 800, 500)
        time.sleep(1)
    except:
        pass
    try:
        atm_btn = driver.find_element(AppiumBy.ID, 'more_btn_atmSinTarjeta')
        atm_btn.click()
        print('  ✅ Click en ATM sin tarjeta (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        atm_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Atm sin tarjeta')]")
        atm_btn.click()
        print('  ✅ Click en ATM sin tarjeta (content-desc)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        atm_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'ATM sin tarjeta')]")
        atm_btn.click()
        print('  ✅ Click en ATM sin tarjeta (ATM mayúsculas)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al seleccionar ATM sin tarjeta: {e}')
        return False

def obtener_datos_atm(driver, timeout=15):
    print('\n  📋 DATOS ATM SIN TARJETA:')
    print('  ' + '-' * 40)
    datos = {'carnet': None, 'clave_temporal': None, 'ok': False}
    try:
        ci = driver.find_element(AppiumBy.ID, 'cardless_txt_identification')
        texto = ci.get_attribute('content-desc') or ''
        if not texto:
            texto = ci.get_attribute('text') or ''
        if not texto:
            try:
                hijo = ci.find_element(AppiumBy.XPATH, './/*[@text]')
                texto = hijo.get_attribute('text') or ''
            except:
                pass
        if texto:
            datos['carnet'] = texto
            print(f'  📌 Carnet de identidad: {texto}')
        else:
            print('  ⚠️ No se pudo leer el carnet')
    except Exception as e:
        print(f'  ⚠️ Error al obtener carnet: {str(e)[:60]}')
    try:
        otp = driver.find_element(AppiumBy.ID, 'cardless_txt_otp')
        texto = otp.get_attribute('text') or ''
        if not texto:
            texto = otp.get_attribute('content-desc') or ''
        if not texto:
            try:
                hijo = otp.find_element(AppiumBy.XPATH, './/*[@text]')
                texto = hijo.get_attribute('text') or ''
            except:
                pass
        if texto:
            datos['clave_temporal'] = texto
            print(f'  📌 Clave temporal: {texto}')
        else:
            print('  ⚠️ No se pudo leer la clave temporal')
    except Exception as e:
        print(f'  ⚠️ Error al obtener clave temporal: {str(e)[:60]}')
    print('  ' + '-' * 40)
    if datos['carnet'] or datos['clave_temporal']:
        datos['ok'] = True
    return datos

def click_generar_nueva_clave(driver, timeout=15):
    """Click en 'Generar nueva clave'"""
    print("  📝 Click en 'Generar nueva clave'...")
    time.sleep(2)
    try:
        btn = driver.find_element(AppiumBy.ID, 'cardless_btn_refresh_otp')
        btn.click()
        print("  ✅ Click en 'Generar nueva clave' (ID)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='cardless_btn_refresh_otp']")
        btn.click()
        print("  ✅ Click en 'Generar nueva clave' (XPATH)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Generar nueva clave']")
        btn.click()
        print("  ✅ Click en 'Generar nueva clave' (content-desc)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Generar nueva clave') and @clickable='true']")
        btn.click()
        print("  ✅ Click en 'Generar nueva clave' (texto)")
        time.sleep(3)
        return True
    except Exception as e:
        print(f"  ❌ Error al clickear 'Generar nueva clave': {e}")
        return False

def verificar_modal_atm(driver, timeout=10):
    """Verifica que el modal de ATM esté visible"""
    print('  📝 Verificando modal de ATM...')
    time.sleep(2)
    titulos_posibles = ['Nueva clave temporal', 'Nueva clave', 'Clave temporal']
    for titulo in titulos_posibles:
        try:
            driver.find_element(AppiumBy.XPATH, f"//*[@content-desc='{titulo}']")
            print(f"  ✅ Modal de ATM visible ('{titulo}')")
            return True
        except:
            pass
        try:
            driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{titulo}')]")
            print(f"  ✅ Modal de ATM visible ('{titulo}' contains)")
            return True
        except:
            pass
        try:
            driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{titulo}')]")
            print(f"  ✅ Modal de ATM visible ('{titulo}' texto)")
            return True
        except:
            pass
    print('  ⚠️ No se pudo verificar el modal de ATM')
    return False

def click_aceptar_modal(driver, timeout=15):
    print('  📝 Click en Aceptar (modal)...')
    time.sleep(2)
    try:
        aceptar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Aceptar']")
        aceptar.click()
        print('  ✅ Click en Aceptar (Button content-desc)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        aceptar = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Aceptar') and @clickable='true']")
        aceptar.click()
        print('  ✅ Click en Aceptar (content-desc contains)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        aceptar = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Aceptar') and @clickable='true']")
        aceptar.click()
        print('  ✅ Click en Aceptar (texto)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        botones = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[@clickable='true']")
        if botones:
            botones[-1].click()
            print('  ✅ Click en último botón (Aceptar)')
            time.sleep(3)
            return True
    except Exception as e:
        print(f'  ❌ Error al clickear Aceptar: {e}')
        return False

def click_cancelar_modal(driver, timeout=10):
    """Click en Cancelar del modal (opcional)"""
    print('  📝 Click en Cancelar (modal)...')
    time.sleep(2)
    try:
        cancelar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Cancelar']")
        cancelar.click()
        print('  ✅ Click en Cancelar (content-desc)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        cancelar = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Cancelar') and @clickable='true']")
        cancelar.click()
        print('  ✅ Click en Cancelar (texto)')
        time.sleep(2)
        return True
    except Exception as e:
        print(f'  ⚠️ Error al clickear Cancelar: {e}')
        return False

def realizar_atm_sin_tarjeta(driver, tiempos=None, reporte=None, paso_inicial=6):
    """
    Realiza el flujo completo:
    Home → Menú Más → ATM sin tarjeta → Generar nueva clave → Aceptar → Volver
    """
    print(f'\n🏧 INICIANDO ATM SIN TARJETA')
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Ir a Más')
    if not click_mas_menu(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Menú Más abierto', "Se accedió al menú 'Más' desde la barra de navegación inferior.", espera=1.5)
    paso_num += 1
    tiempos.start('2. ATM sin tarjeta')
    if not select_atm_sin_tarjeta_mas(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla ATM sin tarjeta', "Se accedió a la pantalla 'ATM sin tarjeta'. Se muestran los datos de carnet de identidad y clave temporal.", espera=2.0)
    paso_num += 1
    print('  📝 Esperando carga de pantalla ATM...')
    time.sleep(3)
    tiempos.start('3. Obtener datos ATM')
    datos_actuales = obtener_datos_atm(driver)
    tiempos.stop()
    if reporte:
        desc_datos = []
        if datos_actuales.get('carnet'):
            desc_datos.append(f"Carnet: {datos_actuales['carnet']}")
        if datos_actuales.get('clave_temporal'):
            desc_datos.append(f"Clave temporal: {datos_actuales['clave_temporal']}")
        detalle = ' | '.join(desc_datos) if desc_datos else 'No se pudieron leer los datos'
        reporte.capturar_paso(paso_num, 'Datos ATM capturados', f'Se leyeron los datos actuales de la pantalla ATM sin tarjeta. {detalle}', espera=1.0)
    paso_num += 1
    tiempos.start('4. Generar nueva clave')
    if not click_generar_nueva_clave(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Generar nueva clave', "Se hizo clic en 'Generar nueva clave' para solicitar una nueva clave temporal de ATM sin tarjeta.", espera=1.5)
    paso_num += 1
    tiempos.start('5. Verificar modal')
    modal_ok = verificar_modal_atm(driver)
    if not modal_ok:
        print('  ⚠️ No se pudo verificar el modal, continuando...')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Modal de nueva clave temporal', f"Se mostró el modal de 'Nueva clave temporal'. Modal detectado: {('sí' if modal_ok else 'no verificado')}.", espera=1.0)
    paso_num += 1
    tiempos.start('6. Aceptar modal')
    if not click_aceptar_modal(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Modal aceptado - Nueva clave generada', 'Se confirmó el modal. La nueva clave temporal fue generada exitosamente.', espera=1.5)
    paso_num += 1
    tiempos.start('7. Volver atrás')
    if not volver_atras(driver):
        print('  ⚠️ Error al volver atrás')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Regreso a pantalla anterior', 'Se regresó a la pantalla anterior.', espera=1.0)
    paso_num += 1
    tiempos.start('8. Volver al home')
    if not volver_home(driver):
        print('  ⚠️ Error al volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo ATM sin Tarjeta finalizado', 'Se regresó exitosamente al home. El flujo de ATM sin tarjeta ha terminado.', espera=1.5)
    paso_num += 1
    if datos_actuales.get('ok'):
        print(f'\n  📊 Datos capturados:')
        if datos_actuales.get('carnet'):
            print(f"     • Carnet: {datos_actuales['carnet']}")
        if datos_actuales.get('clave_temporal'):
            print(f"     • Clave temporal: {datos_actuales['clave_temporal']}")
    print('\n✅ ATM SIN TARJETA COMPLETADO EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('login_atm_sin_tarjeta_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO COMPLETO: LOGIN + ATM SIN TARJETA + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'ATM_Sin_Tarjeta')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={})
    login_ok = _input_cfg.get('login_ok', False)
    atm_ok = _input_cfg.get('atm_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            atm_ok = realizar_atm_sin_tarjeta(driver, tiempos=tiempos, reporte=reporte, paso_inicial=6)
            if atm_ok:
                print('\n🎉 ATM SIN TARJETA EXITOSO!')
            else:
                print('\n❌ ATM SIN TARJETA FALLIDO')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and atm_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login          : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   ATM sin tarjeta: {('✅ OK' if atm_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

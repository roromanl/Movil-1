"""
Flujo Cuenta Principal QR + reporte Word.
Pasos: Login → Menú QR → Cuenta principal QR → Seleccionar cuenta →
       Confirmar cuenta → Modal confirmación → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import go_back_home_cuenta_principal
from framework.common.ui_helpers import _esta_en_home as _esta_en_home

def click_qr_menu(driver, timeout=10):
    print('  📝 Click en menú QR...')
    wait_t = time.time() + timeout
    while time.time() < wait_t:
        try:
            qr_btn = driver.find_element(AppiumBy.ID, 'home_btn_qr')
            try:
                hijo = qr_btn.find_element(AppiumBy.XPATH, ".//android.widget.Button[@content-desc='QR']")
                hijo.click()
                print('  ✅ Click en QR (hijo de home_btn_qr)')
                time.sleep(3)
                return True
            except:
                qr_btn.click()
                print('  ✅ Click en QR (home_btn_qr)')
                time.sleep(3)
                return True
        except:
            time.sleep(0.5)
    try:
        qr_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='QR' and @clickable='true']")
        qr_btn.click()
        print('  ✅ Click en QR (content-desc clickable)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        qr_btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='QR' and @clickable='true']")
        qr_btn.click()
        print('  ✅ Click en QR (View clickable)')
        time.sleep(3)
        return True
    except:
        pass
    print('  ❌ Error al clickear QR')
    return False

def select_cuenta_principal_qr(driver):
    print('  📝 Seleccionando Cuenta principal QR...')
    time.sleep(2)
    try:
        cuenta_btn = driver.find_element(AppiumBy.ID, 'qr_btn_cuenta_principal')
        cuenta_btn.click()
        print('  ✅ Click en Cuenta principal QR (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        cuenta_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Cuenta principal QR') and @clickable='true']")
        cuenta_btn.click()
        print('  ✅ Click en Cuenta principal QR (content-desc)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        cuenta_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Cuenta principal QR') and @clickable='true']")
        cuenta_btn.click()
        print('  ✅ Click en Cuenta principal QR (texto)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al clickear Cuenta principal QR: {e}')
        return False

def select_cuenta_no_seleccionada(driver, numero_cuenta=None):
    print('  📝 Seleccionando cuenta...')
    time.sleep(2)
    cuenta_seleccionada_desc = None
    if numero_cuenta:
        sin_guiones = numero_cuenta.replace('-', '')
        resource_id = f'qr_btn_cuenta_{sin_guiones}'
        print(f'  🔍 Buscando cuenta por resource-id: {resource_id}')
        try:
            cuenta_btn = driver.find_element(AppiumBy.ID, resource_id)
            cuenta_seleccionada_desc = cuenta_btn.get_attribute('content-desc') or numero_cuenta
            cuenta_btn.click()
            print(f'  ✅ Cuenta seleccionada: {numero_cuenta} (por ID)')
            time.sleep(2)
        except:
            try:
                cuenta_btn = driver.find_element(AppiumBy.XPATH, f"//android.widget.Button[contains(@content-desc, '{numero_cuenta}') and @clickable='true']")
                cuenta_seleccionada_desc = cuenta_btn.get_attribute('content-desc') or numero_cuenta
                cuenta_btn.click()
                print(f'  ✅ Cuenta seleccionada: {numero_cuenta} (content-desc)')
                time.sleep(2)
            except:
                try:
                    cuenta_btn = driver.find_element(AppiumBy.XPATH, f"//android.widget.Button[contains(@content-desc, '{sin_guiones}') and @clickable='true']")
                    cuenta_seleccionada_desc = cuenta_btn.get_attribute('content-desc') or numero_cuenta
                    cuenta_btn.click()
                    print(f'  ✅ Cuenta seleccionada: {numero_cuenta} (sin guiones)')
                    time.sleep(2)
                except Exception as e:
                    print(f'  ❌ Error al seleccionar cuenta: {e}')
                    return False
    else:
        try:
            cuentas = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[contains(@resource-id, 'qr_btn_cuenta_') and @clickable='true']")
            print(f'  🔍 Encontradas {len(cuentas)} cuentas')
            if len(cuentas) == 0:
                print('  ❌ No se encontraron cuentas')
                return False
            if len(cuentas) == 1:
                print('  ℹ️ Solo hay 1 cuenta, ya está seleccionada')
                cuenta_seleccionada_desc = cuentas[0].get_attribute('content-desc') or 'única'
                driver._cuenta_seleccionada_desc = cuenta_seleccionada_desc
            else:
                for i, cuenta in enumerate(cuentas):
                    desc = cuenta.get_attribute('content-desc') or ''
                    print(f'    Cuenta {i + 1}: {desc[:40]}...')
                ultima_cuenta = cuentas[-1]
                cuenta_seleccionada_desc = ultima_cuenta.get_attribute('content-desc') or 'última'
                print(f'  🔄 Seleccionando cuenta: {cuenta_seleccionada_desc[:40]}...')
                ultima_cuenta.click()
                time.sleep(2)
        except Exception as e:
            print(f'  ❌ Error al seleccionar cuenta: {e}')
            return False
    if cuenta_seleccionada_desc:
        driver._cuenta_seleccionada_desc = cuenta_seleccionada_desc
    print('  📝 Buscando botón Confirmar cuenta...')
    time.sleep(1)
    try:
        confirmar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Confirmar cuenta' and @clickable='true']")
        confirmar_btn.click()
        print('  ✅ Click en Confirmar cuenta (content-desc)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        view_container = driver.find_element(AppiumBy.ID, 'qr_btn_guardar_cuenta')
        confirmar_btn = view_container.find_element(AppiumBy.XPATH, ".//android.widget.Button[@content-desc='Confirmar cuenta']")
        confirmar_btn.click()
        print('  ✅ Click en Confirmar cuenta (dentro de qr_btn_guardar_cuenta)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        confirmar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Confirmar cuenta') and @clickable='true']")
        confirmar_btn.click()
        print('  ✅ Click en Confirmar cuenta (texto)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        confirmar_btn = driver.find_element(AppiumBy.XPATH, "//android.view.View[@resource-id='qr_btn_guardar_cuenta']//android.widget.Button")
        confirmar_btn.click()
        print('  ✅ Click en Confirmar cuenta (dentro del contenedor)')
        time.sleep(2)
        return True
    except Exception as e:
        print(f'  ❌ Error al clickear Confirmar cuenta: {e}')
        return False

def accept_modal_cuenta_principal(driver):
    print('  📝 Aceptando modal de confirmación...')
    time.sleep(3)
    modal_detectado = False
    try:
        driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Cuenta principal configurada correctamente')]")
        print('  ✅ Modal de confirmación detectado')
        modal_detectado = True
    except:
        try:
            driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Cuenta principal configurada correctamente')]")
            print('  ✅ Modal de confirmación detectado (texto)')
            modal_detectado = True
        except:
            print('  ⚠️ No se detectó modal de confirmación, continuando...')
            return True
    try:
        continuar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar' and @clickable='true']")
        continuar_btn.click()
        print('  ✅ Click en Continuar (modal)')
        time.sleep(2)
        return True
    except:
        try:
            continuar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Continuar') and @clickable='true']")
            continuar_btn.click()
            print('  ✅ Click en Continuar (modal - texto)')
            time.sleep(2)
            return True
        except Exception as e:
            print(f'  ⚠️ No se encontró botón Continuar: {e}')
            return False

def realizar_cuenta_principal_qr(driver, numero_cuenta=None, reporte=None, tiempos=None, paso_inicial=6):
    print(f'\n📱 INICIANDO CONFIGURACIÓN DE CUENTA PRINCIPAL QR')
    print(f"🏦 Cuenta: {(numero_cuenta if numero_cuenta else 'Última disponible')}")
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Click en menú QR')
    if not click_qr_menu(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Menú QR abierto', 'Se accedió al menú QR desde el home.', espera=1.5)
    paso_num += 1
    tiempos.start('2. Cuenta principal QR')
    if not select_cuenta_principal_qr(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla de Cuenta Principal QR', 'Se accedió a la pantalla de configuración de cuenta principal QR. Se muestra la lista de cuentas disponibles.', espera=1.5)
    paso_num += 1
    tiempos.start('3. Seleccionar cuenta y confirmar')
    if not select_cuenta_no_seleccionada(driver, numero_cuenta):
        print('  ⚠️ No se pudo seleccionar una cuenta')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        desc_cuenta = getattr(driver, '_cuenta_seleccionada_desc', '')
        if numero_cuenta:
            reporte.capturar_paso(paso_num, f"Cuenta '{numero_cuenta}' confirmada", f"Se seleccionó y confirmó la cuenta '{numero_cuenta}' como cuenta principal QR.", espera=1.5)
        else:
            reporte.capturar_paso(paso_num, 'Cuenta seleccionada y confirmada', f'Se seleccionó la última cuenta disponible como principal. Detalle: {desc_cuenta[:100]}', espera=1.5)
    paso_num += 1
    tiempos.start('4. Aceptar modal')
    accept_modal_cuenta_principal(driver)
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Modal de confirmación aceptado', "Se confirmó el modal 'Cuenta principal configurada correctamente'.", espera=1.5)
    paso_num += 1
    tiempos.start('5. Volver al home')
    if not go_back_home_cuenta_principal(driver):
        print('  ⚠️ No se pudo volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Cuenta Principal QR finalizado', 'Se regresó exitosamente al home. La cuenta principal QR ha sido configurada.', espera=1.5)
    paso_num += 1
    print('\n✅ CUENTA PRINCIPAL QR CONFIGURADA EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('qr_cuenta_principal_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO: LOGIN + CUENTA PRINCIPAL QR + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    NUMERO_CUENTA = _input_cfg.get('NUMERO_CUENTA', '40-2-1224601-1')
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Cuenta_Principal_QR')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f"🏦 Cuenta: {(NUMERO_CUENTA if NUMERO_CUENTA else 'Última disponible')}")
    print(f'📄 Nombre de la prueba: {NOMBRE_PRUEBA}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Cuenta parametrizada': NUMERO_CUENTA if NUMERO_CUENTA else '(última disponible)'})
    login_ok = _input_cfg.get('login_ok', False)
    cuenta_ok = _input_cfg.get('cuenta_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            cuenta_ok = realizar_cuenta_principal_qr(driver, numero_cuenta=NUMERO_CUENTA, reporte=reporte, tiempos=tiempos, paso_inicial=6)
            if cuenta_ok:
                print('\n🎉 CUENTA PRINCIPAL QR CONFIGURADA EXITOSAMENTE!')
            else:
                print('\n❌ CONFIGURACIÓN DE CUENTA PRINCIPAL QR FALLIDA')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and cuenta_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login              : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Cuenta principal QR: {('✅ OK' if cuenta_ok else '❌ FALLÓ')}")
        print(f'   Carpeta            : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

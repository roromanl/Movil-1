"""
Flujo Transferencias al Exterior (beneficiario existente) + reporte Word.
Pasos: Login → Más → Transferencias al exterior → Buscar beneficiario
       → Card beneficiario → Datos del giro → Términos → Confirmar → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import volver_home_exterior__1284b9fda1 as volver_home_exterior

def click_mas_menu(driver):
    print('  📝 Click en menú Más...')
    wait = WebDriverWait(driver, 5)
    try:
        mas_btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'home_btn_mas')))
        mas_btn.click()
        print('  ✅ Click en Más (ID)')
        time.sleep(3)
        return True
    except:
        try:
            mas_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Más\nMás']")
            mas_btn.click()
            print('  ✅ Click en Más (content-desc)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Más: {e}')
            return False

def select_transferencias_exterior_mas(driver):
    print('  📝 Seleccionando Transferencias al exterior...')
    wait = WebDriverWait(driver, 5)
    try:
        btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'more_btn_transferenciasExterior')))
        btn.click()
        print('  ✅ Click en Transferencias al exterior (ID)')
        time.sleep(3)
        return True
    except:
        try:
            btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Transferencias al exterior')]")
            btn.click()
            print('  ✅ Click en Transferencias al exterior (content-desc)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al seleccionar Transferencias al exterior: {e}')
            return False

def buscar_beneficiario_exterior(driver, nombre_completo):
    print(f'  📝 Buscando beneficiario: {nombre_completo}...')
    wait = WebDriverWait(driver, 10)
    try:
        try:
            search_parent = wait.until(EC.presence_of_element_located((AppiumBy.ID, 'transfers_abroad_search_field')))
            try:
                search_input = search_parent.find_element(AppiumBy.XPATH, './/android.widget.EditText')
                search_input.click()
            except:
                search_parent.click()
        except:
            search_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='Buscar']")
            search_input.click()
            search_parent = search_input
        time.sleep(0.5)
        try:
            search_parent.clear()
        except:
            pass
        try:
            search_input.clear()
            search_input.send_keys(nombre_completo)
        except:
            search_parent.send_keys(nombre_completo)
        print(f'  ✅ Nombre de búsqueda ingresado: {nombre_completo}')
        try:
            driver.hide_keyboard()
        except:
            pass
        time.sleep(2)
        return True
    except Exception as e:
        print(f'  ❌ Error al buscar beneficiario: {e}')
        return False

def click_beneficiario_card(driver, nombre_completo, timeout=15):
    print(f'  📝 Buscando card del beneficiario y click...')
    wait = WebDriverWait(driver, timeout)
    try:
        card = wait.until(EC.presence_of_element_located((AppiumBy.XPATH, f"//android.widget.Button[contains(@resource-id, 'transfers_abroad_item_') and contains(@content-desc, '{nombre_completo}')]")))
        card_id = card.get_attribute('resource-id')
        print(f'  ✅ Card encontrada (id={card_id})')
        card.click()
        print('  ✅ Click en la card del beneficiario')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ No se encontró la card: {e}')
        try:
            cards = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[contains(@resource-id, 'transfers_abroad_item_')]")
            print(f'  🔍 Beneficiarios disponibles: {len(cards)}')
            for c in cards:
                print(f"     - id={c.get_attribute('resource-id')} | desc={c.get_attribute('content-desc')[:80]!r}...")
        except:
            pass
        return False

def seleccionar_cuenta_origen_exterior(driver, numero_cuenta='40-0-2352481-5'):
    print(f'  📝 Seleccionando cuenta de origen: {numero_cuenta}...')
    wait = WebDriverWait(driver, 10)
    try:
        selector = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'transfers_abroad_select_cuenta_origen')))
        selector.click()
        print('  ✅ Click en selector de cuenta de origen')
        time.sleep(2)
    except:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Selecciona una cuenta')]")
            selector.click()
            print('  ✅ Click en selector de cuenta de origen (content-desc)')
            time.sleep(2)
        except Exception as e:
            print(f'  ❌ Error al abrir selector de cuenta: {e}')
            return False
    try:
        cuenta = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, f"//android.widget.Button[contains(@content-desc, '{numero_cuenta}')]")))
        cuenta.click()
        print(f'  ✅ Cuenta seleccionada: {numero_cuenta}')
        time.sleep(2)
        return True
    except:
        try:
            partes = numero_cuenta.split('-')
            if len(partes) >= 2:
                ultimo_segmento = partes[-1]
                cuenta = driver.find_element(AppiumBy.XPATH, f"//android.widget.Button[contains(@content-desc, '{ultimo_segmento}')]")
                cuenta.click()
                print(f'  ✅ Cuenta seleccionada por: {ultimo_segmento}')
                time.sleep(2)
                return True
        except:
            pass
        try:
            cuentas = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'CUENTA')]")
            if cuentas:
                cuentas[0].click()
                print('  ✅ Primera cuenta seleccionada')
                time.sleep(2)
                return True
        except:
            pass
        print(f'  ❌ Error al seleccionar cuenta: {numero_cuenta}')
        return False

def ingresar_monto_exterior(driver, monto='1.00'):
    print(f'  📝 Ingresando monto: {monto}...')
    wait = WebDriverWait(driver, 10)
    try:
        input_field = wait.until(EC.presence_of_element_located((AppiumBy.ID, 'transfers_abroad_input_monto')))
        try:
            edit_text = input_field.find_element(AppiumBy.CLASS_NAME, 'android.widget.EditText')
            edit_text.click()
        except:
            input_field.click()
        input_field.clear()
        input_field.send_keys(monto)
        print(f'  ✅ Monto ingresado: {monto}')
        try:
            driver.hide_keyboard()
        except:
            pass
        time.sleep(0.5)
        return True
    except:
        try:
            edit_text = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='0.00']")
            edit_text.click()
            edit_text.clear()
            edit_text.send_keys(monto)
            print(f'  ✅ Monto ingresado: {monto}')
            try:
                driver.hide_keyboard()
            except:
                pass
            time.sleep(0.5)
            return True
        except Exception as e:
            print(f'  ❌ Error al ingresar monto: {e}')
            return False

def ingresar_concepto_exterior(driver, concepto='PRUEBA'):
    print(f'  📝 Ingresando concepto: {concepto}...')
    wait = WebDriverWait(driver, 3)
    try:
        input_field = wait.until(EC.presence_of_element_located((AppiumBy.ID, 'transfers_abroad_input_concepto')))
        try:
            edit_text = input_field.find_element(AppiumBy.CLASS_NAME, 'android.widget.EditText')
            edit_text.click()
        except:
            input_field.click()
        input_field.clear()
        input_field.send_keys(concepto)
        print(f'  ✅ Concepto ingresado: {concepto}')
        try:
            driver.hide_keyboard()
        except:
            pass
        time.sleep(0.5)
        return True
    except:
        try:
            edit_text = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='Mín. 5 Caracteres']")
            edit_text.click()
            edit_text.clear()
            edit_text.send_keys(concepto)
            print(f'  ✅ Concepto ingresado: {concepto}')
            try:
                driver.hide_keyboard()
            except:
                pass
            time.sleep(0.5)
            return True
        except Exception as e:
            print(f'  ❌ Error al ingresar concepto: {e}')
            return False

def seleccionar_causa_asfi(driver, causa_asfi='Otras transferencias al exterior'):
    print(f'  📝 Seleccionando causa ASFI: {causa_asfi}...')
    wait = WebDriverWait(driver, 3)
    try:
        selector = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'transfers_abroad_select_asfi')))
        selector.click()
        print('  ✅ Click en selector de causa ASFI')
        time.sleep(2)
    except:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Selecciona una causa')]")
            selector.click()
            print('  ✅ Click en selector de causa ASFI (content-desc)')
            time.sleep(2)
        except Exception as e:
            print(f'  ❌ Error al abrir selector de causa ASFI: {e}')
            return False
    try:
        opcion = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, f"//android.view.View[@content-desc='{causa_asfi}']")))
        opcion.click()
        print(f'  ✅ Causa ASFI seleccionada: {causa_asfi}')
        time.sleep(2)
        return True
    except:
        try:
            opcion = driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{causa_asfi}')]")
            opcion.click()
            print(f'  ✅ Causa ASFI seleccionada: {causa_asfi}')
            time.sleep(2)
            return True
        except Exception as e:
            print(f'  ❌ Error al seleccionar causa ASFI: {e}')
            return False

def seleccionar_sucursal_exterior(driver, sucursal='La paz'):
    print(f'  📝 Seleccionando sucursal: {sucursal}...')
    wait = WebDriverWait(driver, 10)
    try:
        driver.swipe(500, 1500, 500, 800, 500)
        time.sleep(1)
    except:
        pass
    try:
        selector = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'transfers_abroad_select_sucursal')))
        selector.click()
        print('  ✅ Click en selector de sucursal')
        time.sleep(2)
    except:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Selecciona una sucursal')]")
            selector.click()
            print('  ✅ Click en selector de sucursal (content-desc)')
            time.sleep(2)
        except Exception as e:
            print(f'  ❌ Error al abrir selector de sucursal: {e}')
            return False
    try:
        opcion = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, f"//android.view.View[@content-desc='{sucursal}']")))
        opcion.click()
        print(f'  ✅ Sucursal seleccionada: {sucursal}')
        time.sleep(2)
        return True
    except:
        try:
            opcion = driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{sucursal}')]")
            opcion.click()
            print(f'  ✅ Sucursal seleccionada: {sucursal}')
            time.sleep(2)
            return True
        except Exception as e:
            print(f'  ❌ Error al seleccionar sucursal: {e}')
            return False

def seleccionar_agencia_exterior(driver, agencia='Agencia cala cala'):
    print(f'  📝 Seleccionando agencia: {agencia}...')
    wait = WebDriverWait(driver, 10)
    try:
        driver.swipe(500, 1500, 500, 800, 500)
        time.sleep(1)
    except:
        pass
    try:
        selector = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'transfers_abroad_select_agencia')))
        selector.click()
        print('  ✅ Click en selector de agencia')
        time.sleep(2)
    except:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Selecciona una agencia')]")
            selector.click()
            print('  ✅ Click en selector de agencia (content-desc)')
            time.sleep(2)
        except Exception as e:
            print(f'  ❌ Error al abrir selector de agencia: {e}')
            return False
    try:
        opcion = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, f"//android.view.View[@content-desc='{agencia}']")))
        opcion.click()
        print(f'  ✅ Agencia seleccionada: {agencia}')
        time.sleep(2)
        return True
    except:
        try:
            opcion = driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{agencia}')]")
            opcion.click()
            print(f'  ✅ Agencia seleccionada: {agencia}')
            time.sleep(2)
            return True
        except Exception as e:
            print(f'  ❌ Error al seleccionar agencia: {e}')
            return False

def ingresar_origen_fondos_exterior(driver, origen_fondos='PRUEBA DE ORIGEN'):
    print(f'  📝 Ingresando origen de fondos: {origen_fondos}...')
    try:
        edit_text = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@resource-id='transfers_abroad_input_origen_fondos']/android.widget.EditText")
        edit_text.click()
        time.sleep(0.5)
        edit_text.clear()
        edit_text.send_keys(origen_fondos)
        print(f'  ✅ Origen de fondos ingresado: {origen_fondos}')
        try:
            driver.hide_keyboard()
        except:
            pass
        time.sleep(0.5)
        return True
    except Exception as e:
        print(f'  ⚠️ Error XPATH origen de fondos: {str(e)[:50]}')
    return False

def ingresar_destino_fondos_exterior(driver, destino_fondos='PRUEBA FONDOS'):
    print(f'  📝 Ingresando destino de fondos: {destino_fondos}...')
    try:
        edit_text = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@resource-id='transfers_abroad_input_destino_fondos']/android.widget.EditText")
        edit_text.click()
        time.sleep(0.5)
        edit_text.clear()
        edit_text.send_keys(destino_fondos)
        print(f'  ✅ Destino de fondos ingresado: {destino_fondos}')
        try:
            driver.hide_keyboard()
        except:
            pass
        time.sleep(0.5)
        return True
    except Exception as e:
        print(f'  ⚠️ Error XPATH destino de fondos: {str(e)[:50]}')
    return False

def click_continuar_transferencia(driver):
    print('  📝 Click en Continuar (transferencia)...')
    wait = WebDriverWait(driver, 10)
    try:
        continuar = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")))
        continuar.click()
        print('  ✅ Click en Continuar')
        time.sleep(3)
        return True
    except:
        try:
            continuar = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Continuar')]")
            continuar.click()
            print('  ✅ Click en Continuar (content-desc)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Continuar: {e}')
            return False

def toggle_terminos_condiciones_exterior(driver, activar=True):
    print(f"  📝 Configurando Términos y Condiciones -> {('Activar' if activar else 'Desactivar')}")
    wait = WebDriverWait(driver, 10)
    try:
        switch = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'transfers_abroad_switch_terminos')))
        is_checked = switch.get_attribute('checked') == 'true'
        print(f"  🔍 Estado actual: {('Activado' if is_checked else 'Desactivado')}")
        if is_checked != activar:
            switch.click()
            time.sleep(1)
            print(f"  ✅ Switch Términos {('activado' if activar else 'desactivado')}")
            return True
        else:
            print(f"  ℹ️ Switch ya está {('activado' if activar else 'desactivado')}")
            return True
    except:
        try:
            switch = driver.find_element(AppiumBy.XPATH, "//android.widget.Switch[@content-desc='Acepto los términos y condiciones']")
            is_checked = switch.get_attribute('checked') == 'true'
            if is_checked != activar:
                switch.click()
                time.sleep(1)
                print(f"  ✅ Switch Términos {('activado' if activar else 'desactivado')}")
                return True
            else:
                print(f"  ℹ️ Switch ya está {('activado' if activar else 'desactivado')}")
                return True
        except Exception as e:
            print(f'  ❌ Error al configurar switch: {e}')
            return False

def click_continuar_terminos_exterior(driver):
    print('  📝 Click en Continuar (términos)...')
    wait = WebDriverWait(driver, 10)
    try:
        continuar = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")))
        continuar.click()
        print('  ✅ Click en Continuar (términos)')
        time.sleep(3)
        return True
    except:
        try:
            continuar = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Continuar')]")
            continuar.click()
            print('  ✅ Click en Continuar (términos - content-desc)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Continuar: {e}')
            return False

def click_confirmar_transaccion_exterior(driver):
    print('  📝 Click en Confirmar transacción...')
    wait = WebDriverWait(driver, 10)
    try:
        confirmar = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'transfers_abroad_btn_confirmar')))
        confirmar.click()
        print('  ✅ Click en Confirmar transacción')
        time.sleep(3)
        return True
    except:
        try:
            confirmar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Confirmar transacción']")
            confirmar.click()
            print('  ✅ Click en Confirmar transacción (content-desc)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Confirmar: {e}')
            return False

def transferencia_con_beneficiario_existente(driver, nombre_completo_busqueda, numero_cuenta_origen='40-0-2352481-5', monto='1.00', concepto='PRUEBA', causa_asfi='Otras transferencias al exterior', sucursal='La paz', agencia='Agencia cala cala', origen_fondos='PRUEBA DE ORIGEN', destino_fondos='PRUEBA FONDOS', clave_temporal='123456', tiempos=None, reporte=None, paso_inicial=6):
    print(f'\n🌎 INICIANDO TRANSFERENCIA AL EXTERIOR (BENEFICIARIO EXISTENTE)')
    print(f'📋 Beneficiario: {nombre_completo_busqueda}')
    print(f'💰 Monto: {monto}')
    print('=' * 60)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Ir a Más')
    if not click_mas_menu(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Menú Más abierto', "Se accedió al menú 'Más' desde la barra de navegación inferior.", espera=1.5)
    paso_num += 1
    tiempos.start('2. Transferencias al exterior')
    if not select_transferencias_exterior_mas(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla Transferencias al exterior', "Se accedió a la pantalla de 'Transferencias al exterior'. Se muestra la lista de beneficiarios y el campo de búsqueda.", espera=2.0)
    paso_num += 1
    print('  📝 Esperando carga de pantalla...')
    time.sleep(1)
    tiempos.start('3. Buscar beneficiario')
    if not buscar_beneficiario_exterior(driver, nombre_completo_busqueda):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f"Búsqueda: '{nombre_completo_busqueda}'", f"Se ingresó el nombre '{nombre_completo_busqueda}' en el campo de búsqueda de beneficiarios.", espera=1.5)
    paso_num += 1
    tiempos.start('4. Click en card beneficiario')
    if not click_beneficiario_card(driver, nombre_completo_busqueda):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Beneficiario seleccionado', f"Se seleccionó la card del beneficiario '{nombre_completo_busqueda}'. Se avanza a la pantalla de datos del giro.", espera=1.5)
    paso_num += 1
    print('  📝 Esperando carga de pantalla de datos del giro...')
    time.sleep(3)
    print('\n📝 PASO 7: Datos del Giro')
    tiempos.start('7. Datos del Giro')
    if not seleccionar_cuenta_origen_exterior(driver, numero_cuenta_origen):
        tiempos.stop()
        return False
    if reporte:
        reporte.capturar_paso(paso_num, f'Cuenta origen: {numero_cuenta_origen}', f'Se seleccionó la cuenta de origen: {numero_cuenta_origen}.', espera=1.0)
        paso_num += 1
    if not ingresar_monto_exterior(driver, monto):
        tiempos.stop()
        return False
    if reporte:
        reporte.capturar_paso(paso_num, f'Monto: {monto}', f'Se ingresó el monto de la transferencia: {monto}.', espera=1.0)
        paso_num += 1
    if not ingresar_concepto_exterior(driver, concepto):
        tiempos.stop()
        return False
    if reporte:
        reporte.capturar_paso(paso_num, f'Concepto: {concepto}', f"Se ingresó el concepto: '{concepto}'.", espera=1.0)
        paso_num += 1
    if not seleccionar_causa_asfi(driver, causa_asfi):
        tiempos.stop()
        return False
    if reporte:
        reporte.capturar_paso(paso_num, f'Causa ASFI: {causa_asfi}', f"Se seleccionó la causa ASFI: '{causa_asfi}'.", espera=1.0)
        paso_num += 1
    if not seleccionar_sucursal_exterior(driver, sucursal):
        tiempos.stop()
        return False
    if reporte:
        reporte.capturar_paso(paso_num, f'Sucursal: {sucursal}', f'Se seleccionó la sucursal: {sucursal}.', espera=1.0)
        paso_num += 1
    if not seleccionar_agencia_exterior(driver, agencia):
        tiempos.stop()
        return False
    if reporte:
        reporte.capturar_paso(paso_num, f'Agencia: {agencia}', f'Se seleccionó la agencia: {agencia}.', espera=1.0)
        paso_num += 1
    if not ingresar_origen_fondos_exterior(driver, origen_fondos):
        tiempos.stop()
        return False
    if reporte:
        reporte.capturar_paso(paso_num, f'Origen fondos: {origen_fondos}', f"Se ingresó el origen de fondos: '{origen_fondos}'.", espera=1.0)
        paso_num += 1
    if not ingresar_destino_fondos_exterior(driver, destino_fondos):
        tiempos.stop()
        return False
    if reporte:
        reporte.capturar_paso(paso_num, f'Destino fondos: {destino_fondos}', f"Se ingresó el destino de fondos: '{destino_fondos}'.", espera=1.0)
        paso_num += 1
    if not click_continuar_transferencia(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Continuar (datos completos)', 'Se hizo clic en Continuar. Se avanzó a la pantalla de Términos y Condiciones.', espera=1.5)
        paso_num += 1
    print('  📝 Esperando carga de pantalla de términos...')
    time.sleep(3)
    print('\n📝 PASO 8: Términos y Condiciones')
    tiempos.start('8. Términos y Condiciones')
    if not toggle_terminos_condiciones_exterior(driver, True):
        tiempos.stop()
        return False
    if reporte:
        reporte.capturar_paso(paso_num, 'Términos y condiciones aceptados', "Se aceptó el switch de 'Términos y condiciones'.", espera=1.0)
        paso_num += 1
    if not click_continuar_terminos_exterior(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Continuar (términos aceptados)', 'Se hizo clic en Continuar. Se avanzó a la pantalla de verificación.', espera=1.5)
        paso_num += 1
    print('  📝 Esperando carga de pantalla de verificación...')
    time.sleep(3)
    print('\n📝 PASO 9: Verificación y Confirmación')
    tiempos.start('9. Verificación y Confirmación')
    if not click_confirmar_transaccion_exterior(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Confirmar transacción', f'Se confirmó la transferencia al exterior por {monto}. Se muestra el modal de éxito.', espera=1.5)
        paso_num += 1
    print('  📝 Esperando carga de pantalla de éxito...')
    time.sleep(3)
    print('\n📝 PASO 10: Finalizar')
    tiempos.start('10. Volver al home')
    if not volver_home_exterior(driver):
        print('  ⚠️ Error al volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Transferencia finalizado', 'Se regresó exitosamente al home. El flujo de transferencia al exterior ha terminado.', espera=1.5)
        paso_num += 1
    print('\n✅ TRANSFERENCIA CON BENEFICIARIO EXISTENTE COMPLETADA EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('mas_transferencias_exterior_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO: LOGIN + TRANSFERENCIA CON BENEFICIARIO EXISTENTE + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    nombre_completo_busqueda = _input_cfg.get('nombre_completo_busqueda', 'Prueba1 Prueba2 Prueba3')
    numero_cuenta_origen = _input_cfg.get('numero_cuenta_origen', '40-0-2352481-5')
    monto = _input_cfg.get('monto', '1.00')
    concepto = _input_cfg.get('concepto', 'PRUEBA')
    causa_asfi = _input_cfg.get('causa_asfi', 'Otras transferencias al exterior')
    sucursal = _input_cfg.get('sucursal', 'La paz')
    agencia = _input_cfg.get('agencia', 'Agencia camacho')
    origen_fondos = _input_cfg.get('origen_fondos', 'PRUEBA DE ORIGEN')
    destino_fondos = _input_cfg.get('destino_fondos', 'PRUEBA FONDOS')
    clave_temporal = _input_cfg.get('clave_temporal', '123456')
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Transferencia_Exterior_Beneficiario_Existente')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f'📋 Beneficiario: {nombre_completo_busqueda}')
    print(f'💰 Monto: {monto}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Beneficiario': nombre_completo_busqueda, 'Cuenta origen': numero_cuenta_origen, 'Monto': monto, 'Concepto': concepto, 'Causa ASFI': causa_asfi, 'Sucursal': sucursal, 'Agencia': agencia, 'Origen fondos': origen_fondos, 'Destino fondos': destino_fondos})
    login_ok = _input_cfg.get('login_ok', False)
    transferencia_ok = _input_cfg.get('transferencia_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            transferencia_ok = transferencia_con_beneficiario_existente(driver, nombre_completo_busqueda=nombre_completo_busqueda, numero_cuenta_origen=numero_cuenta_origen, monto=monto, concepto=concepto, causa_asfi=causa_asfi, sucursal=sucursal, agencia=agencia, origen_fondos=origen_fondos, destino_fondos=destino_fondos, clave_temporal=clave_temporal, tiempos=tiempos, reporte=reporte, paso_inicial=6)
            if transferencia_ok:
                print('\n🎉 TRANSFERENCIA EXITOSA!')
            else:
                print('\n❌ TRANSFERENCIA FALLIDA')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and transferencia_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login         : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Transferencia : {('✅ OK' if transferencia_ok else '❌ FALLÓ')}")
        print(f'   Carpeta       : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

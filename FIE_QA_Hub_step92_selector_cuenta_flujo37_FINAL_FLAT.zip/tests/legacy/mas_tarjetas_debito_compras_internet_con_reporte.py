"""
Flujo Tarjetas de Débito → Compras por Internet + reporte Word.
Pasos: Login → Más → Tarjetas de débito → Compras por internet
       → Toggle switch → Seleccionar fecha → Continuar → Confirmar
       → Éxito → Regresar → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import re
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import volver_atras__3978e940f4 as volver_atras, volver_home__55b0b2e5af as volver_home

def click_mas_menu(driver):
    print('  📝 Click en menú Más...')
    wait = WebDriverWait(driver, 5)
    try:
        mas_btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'home_btn_mas')))
        mas_btn.click()
        print('  ✅ Click en Más (ID)')
        time.sleep(3)
        return True
    except:
        try:
            mas_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Más\nMás']")
            mas_btn.click()
            print('  ✅ Click en Más (content-desc)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Más: {e}')
            return False

def click_tarjetas_debito_mas(driver):
    """En el menú Más, hace click en 'Tarjetas de débito'."""
    print("  📝 Seleccionando 'Tarjetas de débito'...")
    wait = WebDriverWait(driver, 10)
    try:
        btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'more_btn_tarjetas')))
        btn.click()
        print("  ✅ Click en 'Tarjetas de débito' (ID)")
        time.sleep(3)
        return True
    except:
        try:
            btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Tarjetas de débito')]")
            btn.click()
            print("  ✅ Click en 'Tarjetas de débito' (content-desc)")
            time.sleep(3)
            return True
        except Exception as e:
            print(f"  ❌ Error al seleccionar 'Tarjetas de débito': {e}")
            return False

def click_compras_por_internet(driver):
    """En 'Administración de tarjeta de débito', click en 'Compras por internet'."""
    print("  📝 Seleccionando 'Compras por internet'...")
    wait = WebDriverWait(driver, 10)
    try:
        btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'cards_btn_compras_internet')))
        btn.click()
        print("  ✅ Click en 'Compras por internet' (ID)")
        time.sleep(3)
        return True
    except:
        try:
            btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Compras por internet')]")
            btn.click()
            print("  ✅ Click en 'Compras por internet' (content-desc)")
            time.sleep(3)
            return True
        except Exception as e:
            print(f"  ❌ Error al seleccionar 'Compras por internet': {e}")
            return False

def toggle_habilitar_compras_internet(driver, activar=True, timeout=15):
    """Activa o desactiva el switch 'Habilitar compras por internet'."""
    print(f"  📝 Configurando 'Habilitar compras por internet' -> {('Activar' if activar else 'Desactivar')}")
    wait = WebDriverWait(driver, timeout)
    try:
        switch = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'cards_ols_switch_habilitar')))
    except:
        try:
            switch = driver.find_element(AppiumBy.XPATH, "//android.widget.Switch[@content-desc='Habilitar compras por internet']")
        except Exception as e:
            print(f'  ❌ No se encontró el switch: {e}')
            return False
    try:
        is_checked = switch.get_attribute('checked') == 'true'
        print(f"  🔍 Estado actual: {('Activado' if is_checked else 'Desactivado')}")
        if is_checked == activar:
            print(f"  ℹ️ Switch ya está {('activado' if activar else 'desactivado')}")
            return True
        switch.click()
        time.sleep(1)
        nuevo = switch.get_attribute('checked') == 'true'
        if nuevo == activar:
            print(f"  ✅ Switch {('activado' if activar else 'desactivado')}")
            return True
        else:
            print(f'  ⚠️ El switch no cambió al estado esperado')
            return False
    except Exception as e:
        print(f'  ❌ Error al manipular switch: {e}')
        return False

def select_fecha_hasta(driver, fecha, timeout=15):
    """Selecciona Habilitada hasta navegando hacia meses anteriores o posteriores."""
    fecha_original = str(fecha or '').strip()
    partes = fecha_original.replace('-', '/').split('/')
    if len(partes) != 3:
        print(f'  ❌ Formato de fecha inválido: {fecha_original}')
        return False
    if len(partes[0]) == 4:
        anio, mes, dia = partes
    else:
        dia, mes, anio = partes
    dia_int, mes_int, anio_int = int(dia), int(mes), int(anio)
    fecha = f'{dia_int:02d}/{mes_int:02d}/{anio_int:04d}'
    meses = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre']
    mes_nombre = meses[mes_int - 1]
    print(f"  📝 Seleccionando fecha Habilitada hasta: {fecha} (entrada: {fecha_original})...")
    time.sleep(2)

    # En Compras por internet normalmente hay un solo selector de calendario.
    try:
        botones = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Elegir en calendario']")
        print(f"  🔍 Encontrados {len(botones)} botones 'Elegir en calendario'")
        if not botones:
            print('  ❌ No se encontró el botón Elegir en calendario')
            return False
        # Preferir el último botón disponible, equivalente a 'Hasta' en pantallas con rango.
        botones[-1].click()
        print("  ✅ Calendario de 'Habilitada hasta' abierto")
        time.sleep(3)
    except Exception as e:
        print(f'  ❌ Error al abrir calendario: {e}')
        return False

    def obtener_mes_actual():
        xpath = "//android.widget.Button[contains(@content-desc,'Enero') or contains(@content-desc,'Febrero') or contains(@content-desc,'Marzo') or contains(@content-desc,'Abril') or contains(@content-desc,'Mayo') or contains(@content-desc,'Junio') or contains(@content-desc,'Julio') or contains(@content-desc,'Agosto') or contains(@content-desc,'Septiembre') or contains(@content-desc,'Octubre') or contains(@content-desc,'Noviembre') or contains(@content-desc,'Diciembre')]"
        try:
            btn = driver.find_element(AppiumBy.XPATH, xpath)
            return btn.get_attribute('content-desc') or ''
        except Exception:
            return None

    encontrado = False
    for _ in range(24):
        titulo_actual = obtener_mes_actual()
        print(f'  📅 Mes actual: {titulo_actual}')
        if titulo_actual and mes_nombre in titulo_actual and str(anio_int) in titulo_actual:
            encontrado = True
            print(f'  ✅ Mes correcto: {mes_nombre} {anio_int}')
            break
        if not titulo_actual:
            print('  ⚠️ No se pudo determinar mes/año actual')
            break
        mes_actual = next((i for i,nombre in enumerate(meses,1) if nombre in titulo_actual), None)
        anos = re.findall(r'\d{4}', titulo_actual)
        anio_actual = int(anos[0]) if anos else None
        if not mes_actual or not anio_actual:
            print(f'  ⚠️ Título de calendario no reconocido: {titulo_actual}')
            break
        diff_meses = (anio_int - anio_actual) * 12 + (mes_int - mes_actual)
        print(f'  📊 Diferencia de meses: {diff_meses}')
        if diff_meses == 0:
            encontrado = True
            break
        sentido = 'Mes siguiente' if diff_meses > 0 else 'Mes anterior'
        try:
            btn = driver.find_element(AppiumBy.XPATH, f"//android.widget.Button[@content-desc='{sentido}' and @clickable='true']")
        except Exception:
            try:
                btn = driver.find_element(AppiumBy.XPATH, f"//android.widget.Button[@content-desc='{sentido}']")
            except Exception:
                print(f'  ❌ No se encontró {sentido}')
                break
        if btn.get_attribute('enabled') == 'false':
            print(f'  ❌ {sentido} está deshabilitado')
            break
        btn.click()
        print(f'  🔄 Navegando: {sentido}')
        time.sleep(1)

    if not encontrado:
        print(f'  ❌ No se encontró el mes {mes_nombre} {anio_int}')
        return False

    # Seleccionar día. Evitar contains() como primera estrategia para no elegir 19 al buscar 9.
    candidatos = [
        f"//*[@text='{dia_int}' and @clickable='true']",
        f"//*[@content-desc='{dia_int}' and @clickable='true']",
        f"//*[@text='{dia_int:02d}' and @clickable='true']",
        f"//*[@content-desc='{dia_int:02d}' and @clickable='true']",
    ]
    seleccionado = False
    for idx,xpath in enumerate(candidatos,1):
        try:
            dia_btn = driver.find_element(AppiumBy.XPATH, xpath)
            if dia_btn.is_displayed() and dia_btn.is_enabled():
                dia_btn.click(); seleccionado = True
                print(f'  ✅ Día {dia_int} seleccionado (estrategia {idx})')
                break
        except Exception:
            pass
    if not seleccionado:
        print(f'  ❌ No se pudo seleccionar el día {dia_int}')
        return False
    time.sleep(1)
    try:
        aceptar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Aceptar']")
        aceptar.click(); print('  ✅ Fecha confirmada con Aceptar'); time.sleep(2); return True
    except Exception:
        try:
            aceptar = driver.find_element(AppiumBy.XPATH, "//*[contains(@text,'Aceptar') and @clickable='true']")
            aceptar.click(); print('  ✅ Fecha confirmada con Aceptar (texto)'); time.sleep(2); return True
        except Exception as e:
            print(f'  ❌ No se encontró Aceptar: {e}')
            return False

def click_continuar_compras_internet(driver, timeout=15):
    print('  📝 Click en Continuar (compras por internet)...')
    wait = WebDriverWait(driver, timeout)
    try:
        continuar = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//*[@resource-id='cards_ols_btn_continuar']//android.widget.Button[@content-desc='Continuar']")))
        continuar.click()
        print('  ✅ Click en Continuar')
        time.sleep(3)
        return True
    except:
        try:
            continuar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")
            continuar.click()
            print('  ✅ Click en Continuar (fallback)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Continuar: {e}')
            return False

def click_confirmar_transaccion_compras(driver, timeout=15):
    print('  📝 Click en Confirmar transacción...')
    wait = WebDriverWait(driver, timeout)
    try:
        confirmar = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//*[@resource-id='cards_ols_btn_confirmar']//android.widget.Button[@content-desc='Confirmar transacción']")))
        confirmar.click()
        print('  ✅ Click en Confirmar transacción')
        time.sleep(3)
        return True
    except:
        try:
            confirmar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Confirmar transacción']")
            confirmar.click()
            print('  ✅ Click en Confirmar transacción (fallback)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Confirmar: {e}')
            return False

def click_continuar_exito_compras(driver, timeout=15):
    print('  📝 Click en Continuar (pantalla de éxito)...')
    wait = WebDriverWait(driver, timeout)
    try:
        continuar = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//*[@resource-id='cards_ols_btn_continuar_exito']//android.widget.Button[@content-desc='Continuar']")))
        continuar.click()
        print('  ✅ Click en Continuar (éxito)')
        time.sleep(2)
        return True
    except:
        try:
            continuar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")
            continuar.click()
            print('  ✅ Click en Continuar (éxito - fallback)')
            time.sleep(2)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Continuar (éxito): {e}')
            return False

def seleccionar_tarjeta_por_terminacion(driver, terminacion, max_swipes=10):
    """Centra la tarjeta solicitada. El XML puede contener tarjetas aún no visibles."""
    terminacion = str(terminacion or '').strip()
    if len(terminacion) != 4 or not terminacion.isdigit():
        print('  ❌ La terminación debe tener exactamente 4 dígitos')
        return False

    def tarjetas_visibles():
        """Devuelve solo faces que realmente intersectan el viewport, no todo el XML del pager."""
        width = driver.get_window_size()['width']
        candidates = driver.find_elements(AppiumBy.XPATH, "//*[@resource-id='cards_card_debit_face']")
        visible = []
        for el in candidates:
            try:
                box = el.rect
                desc = el.get_attribute('content-desc') or ''
                intersects = box['x'] < width and (box['x'] + box['width']) > 0 and box['width'] > 0
                if el.is_displayed() and intersects:
                    visible.append((el, box, desc))
            except Exception:
                pass
        return visible

    def esta_centrada(box):
        width = driver.get_window_size()['width']
        centro = box['x'] + box['width'] / 2
        # Tarjeta activa ocupa el centro del carrusel. Tolerancia estrecha para no aceptar una lateral.
        return abs(centro - width / 2) <= width * 0.12

    def buscar_objetivo_visible(etapa):
        visibles = tarjetas_visibles()
        print(f'  🔎 Tarjetas realmente visibles en {etapa}: {len(visibles)}')
        for el,box,desc in visibles:
            clean = desc.replace(chr(10), ' ')
            print(f"     • x={box['x']} w={box['width']} :: {clean}")
            if terminacion in desc:
                if esta_centrada(box):
                    print(f'  ✅ Tarjeta {terminacion} ya está centrada')
                    return True
                print(f'  ℹ️ Tarjeta {terminacion} está en el XML/viewport pero aún no está centrada')
        return False

    # Revisar la posición inicial sin mover el carrusel.
    if buscar_objetivo_visible('vista inicial'):
        return True

    for intento in range(1, max_swipes + 1):
        visibles = tarjetas_visibles()
        objetivo = next(((el,box,desc) for el,box,desc in visibles if terminacion in desc), None)
        try:
            pager = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='cards_ols_pager']")
            pb = pager.rect
            y = pb['y'] + pb['height']//2
            width = driver.get_window_size()['width']
            # Si el objetivo ya asoma a la derecha, mover a izquierda para centrarlo. Si asoma a la izquierda, movimiento inverso.
            if objetivo:
                _,box,_ = objetivo
                centro = box['x'] + box['width']/2
                if centro > width/2:
                    x1,x2 = pb['x'] + int(pb['width']*0.78), pb['x'] + int(pb['width']*0.28)
                else:
                    x1,x2 = pb['x'] + int(pb['width']*0.28), pb['x'] + int(pb['width']*0.78)
            else:
                x1,x2 = pb['x'] + int(pb['width']*0.78), pb['x'] + int(pb['width']*0.28)
            print(f'  ↔️ Desplazando carrusel {intento}/{max_swipes} para centrar {terminacion}...')
            driver.swipe(int(x1), int(y), int(x2), int(y), 550)
        except Exception:
            driver.swipe(820, 600, 260, 600, 550)
        time.sleep(1.2)
        if buscar_objetivo_visible(f'después del desplazamiento {intento}'):
            return True

    print(f'  ❌ No fue posible centrar la tarjeta terminada en {terminacion}')
    return False

def compras_por_internet_flow(driver, terminacion_tarjeta='', habilitar=True, fecha_hasta='11/09/2026', tiempos=None, reporte=None, paso_inicial=6):
    print(f'\n💳 INICIANDO FLUJO COMPRAS POR INTERNET')
    print(f'   Habilitar: {habilitar}')
    if habilitar:
        print(f'   Fecha hasta: {fecha_hasta}')
    print('=' * 60)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Ir a Más')
    if not click_mas_menu(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Menú Más abierto', "Se accedió al menú 'Más' desde la barra de navegación inferior.", espera=1.5)
    paso_num += 1
    tiempos.start('2. Tarjetas de débito')
    if not click_tarjetas_debito_mas(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Administración de tarjeta de débito', "Se accedió a la pantalla 'Administración de tarjeta de débito'.", espera=1.5)
    paso_num += 1
    tiempos.start('3. Compras por internet')
    if not click_compras_por_internet(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla Compras por internet', "Se accedió a la configuración de 'Compras por internet'. Se muestra el switch 'Habilitar compras por internet'.", espera=1.5)
    paso_num += 1
    tiempos.start('4. Seleccionar tarjeta')
    if not seleccionar_tarjeta_por_terminacion(driver, terminacion_tarjeta):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Tarjeta **** {terminacion_tarjeta}', f'Se seleccionó la tarjeta de débito terminada en {terminacion_tarjeta}.', espera=1.0)
    paso_num += 1
    tiempos.start('5. Toggle habilitar compras')
    if not toggle_habilitar_compras_internet(driver, activar=habilitar):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f"Switch {('habilitado' if habilitar else 'deshabilitado')}", f"Se {('activó' if habilitar else 'desactivó')} el switch 'Habilitar compras por internet'.", espera=1.5)
    paso_num += 1
    if habilitar:
        print("  📝 Switch activado - seleccionando fecha 'Habilitada hasta'...")
        time.sleep(2)
        tiempos.start('5. Seleccionar fecha hasta')
        if not select_fecha_hasta(driver, fecha_hasta):
            tiempos.stop()
            return False
        tiempos.stop()
        if reporte:
            reporte.capturar_paso(paso_num, f"Fecha 'Habilitada hasta' = {fecha_hasta}", f"Se seleccionó la fecha 'Habilitada hasta' en el calendario: {fecha_hasta}.", espera=1.5)
        paso_num += 1
    tiempos.start('6. Continuar (compras)')
    if not click_continuar_compras_internet(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Continuar (configuración compras)', "Se hizo clic en Continuar. Se abre el modal 'Detalle del cambio'.", espera=1.5)
    paso_num += 1
    print("  📝 Esperando carga del modal 'Detalle del cambio'...")
    time.sleep(3)
    tiempos.start('7. Confirmar transacción')
    if not click_confirmar_transaccion_compras(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Confirmar transacción', "Se confirmó la transacción en el modal 'Detalle del cambio'.", espera=1.5)
    paso_num += 1
    print('  📝 Esperando pantalla de éxito...')
    time.sleep(3)
    tiempos.start('8. Continuar (éxito)')
    if not click_continuar_exito_compras(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Modal de éxito - Cambio aplicado', 'Se mostró el modal de éxito confirmando que el cambio se aplicó correctamente. Se hizo clic en Continuar.', espera=1.5)
    paso_num += 1
    print('  📝 Esperando volver a la pantalla principal...')
    time.sleep(2)
    tiempos.start('9. Volver atrás')
    if not volver_atras(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Regreso a pantalla anterior', 'Se regresó a la pantalla anterior.', espera=1.0)
    paso_num += 1
    tiempos.start('10. Volver al home')
    if not volver_home(driver):
        print('  ⚠️ No se pudo volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Compras por Internet finalizado', 'Se regresó exitosamente al home. El flujo de configuración de compras por internet ha terminado.', espera=1.5)
    paso_num += 1
    print('\n✅ COMPRAS POR INTERNET COMPLETADO EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('mas_tarjetas_debito_compras_internet_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO: LOGIN + TARJETAS DE DÉBITO > COMPRAS POR INTERNET + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    HABILITAR = _input_cfg.get('HABILITAR', True)
    FECHA_HASTA = _input_cfg.get('FECHA_HASTA', '11/09/2026')
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Compras_Internet_Tarjeta_Debito')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f'💳 Habilitar compras: {HABILITAR}')
    if HABILITAR:
        print(f'📅 Fecha hasta: {FECHA_HASTA}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Habilitar compras': str(HABILITAR), 'Fecha hasta': FECHA_HASTA if HABILITAR else 'N/A'})
    login_ok = _input_cfg.get('login_ok', False)
    compras_ok = _input_cfg.get('compras_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            compras_ok = compras_por_internet_flow(driver, habilitar=HABILITAR, fecha_hasta=FECHA_HASTA, tiempos=tiempos, reporte=reporte, paso_inicial=6)
            if compras_ok:
                print('\n🎉 COMPRAS POR INTERNET EXITOSA!')
            else:
                print('\n❌ COMPRAS POR INTERNET FALLIDA')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and compras_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login              : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Compras internet   : {('✅ OK' if compras_ok else '❌ FALLÓ')}")
        print(f'   Carpeta            : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

"""
Flujo Ayuda con:
  - Capturas de pantalla por cada paso
  - Reporte Word (.docx) con datos generales + capturas
  - Carpeta autogenerada con fecha/hora
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import volver_atras_ayuda, volver_home__6ed7229b28 as volver_home
from framework.common.ui_helpers import _ingresar_texto_en_campo as _ingresar_texto_en_campo, _esta_en_home as _esta_en_home

def click_mas_menu(driver, timeout=10):
    print('  📝 Click en menú Más...')
    wait = WebDriverWait(driver, 5)
    try:
        mas_btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'home_btn_mas')))
        mas_btn.click()
        print('  ✅ Click en Más (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        mas_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Más\nMás']")
        mas_btn.click()
        print('  ✅ Click en Más (content-desc)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        mas_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Más') and @clickable='true']")
        mas_btn.click()
        print('  ✅ Click en Más (contains)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al clickear Más: {e}')
        return False

def select_ayuda_mas(driver):
    print('  📝 Seleccionando Ayuda...')
    wait = WebDriverWait(driver, 5)
    try:
        driver.swipe(500, 1500, 500, 800, 500)
        time.sleep(0.5)
    except:
        pass
    try:
        ayuda_btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'more_btn_ayuda')))
        ayuda_btn.click()
        print('  ✅ Click en Ayuda (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        ayuda_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Ayuda')]")
        ayuda_btn.click()
        print('  ✅ Click en Ayuda (content-desc)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        ayuda_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Ayuda') and @clickable='true']")
        ayuda_btn.click()
        print('  ✅ Click en Ayuda (texto)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al seleccionar Ayuda: {e}')
        return False

def buscar_en_ayuda(driver, texto_busqueda):
    print(f"  📝 Buscando: '{texto_busqueda}'...")
    ok = _ingresar_texto_en_campo(driver, 'help_in_search', texto_busqueda, hints_alternativos=['Buscar', 'Busca', 'buscar'])
    if ok:
        print(f"  ✅ Texto '{texto_busqueda}' ingresado")
    else:
        print(f"  ❌ Error al buscar: '{texto_busqueda}'")
    return ok

def seleccionar_opcion_ayuda(driver, opcion):
    print(f'  📝 Seleccionando opción: {opcion}...')
    wait = WebDriverWait(driver, 5)
    opciones_map = {'manual': 'help_btn_manual_de_usuario', 'preguntas': 'help_btn_preguntas_frecuentes', 'seguridad': 'help_btn_consejos_de_seguridad', 'privacidad': 'help_btn_pol_tica_de_privacidad', 'reclamos': 'help_btn_reclamos'}
    if opcion not in opciones_map:
        print(f"  ❌ Opción '{opcion}' no válida. Válidas: {list(opciones_map.keys())}")
        return False
    resource_id = opciones_map[opcion]
    try:
        driver.swipe(500, 1500, 500, 800, 500)
        time.sleep(0.5)
    except:
        pass
    try:
        btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, resource_id)))
        btn.click()
        print(f"  ✅ Opción '{opcion}' seleccionada (ID)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, f"//*[@resource-id='{resource_id}']")
        btn.click()
        print(f"  ✅ Opción '{opcion}' seleccionada (XPATH)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        texto_busqueda = opcion.replace('_', ' ').title()
        btn = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{texto_busqueda}') and @clickable='true']")
        btn.click()
        print(f"  ✅ Opción '{opcion}' seleccionada (content-desc)")
        time.sleep(3)
        return True
    except Exception as e:
        print(f"  ❌ Error al seleccionar opción '{opcion}': {e}")
        try:
            opciones = driver.find_elements(AppiumBy.XPATH, "//*[@clickable='true' and @content-desc and string-length(@content-desc) > 3]")
            print(f'  🔍 Opciones visibles ({len(opciones)}):')
            for o in opciones[:15]:
                desc = (o.get_attribute('content-desc') or '').replace('\n', ' | ')
                if len(desc) < 80:
                    print(f'     - {desc}')
        except:
            pass
        return False

def cerrar_link_ayuda(driver):
    print('  📝 Cerrando link...')
    time.sleep(3)
    try:
        cerrar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Cerrar']")
        cerrar.click()
        print('  ✅ Click en Cerrar')
        time.sleep(2)
        return True
    except:
        pass
    try:
        regresar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Regresar']")
        regresar.click()
        print('  ✅ Click en Regresar')
        time.sleep(2)
        return True
    except:
        pass
    try:
        aceptar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Aceptar']")
        aceptar.click()
        print('  ✅ Click en Aceptar')
        time.sleep(2)
        return True
    except:
        pass
    try:
        listo = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Listo']")
        listo.click()
        print('  ✅ Click en Listo')
        time.sleep(2)
        return True
    except:
        pass
    try:
        driver.back()
        print('  ✅ Back ejecutado')
        time.sleep(2)
        return True
    except Exception as e:
        print(f'  ❌ Error al cerrar link: {e}')
        return False

def realizar_ayuda(driver, opcion='Manual de usuario', reporte=None, tiempos=None, paso_inicial=6):
    mapa={'Manual de usuario':'manual','Preguntas frecuentes':'preguntas','Consejos de seguridad':'consejos','Política de privacidad':'privacidad','Reclamos':'reclamos'}
    texto_busqueda=mapa.get(opcion,opcion);opcion=texto_busqueda
    print(f'\n❓ INICIANDO AYUDA')
    print(f"📝 Buscando: '{texto_busqueda}'")
    print(f'📋 Opción: {opcion}')
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Ir a Más')
    if not click_mas_menu(driver):
        print('  ❌ Error al clickear Menú Más')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Menú Más abierto', "Se accedió al menú 'Más' desde la barra de navegación inferior.", espera=1.5)
    paso_num += 1
    tiempos.start('2. Ayuda')
    if not select_ayuda_mas(driver):
        print('  ❌ Error al seleccionar Ayuda')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla de Ayuda', 'Se ingresó a la pantalla de Ayuda. Se muestra el buscador y las opciones de ayuda disponibles.', espera=1.5)
    paso_num += 1
    print('  📝 Esperando carga de pantalla de ayuda...')
    time.sleep(3)
    tiempos.start('3. Buscar en ayuda')
    if not buscar_en_ayuda(driver, texto_busqueda):
        print('  ⚠️ Error al buscar, continuando...')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f"Búsqueda: '{texto_busqueda}'", f"Se ingresó el texto '{texto_busqueda}' en el buscador de ayuda.", espera=1.5)
    paso_num += 1
    tiempos.start('4. Seleccionar opción')
    if not seleccionar_opcion_ayuda(driver, opcion):
        print('  ❌ Error al seleccionar opción')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f"Opción '{opcion}' seleccionada", f"Se seleccionó la opción '{opcion}' de ayuda. Se abre el contenido correspondiente (link/documento).", espera=2.0)
    paso_num += 1
    tiempos.start('5. Cerrar link')
    if not cerrar_link_ayuda(driver):
        print('  ⚠️ Error al cerrar link, continuando...')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Link cerrado - Regreso a Ayuda', 'Se cerró el contenido abierto y se regresó a la pantalla de Ayuda.', espera=1.5)
    paso_num += 1
    tiempos.start('6. Volver atrás')
    if not volver_atras_ayuda(driver):
        print('  ⚠️ Error al volver atrás')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Regreso al menú Más', 'Se regresó desde la pantalla de Ayuda al menú anterior.', espera=1.0)
    paso_num += 1
    tiempos.start('7. Volver al home')
    if not volver_home(driver):
        print('  ⚠️ Error al volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Ayuda finalizado', 'Se regresó exitosamente al home. El flujo de Ayuda ha terminado.', espera=1.5)
    paso_num += 1
    print('\n✅ AYUDA COMPLETADA EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('login_ayuda_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO: LOGIN + AYUDA + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    texto_busqueda = _input_cfg.get('texto_busqueda', 'manual')
    opcion = _input_cfg.get('opcion', 'manual')
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Ayuda')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f"📝 Buscando: '{texto_busqueda}'")
    print(f'📋 Opción: {opcion}')
    print(f'📄 Nombre de la prueba: {NOMBRE_PRUEBA}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Texto buscado': texto_busqueda, 'Opción de ayuda': opcion})
    login_ok = _input_cfg.get('login_ok', False)
    ayuda_ok = _input_cfg.get('ayuda_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            ayuda_ok = realizar_ayuda(driver, texto_busqueda=texto_busqueda, opcion=opcion, reporte=reporte, tiempos=tiempos, paso_inicial=6)
            if ayuda_ok:
                print('\n🎉 AYUDA EXITOSA!')
            else:
                print('\n❌ AYUDA FALLIDA')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and ayuda_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login          : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Ayuda          : {('✅ OK' if ayuda_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

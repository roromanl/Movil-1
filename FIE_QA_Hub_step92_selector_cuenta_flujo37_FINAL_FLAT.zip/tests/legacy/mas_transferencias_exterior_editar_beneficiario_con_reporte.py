"""
Flujo Transferencias al Exterior - Editar Beneficiario + reporte Word.
Pasos: Login → Más → Transferencias al exterior → Buscar beneficiario
       → Editar → Formulario beneficiario → Banco destino
       → Banco intermediario → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import volver_home_exterior__1284b9fda1 as volver_home_exterior

def click_mas_menu(driver):
    print('  📝 Click en menú Más...')
    wait = WebDriverWait(driver, 5)
    try:
        mas_btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'home_btn_mas')))
        mas_btn.click()
        print('  ✅ Click en Más (ID)')
        time.sleep(3)
        return True
    except:
        try:
            mas_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Más\nMás']")
            mas_btn.click()
            print('  ✅ Click en Más (content-desc)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Más: {e}')
            return False

def select_transferencias_exterior_mas(driver):
    print('  📝 Seleccionando Transferencias al exterior...')
    wait = WebDriverWait(driver, 5)
    try:
        btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'more_btn_transferenciasExterior')))
        btn.click()
        print('  ✅ Click en Transferencias al exterior (ID)')
        time.sleep(3)
        return True
    except:
        try:
            btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Transferencias al exterior')]")
            btn.click()
            print('  ✅ Click en Transferencias al exterior (content-desc)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al seleccionar Transferencias al exterior: {e}')
            return False

def buscar_beneficiario_exterior(driver, nombre_completo):
    print(f'  📝 Buscando beneficiario: {nombre_completo}...')
    wait = WebDriverWait(driver, 10)
    try:
        try:
            search_parent = wait.until(EC.presence_of_element_located((AppiumBy.ID, 'transfers_abroad_search_field')))
            try:
                search_input = search_parent.find_element(AppiumBy.XPATH, './/android.widget.EditText')
                search_input.click()
            except:
                search_parent.click()
        except:
            search_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='Buscar']")
            search_input.click()
            search_parent = search_input
        time.sleep(0.5)
        try:
            search_parent.clear()
        except:
            pass
        try:
            search_input.clear()
            search_input.send_keys(nombre_completo)
        except:
            search_parent.send_keys(nombre_completo)
        print(f'  ✅ Nombre de búsqueda ingresado: {nombre_completo}')
        try:
            driver.hide_keyboard()
        except:
            pass
        time.sleep(2)
        return True
    except Exception as e:
        print(f'  ❌ Error al buscar beneficiario: {e}')
        return False

def click_editar_beneficiario(driver, nombre_completo, timeout=15):
    print(f'  📝 Buscando card del beneficiario y click en Editar...')
    wait = WebDriverWait(driver, timeout)
    card = None
    try:
        card = wait.until(EC.presence_of_element_located((AppiumBy.XPATH, f"//android.widget.Button[contains(@resource-id, 'transfers_abroad_item_') and contains(@content-desc, '{nombre_completo}')]")))
        card_id = card.get_attribute('resource-id')
        print(f'  ✅ Card encontrada (id={card_id})')
    except Exception as e1:
        print(f'  ⚠️ No se encontró por resource-id dinámico: {e1}')
        try:
            card = driver.find_element(AppiumBy.XPATH, f"//android.widget.Button[contains(@content-desc, '{nombre_completo}')]")
            card_id = card.get_attribute('resource-id')
            print(f'  ✅ Card encontrada por content-desc (id={card_id})')
        except Exception as e2:
            print(f'  ❌ No se encontró la card del beneficiario: {e2}')
            try:
                cards = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[contains(@resource-id, 'transfers_abroad_item_')]")
                print(f'  🔍 Beneficiarios disponibles: {len(cards)}')
                for c in cards:
                    print(f"     - id={c.get_attribute('resource-id')} | desc={c.get_attribute('content-desc')[:80]!r}...")
            except:
                pass
            return False
    try:
        editar_btn = card.find_element(AppiumBy.XPATH, ".//android.widget.Button[@content-desc='Editar']")
        print("  ✅ Botón 'Editar' localizado dentro de la card")
    except Exception as e:
        print(f"  ❌ No se encontró el botón 'Editar' dentro de la card: {e}")
        try:
            editar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Editar']")
            print("  ⚠️ Usando primer botón 'Editar' visible (fallback)")
        except Exception as e2:
            print(f"  ❌ No se encontró ningún botón 'Editar': {e2}")
            return False
    try:
        driver.execute_script('mobile: scroll', {'elementId': editar_btn.id, 'toVisible': True})
        time.sleep(0.3)
    except:
        pass
    try:
        editar_btn.click()
        print("  ✅ Click en 'Editar'")
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ⚠️ Click normal falló: {e}. Reintentando con tap...')
        try:
            padre = editar_btn.find_element(AppiumBy.XPATH, './..')
            loc = padre.location
            size = padre.size
            x = loc['x'] + size['width'] // 2
            y = loc['y'] + size['height'] // 2
            driver.tap([(x, y)])
            print("  ✅ Click en 'Editar' (tap)")
            time.sleep(3)
            return True
        except Exception as e2:
            print(f"  ❌ Error al clickear 'Editar': {e} / {e2}")
            return False

def ingresar_nombre_beneficiario(driver, nombre):
    print(f'  📝 Ingresando nombre: {nombre}...')
    wait = WebDriverWait(driver, 5)
    try:
        edit_text = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@resource-id='transfers_abroad_input_nombre']/android.widget.EditText")
        edit_text.click()
        time.sleep(0.5)
        edit_text.clear()
        edit_text.send_keys(nombre)
        print(f'  ✅ Nombre ingresado: {nombre}')
        try:
            driver.hide_keyboard()
        except:
            pass
        time.sleep(0.5)
        return True
    except Exception as e:
        print(f'  ⚠️ Error XPATH nombre: {str(e)[:50]}')
    print(f'  ❌ Error al ingresar Nombre: {nombre}')
    return False

def ingresar_primer_apellido(driver, apellido1):
    print(f'  📝 Ingresando primer apellido: {apellido1}...')
    wait = WebDriverWait(driver, 5)
    try:
        edit_text = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@resource-id='transfers_abroad_input_primer_apellido']/android.widget.EditText")
        edit_text.click()
        time.sleep(0.5)
        edit_text.clear()
        edit_text.send_keys(apellido1)
        print(f'  ✅ Primer apellido ingresado: {apellido1}')
        try:
            driver.hide_keyboard()
        except:
            pass
        time.sleep(0.5)
        return True
    except Exception as e:
        print(f'  ⚠️ Error XPATH Primer apellido: {str(e)[:50]}')
    print(f'  ❌ Error al ingresar Primer Apellido: {apellido1}')
    return False

def ingresar_segundo_apellido(driver, apellido2):
    print(f'  📝 Ingresando segundo apellido: {apellido2}...')
    wait = WebDriverWait(driver, 5)
    try:
        edit_text = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@resource-id='transfers_abroad_input_segundo_apellido']/android.widget.EditText")
        edit_text.click()
        time.sleep(0.5)
        edit_text.clear()
        edit_text.send_keys(apellido2)
        print(f'  ✅ Segundo apellido ingresado: {apellido2}')
        try:
            driver.hide_keyboard()
        except:
            pass
        time.sleep(0.5)
        return True
    except Exception as e:
        print(f'  ⚠️ Error XPATH Segundo apellido: {str(e)[:50]}')
    print(f'  ❌ Error al ingresar Segundo Apellido: {apellido2}')
    return False

def seleccionar_tipo_documento(driver, tipo_documento='Cedula de identidad'):
    print(f'  📝 Seleccionando tipo de documento: {tipo_documento}...')
    try:
        selector = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='transfers_abroad_select_tipo_documento']")
        selector.click()
        print('  ✅ Click en selector de tipo de documento')
        time.sleep(1.5)
    except Exception as e:
        print(f'  ❌ Error al abrir selector: {str(e)[:50]}')
        return False
    try:
        opcion = driver.find_element(AppiumBy.XPATH, f"//android.view.View[@content-desc='{tipo_documento}']")
        opcion.click()
        print(f'  ✅ Tipo de documento seleccionado: {tipo_documento}')
        time.sleep(1)
        return True
    except Exception as e:
        print(f'  ⚠️ Error XPATH opción (View): {str(e)[:50]}')
    try:
        opcion = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{tipo_documento}')]")
        opcion.click()
        print(f'  ✅ Tipo de documento seleccionado: {tipo_documento}')
        time.sleep(1)
        return True
    except Exception as e:
        print(f'  ❌ Error al seleccionar tipo: {str(e)[:50]}')
        return False

def ingresar_numero_documento(driver, numero_documento):
    print(f'  📝 Ingresando número de documento: {numero_documento}...')
    wait = WebDriverWait(driver, 5)
    try:
        edit_text = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@resource-id='transfers_abroad_input_documento']/android.widget.EditText")
        edit_text.click()
        time.sleep(0.5)
        edit_text.clear()
        edit_text.send_keys(numero_documento)
        print(f'  ✅ Número de documento ingresado: {numero_documento}')
        try:
            driver.hide_keyboard()
        except:
            pass
        time.sleep(0.5)
        return True
    except Exception as e:
        print(f'  ⚠️ Error XPATH Número de documento: {str(e)[:50]}')
    print(f'  ❌ Error al ingresar Número de documento')
    return False

def ingresar_numero_cuenta_iban(driver, numero_cuenta):
    print(f'  📝 Ingresando número de cuenta/IBAN: {numero_cuenta}...')
    try:
        edit_text = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@resource-id='transfers_abroad_input_cuenta']/android.widget.EditText")
        edit_text.click()
        time.sleep(0.5)
        edit_text.clear()
        edit_text.send_keys(numero_cuenta)
        print(f'  ✅ Número de cuenta/IBAN ingresado: {numero_cuenta}')
        try:
            driver.hide_keyboard()
        except:
            pass
        time.sleep(0.5)
        return True
    except Exception as e:
        print(f'  ⚠️ Error XPATH Número de cuenta/IBAN: {str(e)[:50]}')
    print(f'  ❌ Error al ingresar Número de cuenta/IBAN')
    return False

def ingresar_direccion_beneficiario(driver, direccion):
    print(f'  📝 Ingresando dirección: {direccion}...')
    try:
        edit_text = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@resource-id='transfers_abroad_input_direccion']/android.widget.EditText")
        edit_text.click()
        time.sleep(0.5)
        edit_text.clear()
        edit_text.send_keys(direccion)
        print(f'  ✅ Dirección ingresada: {direccion}')
        try:
            driver.hide_keyboard()
        except:
            pass
        time.sleep(0.5)
        return True
    except Exception as e:
        print(f'  ⚠️ Error XPATH Dirección: {str(e)[:50]}')
    print(f'  ❌ Error al ingresar Dirección')
    return False

def seleccionar_continente_beneficiario(driver, continente='America del sur'):
    print(f'  📝 Seleccionando continente: {continente}...')
    wait = WebDriverWait(driver, 10)
    try:
        driver.swipe(500, 1500, 500, 800, 500)
        time.sleep(0.5)
    except:
        pass
    try:
        selector = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//*[contains(@content-desc, 'Continente del banco')]")))
        selector.click()
        print('  ✅ Click en selector de continente')
        time.sleep(2)
    except:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Continente')]")
            selector.click()
            print('  ✅ Click en selector de continente (content-desc)')
            time.sleep(2)
        except Exception as e:
            print(f'  ❌ Error al abrir selector de continente: {e}')
            return False
    try:
        opcion = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, f"//android.view.View[@content-desc='{continente}']")))
        opcion.click()
        print(f'  ✅ Continente seleccionado: {continente}')
        time.sleep(2)
        return True
    except:
        try:
            opcion = driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{continente}')]")
            opcion.click()
            print(f'  ✅ Continente seleccionado: {continente}')
            time.sleep(1)
            return True
        except Exception as e:
            print(f'  ❌ Error al seleccionar continente: {e}')
            return False

def seleccionar_pais_beneficiario(driver, pais='Bolivia'):
    print(f'  📝 Seleccionando país: {pais}...')
    wait = WebDriverWait(driver, 40)
    print('  🔍 Buscando selector de país...')
    try:
        selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'País del banco')]")
        selector.click()
        print('  ✅ Click en selector de país')
        time.sleep(2)
    except:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'País')]")
            selector.click()
            print('  ✅ Click en selector de país (content-desc)')
            time.sleep(2)
        except Exception as e:
            print(f'  ❌ Error al abrir selector de país: {e}')
            return False
    try:
        opcion = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, f"//android.view.View[@content-desc='{pais}']")))
        opcion.click()
        print(f'  ✅ País seleccionado: {pais}')
        time.sleep(2)
        return True
    except:
        pass
    print('  🔄 Haciendo scroll dentro del modal hasta encontrar...')
    intento = 0
    while True:
        intento += 1
        try:
            opcion = driver.find_element(AppiumBy.XPATH, f"//android.view.View[@content-desc='{pais}']")
            opcion.click()
            print(f'  ✅ País seleccionado: {pais} (después de {intento} scrolls)')
            time.sleep(2)
            return True
        except:
            try:
                opcion = driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{pais}')]")
                opcion.click()
                print(f'  ✅ País seleccionado: {pais} (por texto parcial, después de {intento} scrolls)')
                time.sleep(2)
                return True
            except:
                pass
            try:
                opcion = driver.find_element(AppiumBy.XPATH, f"//android.view.View[contains(@content-desc, '{pais}')]")
                opcion.click()
                print(f'  ✅ País seleccionado: {pais} (por contains, después de {intento} scrolls)')
                time.sleep(2)
                return True
            except:
                pass
            try:
                driver.swipe(500, 1500, 500, 800, 300)
                time.sleep(0.3)
                print(f'  🔄 Scroll en modal {intento}...')
            except:
                print(f'  ⚠️ No se puede hacer más scroll en el modal')
                break
            if intento > 20:
                print('  🔄 Cambiando dirección de scroll...')
                try:
                    driver.swipe(500, 800, 500, 1500, 300)
                    time.sleep(0.3)
                except:
                    pass
                intento = 0
    print(f'  ❌ No se encontró el país: {pais}')
    return False

def seleccionar_ciudad_beneficiario(driver, ciudad='La paz'):
    print(f'  📝 Seleccionando ciudad: {ciudad}...')
    wait = WebDriverWait(driver, 30)
    print('  🔍 Buscando selector de ciudad...')
    try:
        selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Ciudad del banco')]")
        selector.click()
        print('  ✅ Click en selector de ciudad')
        time.sleep(1)
    except:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Ciudad')]")
            selector.click()
            print('  ✅ Click en selector de ciudad (content-desc)')
            time.sleep(2)
        except Exception as e:
            print(f'  ❌ Error al abrir selector de ciudad: {e}')
            return False
    print(f'  🔍 Buscando ciudad: {ciudad} dentro del modal...')
    try:
        opcion = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, f"//android.view.View[@content-desc='{ciudad}']")))
        opcion.click()
        print(f'  ✅ Ciudad seleccionada: {ciudad}')
        time.sleep(1)
        return True
    except:
        pass
    print('  🔄 Haciendo scroll dentro del modal hasta encontrar...')
    intento = 0
    while True:
        intento += 1
        try:
            opcion = driver.find_element(AppiumBy.XPATH, f"//android.view.View[@content-desc='{ciudad}']")
            opcion.click()
            print(f'  ✅ Ciudad seleccionada: {ciudad} (después de {intento} scrolls)')
            time.sleep(1)
            return True
        except:
            try:
                opcion = driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{ciudad}')]")
                opcion.click()
                print(f'  ✅ Ciudad seleccionada: {ciudad} (por texto parcial, después de {intento} scrolls)')
                time.sleep(1)
                return True
            except:
                pass
            try:
                opcion = driver.find_element(AppiumBy.XPATH, f"//android.view.View[contains(@content-desc, '{ciudad}')]")
                opcion.click()
                print(f'  ✅ Ciudad seleccionada: {ciudad} (por contains, después de {intento} scrolls)')
                time.sleep(1)
                return True
            except:
                pass
            try:
                driver.swipe(500, 1500, 500, 800, 300)
                time.sleep(0.3)
                print(f'  🔄 Scroll en modal {intento}...')
            except:
                print(f'  ⚠️ No se puede hacer más scroll en el modal')
                break
            if intento > 20:
                print('  🔄 Cambiando dirección de scroll...')
                try:
                    driver.swipe(500, 800, 500, 1500, 300)
                    time.sleep(0.3)
                except:
                    pass
                intento = 0
    print(f'  ❌ No se encontró la ciudad: {ciudad}')
    return False

def click_continuar_beneficiario(driver):
    print('  📝 Click en Continuar (beneficiario)...')
    wait = WebDriverWait(driver, 10)
    try:
        continuar = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")))
        continuar.click()
        print('  ✅ Click en Continuar')
        time.sleep(3)
        return True
    except:
        try:
            continuar = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Continuar')]")
            continuar.click()
            print('  ✅ Click en Continuar (content-desc)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Continuar: {e}')
            return False

def ingresar_swift_banco_destino(driver, swift):
    print(f'  📝 Ingresando SWIFT banco destino: {swift}...')
    wait = WebDriverWait(driver, 5)
    try:
        input_field = wait.until(EC.presence_of_element_located((AppiumBy.ID, 'transfers_abroad_input_swift_destino')))
        try:
            edit_text = input_field.find_element(AppiumBy.CLASS_NAME, 'android.widget.EditText')
            edit_text.click()
        except:
            input_field.click()
        input_field.clear()
        input_field.send_keys(swift)
        print(f'  ✅ SWIFT ingresado: {swift}')
        try:
            driver.hide_keyboard()
        except:
            pass
        time.sleep(0.5)
        return True
    except:
        try:
            edit_text = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@resource-id='transfers_abroad_input_swift_destino']/android.widget.EditText")
            edit_text.click()
            edit_text.clear()
            edit_text.send_keys(swift)
            print(f'  ✅ SWIFT ingresado: {swift}')
            try:
                driver.hide_keyboard()
            except:
                pass
            time.sleep(0.5)
            return True
        except Exception as e:
            print(f'  ❌ Error al ingresar SWIFT: {e}')
            return False

def click_buscar_swift_banco_destino(driver):
    print('  📝 Click en Buscar SWIFT (banco destino)...')
    wait = WebDriverWait(driver, 5)
    try:
        btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'transfers_abroad_input_swift_destino_buscar')))
        btn.click()
        print('  ✅ Click en Buscar SWIFT')
        time.sleep(3)
        return True
    except:
        try:
            btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Buscar SWIFT']")
            btn.click()
            print('  ✅ Click en Buscar SWIFT (content-desc)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al buscar SWIFT: {e}')
            return False

def verificar_nombre_banco_destino(driver):
    print('  📝 Verificando nombre del banco destino...')
    time.sleep(2)
    try:
        edit_text = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@resource-id='transfers_abroad_input_banco_destino']")
        texto = edit_text.get_attribute('text') or ''
        if not texto:
            try:
                hijo = edit_text.find_element(AppiumBy.XPATH, './/android.view.View[@text]')
                texto = hijo.get_attribute('text') or ''
            except:
                pass
        if texto and len(texto) > 3:
            print(f'  ✅ Nombre del banco destino ya está lleno: {texto}')
            return True
    except Exception as e:
        print(f'  ⚠️ Error leyendo banco: {e}')
    print('  ⚠️ Nombre del banco destino NO está lleno - campo vacío')
    return False

def ingresar_nombre_banco_destino(driver, nombre_banco):
    print(f'  📝 Ingresando nombre del banco destino: {nombre_banco}...')
    try:
        edit_text = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@resource-id='transfers_abroad_input_banco_destino']/android.widget.EditText")
        edit_text.click()
        time.sleep(0.5)
        edit_text.clear()
        edit_text.send_keys(nombre_banco)
        print(f'  ✅ Nombre del banco destino ingresado: {nombre_banco}')
        try:
            driver.hide_keyboard()
        except:
            pass
        time.sleep(0.5)
        return True
    except Exception as e:
        print(f'  ⚠️ Error XPATH hijo: {str(e)[:50]}')
    print('  ⚠️ Nombre del banco destino NO registrado')
    return False

def toggle_banco_intermediario(driver, activar=True):
    print(f"  📝 Configurando Banco Intermediario -> {('Activar' if activar else 'Desactivar')}")
    wait = WebDriverWait(driver, 30)
    try:
        switch = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'transfers_abroad_switch_intermediario')))
        is_checked = switch.get_attribute('checked') == 'true'
        print(f"  🔍 Estado actual: {('Activado' if is_checked else 'Desactivado')}")
        if is_checked != activar:
            switch.click()
            time.sleep(1)
            print(f"  ✅ Switch {('activado' if activar else 'desactivado')}")
            return True
        else:
            print(f"  ℹ️ Switch ya está {('activado' if activar else 'desactivado')}")
            return True
    except:
        try:
            switch = driver.find_element(AppiumBy.XPATH, "//android.widget.Switch[@content-desc='Banco intermediario']")
            is_checked = switch.get_attribute('checked') == 'true'
            if is_checked != activar:
                switch.click()
                time.sleep(1)
                print(f"  ✅ Switch {('activado' if activar else 'desactivado')}")
            else:
                print(f"  ℹ️ Switch ya está {('activado' if activar else 'desactivado')}")
            try:
                driver.swipe(500, 1500, 500, 800, 500)
                time.sleep(1)
            except:
                pass
            return True
        except Exception as e:
            print(f'  ❌ Error al configurar switch: {e}')
            return False

def click_confirmar_banco_intermediario(driver):
    print('  📝 Click en Confirmar (banco intermediario)...')
    wait = WebDriverWait(driver, 30)
    try:
        confirmar = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//android.widget.Button[@content-desc='Confirmar']")))
        confirmar.click()
        print('  ✅ Click en Confirmar')
        time.sleep(3)
        return True
    except:
        try:
            confirmar = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Confirmar')]")
            confirmar.click()
            print('  ✅ Click en Confirmar (content-desc)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Confirmar: {e}')
            return False

def ingresar_swift_banco_intermediario(driver, swift_inter):
    print(f'  📝 Ingresando SWIFT banco intermediario: {swift_inter}...')
    try:
        edit_text = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@resource-id='transfers_abroad_input_swift_inter']/android.widget.EditText")
        edit_text.click()
        time.sleep(0.5)
        edit_text.clear()
        edit_text.send_keys(swift_inter)
        print(f'  ✅ SWIFT intermediario ingresado: {swift_inter}')
        try:
            driver.hide_keyboard()
        except:
            pass
        time.sleep(0.5)
        return True
    except Exception as e:
        print(f'  ⚠️ Error XPATH: {str(e)[:50]}')
    print('  ⚠️ SWIFT intermediario NO registrado')
    return False

def click_buscar_swift_banco_intermediario(driver):
    print('  📝 Click en Buscar SWIFT (banco intermediario)...')
    wait = WebDriverWait(driver, 10)
    try:
        btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'transfers_abroad_input_swift_inter_buscar')))
        btn.click()
        print('  ✅ Click en Buscar SWIFT (intermediario)')
        time.sleep(3)
        return True
    except:
        try:
            btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Buscar SWIFT']")
            btn.click()
            print('  ✅ Click en Buscar SWIFT (intermediario)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al buscar SWIFT intermediario: {e}')
            return False

def verificar_nombre_banco_intermediario(driver):
    print('  📝 Verificando nombre del banco intermediario...')
    time.sleep(2)
    try:
        edit_text = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@resource-id='transfers_abroad_input_banco_inter']")
        texto = edit_text.get_attribute('text') or ''
        if not texto:
            try:
                hijo = edit_text.find_element(AppiumBy.XPATH, './/android.view.View[@text]')
                texto = hijo.get_attribute('text') or ''
            except:
                pass
        if texto and len(texto) > 3:
            print(f'  ✅ Nombre del banco intermediario ya está lleno: {texto}')
            return True
    except Exception as e:
        print(f'  ⚠️ Error leyendo banco: {e}')
    print('  ⚠️ Nombre del banco intermediario NO está lleno - campo vacío')
    return False

def ingresar_nombre_banco_intermediario(driver, nombre_banco_inter):
    print(f'  📝 Ingresando nombre del banco intermediario: {nombre_banco_inter}...')
    try:
        edit_text = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@resource-id='transfers_abroad_input_banco_inter']/android.widget.EditText")
        edit_text.click()
        time.sleep(0.5)
        edit_text.clear()
        edit_text.send_keys(nombre_banco_inter)
        print(f'  ✅ Nombre ingresado: {nombre_banco_inter}')
        try:
            driver.hide_keyboard()
        except:
            pass
        time.sleep(0.5)
        return True
    except Exception as e:
        print(f'  ⚠️ Error XPATH hijo: {str(e)[:50]}')
    return False

def click_continuar_transferencia(driver):
    print('  📝 Click en Continuar (transferencia)...')
    wait = WebDriverWait(driver, 10)
    try:
        continuar = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")))
        continuar.click()
        print('  ✅ Click en Continuar')
        time.sleep(3)
        return True
    except:
        try:
            continuar = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Continuar')]")
            continuar.click()
            print('  ✅ Click en Continuar (content-desc)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Continuar: {e}')
            return False

def editar_beneficiario_exterior(driver, nombre_completo_busqueda, nombre='Prueba1', apellido1='Prueba2', apellido2='Prueba3', tipo_documento='Cedula de identidad', numero_documento='1234567', numero_cuenta_iban='12345678901234567890', direccion='Calle Prueba 123', continente_beneficiario='America del sur', pais_beneficiario='Bolivia', ciudad_beneficiario='La paz', swift_banco_destino='CHASUS33XXX', nombre_banco_destino='JPMORGAN CHASE BANK, N.A.', continente_banco_destino='America del norte', pais_banco_destino='Estados Unidos', ciudad_banco_destino='New york', banco_intermediario_activar=False, swift_banco_inter='', nombre_banco_inter='', tiempos=None, reporte=None, paso_inicial=6):
    print(f'\n✏️  INICIANDO EDICIÓN DE BENEFICIARIO')
    print(f'🔍 Buscando: {nombre_completo_busqueda}')
    print('=' * 60)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Ir a Más')
    if not click_mas_menu(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Menú Más abierto', "Se accedió al menú 'Más' desde la barra de navegación inferior.", espera=1.5)
    paso_num += 1
    tiempos.start('2. Transferencias al exterior')
    if not select_transferencias_exterior_mas(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla Transferencias al exterior', "Se accedió a la pantalla de 'Transferencias al exterior'. Se muestra la lista de beneficiarios y el campo de búsqueda.", espera=2.0)
    paso_num += 1
    print('  📝 Esperando carga de pantalla...')
    time.sleep(1)
    tiempos.start('3. Buscar beneficiario')
    if not buscar_beneficiario_exterior(driver, nombre_completo_busqueda):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f"Búsqueda: '{nombre_completo_busqueda}'", f"Se ingresó el nombre '{nombre_completo_busqueda}' en el campo de búsqueda de beneficiarios.", espera=1.5)
    paso_num += 1
    tiempos.start('4. Click en Editar')
    if not click_editar_beneficiario(driver, nombre_completo_busqueda):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Editar beneficiario: {nombre_completo_busqueda}', f"Se hizo clic en el botón 'Editar' de la card del beneficiario '{nombre_completo_busqueda}'. Se abre el formulario de edición.", espera=1.5)
    paso_num += 1
    print('  📝 Esperando carga de pantalla de edición...')
    time.sleep(2)
    tiempos.start('5. Formulario Beneficiario')
    if not ingresar_nombre_beneficiario(driver, nombre):
        tiempos.stop()
        return False
    if not ingresar_primer_apellido(driver, apellido1):
        tiempos.stop()
        return False
    if not ingresar_segundo_apellido(driver, apellido2):
        tiempos.stop()
        return False
    if reporte:
        reporte.capturar_paso(paso_num, f'Nombre: {nombre} {apellido1} {apellido2}', f'Se reescribió el nombre completo: {nombre} {apellido1} {apellido2}.', espera=1.0)
    paso_num += 1
    if not seleccionar_tipo_documento(driver, tipo_documento):
        tiempos.stop()
        return False
    if not ingresar_numero_documento(driver, numero_documento):
        tiempos.stop()
        return False
    if reporte:
        reporte.capturar_paso(paso_num, f'Documento: {tipo_documento} {numero_documento}', f'Se reescribió el documento: {tipo_documento} - {numero_documento}.', espera=1.0)
    paso_num += 1
    if not ingresar_numero_cuenta_iban(driver, numero_cuenta_iban):
        tiempos.stop()
        return False
    if reporte:
        reporte.capturar_paso(paso_num, f'Cuenta/IBAN: {numero_cuenta_iban}', f'Se reescribió el número de cuenta/IBAN: {numero_cuenta_iban}.', espera=1.0)
    paso_num += 1
    if not ingresar_direccion_beneficiario(driver, direccion):
        tiempos.stop()
        return False
    if not seleccionar_continente_beneficiario(driver, continente_beneficiario):
        tiempos.stop()
        return False
    if not seleccionar_pais_beneficiario(driver, pais_beneficiario):
        tiempos.stop()
        return False
    if not seleccionar_ciudad_beneficiario(driver, ciudad_beneficiario):
        tiempos.stop()
        return False
    if reporte:
        reporte.capturar_paso(paso_num, f'Ubicación: {pais_beneficiario} - {ciudad_beneficiario}', f'Se reescribió la ubicación: {continente_beneficiario} / {pais_beneficiario} / {ciudad_beneficiario}. Dirección: {direccion}.', espera=1.0)
    paso_num += 1
    if not click_continuar_beneficiario(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Continuar (datos beneficiario)', 'Se hizo clic en Continuar. Se avanzó a la pantalla de datos del banco destino.', espera=1.5)
    paso_num += 1
    print('  📝 Esperando carga de pantalla de banco destino...')
    time.sleep(1)
    tiempos.start('6. Banco destino')
    if not ingresar_swift_banco_destino(driver, swift_banco_destino):
        tiempos.stop()
        return False
    if not click_buscar_swift_banco_destino(driver):
        tiempos.stop()
        return False
    if reporte:
        reporte.capturar_paso(paso_num, f'SWIFT banco destino: {swift_banco_destino}', f"Se ingresó el SWIFT del banco destino ({swift_banco_destino}) y se hizo clic en 'Buscar SWIFT'.", espera=1.5)
    paso_num += 1
    nombre_destino_lleno = verificar_nombre_banco_destino(driver)
    if not nombre_destino_lleno:
        print('  📝 El nombre del banco destino NO se llenó automáticamente - ingresando manualmente...')
        if not ingresar_nombre_banco_destino(driver, nombre_banco_destino):
            tiempos.stop()
            return False
        if reporte:
            reporte.capturar_paso(paso_num, f'Banco destino: {nombre_banco_destino}', f'Se ingresó manualmente el nombre del banco destino: {nombre_banco_destino}.', espera=1.0)
        paso_num += 1
    else:
        print('  ℹ️ Nombre del banco destino se llenó automáticamente')
        if reporte:
            reporte.capturar_paso(paso_num, 'Banco destino autocompletado', 'El nombre del banco destino se llenó automáticamente después de buscar por SWIFT.', espera=1.0)
        paso_num += 1
    tiempos.stop()
    print('  📝 Esperando carga de banco intermediario...')
    time.sleep(3)
    tiempos.start('7. Banco intermediario')
    if banco_intermediario_activar:
        if not toggle_banco_intermediario(driver, True):
            tiempos.stop()
            return False
        if reporte:
            reporte.capturar_paso(paso_num, 'Banco intermediario ACTIVADO', "Se activó el switch 'Banco intermediario'.", espera=1.0)
        paso_num += 1
        if not ingresar_swift_banco_intermediario(driver, swift_banco_inter):
            tiempos.stop()
            return False
        if not click_buscar_swift_banco_intermediario(driver):
            tiempos.stop()
            return False
        if reporte:
            reporte.capturar_paso(paso_num, f'SWIFT intermediario: {swift_banco_inter}', f"Se ingresó el SWIFT del banco intermediario ({swift_banco_inter}) y se hizo clic en 'Buscar SWIFT'.", espera=1.5)
        paso_num += 1
        nombre_inter_lleno = verificar_nombre_banco_intermediario(driver)
        if not nombre_inter_lleno:
            if not ingresar_nombre_banco_intermediario(driver, nombre_banco_inter):
                tiempos.stop()
                return False
            if reporte:
                reporte.capturar_paso(paso_num, f'Banco intermediario: {nombre_banco_inter}', f'Se ingresó manualmente el nombre del banco intermediario: {nombre_banco_inter}.', espera=1.0)
            paso_num += 1
        else:
            if reporte:
                reporte.capturar_paso(paso_num, 'Banco intermediario autocompletado', 'El nombre del banco intermediario se llenó automáticamente.', espera=1.0)
            paso_num += 1
        if not click_continuar_transferencia(driver):
            tiempos.stop()
            return False
        if reporte:
            reporte.capturar_paso(paso_num, 'Continuar (banco intermediario)', 'Se hizo clic en Continuar después de configurar el banco intermediario.', espera=1.5)
        paso_num += 1
        time.sleep(3)
        if not click_confirmar_banco_intermediario(driver):
            tiempos.stop()
            return False
        if reporte:
            reporte.capturar_paso(paso_num, 'Confirmar (banco intermediario)', 'Se confirmó la configuración del banco intermediario.', espera=1.5)
        paso_num += 1
    else:
        if not toggle_banco_intermediario(driver, False):
            tiempos.stop()
            return False
        if reporte:
            reporte.capturar_paso(paso_num, 'Banco intermediario DESACTIVADO', "Se desactivó el switch 'Banco intermediario'.", espera=1.0)
        paso_num += 1
        if not click_continuar_transferencia(driver):
            tiempos.stop()
            return False
        if reporte:
            reporte.capturar_paso(paso_num, 'Continuar (sin banco intermediario)', 'Se hizo clic en Continuar sin banco intermediario.', espera=1.5)
        paso_num += 1
        time.sleep(3)
        if not click_confirmar_banco_intermediario(driver):
            tiempos.stop()
            return False
        if reporte:
            reporte.capturar_paso(paso_num, 'Confirmar (continuar)', 'Se confirmó para finalizar la edición.', espera=1.5)
        paso_num += 1
    tiempos.stop()
    print('  📝 Esperando pantalla de éxito...')
    time.sleep(3)
    tiempos.start('11. Volver al home')
    if not volver_home_exterior(driver):
        print('  ⚠️ Error al volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Edición de beneficiario finalizada', 'Se regresó exitosamente al home. La edición del beneficiario ha terminado.', espera=1.5)
    paso_num += 1
    print('\n✅ EDICIÓN DE BENEFICIARIO COMPLETADA EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('mas_transferencias_exterior_editar_beneficiario_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO: LOGIN + EDITAR BENEFICIARIO (TRANSFERENCIA EXTERIOR) + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '67018956')
    password = _input_cfg.get('password', 'Abc#1234')
    nombre_completo_busqueda = _input_cfg.get('nombre_completo_busqueda', 'Prueba1 Prueba2 Prueba3')
    nombre = _input_cfg.get('nombre', 'Prueba1')
    apellido1 = _input_cfg.get('apellido1', 'Prueba2')
    apellido2 = _input_cfg.get('apellido2', 'Prueba3')
    tipo_documento = _input_cfg.get('tipo_documento', 'Cedula de identidad')
    numero_documento = _input_cfg.get('numero_documento', '1234567')
    numero_cuenta_iban = _input_cfg.get('numero_cuenta_iban', '12345678901234567890')
    direccion = _input_cfg.get('direccion', 'Calle Prueba 123')
    continente_beneficiario = _input_cfg.get('continente_beneficiario', 'America del sur')
    pais_beneficiario = _input_cfg.get('pais_beneficiario', 'Bolivia')
    ciudad_beneficiario = _input_cfg.get('ciudad_beneficiario', 'Abapo')
    swift_banco_destino = _input_cfg.get('swift_banco_destino', 'CHASUS33XXX')
    nombre_banco_destino = _input_cfg.get('nombre_banco_destino', 'JPMORGAN CHASE BANK, N.A.')
    continente_banco_destino = _input_cfg.get('continente_banco_destino', 'America del norte')
    pais_banco_destino = _input_cfg.get('pais_banco_destino', 'Estados Unidos')
    ciudad_banco_destino = _input_cfg.get('ciudad_banco_destino', 'New york')
    banco_intermediario_activar = _input_cfg.get('banco_intermediario_activar', True)
    swift_banco_inter = _input_cfg.get('swift_banco_inter', 'CHASUS33XXX')
    nombre_banco_inter = _input_cfg.get('nombre_banco_inter', 'JPMORGAN 2')
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Editar_Beneficiario_Transferencia_Exterior')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f'🔍 Beneficiario a editar: {nombre_completo_busqueda}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Beneficiario editado': nombre_completo_busqueda, 'Nombre': nombre, 'Primer apellido': apellido1, 'Segundo apellido': apellido2, 'Tipo documento': tipo_documento, 'Número documento': numero_documento, 'Cuenta/IBAN': numero_cuenta_iban, 'Dirección': direccion, 'País': pais_beneficiario, 'Ciudad': ciudad_beneficiario, 'SWIFT banco destino': swift_banco_destino, 'Banco destino': nombre_banco_destino, 'Banco intermediario activado': str(banco_intermediario_activar), 'SWIFT intermediario': swift_banco_inter if banco_intermediario_activar else 'N/A'})
    login_ok = _input_cfg.get('login_ok', False)
    editar_ok = _input_cfg.get('editar_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            editar_ok = editar_beneficiario_exterior(driver, nombre_completo_busqueda=nombre_completo_busqueda, nombre=nombre, apellido1=apellido1, apellido2=apellido2, tipo_documento=tipo_documento, numero_documento=numero_documento, numero_cuenta_iban=numero_cuenta_iban, direccion=direccion, continente_beneficiario=continente_beneficiario, pais_beneficiario=pais_beneficiario, ciudad_beneficiario=ciudad_beneficiario, swift_banco_destino=swift_banco_destino, nombre_banco_destino=nombre_banco_destino, continente_banco_destino=continente_banco_destino, pais_banco_destino=pais_banco_destino, ciudad_banco_destino=ciudad_banco_destino, banco_intermediario_activar=banco_intermediario_activar, swift_banco_inter=swift_banco_inter, nombre_banco_inter=nombre_banco_inter, tiempos=tiempos, reporte=reporte, paso_inicial=6)
            if editar_ok:
                print('\n🎉 EDICIÓN COMPLETADA EXITOSAMENTE!')
            else:
                print('\n❌ EDICIÓN FALLIDA')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        dur_cierre = time.perf_counter() - t_cierre
        tiempos.tiempos['Z. Cierre driver'] = dur_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and editar_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login   : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Edición : {('✅ OK' if editar_ok else '❌ FALLÓ')}")
        print(f'   Carpeta : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

"""
Flujo Unificado: Transferencia + Validación de Movimiento + reporte Word.
Pasos:
  Login → Transferir → Cuenta destino → Cuenta origen → Monto → Concepto
  → Continuar → Confirmar → Verificar → Home
  → Tipo cuenta → Cuenta específica → Buscar (abrir) → Tipo movimiento
  → Fecha Desde → Fecha Hasta → Buscar (ejecutar) → Seleccionar movimiento
  → Cerrar modal → Regresar → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import re
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import go_back_home_from_transfer, go_back__6cc20c23ae as go_back
from framework.common.ui_helpers import _esta_en_home as _esta_en_home, _seleccionar_opcion_case_insensitive__f21faf0807 as _seleccionar_opcion_case_insensitive

def navigate_to_transfer(driver):
    print('  📝 Navegando a Transferencias...')
    time.sleep(2)
    try:
        transfer_btn = driver.find_element(AppiumBy.ID, 'home_btn_transferir')
        transfer_btn.click()
        print('  ✅ Click en Transferir (ID)')
        time.sleep(3)
        return True
    except:
        try:
            transfer_btn = driver.find_element(AppiumBy.ACCESSIBILITY_ID, 'Transferir')
            transfer_btn.click()
            print('  ✅ Click en Transferir (Accessibility)')
            time.sleep(3)
            return True
        except:
            try:
                transfer_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Transferir') or contains(@content-desc, 'Transferir')]")
                transfer_btn.click()
                print('  ✅ Click en Transferir (XPATH)')
                time.sleep(3)
                return True
            except Exception as e:
                print(f'  ❌ Error al navegar a transferencias: {e}')
                return False

def select_destino_cuenta_propia(driver, numero_cuenta=None, tipo_moneda=None, index=0):
    print(f'  📝 Seleccionando cuenta destino...')
    if numero_cuenta:
        print(f'     • Número: {numero_cuenta}')
    if tipo_moneda:
        print(f'     • Moneda: {tipo_moneda}')
    time.sleep(3)
    if numero_cuenta:
        try:
            cuenta_btn = driver.find_element(AppiumBy.XPATH, f"//android.widget.Button[contains(translate(@content-desc, '\n\r', '  '), 'Banco FIE (Propia)') and contains(translate(@content-desc, '\n\r', '  '), '{numero_cuenta}')]")
            cuenta_btn.click()
            print(f'  ✅ Cuenta destino seleccionada (translate + número)')
            time.sleep(2)
            return True
        except:
            try:
                cuenta_btn = driver.find_element(AppiumBy.XPATH, f"//android.widget.Button[contains(translate(@content-desc, '\n\r', '  '), '{numero_cuenta}')]")
                cuenta_btn.click()
                print(f'  ✅ Cuenta destino seleccionada (fallback)')
                time.sleep(2)
                return True
            except Exception as e:
                print(f'  ❌ No se encontró la cuenta {numero_cuenta}: {e}')
                return False
    if tipo_moneda:
        try:
            cuenta_btn = driver.find_element(AppiumBy.XPATH, f"//android.widget.Button[contains(translate(@content-desc, '\n\r', '  '), 'Banco FIE (Propia)') and contains(translate(@content-desc, '\n\r', '  '), '{tipo_moneda}')]")
            cuenta_btn.click()
            print(f'  ✅ Cuenta destino seleccionada (por moneda)')
            time.sleep(2)
            return True
        except Exception as e:
            print(f"  ❌ No se encontró cuenta con moneda '{tipo_moneda}': {e}")
            return False
    try:
        cuentas = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[contains(translate(@content-desc, '\n\r', '  '), 'Banco FIE (Propia)')]")
        if not cuentas:
            print('  ❌ No se encontraron cuentas propias')
            return False
        target = cuentas[index] if len(cuentas) > index else cuentas[0]
        target.click()
        print(f'  ✅ Cuenta destino seleccionada (índice {index})')
        time.sleep(2)
        return True
    except Exception as e:
        print(f'  ❌ Error al seleccionar cuenta destino: {e}')
        return False

def select_source_account(driver, numero_cuenta=None, tipo_cuenta=None, index=0):
    print(f'  📝 Seleccionando cuenta origen...')
    if numero_cuenta:
        print(f'     • Número: {numero_cuenta}')
    if tipo_cuenta:
        print(f'     • Tipo: {tipo_cuenta}')
    time.sleep(3)
    try:
        account_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(translate(@content-desc, '\n\r', '  '), 'Selecciona una cuenta')]")
        account_btn.click()
        print("  ✅ Click en 'Selecciona una cuenta'")
        time.sleep(2)
    except:
        try:
            account_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Selecciona una cuenta') and @clickable='true']")
            account_btn.click()
            print("  ✅ Click en 'Selecciona una cuenta' (texto)")
            time.sleep(2)
        except Exception as e:
            print(f"  ❌ No se encontró 'Selecciona una cuenta': {e}")
            return False
    time.sleep(2)
    seleccionado = False
    if numero_cuenta:
        try:
            account_btn = driver.find_element(AppiumBy.XPATH, f"//*[@clickable='true' and contains(translate(@content-desc, '\n\r', '  '), '{numero_cuenta}')]")
            account_btn.click()
            print(f'  ✅ Cuenta origen seleccionada: {numero_cuenta}')
            seleccionado = True
        except:
            pass
    if not seleccionado and tipo_cuenta:
        try:
            account_btn = driver.find_element(AppiumBy.XPATH, f"//*[@clickable='true' and contains(translate(@content-desc, '\n\r', '  '), '{tipo_cuenta}')]")
            account_btn.click()
            print(f'  ✅ Cuenta origen seleccionada: {tipo_cuenta}')
            seleccionado = True
        except:
            pass
    if not seleccionado:
        try:
            cuentas = driver.find_elements(AppiumBy.XPATH, "//*[@clickable='true' and contains(translate(@content-desc, '\n\r', '  '), 'CUENTA')]")
            if cuentas and len(cuentas) > index:
                cuentas[index].click()
                print(f'  ✅ Cuenta origen seleccionada (índice {index})')
                seleccionado = True
            elif cuentas:
                cuentas[0].click()
                print(f'  ✅ Primera cuenta origen seleccionada')
                seleccionado = True
        except:
            pass
    if not seleccionado:
        try:
            account_btn = driver.find_element(AppiumBy.XPATH, "//*[@clickable='true' and contains(translate(@content-desc, '\n\r', '  '), 'CUENTA DE AHORRO')]")
            account_btn.click()
            print('  ✅ Cuenta AHORRO seleccionada (fallback)')
            seleccionado = True
        except:
            pass
    if not seleccionado:
        print('  ❌ No se pudo seleccionar la cuenta origen')
        return False
    time.sleep(2)
    return True

def enter_amount(driver, monto):
    print(f'  📝 Ingresando monto: {monto}')
    time.sleep(2)
    try:
        amount_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='0.00']")
        amount_input.click()
        time.sleep(1)
        amount_input.clear()
        amount_input.send_keys(str(monto))
        print('  ✅ Monto ingresado')
        try:
            driver.hide_keyboard()
            time.sleep(1)
        except:
            try:
                driver.execute_script('mobile: clickGesture', {'x': 540, 'y': 1500})
                time.sleep(1)
            except:
                pass
        return True
    except:
        try:
            amount_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='Monto']")
            amount_input.click()
            time.sleep(1)
            amount_input.clear()
            amount_input.send_keys(str(monto))
            print('  ✅ Monto ingresado (fallback)')
            try:
                driver.hide_keyboard()
                time.sleep(1)
            except:
                pass
            return True
        except Exception as e:
            print(f'  ❌ Error al ingresar monto: {e}')
            return False

def enter_concept(driver, concepto):
    print(f'  📝 Ingresando concepto: {concepto}')
    time.sleep(2)
    try:
        concept_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='Mín. 5 Caracteres']")
    except:
        print('  ❌ No se encontró el campo de concepto')
        return False
    try:
        concept_input.click()
        time.sleep(1)
        concept_input.clear()
        time.sleep(0.5)
        concept_input.send_keys(concepto)
        print('  ✅ Concepto ingresado')
    except Exception as e:
        print(f'  ⚠️ Error al escribir concepto: {e}')
        return False
    try:
        driver.hide_keyboard()
        time.sleep(1)
    except:
        try:
            driver.execute_script('mobile: clickGesture', {'x': 540, 'y': 1500})
            time.sleep(1)
        except:
            pass
    return True

def click_continuar_transfer(driver):
    print('  📝 Click en Continuar (transferencia)...')
    time.sleep(1)
    try:
        driver.hide_keyboard()
        time.sleep(1)
    except:
        pass
    try:
        continuar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")
        continuar_btn.click()
        print('  ✅ Click en Continuar')
        time.sleep(3)
        return True
    except:
        try:
            continuar_btn = driver.find_element(AppiumBy.ACCESSIBILITY_ID, 'Continuar')
            continuar_btn.click()
            print('  ✅ Click en Continuar (Accessibility)')
            time.sleep(3)
            return True
        except:
            print('  ❌ Error al clickear Continuar')
            return False

def click_confirmar(driver):
    print('  📝 Click en Confirmar...')
    time.sleep(1)
    try:
        confirmar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Confirmar')]")
        confirmar_btn.click()
        print('  ✅ Click en Confirmar')
        time.sleep(3)
        return True
    except:
        print('  ❌ Error al clickear Confirmar')
        return False

def verify_transfer_success(driver):
    print('  📝 Verificando transferencia...')
    time.sleep(6)
    try:
        driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Transferencia exitosa')]")
        print('  ✅ TRANSFERENCIA EXITOSA!')
        return True
    except:
        pass
    print('  ⚠️ No se pudo verificar el estado de la transferencia')
    return False

def realizar_transferencia(driver, monto, concepto, destino_numero_cuenta=None, destino_moneda=None, destino_index=0, origen_numero_cuenta=None, origen_tipo_cuenta=None, origen_index=0, tiempos=None, reporte=None, paso_inicial=6):
    print(f'\n💰 INICIANDO TRANSFERENCIA de Bs. {monto}')
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('T1. Navegar a Transferencias')
    if not navigate_to_transfer(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla Transferencias', 'Se accedió a la pantalla de Transferencias desde el home.', espera=2.0)
    paso_num += 1
    tiempos.start('T2. Seleccionar cuenta destino')
    if not select_destino_cuenta_propia(driver, numero_cuenta=destino_numero_cuenta, tipo_moneda=destino_moneda, index=destino_index):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Cuenta destino seleccionada', f"Se seleccionó la cuenta destino: {destino_numero_cuenta or 'N/A'}.", espera=1.5)
    paso_num += 1
    tiempos.start('T3. Seleccionar cuenta origen')
    if not select_source_account(driver, numero_cuenta=origen_numero_cuenta, tipo_cuenta=origen_tipo_cuenta, index=origen_index):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Cuenta origen seleccionada', f"Se seleccionó la cuenta de origen: {origen_tipo_cuenta or 'N/A'}.", espera=1.5)
    paso_num += 1
    tiempos.start('T4. Ingresar monto')
    if not enter_amount(driver, monto):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Monto: Bs. {monto}', f'Se ingresó el monto de la transferencia: Bs. {monto}.', espera=1.0)
    paso_num += 1
    tiempos.start('T5. Ingresar concepto')
    if not enter_concept(driver, concepto):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Concepto: {concepto}', f"Se ingresó el concepto: '{concepto}'.", espera=1.0)
    paso_num += 1
    tiempos.start('T6. Continuar')
    if not click_continuar_transfer(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Continuar (transferencia)', 'Se hizo clic en Continuar. Se avanzó a la pantalla de verificación.', espera=1.5)
    paso_num += 1
    tiempos.start('T7. Confirmar')
    if not click_confirmar(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Confirmar transferencia', f'Se confirmó la transferencia por Bs. {monto}.', espera=1.5)
    paso_num += 1
    tiempos.start('T8. Verificar transferencia')
    success = verify_transfer_success(driver)
    tiempos.stop()
    if reporte:
        estado_txt = 'exitosa' if success else 'con estado desconocido'
        reporte.capturar_paso(paso_num, f'Resultado transferencia: {estado_txt}', f'Se verificó el resultado de la transferencia: {estado_txt}.', espera=1.5)
    paso_num += 1
    tiempos.start('T9. Volver al home')
    go_back_home_from_transfer(driver)
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Transferencia finalizada', 'Se regresó al home tras completar la transferencia.', espera=1.5)
    paso_num += 1
    if success:
        print('\n✅ TRANSFERENCIA COMPLETADA EXITOSAMENTE')
    else:
        print('\n⚠️ TRANSFERENCIA COMPLETADA (estado desconocido)')
    return success

def select_account_type(driver, tipo_cuenta):
    print(f'  📝 Seleccionando tipo de cuenta: {tipo_cuenta}...')
    time.sleep(3)
    try:
        btn = driver.find_element(AppiumBy.XPATH, f"//*[@content-desc='{tipo_cuenta}' and @clickable='true']")
        btn.click()
        print(f"  ✅ Tipo de cuenta '{tipo_cuenta}' seleccionado (exacto)")
        time.sleep(2)
        return True
    except:
        pass
    if _seleccionar_opcion_case_insensitive(driver, tipo_cuenta, timeout=5, debug=False):
        print(f"  ✅ Tipo de cuenta '{tipo_cuenta}' seleccionado (case-insensitive)")
        time.sleep(2)
        return True
    print(f'  ❌ Error al seleccionar tipo de cuenta: {tipo_cuenta}')
    try:
        tabs = driver.find_elements(AppiumBy.XPATH, "//*[@clickable='true' and @content-desc and string-length(@content-desc) < 30]")
        print('  🔍 Tabs visibles:')
        for t in tabs[:10]:
            desc = (t.get_attribute('content-desc') or '').replace('\n', ' | ')
            print(f"     - '{desc}'")
    except:
        pass
    return False

def select_account_by_number(driver, numero_cuenta):
    print(f'  📝 Seleccionando cuenta específica: {numero_cuenta}...')
    time.sleep(2)
    try:
        cuenta = driver.find_element(AppiumBy.XPATH, f"//android.view.View[@clickable='true' and contains(translate(@content-desc, '\n\r', '  '), 'Cuenta') and contains(translate(@content-desc, '\n\r', '  '), '{numero_cuenta}')]")
        cuenta.click()
        print(f'  ✅ Cuenta seleccionada: {numero_cuenta}')
        time.sleep(3)
        return True
    except:
        try:
            cuenta = driver.find_element(AppiumBy.XPATH, f"//android.view.View[@clickable='true' and contains(translate(@content-desc, '\n\r', '  '), '{numero_cuenta}')]")
            cuenta.click()
            print(f'  ✅ Cuenta seleccionada (fallback): {numero_cuenta}')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ No se encontró la cuenta: {numero_cuenta}')
            return False

def click_buscar_movimientos(driver):
    print('  📝 Click en Buscar (abrir formulario)...')
    time.sleep(2)
    try:
        buscar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Buscar' and @clickable='true']")
        buscar_btn.click()
        print('  ✅ Click en Buscar (abrir - content-desc)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        buscar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Buscar') and @clickable='true']")
        buscar_btn.click()
        print('  ✅ Click en Buscar (abrir - texto)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        buscar_btns = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Buscar']")
        if buscar_btns:
            buscar_btns[0].click()
            print('  ✅ Click en Buscar (abrir - primer botón)')
            time.sleep(3)
            return True
    except:
        pass
    print('  ❌ Error al clickear Buscar')
    return False

def fill_criterio_busqueda(driver, criterio=''):
    if not criterio:
        print('  ℹ️ Criterio vacío - saltando campo')
        return True
    print(f'  📝 Ingresando criterio: {criterio}...')
    time.sleep(2)
    try:
        criterio_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='Buscar por criterio']")
        criterio_input.click()
        time.sleep(1)
        criterio_input.clear()
        criterio_input.send_keys(criterio)
        print(f'  ✅ Criterio ingresado: {criterio}')
        try:
            driver.hide_keyboard()
            time.sleep(1)
        except:
            pass
        return True
    except:
        try:
            criterio_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[contains(@hint, 'Buscar')]")
            criterio_input.click()
            time.sleep(1)
            criterio_input.clear()
            criterio_input.send_keys(criterio)
            print(f'  ✅ Criterio ingresado: {criterio}')
            try:
                driver.hide_keyboard()
                time.sleep(1)
            except:
                pass
            return True
        except Exception as e:
            print(f'  ❌ Error al ingresar criterio: {e}')
            return False

def select_tipo_movimiento(driver, tipo='Todos'):
    print(f'  📝 Seleccionando tipo: {tipo}...')
    time.sleep(2)
    tipos_validos = ['Todos', 'Abonos', 'Debitos', 'Transferencias', 'Pago de servicios', 'Giros', 'Prestamos', 'Estados de cuenta']
    if tipo not in tipos_validos:
        print(f"  ⚠️ Tipo '{tipo}' no está en la lista conocida, intentando igual...")
    try:
        driver.swipe(500, 800, 500, 500, 500)
        time.sleep(1)
    except:
        pass
    abierto = False
    for opcion in tipos_validos:
        try:
            tipo_field = driver.find_element(AppiumBy.XPATH, f"//*[@content-desc='{opcion}' and @clickable='true']")
            tipo_field.click()
            print(f"  ✅ Click en combo Tipo (opción actual: '{opcion}')")
            abierto = True
            time.sleep(2)
            break
        except:
            continue
    if not abierto:
        try:
            tipo_field = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Tipo']/following-sibling::*[@clickable='true']")
            tipo_field.click()
            print('  ✅ Click en combo Tipo (por label)')
            abierto = True
            time.sleep(2)
        except:
            pass
    if not abierto:
        try:
            tipo_field = driver.find_element(AppiumBy.XPATH, "//*[@text='Tipo']/following-sibling::*[@clickable='true']")
            tipo_field.click()
            print('  ✅ Click en combo Tipo (por label texto)')
            abierto = True
            time.sleep(2)
        except:
            pass
    if not abierto:
        print('  ❌ No se encontró el combo Tipo')
        return False
    time.sleep(2)
    if _seleccionar_opcion_case_insensitive(driver, tipo, timeout=5, debug=True):
        print(f'  ✅ Tipo seleccionado: {tipo}')
        time.sleep(1)
        return True
    print(f"  ❌ No se encontró la opción '{tipo}'")
    return False

def select_fecha(driver, campo, fecha):
    """Selecciona una fecha en el calendario con navegación."""
    print(f'  📝 Seleccionando fecha {campo}: {fecha}...')
    time.sleep(2)
    dia, mes, anio = fecha.split('/')
    dia_int = int(dia)
    mes_int = int(mes)
    anio_int = int(anio)
    meses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre']
    mes_nombre = meses[mes_int - 1]
    try:
        botones = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Elegir en calendario']")
        print(f"  🔍 Encontrados {len(botones)} botones 'Elegir en calendario'")
        if campo == 'Desde':
            if len(botones) > 0:
                botones[0].click()
                print(f"  ✅ Click en 'Elegir en calendario' para Desde")
            else:
                print(f'  ❌ No se encontró el botón para Desde')
                return False
        elif len(botones) > 1:
            botones[1].click()
            print(f"  ✅ Click en 'Elegir en calendario' para Hasta")
        else:
            print(f'  ❌ No se encontró el botón para Hasta')
            return False
        time.sleep(2)
    except Exception as e:
        print(f'  ❌ Error al buscar botones: {e}')
        return False
    time.sleep(3)

    def obtener_mes_actual():
        try:
            titulo_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Enero') or contains(@content-desc, 'Febrero') or contains(@content-desc, 'Marzo') or contains(@content-desc, 'Abril') or contains(@content-desc, 'Mayo') or contains(@content-desc, 'Junio') or contains(@content-desc, 'Julio') or contains(@content-desc, 'Agosto') or contains(@content-desc, 'Septiembre') or contains(@content-desc, 'Octubre') or contains(@content-desc, 'Noviembre') or contains(@content-desc, 'Diciembre')]")
            return titulo_btn.get_attribute('content-desc') or ''
        except:
            return None
    encontrado = False
    for intento in range(24):
        titulo_actual = obtener_mes_actual()
        print(f'  📅 Mes actual: {titulo_actual}')
        if titulo_actual and mes_nombre in titulo_actual and (str(anio_int) in titulo_actual):
            print(f'  ✅ Mes correcto: {mes_nombre} {anio_int}')
            encontrado = True
            break
        try:
            mes_actual = None
            for i, nombre_mes in enumerate(meses, 1):
                if nombre_mes in titulo_actual:
                    mes_actual = i
                    break
            anio_actual = None
            años = re.findall('\\d{4}', titulo_actual)
            if años:
                anio_actual = int(años[0])
            if mes_actual and anio_actual:
                diff_meses = (anio_int - anio_actual) * 12 + (mes_int - mes_actual)
                print(f'  📊 Diferencia de meses: {diff_meses}')
                if diff_meses > 0:
                    try:
                        siguiente_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Mes siguiente' and @clickable='true']")
                        siguiente_btn.click()
                        print(f'  🔄 Navegando al siguiente mes...')
                        time.sleep(1)
                    except:
                        try:
                            siguiente_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Mes siguiente']")
                            if siguiente_btn.get_attribute('enabled') == 'true':
                                siguiente_btn.click()
                                print(f'  🔄 Navegando al siguiente mes...')
                                time.sleep(1)
                            else:
                                print(f"  ⚠️ Botón 'Mes siguiente' deshabilitado")
                                break
                        except:
                            print(f'  ⚠️ No se pudo navegar al siguiente mes')
                            break
                elif diff_meses < 0:
                    try:
                        anterior_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Mes anterior' and @clickable='true']")
                        anterior_btn.click()
                        print(f'  🔄 Navegando al mes anterior...')
                        time.sleep(1)
                    except:
                        try:
                            anterior_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Mes anterior']")
                            if anterior_btn.get_attribute('enabled') == 'true':
                                anterior_btn.click()
                                print(f'  🔄 Navegando al mes anterior...')
                                time.sleep(1)
                            else:
                                print(f"  ⚠️ Botón 'Mes anterior' deshabilitado")
                                break
                        except:
                            print(f'  ⚠️ No se pudo navegar al mes anterior')
                            break
                else:
                    encontrado = True
                    break
            else:
                print(f'  ⚠️ No se pudo determinar mes/año actual: {titulo_actual}')
                try:
                    siguiente_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Mes siguiente' and @clickable='true']")
                    siguiente_btn.click()
                    print(f'  🔄 Navegando al siguiente mes (fallback)...')
                    time.sleep(1)
                except:
                    break
        except Exception as e:
            print(f'  ⚠️ Error en navegación: {e}')
            break
    if not encontrado:
        print(f'  ❌ No se encontró el mes {mes_nombre} {anio_int}')
        try:
            driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Cancelar']").click()
            time.sleep(1)
        except:
            pass
        return False
    print(f'  🔄 Haciendo scroll para mostrar todos los días...')
    try:
        driver.swipe(500, 1500, 500, 600, 500)
        time.sleep(1)
    except:
        pass
    time.sleep(1)
    seleccionado = False
    estrategias = [lambda: driver.find_element(AppiumBy.XPATH, f"//*[@text='{dia_int}' and @clickable='true']"), lambda: driver.find_element(AppiumBy.XPATH, f"//*[@content-desc='{dia_int}' and @clickable='true']"), lambda: driver.find_element(AppiumBy.XPATH, f"//*[@text='{dia}' and @clickable='true']"), lambda: driver.find_element(AppiumBy.XPATH, f"//*[@content-desc='{dia}' and @clickable='true']"), lambda: driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{dia_int}') and @clickable='true']"), lambda: driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{dia_int}') and @clickable='true']")]
    for i, estrategia in enumerate(estrategias, 1):
        try:
            dia_btn = estrategia()
            if dia_btn.is_displayed() and dia_btn.is_enabled():
                dia_btn.click()
                print(f'  ✅ Día {dia} seleccionado (estrategia {i})')
                seleccionado = True
                break
        except:
            pass
    if not seleccionado:
        try:
            print(f'  🔍 Buscando día {dia_int} entre todos los días...')
            dias = driver.find_elements(AppiumBy.XPATH, "//*[@clickable='true' and @content-desc and string-length(@content-desc) <= 2]")
            for d in dias:
                desc = d.get_attribute('content-desc') or ''
                if desc.isdigit() and int(desc) == dia_int:
                    d.click()
                    print(f'  ✅ Día {dia} seleccionado (búsqueda entre días)')
                    seleccionado = True
                    break
        except:
            pass
    if not seleccionado:
        print(f'  ❌ No se pudo seleccionar el día {dia}')
        try:
            driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Cancelar']").click()
            time.sleep(1)
        except:
            pass
        return False
    time.sleep(1)
    print(f'  📝 Buscando botón Aceptar para {campo}...')
    try:
        aceptar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Aceptar']")
        if aceptar_btn.is_displayed() and aceptar_btn.is_enabled():
            aceptar_btn.click()
            print(f'  ✅ Fecha {campo} confirmada (click en Aceptar)')
            time.sleep(2)
            return True
    except:
        try:
            aceptar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Aceptar') and @clickable='true']")
            aceptar_btn.click()
            print(f'  ✅ Fecha {campo} confirmada (click en Aceptar - texto)')
            time.sleep(2)
            return True
        except Exception as e:
            print(f'  ❌ No se encontró el botón Aceptar: {e}')
            return False

def click_buscar_ejecutar(driver):
    """Click en 'Buscar' (ejecutar) con 5 estrategias."""
    print('  📝 Ejecutando búsqueda...')
    time.sleep(2)
    try:
        buscar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.ScrollView//android.widget.Button[@content-desc='Buscar']")
        buscar_btn.click()
        print('  ✅ Click en Buscar (ejecutar - ScrollView)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        buscar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Buscar' and @clickable='true' and @selected='false']")
        buscar_btn.click()
        print('  ✅ Click en Buscar (ejecutar - selected=false)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        buscar_btns = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Buscar']")
        print(f"  📊 Botones 'Buscar' encontrados: {len(buscar_btns)}")
        if len(buscar_btns) >= 2:
            buscar_btns[-1].click()
            print('  ✅ Click en Buscar (ejecutar - último botón)')
            time.sleep(3)
            return True
    except:
        pass
    try:
        buscar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Buscar' and @clickable='true']")
        bounds = buscar_btn.get_attribute('bounds') or ''
        if '1973' in bounds or '1974' in bounds:
            buscar_btn.click()
            print('  ✅ Click en Buscar (ejecutar - bounds)')
            time.sleep(3)
            return True
    except:
        pass
    try:
        buscar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.ScrollView//*[contains(@text, 'Buscar') and @clickable='true']")
        buscar_btn.click()
        print('  ✅ Click en Buscar (ejecutar - texto)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al ejecutar búsqueda: {e}')
        return False

def select_movimiento_by_nd(driver, texto_busqueda, monto=None, signo=None, max_scrolls=10, pausa_scroll=0.8, debug=True):
    print(f"  📝 Buscando movimiento con: '{texto_busqueda}'...")
    if monto:
        print(f"  📝 Monto: {(signo if signo else '')}{monto}")
    else:
        print(f'  📝 Monto: (sin filtro)')
    time.sleep(2)
    texto_lower = texto_busqueda.lower() if texto_busqueda else ''
    monto_str = str(monto) if monto is not None else None
    contador = {'n': 0}

    def _listar_movimientos(tag=''):
        xpaths = ["//android.widget.Button[@resource-id='shared_btn_movimiento' and @clickable='true']", "//*[@resource-id='shared_btn_movimiento' and @clickable='true']", "//*[@resource-id='shared_btn_movimiento']", "//*[contains(@resource-id, 'shared_btn_movimiento') and @clickable='true']"]
        for xp in xpaths:
            try:
                movs = driver.find_elements(AppiumBy.XPATH, xp)
                if movs:
                    if debug:
                        print(f"    🔍 [{tag}] XPath '{xp[:80]}' → {len(movs)} elementos")
                    return movs
            except Exception as e:
                if debug:
                    print(f'    ⚠️ [{tag}] XPath falló: {str(e)[:60]}')
        return []

    def _buscar_en_lista_actual(tag=''):
        try:
            movimientos = _listar_movimientos(tag=tag)
            if debug and movimientos:
                for i, m in enumerate(movimientos[:5]):
                    d = (m.get_attribute('content-desc') or '').replace('\n', ' | ')
                    rid = m.get_attribute('resource-id') or ''
                    print(f"       [{i}] id='{rid}', desc='{d[:70]}'")
            if not movimientos:
                if debug:
                    print(f"    ⚠️ [{tag}] No se encontraron elementos con 'shared_btn_movimiento'")
                return False
            for mov in movimientos:
                desc = mov.get_attribute('content-desc') or ''
                desc_lower = desc.lower()
                if texto_lower and texto_lower not in desc_lower:
                    continue
                if monto_str and monto_str not in desc:
                    continue
                if signo:
                    if signo == '+' and '+Bs.' not in desc:
                        continue
                    if signo == '-' and '-Bs.' not in desc:
                        continue
                mov.click()
                driver._last_movimiento_desc = desc
                print(f'  ✅ Movimiento seleccionado: {desc[:100]}...')
                time.sleep(3)
                return True
            return False
        except Exception as e:
            print(f'  ⚠️ Error buscando en lista: {str(e)[:80]}')
            return False
    print('  🔄 Asegurando scroll al TOP...')
    for _ in range(3):
        try:
            driver.swipe(500, 800, 500, 1600, 300)
            time.sleep(0.3)
        except:
            pass
    time.sleep(0.5)
    contador['n'] += 1
    print(f"  🔍 [Intento {contador['n']}] Buscando en TOP...")
    if _buscar_en_lista_actual(tag='TOP'):
        return True
    print('  🔄 Scroll incremental buscando en cada paso...')
    for intento in range(max_scrolls):
        try:
            driver.swipe(500, 1600, 500, 800, 500)
            time.sleep(pausa_scroll)
            contador['n'] += 1
            print(f"  🔍 [Intento {contador['n']}] Después de scroll abajo {intento + 1}/{max_scrolls}")
            if _buscar_en_lista_actual(tag=f'DOWN-{intento + 1}'):
                return True
        except Exception as e:
            print(f'    ⚠️ Error en swipe: {str(e)[:60]}')
    print('  🔄 Volviendo al TOP...')
    for _ in range(max_scrolls + 2):
        try:
            driver.swipe(500, 800, 500, 1600, 300)
            time.sleep(0.2)
        except:
            pass
    time.sleep(0.5)
    contador['n'] += 1
    print(f"  🔍 [Intento {contador['n']}] Buscando de nuevo en TOP...")
    if _buscar_en_lista_actual(tag='TOP-2'):
        return True
    if debug:
        print('\n  🔍 DEBUG FINAL - Volcando lista de movimientos visibles:')
        try:
            movs = _listar_movimientos(tag='DEBUG')
            print(f'  🔍 Total movimientos (todos los XPaths): {len(movs)}')
            for i, mov in enumerate(movs[:10]):
                desc = (mov.get_attribute('content-desc') or '').replace('\n', ' | ')
                rid = mov.get_attribute('resource-id') or ''
                cls = mov.get_attribute('class') or ''
                click = mov.get_attribute('clickable') or 'false'
                print(f"    [{i}] class={cls}, id='{rid}', clickable={click}")
                print(f"         desc='{desc[:120]}'")
        except Exception as e:
            print(f'  ⚠️ Error en debug: {e}')
    print(f"  ❌ No se encontró movimiento con: '{texto_busqueda}'")
    return False

def validar_movimiento_desc(desc, monto_esperado=None, signo_esperado=None):
    print('  🔍 Validando movimiento...')
    detalles = {'desc': desc, 'monto_encontrado': None, 'signo_encontrado': None}
    if not desc:
        print('  ⚠️ Descripción vacía')
        return (False, detalles)
    m = re.search('([+-])?\\s*Bs\\.\\s*([\\d.,]+)', desc)
    if m:
        detalles['signo_encontrado'] = m.group(1)
        detalles['monto_encontrado'] = m.group(2)
        print(f"  📊 Monto detectado: {m.group(1) or ''}Bs. {m.group(2)}")
    ok = True
    if monto_esperado is not None:
        monto_str = str(monto_esperado)
        if monto_str not in desc:
            print(f'  ⚠️ Monto esperado {monto_str} NO aparece en el desc')
            ok = False
        else:
            print(f'  ✅ Monto {monto_str} encontrado en el movimiento')
    if signo_esperado:
        esperado = '+Bs.' if signo_esperado == '+' else '-Bs.'
        if esperado not in desc:
            print(f"  ⚠️ Signo esperado '{esperado}' NO aparece en el desc")
            ok = False
        else:
            print(f"  ✅ Signo '{esperado}' encontrado")
    return (ok, detalles)

def close_movement_modal(driver):
    print('  📝 Cerrando modal de movimiento...')
    time.sleep(3)
    try:
        driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Transferencia') or contains(@content-desc, 'Comprobante') or contains(@content-desc, 'N/d')]")
        print('  ✅ Modal de movimiento detectado')
    except:
        print('  ⚠️ No se detectó modal de movimiento')
    try:
        cerrar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Cerrar']")
        cerrar_btn.click()
        print('  ✅ Click en Cerrar (content-desc)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        cerrar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Cerrar') and @clickable='true']")
        cerrar_btn.click()
        print('  ✅ Click en Cerrar (texto)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        regresar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Regresar']")
        regresar.click()
        print('  ✅ Click en Regresar')
        time.sleep(2)
        return True
    except:
        pass
    try:
        aceptar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Aceptar']")
        aceptar.click()
        print('  ✅ Click en Aceptar')
        time.sleep(2)
        return True
    except:
        pass
    try:
        driver.back()
        print('  ✅ Back para cerrar modal')
        time.sleep(2)
        return True
    except:
        return False

def realizar_consolidado_busqueda(driver, tipo_cuenta='C. AHORRO', numero_cuenta=None, criterio='', tipo_movimiento='Todos', fecha_desde='01/08/2026', fecha_hasta='31/08/2026', texto_movimiento=None, monto_movimiento=None, signo_movimiento=None, tiempos=None, reporte=None, paso_inicial=20):
    print(f'\n📊 INICIANDO CONSOLIDADO CON BÚSQUEDA')
    print(f'🏦 Tipo cuenta: {tipo_cuenta}')
    if numero_cuenta:
        print(f'🏦 Número cuenta: {numero_cuenta}')
    if texto_movimiento:
        print(f'📝 Movimiento: {texto_movimiento}')
        if monto_movimiento:
            print(f"💰 Monto: {(signo_movimiento if signo_movimiento else '')}{monto_movimiento}")
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('C1. Tipo de cuenta')
    if not select_account_type(driver, tipo_cuenta):
        tiempos.stop()
        return (False, None)
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Tipo de cuenta: {tipo_cuenta}', f"Se seleccionó el tipo de cuenta: '{tipo_cuenta}'.", espera=1.5)
    paso_num += 1
    if numero_cuenta:
        tiempos.start('C2. Cuenta específica')
        if not select_account_by_number(driver, numero_cuenta):
            print(f'  ⚠️ No se pudo seleccionar la cuenta {numero_cuenta}, continuando...')
        tiempos.stop()
        if reporte:
            reporte.capturar_paso(paso_num, f'Cuenta específica: {numero_cuenta}', f"Se seleccionó la cuenta específica: '{numero_cuenta}'.", espera=1.5)
        paso_num += 1
    else:
        print('  ⚠️ No se especificó número de cuenta; se usará la primera disponible')
    tiempos.start('C3. Abrir formulario')
    if not click_buscar_movimientos(driver):
        tiempos.stop()
        return (False, None)
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Formulario de búsqueda abierto', 'Se abrió el formulario de búsqueda avanzada de movimientos.', espera=2.0)
    paso_num += 1
    if criterio:
        tiempos.start('C4. Criterio')
        fill_criterio_busqueda(driver, criterio)
        tiempos.stop()
        time.sleep(2)
        if reporte:
            reporte.capturar_paso(paso_num, f'Criterio: {criterio}', f"Se ingresó el criterio de búsqueda: '{criterio}'.", espera=1.0)
        paso_num += 1
    tiempos.start('C5. Tipo movimiento')
    if not select_tipo_movimiento(driver, tipo_movimiento):
        print('  ⚠️ Error al seleccionar tipo, continuando...')
    tiempos.stop()
    time.sleep(2)
    if reporte:
        reporte.capturar_paso(paso_num, f'Tipo movimiento: {tipo_movimiento}', f"Se seleccionó el tipo de movimiento: '{tipo_movimiento}'.", espera=1.0)
    paso_num += 1
    if fecha_desde:
        tiempos.start('C6. Fecha Desde')
        select_fecha(driver, 'Desde', fecha_desde)
        tiempos.stop()
        if reporte:
            reporte.capturar_paso(paso_num, f'Fecha Desde: {fecha_desde}', f'Se seleccionó la fecha Desde: {fecha_desde}.', espera=1.0)
        paso_num += 1
    if fecha_hasta:
        tiempos.start('C7. Fecha Hasta')
        select_fecha(driver, 'Hasta', fecha_hasta)
        tiempos.stop()
        if reporte:
            reporte.capturar_paso(paso_num, f'Fecha Hasta: {fecha_hasta}', f'Se seleccionó la fecha Hasta: {fecha_hasta}.', espera=1.0)
        paso_num += 1
    tiempos.start('C8. Ejecutar búsqueda')
    if not click_buscar_ejecutar(driver):
        tiempos.stop()
        return (False, None)
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Ejecutar búsqueda', 'Se ejecutó la búsqueda con los filtros configurados.', espera=2.0)
    paso_num += 1
    tiempos.start('C9. Seleccionar movimiento')
    desc_mov = None
    if texto_movimiento:
        if not select_movimiento_by_nd(driver, texto_movimiento, monto_movimiento, signo_movimiento):
            print(f'  ❌ No se encontró el movimiento: {texto_movimiento}')
            tiempos.stop()
            return (False, None)
        desc_mov = getattr(driver, '_last_movimiento_desc', None)
    tiempos.stop()
    if reporte:
        desc_mostrar = desc_mov[:120] + '...' if desc_mov and len(desc_mov) > 120 else desc_mov or 'N/A'
        reporte.capturar_paso(paso_num, 'Movimiento encontrado', f'Se seleccionó el movimiento buscado. Desc: {desc_mostrar}', espera=2.0)
    paso_num += 1
    tiempos.start('C10. Cerrar modal')
    close_movement_modal(driver)
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Modal cerrado', 'Se cerró el modal del detalle del movimiento.', espera=1.5)
    paso_num += 1
    tiempos.start('C11. Volver atrás')
    go_back(driver)
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Regreso a pantalla anterior', 'Se regresó a la pantalla anterior (consolidado).', espera=1.0)
    paso_num += 1
    print('\n✅ CONSOLIDADO CON BÚSQUEDA COMPLETADO')
    return (True, desc_mov)

def transferir_y_validar(driver, monto, concepto, destino_numero_cuenta=None, destino_moneda=None, destino_index=0, origen_numero_cuenta=None, origen_tipo_cuenta=None, origen_index=0, validar_tipo_cuenta='C. AHORRO', validar_numero_cuenta=None, validar_criterio='', validar_tipo_movimiento='Transferencias', validar_fecha_desde=None, validar_fecha_hasta=None, validar_texto_movimiento=None, validar_monto=None, validar_signo=None, tiempos=None, reporte=None, paso_inicial=6):
    print(f'\n🔗 FLUJO UNIFICADO: TRANSFERENCIA + VALIDACIÓN')
    print('=' * 60)
    if tiempos is None:
        tiempos = Tiempos()
    resultado = {'transferencia_ok': False, 'consolidado_ok': False, 'movimiento_encontrado': False, 'movimiento_desc': None, 'validacion_ok': False}
    paso_num = paso_inicial
    tiempos.start('T. Transferencia')
    resultado['transferencia_ok'] = realizar_transferencia(driver, monto=monto, concepto=concepto, destino_numero_cuenta=destino_numero_cuenta, destino_moneda=destino_moneda, destino_index=destino_index, origen_numero_cuenta=origen_numero_cuenta, origen_tipo_cuenta=origen_tipo_cuenta, origen_index=origen_index, tiempos=tiempos, reporte=reporte, paso_inicial=paso_num)
    tiempos.stop()
    paso_num += 9
    if not resultado['transferencia_ok']:
        print('\n❌ Transferencia fallida, no se puede validar el movimiento')
        return resultado
    print('\n⏳ Esperando 5s para que el sistema registre el movimiento...')
    time.sleep(5)
    tiempos.start('V. Consolidado')
    cons_ok, desc_mov = realizar_consolidado_busqueda(driver, tipo_cuenta=validar_tipo_cuenta, numero_cuenta=validar_numero_cuenta, criterio=validar_criterio, tipo_movimiento=validar_tipo_movimiento, fecha_desde=validar_fecha_desde, fecha_hasta=validar_fecha_hasta, texto_movimiento=validar_texto_movimiento, monto_movimiento=validar_monto, signo_movimiento=validar_signo, tiempos=tiempos, reporte=reporte, paso_inicial=paso_num)
    tiempos.stop()
    pasos_cons = 11
    if validar_criterio:
        pasos_cons += 1
    if validar_fecha_desde:
        pasos_cons += 1
    if validar_fecha_hasta:
        pasos_cons += 1
    paso_num += pasos_cons
    resultado['consolidado_ok'] = cons_ok
    resultado['movimiento_encontrado'] = cons_ok and desc_mov is not None
    resultado['movimiento_desc'] = desc_mov
    if resultado['movimiento_encontrado']:
        tiempos.start('W. Validación')
        val_ok, detalles = validar_movimiento_desc(desc_mov, monto_esperado=validar_monto, signo_esperado=validar_signo)
        resultado['validacion_ok'] = val_ok
        resultado['detalles'] = detalles
        tiempos.stop()
        if reporte:
            estado = '✅ OK' if val_ok else '❌ FALLÓ'
            reporte.capturar_paso(paso_num, f'Validación del movimiento: {estado}', f"Se validó el movimiento encontrado contra los criterios. Resultado: {estado}. Desc: {(desc_mov or '')[:120]}", espera=1.5)
        paso_num += 1
    else:
        print('\n⚠️ No se encontró el movimiento, no se puede validar')
        if reporte:
            reporte.capturar_paso(paso_num, 'Validación no aplicable', 'No se encontró el movimiento, no se realizó la validación.', espera=1.0)
        paso_num += 1
    print('\n' + '=' * 60)
    print('📊 RESULTADO DEL FLUJO UNIFICADO')
    print('=' * 60)
    print(f"  Transferencia        : {('✅ OK' if resultado['transferencia_ok'] else '❌ FALLÓ')}")
    print(f"  Consolidado          : {('✅ OK' if resultado['consolidado_ok'] else '❌ FALLÓ')}")
    print(f"  Movimiento encontrado: {('✅ SÍ' if resultado['movimiento_encontrado'] else '❌ NO')}")
    print(f"  Validación monto     : {('✅ OK' if resultado['validacion_ok'] else '❌ FALLÓ')}")
    if resultado['movimiento_desc']:
        print(f"  Desc movimiento      : {resultado['movimiento_desc'][:100]}...")
    print('=' * 60)
    return resultado
if __name__ == '__main__':
    _input_cfg = load_input_defaults('validacion_transfer_y_validar_movimiento_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO UNIFICADO: TRANSFERENCIA + VALIDACIÓN DE MOVIMIENTO + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    MONTO = _input_cfg.get('MONTO', 1)
    CONCEPTO = _input_cfg.get('CONCEPTO', 'Transferencia prueba 3')
    DESTINO_NUMERO_CUENTA = _input_cfg.get('DESTINO_NUMERO_CUENTA', '40-0-1189577-1')
    DESTINO_MONEDA = _input_cfg.get('DESTINO_MONEDA', None)
    DESTINO_INDEX = _input_cfg.get('DESTINO_INDEX', 0)
    ORIGEN_NUMERO_CUENTA = _input_cfg.get('ORIGEN_NUMERO_CUENTA', None)
    ORIGEN_TIPO_CUENTA = _input_cfg.get('ORIGEN_TIPO_CUENTA', 'CUENTA DE AHORRO')
    ORIGEN_INDEX = _input_cfg.get('ORIGEN_INDEX', 0)
    VALIDAR_TIPO_CUENTA = _input_cfg.get('VALIDAR_TIPO_CUENTA', 'C. AHORRO')
    VALIDAR_NUMERO_CUENTA = _input_cfg.get('VALIDAR_NUMERO_CUENTA', '40-0-1189577-1')
    VALIDAR_CRITERIO = _input_cfg.get('VALIDAR_CRITERIO', '')
    VALIDAR_TIPO_MOVIMIENTO = _input_cfg.get('VALIDAR_TIPO_MOVIMIENTO', 'Transferencias')
    VALIDAR_FECHA_DESDE = _input_cfg.get('VALIDAR_FECHA_DESDE', '09/09/2026')
    VALIDAR_FECHA_HASTA = _input_cfg.get('VALIDAR_FECHA_HASTA', '17/09/2026')
    VALIDAR_TEXTO_MOVIMIENTO = _input_cfg.get('VALIDAR_TEXTO_MOVIMIENTO', 'Transferencia prueba 3')
    VALIDAR_MONTO = _input_cfg.get('VALIDAR_MONTO', None)
    VALIDAR_SIGNO = _input_cfg.get('VALIDAR_SIGNO', None)
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Transferencia_Y_Validacion_Movimiento')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f'💰 Monto: Bs. {MONTO}')
    print(f'📝 Concepto: {CONCEPTO}')
    print(f'🎯 Destino: {DESTINO_NUMERO_CUENTA}')
    print(f'🎯 Origen tipo: {ORIGEN_TIPO_CUENTA}')
    print(f'🔎 Validar en: {VALIDAR_TIPO_CUENTA} / {VALIDAR_NUMERO_CUENTA}')
    print(f'🔎 Texto movimiento: {VALIDAR_TEXTO_MOVIMIENTO}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Monto': f'Bs. {MONTO}', 'Concepto': CONCEPTO, 'Cuenta destino': DESTINO_NUMERO_CUENTA or 'N/A', 'Tipo cuenta origen': ORIGEN_TIPO_CUENTA or 'N/A', 'Validar tipo cuenta': VALIDAR_TIPO_CUENTA, 'Validar número cuenta': VALIDAR_NUMERO_CUENTA or 'N/A', 'Tipo movimiento a validar': VALIDAR_TIPO_MOVIMIENTO, 'Fecha desde (validación)': VALIDAR_FECHA_DESDE or 'N/A', 'Fecha hasta (validación)': VALIDAR_FECHA_HASTA or 'N/A', 'Texto movimiento a buscar': VALIDAR_TEXTO_MOVIMIENTO or 'N/A'})
    login_ok = _input_cfg.get('login_ok', False)
    resultado_final = _input_cfg.get('resultado_final', None)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            resultado_final = transferir_y_validar(driver, monto=MONTO, concepto=CONCEPTO, destino_numero_cuenta=DESTINO_NUMERO_CUENTA, destino_moneda=DESTINO_MONEDA, destino_index=DESTINO_INDEX, origen_numero_cuenta=ORIGEN_NUMERO_CUENTA, origen_tipo_cuenta=ORIGEN_TIPO_CUENTA, origen_index=ORIGEN_INDEX, validar_tipo_cuenta=VALIDAR_TIPO_CUENTA, validar_numero_cuenta=VALIDAR_NUMERO_CUENTA, validar_criterio=VALIDAR_CRITERIO, validar_tipo_movimiento=VALIDAR_TIPO_MOVIMIENTO, validar_fecha_desde=VALIDAR_FECHA_DESDE, validar_fecha_hasta=VALIDAR_FECHA_HASTA, validar_texto_movimiento=VALIDAR_TEXTO_MOVIMIENTO, validar_monto=VALIDAR_MONTO, validar_signo=VALIDAR_SIGNO, tiempos=tiempos, reporte=reporte, paso_inicial=6)
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        extras = {}
        if resultado_final:
            extras = {'Resultado Transferencia': 'OK' if resultado_final['transferencia_ok'] else 'FALLÓ', 'Resultado Consolidado': 'OK' if resultado_final['consolidado_ok'] else 'FALLÓ', 'Movimiento encontrado': 'SÍ' if resultado_final['movimiento_encontrado'] else 'NO', 'Validación monto': 'OK' if resultado_final['validacion_ok'] else 'FALLÓ', 'Descripción movimiento': resultado_final.get('movimiento_desc') or 'N/A'}
        resultado_global = 'EXITOSO' if login_ok and resultado_final and resultado_final['transferencia_ok'] and resultado_final['validacion_ok'] else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global, extras=extras)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login          : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        if resultado_final:
            print(f"   Transferencia  : {('✅ OK' if resultado_final['transferencia_ok'] else '❌ FALLÓ')}")
            print(f"   Consolidado    : {('✅ OK' if resultado_final['consolidado_ok'] else '❌ FALLÓ')}")
            print(f"   Validación     : {('✅ OK' if resultado_final['validacion_ok'] else '❌ FALLÓ')}")
        else:
            print(f'   Flujo completo : ❌ FALLÓ')
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

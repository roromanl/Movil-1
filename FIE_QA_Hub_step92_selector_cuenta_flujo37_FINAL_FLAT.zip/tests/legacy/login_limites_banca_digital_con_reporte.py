"""
Flujo Límites en Banca Digital + reporte Word.
Pasos: Login → Más → Límites en banca digital → Configurar límites
       → Continuar → Clave temporal → Confirmar → Éxito → Inicio
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import volver_atras_limites, volver_home__96ad0b4a5a as volver_home
from framework.common.ui_helpers import _esta_en_home as _esta_en_home

def click_mas_menu(driver, timeout=10):
    """Click en el menú Más del home"""
    print('  📝 Click en menú Más...')
    time.sleep(2)
    try:
        mas_btn = driver.find_element(AppiumBy.ID, 'home_btn_mas')
        mas_btn.click()
        print('  ✅ Click en Más (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        mas_btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Más\nMás' and @clickable='true']")
        mas_btn.click()
        print('  ✅ Click en Más (content-desc exacto)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        mas_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Más') and @clickable='true']")
        mas_btn.click()
        print('  ✅ Click en Más (content-desc contains)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al clickear Más: {e}')
        return False

def select_limites_mas(driver):
    """Selecciona Límites en banca digital"""
    print('  📝 Seleccionando Límites en banca digital...')
    time.sleep(2)
    try:
        driver.swipe(500, 1500, 500, 800, 500)
        time.sleep(1)
    except:
        pass
    try:
        limites_btn = driver.find_element(AppiumBy.ID, 'more_btn_limites')
        limites_btn.click()
        print('  ✅ Click en Límites en banca digital (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        limites_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Límites en banca digital')]")
        limites_btn.click()
        print('  ✅ Click en Límites en banca digital (content-desc)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al seleccionar Límites: {e}')
        return False

def escribir_limite(driver, campo, valor, timeout=15):
    print(f'  📝 Escribiendo {valor} en campo {campo}...')
    time.sleep(1)
    resource_id = 'more_limits_input_transaccion' if campo == 'transaccion' else 'more_limits_input_periodo'
    try:
        if campo == 'periodo':
            driver.swipe(500, 1500, 500, 800, 500)
            time.sleep(0.5)
    except:
        pass
    edit_text = None
    try:
        input_container = driver.find_element(AppiumBy.ID, resource_id)
        try:
            edit_text = input_container.find_element(AppiumBy.CLASS_NAME, 'android.widget.EditText')
        except:
            edit_text = input_container
    except:
        pass
    if edit_text is None:
        try:
            edit_text = driver.find_element(AppiumBy.XPATH, f"//android.widget.EditText[@resource-id='{resource_id}']/android.widget.EditText")
        except:
            pass
    if edit_text is None:
        try:
            edit_text = driver.find_element(AppiumBy.XPATH, f"//*[@resource-id='{resource_id}']//android.widget.EditText")
        except:
            pass
    if edit_text is None:
        try:
            edit_texts = driver.find_elements(AppiumBy.CLASS_NAME, 'android.widget.EditText')
            for e in edit_texts:
                try:
                    if e.is_displayed() and e.is_enabled():
                        edit_text = e
                        break
                except:
                    continue
        except:
            pass
    if edit_text is None:
        print(f'  ❌ No se encontró el campo {campo}')
        return False
    try:
        edit_text.click()
        time.sleep(0.5)
        edit_text.clear()
        time.sleep(0.3)
        edit_text.send_keys(str(valor))
        print(f'  ✅ Valor {valor} escrito en campo {campo}')
        try:
            driver.hide_keyboard()
        except:
            pass
        time.sleep(0.5)
        return True
    except Exception as e:
        print(f'  ❌ Error al escribir en campo {campo}: {e}')
        return False

def presionar_boton_limite(driver, campo, boton, timeout=10):
    print(f'  📝 Presionando botón {boton} en campo {campo}...')
    time.sleep(1)
    resource_ids = {'transaccion': {'-10000': 'more_limits_pin_transaccion_-10000', '-1000': 'more_limits_pin_transaccion_-1000', '-500': 'more_limits_pin_transaccion_-500', '+500': 'more_limits_pin_transaccion_500', '+1000': 'more_limits_pin_transaccion_1000', '+10000': 'more_limits_pin_transaccion_10000'}, 'periodo': {'-10000': 'more_limits_pin_periodo_-10000', '-1000': 'more_limits_pin_periodo_-1000', '-500': 'more_limits_pin_periodo_-500', '+500': 'more_limits_pin_periodo_500', '+1000': 'more_limits_pin_periodo_1000', '+10000': 'more_limits_pin_periodo_10000'}}
    if campo not in resource_ids:
        print(f"  ❌ Campo '{campo}' no válido")
        return False
    if boton not in resource_ids[campo]:
        print(f"  ❌ Botón '{boton}' no válido")
        return False
    rid = resource_ids[campo][boton]
    try:
        btn = driver.find_element(AppiumBy.ID, rid)
        btn.click()
        print(f'  ✅ Botón {boton} presionado (ID)')
        time.sleep(0.5)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, f"//*[@resource-id='{rid}']")
        btn.click()
        print(f'  ✅ Botón {boton} presionado (XPATH resource-id)')
        time.sleep(0.5)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, f"//android.widget.Button[@content-desc='{boton}']")
        btn.click()
        print(f'  ✅ Botón {boton} presionado (content-desc)')
        time.sleep(0.5)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, f"//*[@text='{boton}' and @clickable='true']")
        btn.click()
        print(f'  ✅ Botón {boton} presionado (text)')
        time.sleep(0.5)
        return True
    except Exception as e:
        print(f'  ❌ Error al presionar botón {boton}: {e}')
        return False

def click_continuar_limites(driver):
    print('  📝 Click en Continuar (límites)...')
    time.sleep(2)
    try:
        continuar = driver.find_element(AppiumBy.ID, 'more_limits_btn_continuar')
        continuar.click()
        print('  ✅ Click en Continuar (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        continuar = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='more_limits_btn_continuar']//android.widget.Button[@content-desc='Continuar']")
        continuar.click()
        print('  ✅ Click en Continuar (XPATH)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        continuar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")
        continuar.click()
        print('  ✅ Click en Continuar (content-desc)')
        time.sleep(3)
        return True
    except:
        try:
            continuar = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Continuar') and @clickable='true']")
            continuar.click()
            print('  ✅ Click en Continuar (texto)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Continuar: {e}')
            return False

def ingresar_clave_temporal_limites(driver, clave_temporal='123456'):
    """Ingresa la clave temporal"""
    print(f'  📝 Ingresando clave temporal: {clave_temporal}...')
    time.sleep(2)
    try:
        otp_input = driver.find_element(AppiumBy.ID, 'more_limits_otp_clave')
        try:
            edit_text = otp_input.find_element(AppiumBy.CLASS_NAME, 'android.widget.EditText')
            edit_text.click()
        except:
            otp_input.click()
        time.sleep(0.5)
        otp_input.clear()
        otp_input.send_keys(clave_temporal)
        print(f'  ✅ Clave temporal ingresada (ID)')
        try:
            driver.hide_keyboard()
        except:
            pass
        time.sleep(0.5)
        return True
    except:
        pass
    try:
        otp_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[contains(@hint, 'Clave temporal')]")
        otp_input.click()
        time.sleep(0.5)
        otp_input.clear()
        otp_input.send_keys(clave_temporal)
        print(f'  ✅ Clave temporal ingresada (hint)')
        try:
            driver.hide_keyboard()
        except:
            pass
        time.sleep(0.5)
        return True
    except:
        pass
    try:
        edits = driver.find_elements(AppiumBy.CLASS_NAME, 'android.widget.EditText')
        for e in edits:
            try:
                if e.is_displayed() and (e.get_attribute('text') or '') == '':
                    e.click()
                    time.sleep(0.5)
                    e.send_keys(clave_temporal)
                    print(f'  ✅ Clave temporal ingresada (primer EditText vacío)')
                    try:
                        driver.hide_keyboard()
                    except:
                        pass
                    time.sleep(0.5)
                    return True
            except:
                continue
    except:
        pass
    print('  ⚠️ No se pudo ingresar clave temporal (puede autocompletarse)')
    return True

def click_confirmar_cambio(driver):
    print('  📝 Click en Confirmar cambio...')
    time.sleep(2)
    try:
        confirmar = driver.find_element(AppiumBy.ID, 'shared_btn_confirmar_clave_temporal')
        confirmar.click()
        print('  ✅ Click en Confirmar cambio (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        confirmar = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='shared_btn_confirmar_clave_temporal']//android.widget.Button[@content-desc='Confirmar cambio']")
        confirmar.click()
        print('  ✅ Click en Confirmar cambio (XPATH)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        confirmar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Confirmar')]")
        confirmar.click()
        print('  ✅ Click en Confirmar cambio (content-desc)')
        time.sleep(3)
        return True
    except:
        try:
            confirmar = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Confirmar') and @clickable='true']")
            confirmar.click()
            print('  ✅ Click en Confirmar (texto)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Confirmar cambio: {e}')
            return False

def click_continuar_exito_limites(driver):
    print('  📝 Click en Continuar (modal de éxito)...')
    time.sleep(2)
    try:
        continuar = driver.find_element(AppiumBy.ID, 'more_limits_btn_continuar_exito')
        continuar.click()
        print('  ✅ Click en Continuar (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        continuar = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='more_limits_btn_continuar_exito']//android.widget.Button[@content-desc='Continuar']")
        continuar.click()
        print('  ✅ Click en Continuar (XPATH)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        continuar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")
        continuar.click()
        print('  ✅ Click en Continuar (content-desc)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al clickear Continuar: {e}')
        return False

def realizar_limites_banca_digital(driver, valor_transaccion='5000', boton1_transaccion='-1000', boton2_transaccion='+500', valor_diario='5000', boton1_diario='-1000', boton2_diario='+500', clave_temporal='123456', tiempos=None, reporte=None, paso_inicial=6):
    """Realiza el flujo completo de Límites en Banca Digital"""
    print(f'\n📊 INICIANDO LÍMITES EN BANCA DIGITAL')
    print(f'💰 Límite por transacción: {valor_transaccion}')
    print(f'   Botón 1: {boton1_transaccion}, Botón 2: {boton2_transaccion}')
    print(f'💰 Límite diario acumulado: {valor_diario}')
    print(f'   Botón 1: {boton1_diario}, Botón 2: {boton2_diario}')
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Ir a Más')
    if not click_mas_menu(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Menú Más abierto', "Se accedió al menú 'Más' desde la barra de navegación inferior.", espera=1.5)
    paso_num += 1
    tiempos.start('2. Límites banca digital')
    if not select_limites_mas(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla Límites en banca digital', 'Se accedió a la pantalla de configuración de límites en banca digital. Se muestran los campos de límite por transacción y límite diario acumulado.', espera=2.0)
    paso_num += 1
    print('  📝 Esperando carga de pantalla de límites...')
    time.sleep(3)
    tiempos.start('3. Escribir transacción')
    if not escribir_limite(driver, 'transaccion', valor_transaccion):
        print('  ⚠️ Error al escribir límite por transacción, continuando...')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Límite transacción = {valor_transaccion}', f'Se estableció el límite por transacción en {valor_transaccion}.', espera=1.0)
    paso_num += 1
    tiempos.start('4. Botones transacción')
    if not presionar_boton_limite(driver, 'transaccion', boton1_transaccion):
        print('  ⚠️ Error al presionar botón 1 en transacción, continuando...')
    if not presionar_boton_limite(driver, 'transaccion', boton2_transaccion):
        print('  ⚠️ Error al presionar botón 2 en transacción, continuando...')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Ajustes aplicados en transacción', f'Se aplicaron los ajustes: {boton1_transaccion}, {boton2_transaccion} en el límite por transacción.', espera=1.0)
    paso_num += 1
    tiempos.start('5. Escribir diario')
    if not escribir_limite(driver, 'periodo', valor_diario):
        print('  ⚠️ Error al escribir límite diario, continuando...')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Límite diario = {valor_diario}', f'Se estableció el límite diario acumulado en {valor_diario}.', espera=1.0)
    paso_num += 1
    tiempos.start('6. Botones diario')
    if not presionar_boton_limite(driver, 'periodo', boton1_diario):
        print('  ⚠️ Error al presionar botón 1 en diario, continuando...')
    if not presionar_boton_limite(driver, 'periodo', boton2_diario):
        print('  ⚠️ Error al presionar botón 2 en diario, continuando...')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Ajustes aplicados en diario', f'Se aplicaron los ajustes: {boton1_diario}, {boton2_diario} en el límite diario.', espera=1.0)
    paso_num += 1
    tiempos.start('7. Continuar (límites)')
    if not click_continuar_limites(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Continuar (configuración de límites)', 'Se hizo clic en Continuar para avanzar al paso de confirmación.', espera=1.5)
    paso_num += 1
    tiempos.start('8. Clave temporal')
    if not ingresar_clave_temporal_limites(driver, clave_temporal):
        print('  ⚠️ Error al ingresar clave temporal, continuando...')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Clave temporal ingresada', 'Se ingresó la clave temporal para autorizar el cambio de límites.', espera=1.0)
    paso_num += 1
    tiempos.start('9. Confirmar cambio')
    if not click_confirmar_cambio(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Confirmar cambio', 'Se confirmó el cambio de límites en el modal de validación.', espera=1.5)
    paso_num += 1
    tiempos.start('10. Continuar (éxito)')
    if not click_continuar_exito_limites(driver):
        print('  ⚠️ Error al clickear Continuar (modal de éxito)')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Modal de éxito - Cambio aplicado', 'Se mostró el modal de éxito indicando que los límites fueron actualizados correctamente.', espera=1.5)
    paso_num += 1
    tiempos.start('11. Volver atrás')
    if not volver_atras_limites(driver):
        print('  ⚠️ Error al volver atrás')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Regreso a pantalla anterior', 'Se regresó a la pantalla anterior.', espera=1.0)
    paso_num += 1
    tiempos.start('12. Volver al home')
    if not volver_home(driver):
        print('  ⚠️ Error al volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Límites finalizado', 'Se regresó exitosamente al home. El flujo de configuración de límites en banca digital ha terminado.', espera=1.5)
    paso_num += 1
    print('\n✅ LÍMITES EN BANCA DIGITAL COMPLETADO EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('login_limites_banca_digital_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO COMPLETO: LOGIN + LÍMITES EN BANCA DIGITAL + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    VALOR_TRANSACCION = _input_cfg.get('VALOR_TRANSACCION', '5000')
    BOTON1_TRANSACCION = _input_cfg.get('BOTON1_TRANSACCION', '-1000')
    BOTON2_TRANSACCION = _input_cfg.get('BOTON2_TRANSACCION', '+500')
    VALOR_DIARIO = _input_cfg.get('VALOR_DIARIO', '5000')
    BOTON1_DIARIO = _input_cfg.get('BOTON1_DIARIO', '-1000')
    BOTON2_DIARIO = _input_cfg.get('BOTON2_DIARIO', '+500')
    CLAVE_TEMPORAL = _input_cfg.get('CLAVE_TEMPORAL', '123456')
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Limites_Banca_Digital')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f'💰 Límite transacción: {VALOR_TRANSACCION} (botones: {BOTON1_TRANSACCION}, {BOTON2_TRANSACCION})')
    print(f'💰 Límite diario: {VALOR_DIARIO} (botones: {BOTON1_DIARIO}, {BOTON2_DIARIO})')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Límite por transacción': VALOR_TRANSACCION, 'Ajuste transacción 1': BOTON1_TRANSACCION, 'Ajuste transacción 2': BOTON2_TRANSACCION, 'Límite diario acumulado': VALOR_DIARIO, 'Ajuste diario 1': BOTON1_DIARIO, 'Ajuste diario 2': BOTON2_DIARIO})
    login_ok = _input_cfg.get('login_ok', False)
    limites_ok = _input_cfg.get('limites_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            limites_ok = realizar_limites_banca_digital(driver, valor_transaccion=VALOR_TRANSACCION, boton1_transaccion=BOTON1_TRANSACCION, boton2_transaccion=BOTON2_TRANSACCION, valor_diario=VALOR_DIARIO, boton1_diario=BOTON1_DIARIO, boton2_diario=BOTON2_DIARIO, clave_temporal=CLAVE_TEMPORAL, tiempos=tiempos, reporte=reporte, paso_inicial=6)
            if limites_ok:
                print('\n🎉 LÍMITES EN BANCA DIGITAL EXITOSO!')
            else:
                print('\n❌ LÍMITES EN BANCA DIGITAL FALLIDO')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and limites_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login          : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Límites        : {('✅ OK' if limites_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

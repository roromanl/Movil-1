"""
Flujo Tarjetas de Débito → Bloqueo/Desbloqueo + reporte Word.
Pasos: Login → Más → Tarjetas de débito → Bloqueo de tarjeta
       → (Tipo/Motivo/Fecha según acción) → Continuar → Confirmar
       → Éxito → Regresar → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import re
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import volver_atras__577b1f7cf5 as volver_atras, volver_home__665e4231ff as volver_home

def click_mas_menu(driver):
    print('  📝 Click en menú Más...')
    wait = WebDriverWait(driver, 5)
    try:
        mas_btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'home_btn_mas')))
        mas_btn.click()
        print('  ✅ Click en Más (ID)')
        time.sleep(3)
        return True
    except:
        try:
            mas_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Más\nMás']")
            mas_btn.click()
            print('  ✅ Click en Más (content-desc)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Más: {e}')
            return False

def click_tarjetas_debito_mas(driver):
    """En el menú Más, hace click en 'Tarjetas de débito'."""
    print("  📝 Seleccionando 'Tarjetas de débito'...")
    wait = WebDriverWait(driver, 10)
    try:
        btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'more_btn_tarjetas')))
        btn.click()
        print("  ✅ Click en 'Tarjetas de débito' (ID)")
        time.sleep(3)
        return True
    except:
        try:
            btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Tarjetas de débito')]")
            btn.click()
            print("  ✅ Click en 'Tarjetas de débito' (content-desc)")
            time.sleep(3)
            return True
        except Exception as e:
            print(f"  ❌ Error al seleccionar 'Tarjetas de débito': {e}")
            return False

def click_bloqueo_tarjeta(driver):
    """En 'Administración de tarjeta de débito', click en 'Bloqueo de tarjeta'."""
    print("  📝 Seleccionando 'Bloqueo de tarjeta'...")
    wait = WebDriverWait(driver, 10)
    try:
        btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'cards_btn_bloqueo')))
        btn.click()
        print("  ✅ Click en 'Bloqueo de tarjeta' (ID)")
        time.sleep(3)
        return True
    except:
        try:
            btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Bloqueo de tarjeta')]")
            btn.click()
            print("  ✅ Click en 'Bloqueo de tarjeta' (content-desc)")
            time.sleep(3)
            return True
        except Exception as e:
            print(f"  ❌ Error al seleccionar 'Bloqueo de tarjeta': {e}")
            return False

def tarjeta_esta_bloqueada(driver, timeout=5):
    print('  📝 Verificando estado de la tarjeta...')
    wait = WebDriverWait(driver, timeout)
    try:
        switch = wait.until(EC.presence_of_element_located((AppiumBy.ID, 'cards_cb_switch_desbloquear')))
        print("  ⚠️ Tarjeta YA está bloqueada (switch 'Desbloquear tarjeta' visible)")
        return True
    except:
        pass
    try:
        driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Tarjeta de débito bloqueada']")
        print('  ⚠️ Tarjeta YA está bloqueada (content-desc detectado)')
        return True
    except:
        pass
    print('  ℹ️ Tarjeta NO está bloqueada (se puede bloquear)')
    return False

def activar_switch_desbloquear(driver, timeout=15):
    print("  📝 Activando switch 'Desbloquear tarjeta'...")
    wait = WebDriverWait(driver, timeout)
    try:
        switch = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'cards_cb_switch_desbloquear')))
    except:
        try:
            switch = driver.find_element(AppiumBy.XPATH, "//android.widget.Switch[@content-desc='Desbloquear tarjeta']")
        except Exception as e:
            print(f'  ❌ No se encontró el switch de desbloqueo: {e}')
            return False
    try:
        is_checked = switch.get_attribute('checked') == 'true'
        print(f"  🔍 Estado actual del switch: {('Activado' if is_checked else 'Desactivado')}")
        if is_checked:
            print('  ℹ️ El switch ya está activado')
            return True
        switch.click()
        time.sleep(1)
        nuevo = switch.get_attribute('checked') == 'true'
        if nuevo:
            print("  ✅ Switch 'Desbloquear tarjeta' activado")
            return True
        else:
            print('  ⚠️ El switch no cambió al estado esperado')
            return False
    except Exception as e:
        print(f'  ❌ Error al manipular switch: {e}')
        return False

def seleccionar_tipo_bloqueo(driver, tipo_bloqueo, timeout=15):
    print(f'  📝 Seleccionando tipo de bloqueo: {tipo_bloqueo}...')
    wait = WebDriverWait(driver, timeout)
    tipo_norm = tipo_bloqueo.strip().lower()
    if 'definitivo' in tipo_norm:
        rid = 'cards_cb_lock_h'
    elif 'temporal' in tipo_norm:
        rid = 'cards_cb_lock_w'
    else:
        print(f'  ❌ Tipo de bloqueo inválido: {tipo_bloqueo}')
        return False
    try:
        btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, rid)))
        btn.click()
        print(f"  ✅ Click en '{tipo_bloqueo}' (ID)")
        time.sleep(2)
        return True
    except:
        try:
            btn = driver.find_element(AppiumBy.XPATH, f"//android.widget.Button[contains(@content-desc, '{tipo_bloqueo}')]")
            btn.click()
            print(f"  ✅ Click en '{tipo_bloqueo}' (content-desc)")
            time.sleep(2)
            return True
        except Exception as e:
            print(f"  ❌ No se encontró el botón '{tipo_bloqueo}': {e}")
            return False

def seleccionar_motivo_bloqueo(driver, motivo, timeout=15):
    print(f'  📝 Seleccionando motivo: {motivo}...')
    wait = WebDriverWait(driver, timeout)
    try:
        selector = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'cards_cb_motivo')))
        selector.click()
        print('  ✅ Click en selector de motivo (ID)')
        time.sleep(2)
    except:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='cards_cb_motivo']")
            selector.click()
            print('  ✅ Click en selector de motivo (XPATH)')
            time.sleep(2)
        except Exception as e:
            print(f'  ❌ Error al abrir selector de motivo: {e}')
            return False
    try:
        opcion = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, f"//android.view.View[@content-desc='{motivo}']")))
        opcion.click()
        print(f'  ✅ Motivo seleccionado: {motivo}')
        time.sleep(2)
        return True
    except:
        try:
            opcion = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{motivo}')]")
            opcion.click()
            print(f'  ✅ Motivo seleccionado: {motivo} (contains)')
            time.sleep(2)
            return True
        except Exception as e:
            print(f"  ❌ No se encontró el motivo '{motivo}': {e}")
            try:
                opciones = driver.find_elements(AppiumBy.XPATH, "//android.view.View[@content-desc and contains(@content-desc, 'Tarjeta')]")
                print(f"  🔍 Motivos disponibles: {[o.get_attribute('content-desc') for o in opciones]}")
            except:
                pass
            return False

def select_fecha_hasta_bloqueo(driver, fecha, timeout=15):
    """Selecciona la fecha 'Hasta' del bloqueo temporal."""
    print(f"  📝 Seleccionando fecha 'Hasta': {fecha}...")
    time.sleep(2)
    dia, mes, anio = fecha.split('/')
    dia_int = int(dia)
    mes_int = int(mes)
    anio_int = int(anio)
    meses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre']
    mes_nombre = meses[mes_int - 1]
    abierto = False
    try:
        btn_cal = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='cards_cb_date_to_calendario']//android.widget.Button[@content-desc='Elegir en calendario']")
        btn_cal.click()
        print("  ✅ Click en 'Elegir en calendario' (Hasta, resource-id)")
        abierto = True
        time.sleep(3)
    except Exception as e1:
        print(f'  ⚠️ No se encontró botón Hasta por resource-id: {e1}')
    if not abierto:
        try:
            botones = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Elegir en calendario' and @clickable='true']")
            print(f"  🔍 Encontrados {len(botones)} botones 'Elegir en calendario'")
            if len(botones) >= 2:
                botones[1].click()
                print("  ✅ Click en 'Elegir en calendario' para Hasta (botón 2)")
                abierto = True
                time.sleep(3)
            elif len(botones) == 1:
                botones[0].click()
                print("  ✅ Click en 'Elegir en calendario' (botón único)")
                abierto = True
                time.sleep(3)
        except Exception as e2:
            print(f"  ⚠️ Error con botones 'Elegir en calendario': {e2}")
    if not abierto:
        try:
            campo = driver.find_element(AppiumBy.ID, 'cards_cb_date_to')
            campo.click()
            print('  ✅ Click en campo Hasta (ID)')
            abierto = True
            time.sleep(3)
        except Exception as e3:
            print(f'  ❌ No se pudo abrir el calendario: {e3}')
            return False
    time.sleep(3)

    def obtener_mes_actual():
        try:
            titulo_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Enero') or contains(@content-desc, 'Febrero') or contains(@content-desc, 'Marzo') or contains(@content-desc, 'Abril') or contains(@content-desc, 'Mayo') or contains(@content-desc, 'Junio') or contains(@content-desc, 'Julio') or contains(@content-desc, 'Agosto') or contains(@content-desc, 'Septiembre') or contains(@content-desc, 'Octubre') or contains(@content-desc, 'Noviembre') or contains(@content-desc, 'Diciembre')]")
            return titulo_btn.get_attribute('content-desc') or ''
        except:
            return None
    encontrado = False
    for intento in range(24):
        titulo_actual = obtener_mes_actual()
        print(f'  📅 Mes actual: {titulo_actual}')
        if titulo_actual and mes_nombre in titulo_actual and (str(anio_int) in titulo_actual):
            print(f'  ✅ Mes correcto: {mes_nombre} {anio_int}')
            encontrado = True
            break
        try:
            mes_actual = None
            for i, nombre_mes in enumerate(meses, 1):
                if nombre_mes in (titulo_actual or ''):
                    mes_actual = i
                    break
            anio_actual = None
            años = re.findall('\\d{4}', titulo_actual or '')
            if años:
                anio_actual = int(años[0])
            if mes_actual and anio_actual:
                diff_meses = (anio_int - anio_actual) * 12 + (mes_int - mes_actual)
                print(f'  📊 Diferencia de meses: {diff_meses}')
                if diff_meses > 0:
                    siguiente_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Mes siguiente' and @clickable='true']")
                    siguiente_btn.click()
                    print('  🔄 Navegando al siguiente mes...')
                    time.sleep(1)
                elif diff_meses < 0:
                    anterior_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Mes anterior' and @clickable='true']")
                    anterior_btn.click()
                    print('  🔄 Navegando al mes anterior...')
                    time.sleep(1)
                else:
                    encontrado = True
                    break
            else:
                print(f'  ⚠️ No se pudo determinar mes/año: {titulo_actual}')
                try:
                    siguiente_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Mes siguiente' and @clickable='true']")
                    siguiente_btn.click()
                    time.sleep(1)
                except:
                    break
        except Exception as e:
            print(f'  ⚠️ Error en navegación: {e}')
            break
    if not encontrado:
        print(f'  ❌ No se encontró el mes {mes_nombre} {anio_int}')
        try:
            driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Cancelar']").click()
            time.sleep(1)
        except:
            pass
        return False
    print('  🔄 Haciendo scroll para mostrar todos los días...')
    try:
        driver.swipe(500, 1500, 500, 600, 500)
        time.sleep(1)
    except:
        pass
    time.sleep(1)
    seleccionado = False
    estrategias = [lambda: driver.find_element(AppiumBy.XPATH, f"//*[@text='{dia_int}' and @clickable='true']"), lambda: driver.find_element(AppiumBy.XPATH, f"//*[@content-desc='{dia_int}' and @clickable='true']"), lambda: driver.find_element(AppiumBy.XPATH, f"//*[@text='{dia}' and @clickable='true']"), lambda: driver.find_element(AppiumBy.XPATH, f"//*[@content-desc='{dia}' and @clickable='true']"), lambda: driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{dia_int}') and @clickable='true']"), lambda: driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{dia_int}') and @clickable='true']")]
    for i, estrategia in enumerate(estrategias, 1):
        try:
            dia_btn = estrategia()
            if dia_btn.is_displayed() and dia_btn.is_enabled():
                dia_btn.click()
                print(f'  ✅ Día {dia} seleccionado (estrategia {i})')
                seleccionado = True
                break
        except:
            pass
    if not seleccionado:
        try:
            print(f'  🔍 Buscando día {dia_int} entre todos los días...')
            dias = driver.find_elements(AppiumBy.XPATH, "//*[@clickable='true' and @content-desc and string-length(@content-desc) <= 2]")
            for d in dias:
                desc = d.get_attribute('content-desc') or ''
                if desc.isdigit() and int(desc) == dia_int:
                    d.click()
                    print(f'  ✅ Día {dia} seleccionado (búsqueda entre días)')
                    seleccionado = True
                    break
        except:
            pass
    if not seleccionado:
        print(f'  ❌ No se pudo seleccionar el día {dia}')
        try:
            driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Cancelar']").click()
            time.sleep(1)
        except:
            pass
        return False
    time.sleep(1)
    print('  📝 Buscando botón Aceptar...')
    try:
        aceptar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Aceptar']")
        if aceptar_btn.is_displayed() and aceptar_btn.is_enabled():
            aceptar_btn.click()
            print('  ✅ Fecha confirmada (Aceptar)')
            time.sleep(2)
            return True
    except:
        try:
            aceptar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Aceptar') and @clickable='true']")
            aceptar_btn.click()
            print('  ✅ Fecha confirmada (Aceptar - texto)')
            time.sleep(2)
            return True
        except Exception as e:
            print(f'  ❌ No se encontró el botón Aceptar: {e}')
            return False

def seleccionar_periodo_maximo(driver, timeout=15):
    """Click en el botón 'Periodo máximo (58 días)'."""
    print("  📝 Seleccionando 'Periodo máximo (58 días)'...")
    wait = WebDriverWait(driver, timeout)
    try:
        btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'cards_cb_periodo_maximo')))
        btn.click()
        print("  ✅ Click en 'Periodo máximo (58 días)' (ID)")
        time.sleep(2)
        return True
    except:
        try:
            btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Periodo máximo')]")
            btn.click()
            print("  ✅ Click en 'Periodo máximo' (content-desc)")
            time.sleep(2)
            return True
        except Exception as e:
            print(f"  ❌ No se encontró 'Periodo máximo': {e}")
            return False

def click_continuar_bloqueo(driver, timeout=15):
    """Click en 'Continuar' de la pantalla de bloqueo."""
    print('  📝 Click en Continuar (bloqueo)...')
    wait = WebDriverWait(driver, timeout)
    try:
        continuar = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//*[@resource-id='cards_cb_btn_continuar']//android.widget.Button[@content-desc='Continuar']")))
        continuar.click()
        print('  ✅ Click en Continuar (bloqueo)')
        time.sleep(3)
        return True
    except:
        try:
            continuar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")
            continuar.click()
            print('  ✅ Click en Continuar (bloqueo - fallback)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Continuar: {e}')
            return False

def click_confirmar_transaccion_bloqueo(driver, timeout=15):
    print('  📝 Click en Confirmar transacción (bloqueo)...')
    wait = WebDriverWait(driver, timeout)
    try:
        confirmar = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//*[@resource-id='cards_cb_btn_confirmar']//android.widget.Button[@content-desc='Confirmar transacción']")))
        confirmar.click()
        print('  ✅ Click en Confirmar transacción')
        time.sleep(3)
        return True
    except:
        try:
            confirmar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Confirmar transacción']")
            confirmar.click()
            print('  ✅ Click en Confirmar transacción (fallback)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Confirmar: {e}')
            return False

def click_continuar_exito_bloqueo(driver, timeout=15):
    """Click en 'Continuar' en la pantalla de éxito."""
    print('  📝 Click en Continuar (pantalla de éxito)...')
    wait = WebDriverWait(driver, timeout)
    try:
        continuar = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//*[@resource-id='cards_cb_btn_continuar_exito']//android.widget.Button[@content-desc='Continuar']")))
        continuar.click()
        print('  ✅ Click en Continuar (éxito)')
        time.sleep(2)
        return True
    except:
        try:
            continuar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")
            continuar.click()
            print('  ✅ Click en Continuar (éxito - fallback)')
            time.sleep(2)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Continuar (éxito): {e}')
            return False
def seleccionar_tarjeta_por_terminacion(driver, terminacion, max_swipes=10):
    """Centra la tarjeta solicitada. El XML puede contener tarjetas aún no visibles."""
    terminacion = str(terminacion or '').strip()
    if len(terminacion) != 4 or not terminacion.isdigit():
        print('  ❌ La terminación debe tener exactamente 4 dígitos')
        return False

    def tarjetas_visibles():
        """Devuelve solo faces que realmente intersectan el viewport, no todo el XML del pager."""
        width = driver.get_window_size()['width']
        candidates = driver.find_elements(AppiumBy.XPATH, "//*[@resource-id='cards_card_debit_face']")
        visible = []
        for el in candidates:
            try:
                box = el.rect
                desc = el.get_attribute('content-desc') or ''
                intersects = box['x'] < width and (box['x'] + box['width']) > 0 and box['width'] > 0
                if el.is_displayed() and intersects:
                    visible.append((el, box, desc))
            except Exception:
                pass
        return visible

    def esta_centrada(box):
        width = driver.get_window_size()['width']
        centro = box['x'] + box['width'] / 2
        # Tarjeta activa ocupa el centro del carrusel. Tolerancia estrecha para no aceptar una lateral.
        return abs(centro - width / 2) <= width * 0.12

    def buscar_objetivo_visible(etapa):
        visibles = tarjetas_visibles()
        print(f'  🔎 Tarjetas realmente visibles en {etapa}: {len(visibles)}')
        for el,box,desc in visibles:
            clean = desc.replace(chr(10), ' ')
            print(f"     • x={box['x']} w={box['width']} :: {clean}")
            if terminacion in desc:
                if esta_centrada(box):
                    print(f'  ✅ Tarjeta {terminacion} ya está centrada')
                    return True
                print(f'  ℹ️ Tarjeta {terminacion} está en el XML/viewport pero aún no está centrada')
        return False

    # Revisar la posición inicial sin mover el carrusel.
    if buscar_objetivo_visible('vista inicial'):
        return True

    for intento in range(1, max_swipes + 1):
        visibles = tarjetas_visibles()
        objetivo = next(((el,box,desc) for el,box,desc in visibles if terminacion in desc), None)
        try:
            pager = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='cards_ols_pager']")
            pb = pager.rect
            y = pb['y'] + pb['height']//2
            width = driver.get_window_size()['width']
            # Si el objetivo ya asoma a la derecha, mover a izquierda para centrarlo. Si asoma a la izquierda, movimiento inverso.
            if objetivo:
                _,box,_ = objetivo
                centro = box['x'] + box['width']/2
                if centro > width/2:
                    x1,x2 = pb['x'] + int(pb['width']*0.78), pb['x'] + int(pb['width']*0.28)
                else:
                    x1,x2 = pb['x'] + int(pb['width']*0.28), pb['x'] + int(pb['width']*0.78)
            else:
                x1,x2 = pb['x'] + int(pb['width']*0.78), pb['x'] + int(pb['width']*0.28)
            print(f'  ↔️ Desplazando carrusel {intento}/{max_swipes} para centrar {terminacion}...')
            driver.swipe(int(x1), int(y), int(x2), int(y), 550)
        except Exception:
            driver.swipe(820, 600, 260, 600, 550)
        time.sleep(1.2)
        if buscar_objetivo_visible(f'después del desplazamiento {intento}'):
            return True

    print(f'  ❌ No fue posible centrar la tarjeta terminada en {terminacion}')
    return False

def bloqueo_tarjeta_flow(driver, terminacion_tarjeta='', accion='Bloquear', tipo_bloqueo='Bloqueo definitivo', motivo='Tarjeta robada', fecha_hasta='06/11/2026', periodo_maximo=False, tiempos=None, reporte=None, paso_inicial=6):
    print(f'\n🔒 INICIANDO FLUJO BLOQUEO/DESBLOQUEO DE TARJETA')
    print(f'   Acción: {accion}')
    if accion.lower() == 'bloquear':
        print(f'   Tipo: {tipo_bloqueo}')
        if 'definitivo' in tipo_bloqueo.lower():
            print(f'   Motivo: {motivo}')
        elif periodo_maximo:
            print('   Periodo: máximo (58 días)')
        else:
            print(f'   Fecha hasta: {fecha_hasta}')
    print('=' * 60)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Ir a Más')
    if not click_mas_menu(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Menú Más abierto', "Se accedió al menú 'Más' desde la barra de navegación inferior.", espera=1.5)
    paso_num += 1
    tiempos.start('2. Tarjetas de débito')
    if not click_tarjetas_debito_mas(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Administración de tarjeta de débito', "Se accedió a la pantalla 'Administración de tarjeta de débito'.", espera=1.5)
    paso_num += 1
    tiempos.start('3. Bloqueo de tarjeta')
    if not click_bloqueo_tarjeta(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla Bloqueo de tarjeta', "Se accedió a la pantalla de 'Bloqueo de tarjeta'.", espera=1.5)
    paso_num += 1
    print('  📝 Esperando carga de la pantalla de bloqueo...')
    time.sleep(2)
    tiempos.start('4. Seleccionar tarjeta')
    if not seleccionar_tarjeta_por_terminacion(driver, terminacion_tarjeta):
        tiempos.stop(); return False
    tiempos.stop()
    if reporte: reporte.capturar_paso(paso_num, f'Tarjeta **** {terminacion_tarjeta}', f'Se centró la tarjeta terminada en {terminacion_tarjeta}.', espera=1.0)
    paso_num += 1
    ya_bloqueada = tarjeta_esta_bloqueada(driver)
    if reporte:
        estado_txt = 'bloqueada' if ya_bloqueada else 'desbloqueada'
        reporte.capturar_paso(paso_num, f'Estado detectado: tarjeta {estado_txt}', f'Se detectó que la tarjeta actualmente está {estado_txt}.', espera=1.0)
        paso_num += 1
    if accion.lower() == 'desbloquear':
        if not ya_bloqueada:
            print('  ⚠️ Se pidió desbloquear, pero la tarjeta NO está bloqueada.')
            print('     (la pantalla muestra opciones de bloqueo, no el switch)')
            return False
        tiempos.start('4. Activar switch desbloquear')
        if not activar_switch_desbloquear(driver):
            tiempos.stop()
            return False
        tiempos.stop()
        if reporte:
            reporte.capturar_paso(paso_num, "Switch 'Desbloquear tarjeta' activado", "Se activó el switch 'Desbloquear tarjeta' para desbloquear la tarjeta.", espera=1.5)
            paso_num += 1
    else:
        if ya_bloqueada:
            print('  ⚠️ Se pidió bloquear, pero la tarjeta YA está bloqueada.')
            print('     (la pantalla muestra el switch de desbloqueo)')
            print("     Para desbloquear, usa accion='Desbloquear'")
            return False
        tiempos.start('4. Tipo de bloqueo')
        if not seleccionar_tipo_bloqueo(driver, tipo_bloqueo):
            tiempos.stop()
            return False
        tiempos.stop()
        if reporte:
            reporte.capturar_paso(paso_num, f'Tipo de bloqueo: {tipo_bloqueo}', f"Se seleccionó el tipo de bloqueo '{tipo_bloqueo}'.", espera=1.5)
            paso_num += 1
        if 'definitivo' in tipo_bloqueo.lower():
            tiempos.start('5. Motivo')
            if not seleccionar_motivo_bloqueo(driver, motivo):
                tiempos.stop()
                return False
            tiempos.stop()
            if reporte:
                reporte.capturar_paso(paso_num, f'Motivo: {motivo}', f"Se seleccionó el motivo del bloqueo: '{motivo}'.", espera=1.5)
                paso_num += 1
        elif periodo_maximo:
            tiempos.start('6. Periodo máximo')
            if not seleccionar_periodo_maximo(driver):
                tiempos.stop()
                return False
            tiempos.stop()
            if reporte:
                reporte.capturar_paso(paso_num, 'Periodo máximo (58 días)', "Se seleccionó 'Periodo máximo (58 días)' para el bloqueo temporal.", espera=1.5)
                paso_num += 1
        else:
            tiempos.start('6. Fecha hasta')
            if not select_fecha_hasta_bloqueo(driver, fecha_hasta):
                tiempos.stop()
                return False
            tiempos.stop()
            if reporte:
                reporte.capturar_paso(paso_num, f"Fecha 'Hasta' = {fecha_hasta}", f"Se seleccionó la fecha 'Hasta' para el bloqueo temporal: {fecha_hasta}.", espera=1.5)
                paso_num += 1
    tiempos.start('7. Continuar (bloqueo)')
    if not click_continuar_bloqueo(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Continuar (bloqueo)', "Se hizo clic en Continuar. Se abre el modal 'Detalle del cambio'.", espera=1.5)
    paso_num += 1
    print("  📝 Esperando carga del modal 'Detalle del cambio'...")
    time.sleep(3)
    tiempos.start('8. Confirmar transacción')
    if not click_confirmar_transaccion_bloqueo(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Confirmar transacción', "Se confirmó la transacción en el modal 'Detalle del cambio'.", espera=1.5)
    paso_num += 1
    print('  📝 Esperando pantalla de éxito...')
    time.sleep(3)
    tiempos.start('9. Continuar (éxito)')
    if not click_continuar_exito_bloqueo(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Modal de éxito - Cambio aplicado', f"Se mostró el modal de éxito confirmando que la acción '{accion}' se aplicó correctamente.", espera=1.5)
    paso_num += 1
    print('  📝 Esperando volver a la pantalla principal...')
    time.sleep(2)
    tiempos.start('10. Volver atrás')
    if not volver_atras(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Regreso a pantalla anterior', 'Se regresó a la pantalla anterior.', espera=1.0)
    paso_num += 1
    tiempos.start('11. Volver al home')
    if not volver_home(driver):
        print('  ⚠️ No se pudo volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Home - Flujo {accion} finalizado', f"Se regresó exitosamente al home. El flujo de '{accion}' de tarjeta ha terminado.", espera=1.5)
    paso_num += 1
    print(f'\n✅ {accion.upper()} DE TARJETA COMPLETADO EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('mas_tarjetas_debito_bloqueo_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO: LOGIN + TARJETAS DE DÉBITO > BLOQUEO/DESBLOQUEO + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    ACCION = _input_cfg.get('ACCION', 'Bloquear')
    TIPO_BLOQUEO = _input_cfg.get('TIPO_BLOQUEO', 'Bloqueo definitivo')
    MOTIVO = _input_cfg.get('MOTIVO', 'Tarjeta robada')
    FECHA_HASTA = _input_cfg.get('FECHA_HASTA', '06/11/2026')
    PERIODO_MAXIMO = _input_cfg.get('PERIODO_MAXIMO', False)
    NOMBRE_PRUEBA = f'{ACCION}_Tarjeta_Debito'
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f'🔒 Acción: {ACCION}')
    if ACCION.lower() == 'bloquear':
        print(f'🔒 Tipo de bloqueo: {TIPO_BLOQUEO}')
        if 'definitivo' in TIPO_BLOQUEO.lower():
            print(f'📋 Motivo: {MOTIVO}')
        elif PERIODO_MAXIMO:
            print(f'📅 Periodo: máximo (58 días)')
        else:
            print(f'📅 Fecha hasta: {FECHA_HASTA}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    parametros_reporte = {'Acción': ACCION}
    if ACCION.lower() == 'bloquear':
        parametros_reporte['Tipo de bloqueo'] = TIPO_BLOQUEO
        if 'definitivo' in TIPO_BLOQUEO.lower():
            parametros_reporte['Motivo'] = MOTIVO
        elif PERIODO_MAXIMO:
            parametros_reporte['Periodo'] = 'Máximo (58 días)'
        else:
            parametros_reporte['Fecha hasta'] = FECHA_HASTA
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros=parametros_reporte)
    login_ok = _input_cfg.get('login_ok', False)
    bloqueo_ok = _input_cfg.get('bloqueo_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            bloqueo_ok = bloqueo_tarjeta_flow(driver, accion=ACCION, tipo_bloqueo=TIPO_BLOQUEO, motivo=MOTIVO, fecha_hasta=FECHA_HASTA, periodo_maximo=PERIODO_MAXIMO, tiempos=tiempos, reporte=reporte, paso_inicial=6)
            if bloqueo_ok:
                print(f'\n🎉 {ACCION.upper()} DE TARJETA EXITOSO!')
            else:
                print(f'\n❌ {ACCION.upper()} DE TARJETA FALLIDO')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and bloqueo_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login                    : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   {ACCION} tarjeta          : {('✅ OK' if bloqueo_ok else '❌ FALLÓ')}")
        print(f'   Carpeta                  : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

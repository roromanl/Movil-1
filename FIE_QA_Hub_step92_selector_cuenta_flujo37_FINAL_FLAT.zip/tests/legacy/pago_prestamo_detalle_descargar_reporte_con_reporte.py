"""
Flujo Plan de pagos + Descargar Reporte + reporte Word.
Pasos: Login → PRÉSTAMO → Plan de pagos → Scroll al final
       → Descargar reporte → Cerrar reporte → Regresar → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import volver_atras_detalle__7684ec12c9 as volver_atras_detalle, volver_home__ec69435608 as volver_home
from framework.common.ui_helpers import _esta_en_home as _esta_en_home, _seleccionar_opcion_case_insensitive__4318d7731b as _seleccionar_opcion_case_insensitive

def ir_a_prestamo(driver):
    print('  📝 Navegando a PRÉSTAMO...')
    time.sleep(3)
    texto_objetivo = 'PRÉSTAMO'
    texto_lower = texto_objetivo.lower()

    def _buscar_en_lista_actual():
        try:
            prestamo = driver.find_element(AppiumBy.XPATH, f"//android.view.View[@content-desc='{texto_objetivo}']")
            prestamo.click()
            print('  ✅ Click en PRÉSTAMO (content-desc exacto)')
            time.sleep(3)
            return True
        except:
            pass
        try:
            prestamo = driver.find_element(AppiumBy.XPATH, f"//*[contains(translate(@content-desc, 'ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÑ', 'abcdefghijklmnopqrstuvwxyzáéíóúñ'), '{texto_lower}') and @clickable='true']")
            prestamo.click()
            print('  ✅ Click en PRÉSTAMO (case-insensitive)')
            time.sleep(3)
            return True
        except:
            pass
        try:
            prestamo = driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{texto_objetivo}') and @clickable='true']")
            prestamo.click()
            print('  ✅ Click en PRÉSTAMO (texto)')
            time.sleep(3)
            return True
        except:
            pass
        try:
            prestamo = driver.find_element(AppiumBy.XPATH, f"//*[contains(translate(@text, 'ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÑ', 'abcdefghijklmnopqrstuvwxyzáéíóúñ'), '{texto_lower}') and @clickable='true']")
            prestamo.click()
            print('  ✅ Click en PRÉSTAMO (texto case-insensitive)')
            time.sleep(3)
            return True
        except:
            pass
        return False
    if _buscar_en_lista_actual():
        return True
    print('  🔄 Buscando con scroll incremental...')
    for intento in range(5):
        try:
            driver.swipe(500, 1200, 500, 400, 500)
            time.sleep(0.6)
            if _buscar_en_lista_actual():
                return True
        except:
            pass
    for intento in range(3):
        try:
            driver.swipe(500, 400, 500, 1200, 500)
            time.sleep(0.6)
            if _buscar_en_lista_actual():
                return True
        except:
            pass
    print('  ❌ Error al seleccionar PRÉSTAMO')
    try:
        opciones = driver.find_elements(AppiumBy.XPATH, "//*[@clickable='true' and @content-desc and string-length(@content-desc) > 3]")
        print(f'  🔍 Elementos visibles ({len(opciones)}):')
        for o in opciones[:10]:
            desc = (o.get_attribute('content-desc') or '').replace('\n', ' | ')
            if len(desc) < 80:
                print(f'     - {desc}')
    except:
        pass
    return False

def seleccionar_detalle_prestamo(driver):
    print("  📝 Seleccionando 'Plan de pagos'...")
    time.sleep(3)
    if _seleccionar_opcion_case_insensitive(driver, 'Plan de pagos', timeout=5):
        print("  ✅ Click en 'Plan de pagos'")
        time.sleep(3)
        return True
    print("  ❌ Error al seleccionar 'Plan de pagos'")
    try:
        opciones = driver.find_elements(AppiumBy.XPATH, "//*[@clickable='true' and @content-desc and string-length(@content-desc) > 3]")
        print(f'  🔍 Elementos visibles ({len(opciones)}):')
        for o in opciones[:10]:
            desc = (o.get_attribute('content-desc') or '').replace('\n', ' | ')
            if len(desc) < 80:
                print(f'     - {desc}')
    except:
        pass
    return False

def scroll_al_final_detalle(driver, scrolls=3):
    print(f'  📝 Haciendo scroll al final de la pantalla ({scrolls} scrolls)...')
    time.sleep(1)
    for i in range(scrolls):
        scrolleado = False
        try:
            driver.execute_script('mobile: scroll', {'direction': 'down'})
            print(f'  ✅ Scroll {i + 1} completado (mobile:scroll)')
            scrolleado = True
            time.sleep(1)
        except:
            pass
        if not scrolleado:
            try:
                driver.find_element(AppiumBy.ANDROID_UIAUTOMATOR, 'new UiScrollable(new UiSelector().scrollable(true)).scrollForward()')
                print(f'  ✅ Scroll {i + 1} completado (UiScrollable)')
                scrolleado = True
                time.sleep(1)
            except:
                pass
        if not scrolleado:
            try:
                driver.swipe(500, 1500, 500, 500, 500)
                print(f'  ✅ Scroll {i + 1} completado (swipe)')
                scrolleado = True
                time.sleep(1)
            except Exception as e:
                print(f'  ⚠️ Error en scroll {i + 1}: {e}')
    return True

def click_descargar_reporte(driver, tipo_reporte='plan_pagos'):
    if tipo_reporte == 'plan_pagos':
        print("  📝 Click en 'Descargar plan de pagos'...")
        resource_id = 'credit_report_ta'
        content_desc = 'Descargar plan de pagos'
    elif tipo_reporte == 'pagos_realizados':
        print("  📝 Click en 'Descargar pagos realizados'...")
        resource_id = 'credit_report_ec'
        content_desc = 'Descargar pagos realizados'
    else:
        print(f"  ❌ Tipo de reporte '{tipo_reporte}' no válido")
        print(f"     Válidos: 'plan_pagos' | 'pagos_realizados'")
        return False
    time.sleep(2)
    try:
        btn = driver.find_element(AppiumBy.ID, resource_id)
        btn.click()
        print(f"  ✅ Click en '{content_desc}' (ID)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, f"//*[@resource-id='{resource_id}']")
        btn.click()
        print(f"  ✅ Click en '{content_desc}' (XPATH resource-id)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, f"//android.widget.Button[@content-desc='{content_desc}']")
        btn.click()
        print(f"  ✅ Click en '{content_desc}' (content-desc)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{content_desc}') and @clickable='true']")
        btn.click()
        print(f"  ✅ Click en '{content_desc}' (contains)")
        time.sleep(3)
        return True
    except Exception as e:
        print(f"  ❌ Error al clickear '{content_desc}': {e}")
        try:
            botones = driver.find_elements(AppiumBy.XPATH, "//*[@clickable='true' and @content-desc and string-length(@content-desc) > 3]")
            print(f'  🔍 Elementos visibles ({len(botones)}):')
            for o in botones[:10]:
                desc = (o.get_attribute('content-desc') or '').replace('\n', ' | ')
                if len(desc) < 80:
                    print(f'     - {desc}')
        except:
            pass
        return False

def cerrar_reporte_descargado(driver, timeout=10):
    print('  📝 Cerrando reporte descargado...')
    time.sleep(3)
    try:
        regresar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Regresar']")
        regresar.click()
        print('  ✅ Click en Regresar (reporte)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        cerrar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Cerrar']")
        cerrar.click()
        print('  ✅ Click en Cerrar (reporte)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        listo = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Listo']")
        listo.click()
        print('  ✅ Click en Listo (reporte)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        aceptar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Aceptar']")
        aceptar.click()
        print('  ✅ Click en Aceptar (reporte)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        driver.back()
        print('  ✅ Back ejecutado (reporte)')
        time.sleep(2)
        return True
    except:
        pass
    print('  ⚠️ No se pudo cerrar el reporte, continuando...')
    return True

def realizar_detalle_descargar_reporte(driver, tipo_reporte='plan_pagos', tiempos=None, reporte=None, paso_inicial=6):
    tipo_reporte = {'Plan de pagos':'plan_pagos','Pagos realizados':'pagos_realizados'}.get(tipo_reporte, tipo_reporte)
    print(f'\n📋 INICIANDO DETALLE DE PRÉSTAMO + DESCARGAR REPORTE')
    print(f'📄 Tipo de reporte: {tipo_reporte}')
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Ir a PRÉSTAMO')
    if not ir_a_prestamo(driver):
        print('  ❌ Error al ir a PRÉSTAMO')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla PRÉSTAMO', 'Se accedió a la sección de Préstamo desde el home.', espera=2.0)
    paso_num += 1
    tiempos.start('2. Plan de pagos')
    if not seleccionar_detalle_prestamo(driver):
        print('  ❌ Error al seleccionar Plan de pagos')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Opción Plan de pagos', "Se seleccionó la opción 'Plan de pagos'. Se abre la pantalla con la información del préstamo.", espera=2.0)
    paso_num += 1
    tiempos.start('3. Scroll al final')
    if not scroll_al_final_detalle(driver, scrolls=3):
        print('  ⚠️ Error al hacer scroll, continuando...')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Scroll al final del detalle', 'Se hizo scroll al final de la pantalla de detalle para acceder a los botones de descarga de reportes.', espera=1.5)
    paso_num += 1
    tiempos.start('4. Click descargar reporte')
    if not click_descargar_reporte(driver, tipo_reporte):
        print('  ❌ Error al clickear el reporte')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        if tipo_reporte == 'plan_pagos':
            desc_reporte = 'plan de pagos'
        else:
            desc_reporte = 'pagos realizados'
        reporte.capturar_paso(paso_num, f'Descargar reporte: {desc_reporte}', f"Se hizo clic en el botón 'Descargar {desc_reporte}'. Se abrió el reporte en el visor.", espera=2.0)
    paso_num += 1
    tiempos.start('5. Cerrar reporte')
    if not cerrar_reporte_descargado(driver):
        print('  ⚠️ Error al cerrar el reporte, continuando...')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Reporte cerrado', 'Se cerró el visor del reporte descargado.', espera=1.5)
    paso_num += 1
    tiempos.start('6. Volver atrás')
    if not volver_atras_detalle(driver):
        print('  ⚠️ Error al volver atrás')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Regreso a pantalla anterior', 'Se regresó a la pantalla anterior.', espera=1.0)
    paso_num += 1
    tiempos.start('7. Volver al home')
    if not volver_home(driver):
        print('  ⚠️ Error al volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Detalle + Reporte finalizado', 'Se regresó exitosamente al home. El flujo de detalle de préstamo + descarga de reporte ha terminado.', espera=1.5)
    paso_num += 1
    print('\n✅ DETALLE DE PRÉSTAMO + DESCARGAR REPORTE COMPLETADO EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('pago_prestamo_detalle_descargar_reporte_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO COMPLETO: LOGIN + DETALLE DE PRÉSTAMO + DESCARGAR REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    tipo_reporte = _input_cfg.get('tipo_reporte', 'plan_pagos')
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Detalle_Prestamo_Descargar_Reporte')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f'📄 Tipo de reporte: {tipo_reporte}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Tipo de reporte descargado': tipo_reporte})
    login_ok = _input_cfg.get('login_ok', False)
    reporte_ok = _input_cfg.get('reporte_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            reporte_ok = realizar_detalle_descargar_reporte(driver, tipo_reporte=tipo_reporte, tiempos=tiempos, reporte=reporte, paso_inicial=6)
            if reporte_ok:
                print('\n🎉 DETALLE DE PRÉSTAMO + DESCARGAR REPORTE EXITOSO!')
            else:
                print('\n❌ DETALLE DE PRÉSTAMO + DESCARGAR REPORTE FALLIDO')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and reporte_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login          : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Reporte        : {('✅ OK' if reporte_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

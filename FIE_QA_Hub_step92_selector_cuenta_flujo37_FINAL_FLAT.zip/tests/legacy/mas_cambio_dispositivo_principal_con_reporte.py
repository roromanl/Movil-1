"""
Flujo Cambio de Dispositivo Principal + reporte Word.
Pasos: Login → Más → Configuraciones de usuario → Dispositivos
       → Seleccionar dispositivo secundario → Confirmar cambio
       → Continuar → Volver atrás → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import volver_atras__418bccfa84 as volver_atras, volver_home__71a629aeab as volver_home
from framework.common.ui_helpers import _esta_en_home as _esta_en_home, _seleccionar_opcion_case_insensitive__f21faf0807 as _seleccionar_opcion_case_insensitive

def click_mas_menu(driver):
    print('  📝 Click en menú Más...')
    time.sleep(2)
    wait = WebDriverWait(driver, 5)
    try:
        mas_btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'home_btn_mas')))
        mas_btn.click()
        print('  ✅ Click en Más (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        mas_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Más\nMás']")
        mas_btn.click()
        print('  ✅ Click en Más (content-desc exacto)')
        time.sleep(3)
        return True
    except:
        pass
    if _seleccionar_opcion_case_insensitive(driver, 'Más', timeout=5, debug=True):
        print('  ✅ Click en Más (helper)')
        time.sleep(3)
        return True
    print('  ❌ Error al clickear Más')
    return False

def click_configuraciones_usuario(driver):
    print("  📝 Click en 'Configuraciones de usuario'...")
    time.sleep(2)
    try:
        btn = driver.find_element(AppiumBy.ID, 'more_btn_usuario')
        btn.click()
        print("  ✅ Click en 'Configuraciones de usuario' (ID)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='more_btn_usuario' and @clickable='true']")
        btn.click()
        print("  ✅ Click en 'Configuraciones de usuario' (XPATH)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Configuraciones de usuario\nConfiguraciones de usuario']")
        btn.click()
        print("  ✅ Click en 'Configuraciones de usuario' (content-desc)")
        time.sleep(3)
        return True
    except:
        pass
    if _seleccionar_opcion_case_insensitive(driver, 'Configuraciones de usuario', timeout=5, debug=True):
        print("  ✅ Click en 'Configuraciones de usuario' (helper)")
        time.sleep(3)
        return True
    print("  ❌ Error al clickear 'Configuraciones de usuario'")
    return False

def click_dispositivos(driver):
    print("  📝 Click en 'Dispositivos'...")
    time.sleep(2)
    try:
        btn = driver.find_element(AppiumBy.ID, 'user_profile_settings_devices')
        btn.click()
        print("  ✅ Click en 'Dispositivos' (ID)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='user_profile_settings_devices' and @clickable='true']")
        btn.click()
        print("  ✅ Click en 'Dispositivos' (XPATH)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Dispositivos\nDispositivos']")
        btn.click()
        print("  ✅ Click en 'Dispositivos' (content-desc)")
        time.sleep(3)
        return True
    except:
        pass
    if _seleccionar_opcion_case_insensitive(driver, 'Dispositivos', timeout=5, debug=True):
        print("  ✅ Click en 'Dispositivos' (helper)")
        time.sleep(3)
        return True
    print("  ❌ Error al clickear 'Dispositivos'")
    return False

def seleccionar_dispositivo_secundario(driver, nombre_dispositivo):
    print(f"  📝 Seleccionando dispositivo: '{nombre_dispositivo}'...")
    time.sleep(3)

    def _buscar_y_clickear():
        try:
            dispositivos = driver.find_elements(AppiumBy.XPATH, "//*[contains(@resource-id, 'linked_device_') and not(contains(@resource-id, 'btn_eliminar')) and not(contains(@resource-id, '_resumen_')) and not(contains(@resource-id, '_otp_')) and @clickable='true']")
            print(f'    🔍 Dispositivos clickeables encontrados: {len(dispositivos)}')
            for disp in dispositivos:
                desc = disp.get_attribute('content-desc') or ''
                rid = disp.get_attribute('resource-id') or ''
                print(f"    [{rid}] '{desc[:60]}'")
                if nombre_dispositivo.lower() in desc.lower():
                    disp.click()
                    print(f"  ✅ Dispositivo seleccionado: '{nombre_dispositivo}'")
                    print(f'     {desc[:80]}...')
                    time.sleep(3)
                    driver._last_dispositivo_desc = desc
                    return True
        except Exception as e:
            print(f'    ⚠️ Error estrategia ID: {str(e)[:60]}')
        try:
            disp = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{nombre_dispositivo}') and contains(@resource-id, 'linked_device_') and @clickable='true']")
            desc = disp.get_attribute('content-desc') or ''
            disp.click()
            print(f"  ✅ Dispositivo seleccionado (contains): '{nombre_dispositivo}'")
            time.sleep(3)
            driver._last_dispositivo_desc = desc
            return True
        except:
            pass
        try:
            nombre_lower = nombre_dispositivo.lower()
            disp = driver.find_element(AppiumBy.XPATH, f"//*[contains(translate(@content-desc, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '{nombre_lower}') and contains(@resource-id, 'linked_device_') and @clickable='true']")
            desc = disp.get_attribute('content-desc') or ''
            disp.click()
            print(f'  ✅ Dispositivo seleccionado (case-insensitive)')
            time.sleep(3)
            driver._last_dispositivo_desc = desc
            return True
        except:
            pass
        return False
    if _buscar_y_clickear():
        return True
    print(f"  ❌ No se encontró el dispositivo: '{nombre_dispositivo}'")
    try:
        print('  🔍 Dispositivos disponibles:')
        dispositivos = driver.find_elements(AppiumBy.XPATH, "//*[contains(@resource-id, 'linked_device_') and not(contains(@resource-id, 'btn_eliminar')) and not(contains(@resource-id, '_resumen_')) and not(contains(@resource-id, '_otp_'))]")
        for d in dispositivos:
            desc = (d.get_attribute('content-desc') or '').replace('\n', ' | ')
            rid = d.get_attribute('resource-id') or ''
            clickable = d.get_attribute('clickable') or 'false'
            print(f"     - id='{rid}', clickable={clickable}, desc='{desc[:70]}'")
    except:
        pass
    return False

def click_confirmar_cambio(driver):
    print("  📝 Click en 'Confirmar cambio'...")
    time.sleep(2)
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='shared_btn_confirmar_clave_temporal']//android.widget.Button[@content-desc='Confirmar cambio']")
        btn.click()
        print("  ✅ Click en 'Confirmar cambio' (ID padre + hijo)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Confirmar cambio']")
        btn.click()
        print("  ✅ Click en 'Confirmar cambio' (content-desc)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Confirmar cambio') and @clickable='true']")
        btn.click()
        print("  ✅ Click en 'Confirmar cambio' (contains)")
        time.sleep(3)
        return True
    except:
        pass
    if _seleccionar_opcion_case_insensitive(driver, 'Confirmar cambio', timeout=5, debug=True):
        print("  ✅ Click en 'Confirmar cambio' (helper)")
        time.sleep(3)
        return True
    print("  ❌ Error al clickear 'Confirmar cambio'")
    return False

def click_continuar(driver):
    print("  📝 Click en 'Continuar'...")
    time.sleep(3)
    wait = WebDriverWait(driver, 10)
    try:
        btn = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")))
        btn.click()
        print("  ✅ Click en 'Continuar' (content-desc)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.ACCESSIBILITY_ID, 'Continuar')
        btn.click()
        print("  ✅ Click en 'Continuar' (Accessibility ID)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Continuar') and @clickable='true']")
        btn.click()
        print("  ✅ Click en 'Continuar' (contains)")
        time.sleep(3)
        return True
    except:
        pass
    if _seleccionar_opcion_case_insensitive(driver, 'Continuar', timeout=5, debug=True):
        print("  ✅ Click en 'Continuar' (helper)")
        time.sleep(3)
        return True
    print("  ❌ Error al clickear 'Continuar'")
    return False

def realizar_cambio_dispositivo_principal(driver, nombre_dispositivo='samsunga54', reporte=None, tiempos=None, paso_inicial=6):
    print(f'\n📱 INICIANDO CAMBIO DE DISPOSITIVO PRINCIPAL')
    print(f"📋 Dispositivo a convertir en principal: '{nombre_dispositivo}'")
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Click Más')
    if not click_mas_menu(driver):
        print('  ❌ Error al clickear Más')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Menú Más abierto', "Se accedió al menú 'Más' desde la barra de navegación inferior.", espera=1.5)
    paso_num += 1
    tiempos.start('2. Configuraciones usuario')
    if not click_configuraciones_usuario(driver):
        print("  ❌ Error al clickear 'Configuraciones de usuario'")
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Configuraciones de usuario', 'Se accedió a las Configuraciones de usuario.', espera=1.5)
    paso_num += 1
    tiempos.start('3. Dispositivos')
    if not click_dispositivos(driver):
        print("  ❌ Error al clickear 'Dispositivos'")
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla de Dispositivos', 'Se accedió a la lista de dispositivos enlazados. Se muestra el dispositivo principal actual y los dispositivos secundarios.', espera=2.0)
    paso_num += 1
    print('  📝 Esperando carga de la lista de dispositivos...')
    time.sleep(3)
    tiempos.start('4. Seleccionar dispositivo')
    if not seleccionar_dispositivo_secundario(driver, nombre_dispositivo):
        print(f"  ❌ Error al seleccionar dispositivo: '{nombre_dispositivo}'")
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        desc_disp = getattr(driver, '_last_dispositivo_desc', '') or ''
        reporte.capturar_paso(paso_num, f"Dispositivo '{nombre_dispositivo}' seleccionado", f"Se seleccionó el dispositivo '{nombre_dispositivo}' para convertirlo en principal. Detalle: {desc_disp[:120]}", espera=1.5)
    paso_num += 1
    print('  📝 Esperando carga del modal de confirmación...')
    time.sleep(3)
    tiempos.start('5. Confirmar cambio')
    if not click_confirmar_cambio(driver):
        print("  ❌ Error al clickear 'Confirmar cambio'")
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Cambio confirmado', 'Se confirmó el cambio en el modal de confirmación.', espera=1.5)
    paso_num += 1
    print('  📝 Esperando carga de pantalla siguiente...')
    time.sleep(3)
    tiempos.start('6. Continuar')
    if not click_continuar(driver):
        print("  ⚠️ Error al clickear 'Continuar', continuando...")
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Continuar (pantalla siguiente)', 'Se hizo clic en Continuar tras el cambio de dispositivo.', espera=1.5)
    paso_num += 1
    print('  📝 Esperando procesamiento...')
    time.sleep(3)
    tiempos.start('7. Volver atrás')
    if not volver_atras(driver):
        print('  ⚠️ Error al volver atrás')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Regreso a la pantalla anterior', 'Se regresó a la pantalla anterior.', espera=1.0)
    paso_num += 1
    tiempos.start('8. Volver al home')
    if not volver_home(driver):
        print('  ⚠️ Error al volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Cambio de Dispositivo finalizado', f"Se regresó exitosamente al home. El cambio de dispositivo principal ('{nombre_dispositivo}') ha terminado.", espera=1.5)
    paso_num += 1
    print(f'\n✅ CAMBIO DE DISPOSITIVO PRINCIPAL COMPLETADO EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('mas_cambio_dispositivo_principal_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO: LOGIN + CAMBIO DE DISPOSITIVO PRINCIPAL + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    NOMBRE_DISPOSITIVO = _input_cfg.get('NOMBRE_DISPOSITIVO', 'samsunga54')
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Cambio_Dispositivo_Principal')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f"📋 Dispositivo a convertir en principal: '{NOMBRE_DISPOSITIVO}'")
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Dispositivo a convertir en principal': NOMBRE_DISPOSITIVO})
    login_ok = _input_cfg.get('login_ok', False)
    cambio_ok = _input_cfg.get('cambio_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            cambio_ok = realizar_cambio_dispositivo_principal(driver, nombre_dispositivo=NOMBRE_DISPOSITIVO, reporte=reporte, tiempos=tiempos, paso_inicial=6)
            if cambio_ok:
                print('\n🎉 CAMBIO DE DISPOSITIVO PRINCIPAL EXITOSO!')
            else:
                print('\n❌ CAMBIO DE DISPOSITIVO PRINCIPAL FALLIDO')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and cambio_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login          : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Cambio disp.   : {('✅ OK' if cambio_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

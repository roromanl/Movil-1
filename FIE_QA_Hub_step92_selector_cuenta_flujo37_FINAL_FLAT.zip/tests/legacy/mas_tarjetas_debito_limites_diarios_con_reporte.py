"""
Flujo Tarjetas de Débito → Límites Diarios + reporte Word.
Pasos: Login → Más → Tarjetas de débito → Límites diarios
       → Límite retiro → Límite compra → Continuar → Confirmar
       → Éxito → Regresar → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import volver_atras__577b1f7cf5 as volver_atras, volver_home__1a5d4bb43d as volver_home

def click_mas_menu(driver):
    print('  📝 Click en menú Más...')
    wait = WebDriverWait(driver, 5)
    try:
        mas_btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'home_btn_mas')))
        mas_btn.click()
        print('  ✅ Click en Más (ID)')
        time.sleep(3)
        return True
    except:
        try:
            mas_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Más\nMás']")
            mas_btn.click()
            print('  ✅ Click en Más (content-desc)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Más: {e}')
            return False

def click_tarjetas_debito_mas(driver):
    """En el menú Más, hace click en 'Tarjetas de débito'."""
    print("  📝 Seleccionando 'Tarjetas de débito'...")
    wait = WebDriverWait(driver, 10)
    try:
        btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'more_btn_tarjetas')))
        btn.click()
        print("  ✅ Click en 'Tarjetas de débito' (ID)")
        time.sleep(3)
        return True
    except:
        try:
            btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Tarjetas de débito')]")
            btn.click()
            print("  ✅ Click en 'Tarjetas de débito' (content-desc)")
            time.sleep(3)
            return True
        except Exception as e:
            print(f"  ❌ Error al seleccionar 'Tarjetas de débito': {e}")
            return False

def click_limites_diarios_mas(driver):
    """En 'Administración de tarjeta de débito', click en 'Límites diarios'."""
    print("  📝 Seleccionando 'Límites diarios'...")
    wait = WebDriverWait(driver, 10)
    try:
        btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'cards_btn_limites_diarios')))
        btn.click()
        print("  ✅ Click en 'Límites diarios' (ID)")
        time.sleep(3)
        return True
    except:
        try:
            btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Límites diarios')]")
            btn.click()
            print("  ✅ Click en 'Límites diarios' (content-desc)")
            time.sleep(3)
            return True
        except Exception as e:
            print(f"  ❌ Error al seleccionar 'Límites diarios': {e}")
            return False

def seleccionar_limite_retiro(driver, monto_limite, timeout=15):
    """
    Abre el selector 'Nuevo límite de retiro' y elige el monto indicado.
    monto_limite: string ej. "Bs. 1,000.00" (debe coincidir con el content-desc)
    """
    print(f'  📝 Seleccionando nuevo límite de retiro: {monto_limite}...')
    wait = WebDriverWait(driver, timeout)
    try:
        selector = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'cards_dl_atm_nuevo')))
        selector.click()
        print('  ✅ Click en selector de retiro (ID)')
        time.sleep(2)
    except:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='cards_dl_atm_nuevo']")
            selector.click()
            print('  ✅ Click en selector de retiro (XPATH)')
            time.sleep(2)
        except Exception as e:
            print(f'  ❌ Error al abrir selector de retiro: {e}')
            return False
    try:
        opcion = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, f"//android.view.View[@content-desc='{monto_limite}']")))
        opcion.click()
        print(f'  ✅ Límite de retiro seleccionado: {monto_limite}')
        time.sleep(2)
        return True
    except Exception as e:
        print(f"  ❌ No se encontró la opción '{monto_limite}' en el modal: {e}")
        try:
            opciones = driver.find_elements(AppiumBy.XPATH, "//android.view.View[contains(@content-desc, 'Bs.')]")
            print(f"  🔍 Opciones disponibles: {[o.get_attribute('content-desc') for o in opciones[:10]]}")
        except:
            pass
        return False

def seleccionar_limite_compra(driver, monto_limite, timeout=15):
    print(f'  📝 Seleccionando nuevo límite de compra: {monto_limite}...')
    wait = WebDriverWait(driver, timeout)
    try:
        driver.swipe(500, 1500, 500, 800, 500)
        time.sleep(1)
    except:
        pass
    try:
        selector = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'cards_dl_pos_nuevo')))
        selector.click()
        print('  ✅ Click en selector de compra (ID)')
        time.sleep(2)
    except:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='cards_dl_pos_nuevo']")
            selector.click()
            print('  ✅ Click en selector de compra (XPATH)')
            time.sleep(2)
        except Exception as e:
            print(f'  ❌ Error al abrir selector de compra: {e}')
            return False
    try:
        opcion = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, f"//android.view.View[@content-desc='{monto_limite}']")))
        opcion.click()
        print(f'  ✅ Límite de compra seleccionado: {monto_limite}')
        time.sleep(2)
        return True
    except Exception as e:
        print(f"  ❌ No se encontró la opción '{monto_limite}' en el modal: {e}")
        try:
            opciones = driver.find_elements(AppiumBy.XPATH, "//android.view.View[contains(@content-desc, 'Bs.')]")
            print(f"  🔍 Opciones disponibles: {[o.get_attribute('content-desc') for o in opciones[:10]]}")
        except:
            pass
        return False

def click_continuar_limites(driver, timeout=15):
    """Click en 'Continuar' de la pantalla de Límites diarios."""
    print('  📝 Click en Continuar (límites)...')
    wait = WebDriverWait(driver, timeout)
    try:
        continuar = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//*[@resource-id='cards_dl_btn_continuar']//android.widget.Button[@content-desc='Continuar']")))
        continuar.click()
        print('  ✅ Click en Continuar (límites)')
        time.sleep(3)
        return True
    except:
        try:
            continuar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")
            continuar.click()
            print('  ✅ Click en Continuar (límites - fallback)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Continuar: {e}')
            return False

def click_confirmar_transaccion_limites(driver, timeout=15):
    """Click en 'Confirmar transacción' del modal 'Detalle del cambio'."""
    print('  📝 Click en Confirmar transacción (límites)...')
    wait = WebDriverWait(driver, timeout)
    try:
        confirmar = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//*[@resource-id='cards_dl_btn_confirmar']//android.widget.Button[@content-desc='Confirmar transacción']")))
        confirmar.click()
        print('  ✅ Click en Confirmar transacción')
        time.sleep(3)
        return True
    except:
        try:
            confirmar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Confirmar transacción']")
            confirmar.click()
            print('  ✅ Click en Confirmar transacción (fallback)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Confirmar: {e}')
            return False

def click_continuar_exito_limites(driver, timeout=15):
    """Click en 'Continuar' en la pantalla de éxito."""
    print('  📝 Click en Continuar (pantalla de éxito)...')
    wait = WebDriverWait(driver, timeout)
    try:
        continuar = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")))
        continuar.click()
        print('  ✅ Click en Continuar (éxito)')
        time.sleep(2)
        return True
    except Exception as e:
        print(f'  ❌ Error al clickear Continuar (éxito): {e}')
        return False
def seleccionar_tarjeta_por_terminacion(driver, terminacion, max_swipes=10):
    """Centra la tarjeta solicitada. El XML puede contener tarjetas aún no visibles."""
    terminacion = str(terminacion or '').strip()
    if len(terminacion) != 4 or not terminacion.isdigit():
        print('  ❌ La terminación debe tener exactamente 4 dígitos')
        return False

    def tarjetas_visibles():
        """Devuelve solo faces que realmente intersectan el viewport, no todo el XML del pager."""
        width = driver.get_window_size()['width']
        candidates = driver.find_elements(AppiumBy.XPATH, "//*[@resource-id='cards_card_debit_face']")
        visible = []
        for el in candidates:
            try:
                box = el.rect
                desc = el.get_attribute('content-desc') or ''
                intersects = box['x'] < width and (box['x'] + box['width']) > 0 and box['width'] > 0
                if el.is_displayed() and intersects:
                    visible.append((el, box, desc))
            except Exception:
                pass
        return visible

    def esta_centrada(box):
        width = driver.get_window_size()['width']
        centro = box['x'] + box['width'] / 2
        # Tarjeta activa ocupa el centro del carrusel. Tolerancia estrecha para no aceptar una lateral.
        return abs(centro - width / 2) <= width * 0.12

    def buscar_objetivo_visible(etapa):
        visibles = tarjetas_visibles()
        print(f'  🔎 Tarjetas realmente visibles en {etapa}: {len(visibles)}')
        for el,box,desc in visibles:
            clean = desc.replace(chr(10), ' ')
            print(f"     • x={box['x']} w={box['width']} :: {clean}")
            if terminacion in desc:
                if esta_centrada(box):
                    print(f'  ✅ Tarjeta {terminacion} ya está centrada')
                    return True
                print(f'  ℹ️ Tarjeta {terminacion} está en el XML/viewport pero aún no está centrada')
        return False

    # Revisar la posición inicial sin mover el carrusel.
    if buscar_objetivo_visible('vista inicial'):
        return True

    for intento in range(1, max_swipes + 1):
        visibles = tarjetas_visibles()
        objetivo = next(((el,box,desc) for el,box,desc in visibles if terminacion in desc), None)
        try:
            pager = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='cards_ols_pager']")
            pb = pager.rect
            y = pb['y'] + pb['height']//2
            width = driver.get_window_size()['width']
            # Si el objetivo ya asoma a la derecha, mover a izquierda para centrarlo. Si asoma a la izquierda, movimiento inverso.
            if objetivo:
                _,box,_ = objetivo
                centro = box['x'] + box['width']/2
                if centro > width/2:
                    x1,x2 = pb['x'] + int(pb['width']*0.78), pb['x'] + int(pb['width']*0.28)
                else:
                    x1,x2 = pb['x'] + int(pb['width']*0.28), pb['x'] + int(pb['width']*0.78)
            else:
                x1,x2 = pb['x'] + int(pb['width']*0.78), pb['x'] + int(pb['width']*0.28)
            print(f'  ↔️ Desplazando carrusel {intento}/{max_swipes} para centrar {terminacion}...')
            driver.swipe(int(x1), int(y), int(x2), int(y), 550)
        except Exception:
            driver.swipe(820, 600, 260, 600, 550)
        time.sleep(1.2)
        if buscar_objetivo_visible(f'después del desplazamiento {intento}'):
            return True

    print(f'  ❌ No fue posible centrar la tarjeta terminada en {terminacion}')
    return False

def limites_diarios_flow(driver, terminacion_tarjeta='', limite_retiro='Bs. 1,000.00', limite_compra='Bs. 50,000.00', tiempos=None, reporte=None, paso_inicial=6):
    print(f'\n📊 INICIANDO FLUJO LÍMITES DIARIOS')
    print(f'   Límite retiro: {limite_retiro}')
    print(f'   Límite compra: {limite_compra}')
    print('=' * 60)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Ir a Más')
    if not click_mas_menu(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Menú Más abierto', "Se accedió al menú 'Más' desde la barra de navegación inferior.", espera=1.5)
    paso_num += 1
    tiempos.start('2. Tarjetas de débito')
    if not click_tarjetas_debito_mas(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Administración de tarjeta de débito', "Se accedió a la pantalla 'Administración de tarjeta de débito'.", espera=1.5)
    paso_num += 1
    tiempos.start('3. Límites diarios')
    if not click_limites_diarios_mas(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla Límites diarios', "Se accedió a la pantalla de 'Límites diarios'. Se muestran los selectores de 'Nuevo límite de retiro' y 'Nuevo límite de compra'.", espera=1.5)
    paso_num += 1
    tiempos.start('4. Seleccionar tarjeta')
    if not seleccionar_tarjeta_por_terminacion(driver, terminacion_tarjeta):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Tarjeta **** {terminacion_tarjeta}', f'Se centró la tarjeta de débito terminada en {terminacion_tarjeta}.', espera=1.0)
    paso_num += 1
    tiempos.start('5. Límite de retiro')
    if not seleccionar_limite_retiro(driver, limite_retiro):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Límite de retiro = {limite_retiro}', f'Se seleccionó el nuevo límite de retiro: {limite_retiro}.', espera=1.5)
    paso_num += 1
    tiempos.start('5. Límite de compra')
    if not seleccionar_limite_compra(driver, limite_compra):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Límite de compra = {limite_compra}', f'Se seleccionó el nuevo límite de compra: {limite_compra}.', espera=1.5)
    paso_num += 1
    tiempos.start('6. Continuar (límites)')
    if not click_continuar_limites(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Continuar (límites diarios)', "Se hizo clic en Continuar. Se abre el modal 'Detalle del cambio'.", espera=1.5)
    paso_num += 1
    print("  📝 Esperando carga del modal 'Detalle del cambio'...")
    time.sleep(3)
    tiempos.start('7. Confirmar transacción')
    if not click_confirmar_transaccion_limites(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Confirmar transacción', "Se confirmó la transacción en el modal 'Detalle del cambio'.", espera=1.5)
    paso_num += 1
    print('  📝 Esperando pantalla de éxito...')
    time.sleep(3)
    tiempos.start('8. Continuar (éxito)')
    if not click_continuar_exito_limites(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Modal de éxito - Cambio aplicado', 'Se mostró el modal de éxito confirmando que el cambio de límites se aplicó correctamente. Se hizo clic en Continuar.', espera=1.5)
    paso_num += 1
    print('  📝 Esperando volver a la pantalla principal...')
    time.sleep(2)
    tiempos.start('9. Volver atrás')
    if not volver_atras(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Regreso a pantalla anterior', 'Se regresó a la pantalla anterior.', espera=1.0)
    paso_num += 1
    tiempos.start('10. Volver al home')
    if not volver_home(driver):
        print('  ⚠️ No se pudo volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Límites Diarios finalizado', 'Se regresó exitosamente al home. El flujo de configuración de límites diarios ha terminado.', espera=1.5)
    paso_num += 1
    print('\n✅ LÍMITES DIARIOS COMPLETADO EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('mas_tarjetas_debito_limites_diarios_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO: LOGIN + TARJETAS DE DÉBITO > LÍMITES DIARIOS + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    LIMITE_RETIRO = _input_cfg.get('LIMITE_RETIRO', 'Bs. 2,000.00')
    LIMITE_COMPRA = _input_cfg.get('LIMITE_COMPRA', 'Bs. 50,000.00')
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Limites_Diarios_Tarjeta_Debito')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f'💳 Límite retiro: {LIMITE_RETIRO}')
    print(f'💳 Límite compra: {LIMITE_COMPRA}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Límite de retiro': LIMITE_RETIRO, 'Límite de compra': LIMITE_COMPRA})
    login_ok = _input_cfg.get('login_ok', False)
    limites_ok = _input_cfg.get('limites_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            limites_ok = limites_diarios_flow(driver, limite_retiro=LIMITE_RETIRO, limite_compra=LIMITE_COMPRA, tiempos=tiempos, reporte=reporte, paso_inicial=6)
            if limites_ok:
                print('\n🎉 LÍMITES DIARIOS EXITOSO!')
            else:
                print('\n❌ LÍMITES DIARIOS FALLIDO')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and limites_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login            : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Límites diarios  : {('✅ OK' if limites_ok else '❌ FALLÓ')}")
        print(f'   Carpeta          : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

"""
Flujo Movimientos de Tarjeta de Crédito + reporte Word.
Pasos: Login → T. CRÉDITO → Tab Movimientos → Buscar movimiento (scroll)
       → Click movimiento → Modal detalle → Cerrar → Volver → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import volver_atras_tc__109533fdac as volver_atras_tc, volver_home__71a629aeab as volver_home
from framework.common.ui_helpers import _esta_en_home as _esta_en_home, _seleccionar_opcion_case_insensitive__f21faf0807 as _seleccionar_opcion_case_insensitive

def ir_a_tarjeta_credito(driver, max_intentos=8):
    print('  📝 Navegando a T. CRÉDITO...')
    time.sleep(3)
    texto_objetivo = 'T. CRÉDITO'

    def _buscar_en_pantalla():
        try:
            tc = driver.find_element(AppiumBy.XPATH, f"//android.view.View[@content-desc='{texto_objetivo}']")
            tc.click()
            print('  ✅ Click en T. CRÉDITO (content-desc exacto)')
            time.sleep(3)
            return True
        except:
            pass
        try:
            tc = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{texto_objetivo}') and @clickable='true']")
            tc.click()
            print('  ✅ Click en T. CRÉDITO (content-desc contains)')
            time.sleep(3)
            return True
        except:
            pass
        try:
            tc = driver.find_element(AppiumBy.XPATH, f"//*[contains(translate(@content-desc, 'ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÑ.', 'abcdefghijklmnopqrstuvwxyzáéíóúñ.'), 't. crédito') and @clickable='true']")
            tc.click()
            print('  ✅ Click en T. CRÉDITO (case-insensitive)')
            time.sleep(3)
            return True
        except:
            pass
        try:
            tc = driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{texto_objetivo}') and @clickable='true']")
            tc.click()
            print('  ✅ Click en T. CRÉDITO (texto)')
            time.sleep(3)
            return True
        except:
            pass
        return False
    if _buscar_en_pantalla():
        return True
    for intento in range(max_intentos):
        try:
            if intento % 2 == 0:
                print(f'  🔄 Scroll horizontal IZQUIERDA {intento // 2 + 1}...')
                driver.swipe(900, 1000, 200, 1000, 500)
            else:
                print(f'  🔄 Scroll horizontal DERECHA {intento // 2 + 1}...')
                driver.swipe(200, 1000, 900, 1000, 500)
            time.sleep(0.6)
            if _buscar_en_pantalla():
                return True
        except:
            pass
    print('  ❌ Error al seleccionar T. CRÉDITO')
    try:
        print('  🔍 Elementos visibles:')
        elementos = driver.find_elements(AppiumBy.XPATH, "//*[@clickable='true' and @content-desc and string-length(@content-desc) > 3]")
        for e in elementos[:15]:
            desc = (e.get_attribute('content-desc') or '').replace('\n', ' | ')
            if len(desc) < 80:
                print(f'     - {desc}')
    except:
        pass
    return False

def seleccionar_movimientos_tc(driver):
    print("  📝 Seleccionando 'Movimientos'...")
    time.sleep(3)
    try:
        movimientos = driver.find_element(AppiumBy.ID, 'credit_card_tab_movements')
        movimientos.click()
        print("  ✅ Click en 'Movimientos' (ID)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        movimientos = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='credit_card_tab_movements']")
        movimientos.click()
        print("  ✅ Click en 'Movimientos' (XPATH resource-id)")
        time.sleep(3)
        return True
    except:
        pass
    if _seleccionar_opcion_case_insensitive(driver, 'Movimientos', timeout=5, debug=True):
        print("  ✅ Click en 'Movimientos' (case-insensitive)")
        time.sleep(3)
        return True
    print('  ❌ Error al seleccionar Movimientos')
    return False

def scroll_buscar_movimiento(driver, descripcion_busqueda, monto_busqueda, max_scrolls=15, pausa_scroll=0.8, debug=True):
    print(f"  📝 Buscando movimiento: '{descripcion_busqueda}' - Monto: {monto_busqueda}...")
    time.sleep(2)
    desc_lower = descripcion_busqueda.lower() if descripcion_busqueda else ''

    def _buscar_en_pantalla_actual():
        try:
            if descripcion_busqueda and monto_busqueda:
                try:
                    mov = driver.find_element(AppiumBy.XPATH, f"//android.widget.Button[contains(translate(@content-desc, 'ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÑ', 'abcdefghijklmnopqrstuvwxyzáéíóúñ'), '{desc_lower}') and contains(@content-desc, '{monto_busqueda}')]")
                    return mov
                except:
                    pass
            if descripcion_busqueda:
                try:
                    mov = driver.find_element(AppiumBy.XPATH, f"//android.widget.Button[contains(translate(@content-desc, 'ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÑ', 'abcdefghijklmnopqrstuvwxyzáéíóúñ'), '{desc_lower}')]")
                    return mov
                except:
                    pass
            if monto_busqueda:
                try:
                    mov = driver.find_element(AppiumBy.XPATH, f"//android.widget.Button[contains(@content-desc, '{monto_busqueda}')]")
                    return mov
                except:
                    pass
            return None
        except:
            return None
    mov = _buscar_en_pantalla_actual()
    if mov:
        print(f'  ✅ Movimiento encontrado sin scroll')
        return mov
    print('  🔄 Buscando con scroll incremental...')
    for intento in range(max_scrolls):
        try:
            driver.swipe(500, 1500, 500, 600, 800)
            time.sleep(pausa_scroll)
            print(f'    Scroll {intento + 1}/{max_scrolls}')
            mov = _buscar_en_pantalla_actual()
            if mov:
                print(f'  ✅ Movimiento encontrado en intento {intento + 1}')
                return mov
        except:
            pass
    print('  🔄 Scroll hacia arriba por si acaso...')
    for intento in range(3):
        try:
            driver.swipe(500, 600, 500, 1500, 800)
            time.sleep(pausa_scroll)
            mov = _buscar_en_pantalla_actual()
            if mov:
                print(f'  ✅ Movimiento encontrado en scroll arriba {intento + 1}')
                return mov
        except:
            pass
    if debug:
        print('  🔍 Movimientos disponibles (debug):')
        try:
            movimientos = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Bs.')]")
            print(f'  🔍 Total en pantalla: {len(movimientos)}')
            for i, mov in enumerate(movimientos[:10]):
                desc = mov.get_attribute('content-desc') or ''
                print(f'    [{i}] {desc[:100]}...')
        except:
            pass
    print(f'  ❌ No se encontró el movimiento después de {max_scrolls} intentos')
    return None

def click_movimiento(driver, movimiento):
    print('  📝 Click en movimiento...')
    time.sleep(1)
    try:
        movimiento.click()
        print('  ✅ Click en movimiento (directo)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        driver.execute_script('mobile: clickGesture', {'elementId': movimiento.id})
        print('  ✅ Click en movimiento (clickGesture)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        rect = movimiento.rect
        x = rect['x'] + rect['width'] // 2
        y = rect['y'] + rect['height'] // 2
        driver.execute_script('mobile: tap', {'x': x, 'y': y})
        print('  ✅ Click en movimiento (tap por coordenadas)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al clickear movimiento: {e}')
        return False

def verificar_detalle_transaccion(driver):
    print('  📝 Verificando modal de detalle de transacción...')
    time.sleep(2)
    try:
        driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Detalle de Transacción']")
        print('  ✅ Modal de detalle abierto (content-desc exacto)')
        return True
    except:
        pass
    try:
        driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Detalle de Transacción')]")
        print('  ✅ Modal de detalle abierto (texto)')
        return True
    except:
        pass
    try:
        driver.find_element(AppiumBy.XPATH, "//*[contains(translate(@content-desc, 'ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÑ', 'abcdefghijklmnopqrstuvwxyzáéíóúñ'), 'detalle de transacción')]")
        print('  ✅ Modal de detalle abierto (case-insensitive)')
        return True
    except:
        pass
    try:
        driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Detalle')]")
        print('  ✅ Modal de detalle abierto (contains Detalle)')
        return True
    except:
        pass
    print('  ⚠️ No se pudo verificar el modal')
    return False

def cerrar_modal_detalle_transaccion(driver):
    """Cierra el modal de detalle con 5 estrategias."""
    print('  📝 Cerrando modal de detalle de transacción...')
    time.sleep(2)
    try:
        cerrar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Cerrar']")
        cerrar.click()
        print('  ✅ Click en Cerrar (content-desc)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        cerrar = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Cerrar') and @clickable='true']")
        cerrar.click()
        print('  ✅ Click en Cerrar (texto)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        regresar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Regresar']")
        regresar.click()
        print('  ✅ Click en Regresar')
        time.sleep(2)
        return True
    except:
        pass
    try:
        aceptar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Aceptar']")
        aceptar.click()
        print('  ✅ Click en Aceptar')
        time.sleep(2)
        return True
    except:
        pass
    try:
        driver.back()
        print('  ✅ Back ejecutado')
        time.sleep(2)
        return True
    except Exception as e:
        print(f'  ❌ Error al cerrar modal: {e}')
        return False

def realizar_movimientos_tarjeta_credito(driver, descripcion_busqueda='Pago', monto_busqueda='100.00', tiempos=None, reporte=None, paso_inicial=6):
    print(f'\n💳 INICIANDO MOVIMIENTOS DE TARJETA DE CRÉDITO')
    print(f"📝 Buscando: '{descripcion_busqueda}' - Monto: {monto_busqueda}")
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Ir a T. CRÉDITO')
    if not ir_a_tarjeta_credito(driver):
        print('  ❌ Error al ir a T. CRÉDITO')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla T. CRÉDITO', 'Se accedió a la sección de Tarjeta de Crédito desde el home.', espera=2.0)
    paso_num += 1
    print('  📝 Esperando carga de pantalla...')
    time.sleep(3)
    tiempos.start('2. Tab Movimientos')
    if not seleccionar_movimientos_tc(driver):
        print('  ❌ Error al seleccionar Movimientos')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Tab Movimientos seleccionado', "Se seleccionó el tab 'Movimientos' en la pantalla de la Tarjeta de Crédito. Se muestra el listado de movimientos.", espera=2.0)
    paso_num += 1
    print('  📝 Esperando carga de movimientos...')
    time.sleep(3)
    tiempos.start('3. Buscar movimiento')
    movimiento = scroll_buscar_movimiento(driver, descripcion_busqueda, monto_busqueda)
    if not movimiento:
        print('  ❌ No se encontró el movimiento')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Movimiento encontrado', f"Se localizó el movimiento buscando: '{descripcion_busqueda}' con monto '{monto_busqueda}'.", espera=1.5)
    paso_num += 1
    tiempos.start('4. Click movimiento')
    if not click_movimiento(driver, movimiento):
        print('  ❌ Error al clickear movimiento')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Click en movimiento', 'Se hizo clic en el movimiento para abrir el detalle de la transacción.', espera=1.5)
    paso_num += 1
    tiempos.start('5. Verificar modal')
    if not verificar_detalle_transaccion(driver):
        print('  ⚠️ No se pudo verificar el modal de detalle')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, "Modal 'Detalle de Transacción'", 'Se abrió el modal de detalle de la transacción con la información completa del movimiento.', espera=1.5)
    paso_num += 1
    tiempos.start('6. Cerrar modal')
    if not cerrar_modal_detalle_transaccion(driver):
        print('  ⚠️ Error al cerrar modal')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Modal cerrado', 'Se cerró el modal de detalle de la transacción.', espera=1.5)
    paso_num += 1
    tiempos.start('7. Volver atrás')
    if not volver_atras_tc(driver):
        print('  ⚠️ Error al volver atrás')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Regreso a pantalla anterior', 'Se regresó a la pantalla anterior (listado de movimientos).', espera=1.0)
    paso_num += 1
    tiempos.start('8. Volver al home')
    if not volver_home(driver):
        print('  ⚠️ Error al volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Movimientos TC finalizado', 'Se regresó exitosamente al home. El flujo de movimientos de tarjeta de crédito ha terminado.', espera=1.5)
    paso_num += 1
    print('\n✅ MOVIMIENTOS DE TARJETA DE CRÉDITO COMPLETADO EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('tarjeta_de_credito_movimientos_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO COMPLETO: LOGIN + MOVIMIENTOS DE TARJETA DE CRÉDITO + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    descripcion_busqueda = _input_cfg.get('descripcion_busqueda', 'Pago')
    monto_busqueda = _input_cfg.get('monto_busqueda', '100.00')
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Movimientos_Tarjeta_Credito')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f"📝 Buscando: '{descripcion_busqueda}' - Monto: {monto_busqueda}")
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Descripción buscada': descripcion_busqueda, 'Monto buscado': monto_busqueda})
    login_ok = _input_cfg.get('login_ok', False)
    movimientos_ok = _input_cfg.get('movimientos_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            movimientos_ok = realizar_movimientos_tarjeta_credito(driver, descripcion_busqueda=descripcion_busqueda, monto_busqueda=monto_busqueda, tiempos=tiempos, reporte=reporte, paso_inicial=6)
            if movimientos_ok:
                print('\n🎉 MOVIMIENTOS DE TARJETA DE CRÉDITO EXITOSO!')
            else:
                print('\n❌ MOVIMIENTOS DE TARJETA DE CRÉDITO FALLIDO')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and movimientos_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login          : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Movimientos    : {('✅ OK' if movimientos_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

"""
Flujo Plan de pagos + Pagar Cuota + reporte Word.
Pasos: Login → PRÉSTAMO → Plan de pagos → Pagar cuota
       → Cuenta origen → Monto → Continuar → Modal → Confirmar → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import volver_home_desde_confirmacion
from framework.common.ui_helpers import _esta_en_home as _esta_en_home, _seleccionar_opcion_case_insensitive__4318d7731b as _seleccionar_opcion_case_insensitive

def ir_a_prestamo(driver):
    print('  📝 Navegando a PRÉSTAMO...')
    time.sleep(3)
    texto_objetivo = 'PRÉSTAMO'
    texto_lower = texto_objetivo.lower()

    def _buscar_en_lista_actual():
        try:
            prestamo = driver.find_element(AppiumBy.XPATH, f"//android.view.View[@content-desc='{texto_objetivo}']")
            prestamo.click()
            print('  ✅ Click en PRÉSTAMO (content-desc exacto)')
            time.sleep(3)
            return True
        except:
            pass
        try:
            prestamo = driver.find_element(AppiumBy.XPATH, f"//*[contains(translate(@content-desc, 'ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÑ', 'abcdefghijklmnopqrstuvwxyzáéíóúñ'), '{texto_lower}') and @clickable='true']")
            prestamo.click()
            print('  ✅ Click en PRÉSTAMO (case-insensitive)')
            time.sleep(3)
            return True
        except:
            pass
        try:
            prestamo = driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{texto_objetivo}') and @clickable='true']")
            prestamo.click()
            print('  ✅ Click en PRÉSTAMO (texto)')
            time.sleep(3)
            return True
        except:
            pass
        try:
            prestamo = driver.find_element(AppiumBy.XPATH, f"//*[contains(translate(@text, 'ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÑ', 'abcdefghijklmnopqrstuvwxyzáéíóúñ'), '{texto_lower}') and @clickable='true']")
            prestamo.click()
            print('  ✅ Click en PRÉSTAMO (texto case-insensitive)')
            time.sleep(3)
            return True
        except:
            pass
        return False
    if _buscar_en_lista_actual():
        return True
    print('  🔄 Buscando con scroll incremental...')
    for intento in range(5):
        try:
            driver.swipe(500, 1200, 500, 400, 500)
            time.sleep(0.6)
            if _buscar_en_lista_actual():
                return True
        except:
            pass
    for intento in range(3):
        try:
            driver.swipe(500, 400, 500, 1200, 500)
            time.sleep(0.6)
            if _buscar_en_lista_actual():
                return True
        except:
            pass
    print('  ❌ Error al seleccionar PRÉSTAMO')
    try:
        opciones = driver.find_elements(AppiumBy.XPATH, "//*[@clickable='true' and @content-desc and string-length(@content-desc) > 3]")
        print(f'  🔍 Elementos visibles ({len(opciones)}):')
        for o in opciones[:10]:
            desc = (o.get_attribute('content-desc') or '').replace('\n', ' | ')
            if len(desc) < 80:
                print(f'     - {desc}')
    except:
        pass
    return False

def seleccionar_detalle_prestamo(driver):
    print("  📝 Seleccionando 'Plan de pagos'...")
    time.sleep(3)
    if _seleccionar_opcion_case_insensitive(driver, 'Plan de pagos', timeout=5):
        print("  ✅ Click en 'Plan de pagos'")
        time.sleep(3)
        return True
    print("  ❌ Error al seleccionar 'Plan de pagos'")
    try:
        opciones = driver.find_elements(AppiumBy.XPATH, "//*[@clickable='true' and @content-desc and string-length(@content-desc) > 3]")
        print(f'  🔍 Elementos visibles ({len(opciones)}):')
        for o in opciones[:10]:
            desc = (o.get_attribute('content-desc') or '').replace('\n', ' | ')
            if len(desc) < 80:
                print(f'     - {desc}')
    except:
        pass
    return False

def click_pagar_cuota(driver):
    print("  📝 Click en 'Pagar cuota'...")
    time.sleep(2)
    try:
        pagar = driver.find_element(AppiumBy.ID, 'product_loan_detail_pay')
        pagar.click()
        print("  ✅ Click en 'Pagar cuota' (ID)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        pagar = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='product_loan_detail_pay']//android.widget.Button[@content-desc='Pagar cuota']")
        pagar.click()
        print("  ✅ Click en 'Pagar cuota' (XPATH padre+hijo)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        pagar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Pagar cuota']")
        pagar.click()
        print("  ✅ Click en 'Pagar cuota' (content-desc)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        pagar = driver.find_element(AppiumBy.XPATH, "//*[contains(translate(@content-desc, 'ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÑ', 'abcdefghijklmnopqrstuvwxyzáéíóúñ'), 'pagar cuota') and @clickable='true']")
        pagar.click()
        print("  ✅ Click en 'Pagar cuota' (case-insensitive)")
        time.sleep(3)
        return True
    except Exception as e:
        print(f"  ❌ Error al clickear 'Pagar cuota': {e}")
        try:
            botones = driver.find_elements(AppiumBy.XPATH, "//*[@clickable='true' and @content-desc and string-length(@content-desc) > 3]")
            print(f'  🔍 Elementos visibles ({len(botones)}):')
            for o in botones[:10]:
                desc = (o.get_attribute('content-desc') or '').replace('\n', ' | ')
                if len(desc) < 80:
                    print(f'     - {desc}')
        except:
            pass
        return False

def seleccionar_cuenta_origen(driver, numero_cuenta='40-0-0124460-6'):
    print(f'  📝 Seleccionando cuenta origen: {numero_cuenta}...')
    time.sleep(3)
    wait = WebDriverWait(driver, 5)
    abierto = False
    try:
        selector = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'loan_compose_origin')))
        selector.click()
        print('  ✅ Click en selector de cuenta origen (ID)')
        abierto = True
    except:
        pass
    if not abierto:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='loan_compose_origin']")
            selector.click()
            print('  ✅ Click en selector de cuenta origen (XPATH)')
            abierto = True
        except:
            pass
    if not abierto:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Selecciona la cuenta de origen')]")
            selector.click()
            print('  ✅ Click en selector de cuenta origen (content-desc)')
            abierto = True
        except:
            pass
    if not abierto:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'cuenta de origen') and @clickable='true']")
            selector.click()
            print('  ✅ Click en selector de cuenta origen (contains)')
            abierto = True
        except Exception as e:
            print(f'  ❌ Error al abrir selector de cuenta: {e}')
            return False
    time.sleep(2)
    try:
        cuenta = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, f"//android.widget.Button[contains(@content-desc, '{numero_cuenta}')]")))
        cuenta.click()
        print(f'  ✅ Cuenta seleccionada (completa): {numero_cuenta}')
        time.sleep(2)
        return True
    except:
        pass
    try:
        partes = numero_cuenta.split('-')
        if len(partes) >= 2:
            ultimo_segmento = partes[-1]
            cuenta = driver.find_element(AppiumBy.XPATH, f"//android.widget.Button[contains(@content-desc, '{ultimo_segmento}')]")
            cuenta.click()
            print(f'  ✅ Cuenta seleccionada (último segmento: {ultimo_segmento})')
            time.sleep(2)
            return True
    except:
        pass
    try:
        cuentas = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'CUENTA')]")
        if cuentas:
            cuentas[0].click()
            print('  ✅ Primera cuenta seleccionada (fallback)')
            time.sleep(2)
            return True
    except:
        pass
    print(f'  ❌ Error al seleccionar cuenta: {numero_cuenta}')
    return False

def ingresar_monto_pago(driver, monto='69.19'):
    print(f'  📝 Ingresando monto: {monto}...')
    time.sleep(2)
    edit_text = None
    if edit_text is None:
        try:
            edit_texts = driver.find_elements(AppiumBy.XPATH, '//android.widget.EditText')
            if len(edit_texts) >= 1:
                for et in edit_texts:
                    try:
                        if et.is_displayed() and et.is_enabled():
                            edit_text = et
                    except:
                        pass
                if edit_text:
                    print(f'  ✅ EditText encontrado (único visible, total={len(edit_texts)})')
        except:
            pass
    if edit_text is None:
        try:
            edit_text = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[contains(@text, 'Bs.')]")
            print("  ✅ EditText encontrado (contiene 'Bs.')")
        except:
            pass
    if edit_text is None:
        print('  ❌ No se encontró el EditText de monto')
        try:
            print('  🔍 EditTexts visibles:')
            todos = driver.find_elements(AppiumBy.XPATH, '//android.widget.EditText')
            print(f'     Total: {len(todos)}')
            for i, et in enumerate(todos):
                try:
                    rid = et.get_attribute('resource-id') or '(sin id)'
                    hint = et.get_attribute('hint') or '(sin hint)'
                    texto = et.get_attribute('text') or '(vacío)'
                    print(f"     [{i}] id='{rid}', hint='{hint}', text='{texto[:30]}'")
                except:
                    pass
        except:
            pass
        return False
    try:
        edit_text.click()
        time.sleep(0.5)
        try:
            edit_text.clear()
        except:
            pass
        texto_actual = edit_text.get_attribute('text') or ''
        if texto_actual.strip():
            print(f"  ⚠️ Campo no vacío tras clear() ('{texto_actual[:20]}'), borrando con BACKSPACE...")
            driver.press_keycode(123)
            time.sleep(0.3)
            for _ in range(len(texto_actual) + 2):
                driver.press_keycode(67)
            time.sleep(0.3)
        edit_text.send_keys(monto)
        print(f'  ✅ Monto ingresado: {monto}')
        try:
            driver.hide_keyboard()
        except:
            pass
        time.sleep(0.5)
        return True
    except Exception as e:
        print(f'  ❌ Error al ingresar monto: {e}')
        return False

def click_continuar_pago(driver):
    print('  📝 Click en Continuar (pago)...')
    time.sleep(3)
    try:
        continuar = driver.find_element(AppiumBy.ID, 'loan_compose_continue')
        continuar.click()
        print('  ✅ Click en Continuar (ID)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        continuar = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='loan_compose_continue']//android.widget.Button[@content-desc='Continuar']")
        continuar.click()
        print('  ✅ Click en Continuar (XPATH)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        continuar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")
        continuar.click()
        print('  ✅ Click en Continuar (content-desc)')
        time.sleep(2)
        return True
    except Exception as e:
        print(f'  ❌ Error al clickear Continuar: {e}')
        return False

def click_continuar_modal_informativo(driver, timeout=15):
    print('  📝 Click en Continuar (modal informativo)...')
    time.sleep(3)
    wait = WebDriverWait(driver, 5)
    try:
        continuar = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")))
        continuar.click()
        print('  ✅ Click en Continuar (modal - content-desc)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        continuar = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Continuar') and @clickable='true']")
        continuar.click()
        print('  ✅ Click en Continuar (modal - contains)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        continuar = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Continuar') and @clickable='true']")
        continuar.click()
        print('  ✅ Click en Continuar (modal - texto)')
        time.sleep(2)
        return True
    except Exception as e:
        print(f'  ❌ Error al clickear Continuar en modal: {e}')
        return False

def click_confirmar_transaccion(driver):
    print('  📝 Click en Confirmar transacción...')
    time.sleep(5)
    try:
        confirmar = driver.find_element(AppiumBy.ID, 'loan_verification_confirm')
        confirmar.click()
        print('  ✅ Click en Confirmar transacción (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        confirmar = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='loan_verification_confirm']//android.widget.Button[@content-desc='Confirmar la transacción']")
        confirmar.click()
        print('  ✅ Click en Confirmar transacción (XPATH)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        confirmar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Confirmar la transacción']")
        confirmar.click()
        print('  ✅ Click en Confirmar transacción (content-desc)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        confirmar = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Confirmar') and @clickable='true']")
        confirmar.click()
        print('  ✅ Click en Confirmar transacción (contains)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al clickear Confirmar transacción: {e}')
        return False

def realizar_detalle_y_pagar_cuota(driver, numero_cuenta='40-0-0124460-6', monto='69.19', tiempos=None, reporte=None, paso_inicial=6):
    print(f'\n📋 INICIANDO DETALLE DE PRÉSTAMO + PAGAR CUOTA')
    print(f'🏦 Cuenta origen: {numero_cuenta}')
    print(f'💰 Monto: {monto}')
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Ir a PRÉSTAMO')
    if not ir_a_prestamo(driver):
        print('  ❌ Error al ir a PRÉSTAMO')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla PRÉSTAMO', 'Se accedió a la sección de Préstamo desde el home.', espera=2.0)
    paso_num += 1
    tiempos.start('2. Plan de pagos')
    if not seleccionar_detalle_prestamo(driver):
        print('  ❌ Error al seleccionar Plan de pagos')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Opción Plan de pagos', "Se seleccionó la opción 'Plan de pagos'. Se abre la pantalla con la información del préstamo.", espera=2.0)
    paso_num += 1
    tiempos.start('3. Pagar cuota')
    if not click_pagar_cuota(driver):
        print("  ❌ Error al clickear 'Pagar cuota'")
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, "Click en 'Pagar cuota'", "Se hizo clic en el botón 'Pagar cuota'. Se abre la pantalla de pago del préstamo.", espera=2.0)
    paso_num += 1
    tiempos.start('4. Cuenta origen')
    if not seleccionar_cuenta_origen(driver, numero_cuenta):
        print('  ❌ Error al seleccionar cuenta origen')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Cuenta origen: {numero_cuenta}', f'Se seleccionó la cuenta de origen: {numero_cuenta}.', espera=1.5)
    paso_num += 1
    tiempos.start('5. Monto')
    if not ingresar_monto_pago(driver, monto):
        print('  ❌ Error al ingresar monto')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Monto: Bs. {monto}', f'Se ingresó el monto del pago: Bs. {monto}.', espera=1.0)
    paso_num += 1
    tiempos.start('6. Continuar (pago)')
    if not click_continuar_pago(driver):
        print('  ❌ Error al clickear Continuar')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Continuar (pago)', 'Se hizo clic en Continuar. Se avanzó a la pantalla de verificación.', espera=1.5)
    paso_num += 1
    tiempos.start('7. Continuar (modal)')
    if not click_continuar_modal_informativo(driver):
        print('  ⚠️ Error al clickear Continuar en modal, continuando...')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Continuar (modal informativo)', 'Se confirmó el modal informativo haciendo clic en Continuar.', espera=1.5)
    paso_num += 1
    tiempos.start('8. Confirmar transacción')
    if not click_confirmar_transaccion(driver):
        print('  ❌ Error al clickear Confirmar transacción')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Confirmar transacción', f'Se confirmó la transacción de pago de cuota por Bs. {monto}.', espera=1.5)
    paso_num += 1
    tiempos.start('9. Volver al home')
    if not volver_home_desde_confirmacion(driver):
        print('  ⚠️ Error al volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Detalle + Pagar Cuota finalizado', 'Se regresó exitosamente al home. El flujo de detalle de préstamo + pagar cuota ha terminado.', espera=1.5)
    paso_num += 1
    print('\n✅ DETALLE DE PRÉSTAMO + PAGAR CUOTA COMPLETADO EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('pago_prestamo_detalle_pagar_cuota_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO COMPLETO: LOGIN + DETALLE DE PRÉSTAMO + PAGAR CUOTA + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    numero_cuenta = _input_cfg.get('numero_cuenta', '40-0-1189577-1')
    monto_pago = _input_cfg.get('monto_pago', '69.19')
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Detalle_Prestamo_Pagar_Cuota')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f'🏦 Cuenta origen: {numero_cuenta}')
    print(f'💰 Monto a pagar: {monto_pago}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Cuenta origen': numero_cuenta, 'Monto': f'Bs. {monto_pago}'})
    login_ok = _input_cfg.get('login_ok', False)
    pago_ok = _input_cfg.get('pago_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            pago_ok = realizar_detalle_y_pagar_cuota(driver, numero_cuenta=numero_cuenta, monto=monto_pago, tiempos=tiempos, reporte=reporte, paso_inicial=6)
            if pago_ok:
                print('\n🎉 DETALLE DE PRÉSTAMO + PAGAR CUOTA EXITOSO!')
            else:
                print('\n❌ DETALLE DE PRÉSTAMO + PAGAR CUOTA FALLIDO')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and pago_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login          : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Pagar cuota    : {('✅ OK' if pago_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

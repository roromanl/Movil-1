"""
Flujo Pagar QR + reporte Word.
Pasos: Login → QR → Pagar QR → Galería → Primera foto QR → Seleccionar cuenta
       → Monto → Confirmar transacción → Cerrar comprobante → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import volver_home_pagar_qr
from framework.common.ui_helpers import _esta_en_home as _esta_en_home, _ingresar_texto_en_campo as _ingresar_texto_en_campo

def click_qr_menu(driver):
    print('  📝 Click en menú QR...')
    time.sleep(2)
    try:
        qr_btn = driver.find_element(AppiumBy.ID, 'home_btn_qr')
        qr_btn.click()
        print('  ✅ Click en QR (ID home_btn_qr)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        qr_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='QR' or @content-desc='Qr' or @content-desc='qr']")
        qr_btn.click()
        print('  ✅ Click en QR (content-desc)')
        time.sleep(3)
        return True
    except:
        pass
    print('  ❌ Error al clickear QR')
    return False

def select_pagar_qr(driver):
    print('  📝 Seleccionando Pagar QR...')
    time.sleep(2)
    try:
        pagar_btn = driver.find_element(AppiumBy.ID, 'qr_btn_pagar')
        pagar_btn.click()
        print('  ✅ Click en Pagar QR (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        pagar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Pagar QR\nPagar QR']")
        pagar_btn.click()
        print('  ✅ Click en Pagar QR (content-desc exacto)')
        time.sleep(3)
        return True
    except:
        pass
    print('  ❌ Error al clickear Pagar QR')
    return False

def abrir_galeria(driver):
    print('  📝 Abriendo galería...')
    time.sleep(2)
    try:
        galeria_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Buscar en galería']")
        galeria_btn.click()
        print('  ✅ Click en Buscar en galería (content-desc)')
        time.sleep(3)
        return True
    except:
        pass
    print('  ❌ Error al abrir galería')
    return False

def seleccionar_primera_foto_qr(driver):
    print('  📝 Seleccionando la primera foto QR...')
    time.sleep(3)
    foto_seleccionada = False
    try:
        grid = driver.find_element(AppiumBy.XPATH, "//android.view.View[@content-desc='Cuadrícula de contenido multimedia']")
        fotos = grid.find_elements(AppiumBy.XPATH, ".//android.view.View[@clickable='true']")
        if fotos:
            fotos[0].click()
            print('  ✅ Primera foto seleccionada (desde cuadrícula)')
            foto_seleccionada = True
            time.sleep(2)
    except:
        pass
    if not foto_seleccionada:
        print('  ⚠️ No se pudo seleccionar ninguna foto, intentando continuar...')
    print("  📝 Buscando botón 'Listo'...")
    time.sleep(2)
    try:
        listo_text = driver.find_element(AppiumBy.XPATH, "//android.widget.TextView[@text='Listo']")
        listo_text.click()
        print("  ✅ Click en 'Listo' (TextView)")
        time.sleep(3)
        return foto_seleccionada
    except:
        pass
    print("  ⚠️ No se encontró botón 'Listo'")
    return foto_seleccionada

def seleccionar_cuenta_pagar_qr(driver, numero_cuenta=None):
    print('  📝 Seleccionando cuenta...')
    time.sleep(8)
    cuenta_desc = None
    abierto = False
    try:
        cambiar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Toca para cambiar')]")
        cambiar_btn.click()
        print("  ✅ Click en 'Toca para cambiar'")
        abierto = True
        time.sleep(2)
    except:
        pass
    if not abierto:
        try:
            cambiar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(translate(@content-desc, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'cambiar')]")
            cambiar_btn.click()
            print("  ✅ Click en selector (contiene 'cambiar')")
            abierto = True
            time.sleep(2)
        except:
            pass
    if not abierto:
        try:
            cambiar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@resource-id, 'account') and @clickable='true']")
            cambiar_btn.click()
            print('  ✅ Click en selector (por resource-id)')
            abierto = True
            time.sleep(2)
        except:
            pass
    if not abierto:
        try:
            cambiar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'CUENTA') and @clickable='true']")
            cambiar_btn.click()
            print('  ✅ Click en selector (contiene CUENTA)')
            abierto = True
            time.sleep(2)
        except Exception as e:
            print(f'  ❌ Error al abrir selector de cuentas: {e}')
            return False
    time.sleep(1)
    cuenta_seleccionada = False
    if numero_cuenta:
        try:
            cuenta_btn = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{numero_cuenta}') and @clickable='true']")
            cuenta_desc = cuenta_btn.get_attribute('content-desc') or numero_cuenta
            cuenta_btn.click()
            print(f'  ✅ Cuenta seleccionada: {numero_cuenta}')
            cuenta_seleccionada = True
            time.sleep(2)
        except:
            pass
        if not cuenta_seleccionada:
            try:
                sin_guiones = numero_cuenta.replace('-', '')
                cuenta_btn = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{sin_guiones}') and @clickable='true']")
                cuenta_desc = cuenta_btn.get_attribute('content-desc') or sin_guiones
                cuenta_btn.click()
                print(f'  ✅ Cuenta seleccionada (sin guiones): {sin_guiones}')
                cuenta_seleccionada = True
                time.sleep(2)
            except:
                pass
        if not cuenta_seleccionada:
            try:
                partes = numero_cuenta.split('-')
                if len(partes) >= 2:
                    ultimo = partes[-1]
                    cuenta_btn = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{ultimo}') and @clickable='true']")
                    cuenta_desc = cuenta_btn.get_attribute('content-desc') or ultimo
                    cuenta_btn.click()
                    print(f'  ✅ Cuenta seleccionada (último segmento: {ultimo})')
                    cuenta_seleccionada = True
                    time.sleep(2)
            except:
                pass
    if not cuenta_seleccionada:
        try:
            cuenta_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'CUENTA') and @clickable='true']")
            cuenta_desc = cuenta_btn.get_attribute('content-desc') or 'primera'
            cuenta_btn.click()
            print('  ✅ Primera cuenta seleccionada (fallback)')
            cuenta_seleccionada = True
            time.sleep(2)
        except:
            pass
    if cuenta_desc:
        driver._cuenta_seleccionada_desc = cuenta_desc
    print('  📝 Cerrando modal de selección...')
    time.sleep(1)
    try:
        aceptar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Aceptar' or @content-desc='Confirmar' or contains(@text, 'Aceptar')]")
        aceptar_btn.click()
        print('  ✅ Modal cerrado (Aceptar/Confirmar)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        cerrar_btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Cerrar' and @clickable='true']")
        cerrar_btn.click()
        print('  ✅ Modal cerrado (Cerrar)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        cont_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")
        cont_btn.click()
        print('  ✅ Modal cerrado (Continuar)')
        time.sleep(2)
        return True
    except:
        pass
    if cuenta_seleccionada:
        print('  ℹ️ Cuenta seleccionada, modal se cierra automáticamente')
        return True
    print('  ⚠️ No se pudo cerrar el modal')
    return cuenta_seleccionada

def ingresar_monto_pagar_qr(driver, monto='1.00'):
    print(f'  📝 Ingresando monto: {monto}...')
    time.sleep(2)
    ok = _ingresar_texto_en_campo(driver, resource_id='qr_input_monto', valor=monto, hints_alternativos=['0.00', 'Monto', 'Importe'])
    if ok:
        print(f'  ✅ Monto ingresado: {monto}')
    else:
        print(f'  ❌ Error al ingresar monto')
    return ok

def click_confirmar_pago_qr(driver):
    print('  📝 Click en Confirmar la transacción...')
    time.sleep(2)
    try:
        confirmar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Confirmar la transacción']")
        confirmar_btn.click()
        print('  ✅ Click en Confirmar la transacción (content-desc)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        confirmar_btn = driver.find_element(AppiumBy.XPATH, "//android.view.View[@resource-id='qr_btn_confirmar_pago']//android.widget.Button")
        confirmar_btn.click()
        print('  ✅ Click en Confirmar (ID + hijo)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        confirmar_btn = driver.find_element(AppiumBy.ID, 'qr_btn_confirmar_pago')
        confirmar_btn.click()
        print('  ✅ Click en Confirmar (ID directo)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        confirmar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Confirmar') and @clickable='true']")
        confirmar_btn.click()
        print('  ✅ Click en Confirmar (texto)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al clickear Confirmar: {e}')
        return False

def cerrar_comprobante_pagar_qr(driver):
    print('  📝 Cerrando comprobante...')
    time.sleep(3)
    try:
        cerrar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Cerrar']")
        cerrar_btn.click()
        print('  ✅ Click en Cerrar (content-desc)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        cerrar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Cerrar') and @clickable='true']")
        cerrar_btn.click()
        print('  ✅ Click en Cerrar (texto)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        regresar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Regresar']")
        regresar.click()
        print('  ✅ Click en Regresar')
        time.sleep(2)
        return True
    except:
        pass
    try:
        aceptar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Aceptar']")
        aceptar.click()
        print('  ✅ Click en Aceptar')
        time.sleep(2)
        return True
    except:
        pass
    try:
        driver.back()
        print('  ✅ Back ejecutado')
        time.sleep(2)
        return True
    except:
        print('  ⚠️ No se encontró botón Cerrar')
        return False

def realizar_pagar_qr(driver, monto='1.00', numero_cuenta=None, reporte=None, tiempos=None, paso_inicial=6):
    print(f'\n📱 INICIANDO PAGO QR')
    print(f'💰 Monto: {monto}')
    print(f"🏦 Cuenta: {(numero_cuenta if numero_cuenta else 'Primera disponible')}")
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Click QR')
    if not click_qr_menu(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Menú QR abierto', 'Se accedió al menú QR desde el home.', espera=1.5)
    paso_num += 1
    tiempos.start('2. Pagar QR')
    if not select_pagar_qr(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla Pagar QR', 'Se accedió a la pantalla de Pago QR. Se solicita la imagen del código QR.', espera=1.5)
    paso_num += 1
    tiempos.start('3. Abrir galería')
    if not abrir_galeria(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Galería abierta', 'Se abrió la galería de imágenes para seleccionar el código QR.', espera=1.5)
    paso_num += 1
    tiempos.start('4. Seleccionar foto')
    foto_ok = seleccionar_primera_foto_qr(driver)
    tiempos.stop()
    if reporte:
        if foto_ok:
            reporte.capturar_paso(paso_num, 'Imagen QR seleccionada', 'Se seleccionó la primera imagen de la galería como código QR a pagar.', espera=1.5)
        else:
            reporte.capturar_paso(paso_num, 'Selección de imagen QR', 'No se pudo confirmar la selección de la imagen QR.', espera=1.5)
    paso_num += 1
    if not foto_ok:
        tiempos.stop()
        return False
    tiempos.start('5. Seleccionar cuenta')
    if not seleccionar_cuenta_pagar_qr(driver, numero_cuenta):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        desc_cuenta = getattr(driver, '_cuenta_seleccionada_desc', '')
        if numero_cuenta:
            reporte.capturar_paso(paso_num, f"Cuenta '{numero_cuenta}' seleccionada", f"Se seleccionó la cuenta '{numero_cuenta}' para el pago QR.", espera=1.5)
        else:
            reporte.capturar_paso(paso_num, 'Cuenta seleccionada', f"Se seleccionó la cuenta '{desc_cuenta[:100]}' para el pago QR.", espera=1.5)
    paso_num += 1
    tiempos.start('6. Ingresar monto')
    if not ingresar_monto_pagar_qr(driver, monto):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Monto ingresado: {monto}', f"Se ingresó el monto '{monto}' en el campo correspondiente.", espera=1.5)
    paso_num += 1
    tiempos.start('7. Confirmar transacción')
    if not click_confirmar_pago_qr(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pago confirmado', f"Se confirmó la transacción del pago QR por '{monto}'.", espera=2.0)
    paso_num += 1
    tiempos.start('8. Cerrar comprobante')
    cerrar_comprobante_pagar_qr(driver)
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Comprobante cerrado', 'Se cerró el comprobante del pago QR.', espera=1.0)
    paso_num += 1
    tiempos.start('9. Volver al home')
    if not volver_home_pagar_qr(driver):
        print('  ⚠️ No se pudo volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Pagar QR finalizado', 'Se regresó exitosamente al home. El pago QR ha sido completado.', espera=1.5)
    paso_num += 1
    print('\n✅ PAGO QR COMPLETADO EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('qr_pagar_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO: LOGIN + PAGAR QR + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    MONTO = _input_cfg.get('MONTO', '1.00')
    NUMERO_CUENTA = _input_cfg.get('NUMERO_CUENTA', '40-0-1157872-3')
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Pagar_QR')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f'💰 Monto: {MONTO}')
    print(f"🏦 Cuenta: {(NUMERO_CUENTA if NUMERO_CUENTA else 'Primera disponible')}")
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Monto del pago': MONTO, 'Número de cuenta': NUMERO_CUENTA if NUMERO_CUENTA else '(primera disponible)', 'Fuente del QR': 'Galería (primera foto)'})
    login_ok = _input_cfg.get('login_ok', False)
    pago_ok = _input_cfg.get('pago_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            pago_ok = realizar_pagar_qr(driver, monto=MONTO, numero_cuenta=NUMERO_CUENTA, reporte=reporte, tiempos=tiempos, paso_inicial=6)
            if pago_ok:
                print('\n🎉 PAGO QR EXITOSO!')
            else:
                print('\n❌ PAGO QR FALLIDO')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and pago_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login          : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Pagar QR       : {('✅ OK' if pago_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

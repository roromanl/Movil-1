"""
Flujo Pago de T. Crédito (desde Movimientos) + reporte Word.
Pasos: Login → T. CRÉDITO → Movimientos (inferior) → Pagar
       → Cuenta origen → Tipo de pago → (Monto si "Otro")
       → Continuar → Confirmar → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import volver_home_tc__f294298b41 as volver_home_tc
from framework.common.ui_helpers import _esta_en_home as _esta_en_home, _seleccionar_opcion_case_insensitive__f21faf0807 as _seleccionar_opcion_case_insensitive, _ingresar_texto_en_campo as _ingresar_texto_en_campo

def ir_a_tarjeta_credito(driver, max_intentos=8):
    print('  📝 Navegando a T. CRÉDITO...')
    time.sleep(3)
    texto_objetivo = 'T. CRÉDITO'

    def _buscar_en_pantalla():
        try:
            tc = driver.find_element(AppiumBy.XPATH, f"//android.view.View[@content-desc='{texto_objetivo}']")
            tc.click()
            print('  ✅ Click en T. CRÉDITO (content-desc exacto)')
            time.sleep(3)
            return True
        except:
            pass
        try:
            tc = driver.find_element(AppiumBy.XPATH, f"//*[contains(translate(@content-desc, 'ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÑ.', 'abcdefghijklmnopqrstuvwxyzáéíóúñ.'), 't. crédito') and @clickable='true']")
            tc.click()
            print('  ✅ Click en T. CRÉDITO (case-insensitive)')
            time.sleep(3)
            return True
        except:
            pass
        try:
            tc = driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{texto_objetivo}') and @clickable='true']")
            tc.click()
            print('  ✅ Click en T. CRÉDITO (texto)')
            time.sleep(3)
            return True
        except:
            pass
        try:
            tc = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, 'CRÉDITO') and @clickable='true']")
            tc.click()
            print('  ✅ Click en T. CRÉDITO (contains CRÉDITO)')
            time.sleep(3)
            return True
        except:
            pass
        return False
    if _buscar_en_pantalla():
        return True
    for intento in range(max_intentos):
        try:
            if intento % 2 == 0:
                print(f'  🔄 Scroll horizontal IZQUIERDA {intento // 2 + 1}...')
                driver.swipe(900, 1000, 200, 1000, 500)
            else:
                print(f'  🔄 Scroll horizontal DERECHA {intento // 2 + 1}...')
                driver.swipe(200, 1000, 900, 1000, 500)
            time.sleep(0.6)
            if _buscar_en_pantalla():
                return True
        except:
            pass
    print('  ❌ Error al seleccionar T. CRÉDITO')
    try:
        print('  🔍 Elementos visibles:')
        elementos = driver.find_elements(AppiumBy.XPATH, "//*[@clickable='true' and @content-desc and string-length(@content-desc) > 3]")
        for e in elementos[:15]:
            desc = (e.get_attribute('content-desc') or '').replace('\n', ' | ')
            if len(desc) < 80:
                print(f'     - {desc}')
    except:
        pass
    return False

def seleccionar_movimientos_inferior(driver):
    print("  📝 Seleccionando 'Movimientos' (opción inferior)...")
    time.sleep(2)
    try:
        movimientos = driver.find_element(AppiumBy.ID, 'credit_card_tab_movements')
        movimientos.click()
        print("  ✅ Click en 'Movimientos' (ID tab)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        movimientos = driver.find_element(AppiumBy.XPATH, "//android.view.View[@content-desc='Movimientos' and @clickable='true']")
        movimientos.click()
        print("  ✅ Click en 'Movimientos' (content-desc)")
        time.sleep(3)
        return True
    except:
        pass
    if _seleccionar_opcion_case_insensitive(driver, 'Movimientos', timeout=5, debug=True):
        print("  ✅ Click en 'Movimientos' (case-insensitive)")
        time.sleep(3)
        return True
    print("  ❌ Error al seleccionar 'Movimientos'")
    return False

def click_pagar_desde_movimientos(driver):
    print("  📝 Click en 'Pagar' (desde Movimientos)...")
    time.sleep(3)
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Pagar' and @clickable='true']")
        btn.click()
        print("  ✅ Click en 'Pagar' (content-desc exacto)")
        time.sleep(5)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Pagar') and @clickable='true']")
        btn.click()
        print("  ✅ Click en 'Pagar' (content-desc contains)")
        time.sleep(5)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//*[@text='Pagar' and @clickable='true']")
        btn.click()
        print("  ✅ Click en 'Pagar' (texto)")
        time.sleep(5)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//*[contains(translate(@content-desc, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'pagar') and @clickable='true']")
        btn.click()
        print("  ✅ Click en 'Pagar' (case-insensitive)")
        time.sleep(5)
        return True
    except:
        pass
    print("  ❌ Error al clickear 'Pagar' desde Movimientos")
    try:
        print('  🔍 Elementos visibles en Movimientos:')
        elementos = driver.find_elements(AppiumBy.XPATH, "//*[@clickable='true' and @content-desc and string-length(@content-desc) > 3]")
        for e in elementos[:15]:
            desc = (e.get_attribute('content-desc') or '').replace('\n', ' | ')
            if len(desc) < 80:
                print(f'     - {desc}')
    except:
        pass
    return False

def seleccionar_cuenta_origen_tc(driver, numero_cuenta='40-0-0124460-6'):
    print(f'  📝 Seleccionando cuenta origen: {numero_cuenta}...')
    time.sleep(3)
    wait = WebDriverWait(driver, 5)
    try:
        selector_actual = driver.find_element(AppiumBy.ID, 'credit_card_origin')
        desc_actual = selector_actual.get_attribute('content-desc') or ''
        if numero_cuenta in desc_actual:
            print(f'  ✅ Cuenta ya está seleccionada: {numero_cuenta}')
            return True
    except:
        pass
    abierto = False
    try:
        selector = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'credit_card_origin')))
        selector.click()
        print('  ✅ Click en selector de cuenta (ID)')
        abierto = True
    except:
        pass
    if not abierto:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='credit_card_origin']")
            selector.click()
            print('  ✅ Click en selector de cuenta (XPATH)')
            abierto = True
        except:
            pass
    if not abierto:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Selecciona una cuenta']")
            selector.click()
            print('  ✅ Click en selector de cuenta (content-desc)')
            abierto = True
        except:
            pass
    if not abierto:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'cuenta') and @clickable='true']")
            selector.click()
            print('  ✅ Click en selector de cuenta (contains)')
            abierto = True
        except Exception as e:
            print(f'  ❌ Error al abrir selector de cuenta: {e}')
            return False
    time.sleep(2)
    try:
        cuenta = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, f"//android.widget.Button[contains(@content-desc, '{numero_cuenta}')]")))
        cuenta.click()
        print(f'  ✅ Cuenta seleccionada (completa): {numero_cuenta}')
        time.sleep(2)
        return True
    except:
        pass
    try:
        partes = numero_cuenta.split('-')
        if len(partes) >= 2:
            ultimo_segmento = partes[-1]
            cuenta = driver.find_element(AppiumBy.XPATH, f"//android.widget.Button[contains(@content-desc, '{ultimo_segmento}')]")
            cuenta.click()
            print(f'  ✅ Cuenta seleccionada por: {ultimo_segmento}')
            time.sleep(2)
            return True
    except:
        pass
    try:
        cuentas = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'CUENTA')]")
        if cuentas:
            cuentas[0].click()
            print('  ✅ Primera cuenta seleccionada')
            time.sleep(2)
            return True
    except:
        pass
    print(f'  ❌ Error al seleccionar cuenta: {numero_cuenta}')
    return False

def seleccionar_tipo_pago_tc(driver, tipo_pago='Pago minimo'):
    print(f'  📝 Seleccionando tipo de pago: {tipo_pago}...')
    time.sleep(2)
    wait = WebDriverWait(driver, 5)
    abierto = False
    try:
        selector = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'credit_card_debt_type')))
        selector.click()
        print('  ✅ Click en selector de tipo de pago (ID)')
        abierto = True
    except:
        pass
    if not abierto:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='credit_card_debt_type']")
            selector.click()
            print('  ✅ Click en selector de tipo de pago (XPATH)')
            abierto = True
        except:
            pass
    if not abierto:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Selecciona tipo de pago']")
            selector.click()
            print('  ✅ Click en selector de tipo de pago (content-desc)')
            abierto = True
        except:
            pass
    if not abierto:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'tipo de pago') and @clickable='true']")
            selector.click()
            print('  ✅ Click en selector de tipo de pago (contains)')
            abierto = True
        except Exception as e:
            print(f'  ❌ Error al abrir selector de tipo de pago: {e}')
            return False
    time.sleep(2)
    if _seleccionar_opcion_case_insensitive(driver, tipo_pago, timeout=5, debug=True):
        print(f'  ✅ Tipo de pago seleccionado: {tipo_pago}')
        time.sleep(2)
        return True
    print(f'  ❌ Error al seleccionar tipo de pago: {tipo_pago}')
    return False

def ingresar_monto_pago_tc(driver, monto='100.00'):
    print(f'  📝 Ingresando monto: {monto}...')
    time.sleep(2)
    ok = _ingresar_texto_en_campo(driver, resource_id='credit_card_amount', valor=monto, hints_alternativos=['0.00', 'Monto', 'Importe'])
    if ok:
        print(f'  ✅ Monto ingresado: {monto}')
    else:
        print(f'  ❌ Error al ingresar monto')
    return ok

def click_continuar_pago_tc(driver):
    print('  📝 Click en Continuar (pago)...')
    time.sleep(3)
    try:
        continuar = driver.find_element(AppiumBy.ID, 'credit_card_continue')
        continuar.click()
        print('  ✅ Click en Continuar (ID)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        continuar = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='credit_card_continue']")
        continuar.click()
        print('  ✅ Click en Continuar (XPATH)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        continuar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")
        continuar.click()
        print('  ✅ Click en Continuar (content-desc)')
        time.sleep(2)
        return True
    except Exception as e:
        print(f'  ❌ Error al clickear Continuar: {e}')
        return False

def click_confirmar_transaccion_tc(driver):
    print('  📝 Click en Confirmar transacción...')
    time.sleep(8)
    try:
        confirmar = driver.find_element(AppiumBy.ID, 'credit_card_verification_confirm')
        confirmar.click()
        print('  ✅ Click en Confirmar transacción (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        confirmar = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='credit_card_verification_confirm']//android.widget.Button[@content-desc='Confirmar la transacción']")
        confirmar.click()
        print('  ✅ Click en Confirmar transacción (XPATH)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        confirmar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Confirmar la transacción']")
        confirmar.click()
        print('  ✅ Click en Confirmar transacción (content-desc)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        confirmar = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Confirmar') and @clickable='true']")
        confirmar.click()
        print('  ✅ Click en Confirmar transacción (contains)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al clickear Confirmar transacción: {e}')
        return False

def realizar_pago_desde_movimientos_tc(driver, numero_cuenta='40-0-0124460-6', tipo_pago='Pago minimo', monto='100.00', tiempos=None, reporte=None, paso_inicial=6):
    print(f'\n💳 INICIANDO PAGO DE T. CRÉDITO (desde Movimientos)')
    print(f'🏦 Cuenta origen: {numero_cuenta}')
    print(f'📄 Tipo de pago: {tipo_pago}')
    if tipo_pago.lower().strip() == 'otro':
        print(f'💰 Monto: {monto} (manual)')
    else:
        print(f'💰 Monto: (calculado automáticamente)')
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Ir a T. CRÉDITO')
    if not ir_a_tarjeta_credito(driver):
        print('  ❌ Error al ir a T. CRÉDITO')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla T. CRÉDITO', 'Se accedió a la sección de Tarjeta de Crédito desde el home.', espera=2.0)
    paso_num += 1
    print('  📝 Esperando carga de pantalla de T. CRÉDITO...')
    time.sleep(3)
    tiempos.start('2. Movimientos inferior')
    if not seleccionar_movimientos_inferior(driver):
        print("  ❌ Error al seleccionar 'Movimientos'")
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Opción Movimientos (inferior)', "Se seleccionó la opción 'Movimientos' en la parte inferior de la pantalla de Tarjeta de Crédito.", espera=1.5)
    paso_num += 1
    print('  📝 Esperando carga de movimientos...')
    time.sleep(3)
    tiempos.start('3. Click Pagar')
    if not click_pagar_desde_movimientos(driver):
        print("  ❌ Error al clickear 'Pagar'")
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, "Click en 'Pagar' desde Movimientos", "Se hizo clic en el botón 'Pagar' desde la pantalla de Movimientos. Se abrió la pantalla de pago de tarjeta de crédito.", espera=2.0)
    paso_num += 1
    print('  📝 Esperando carga de pantalla de pago...')
    time.sleep(3)
    tiempos.start('4. Cuenta origen')
    if not seleccionar_cuenta_origen_tc(driver, numero_cuenta):
        print('  ❌ Error al seleccionar cuenta origen')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Cuenta origen: {numero_cuenta}', f'Se seleccionó la cuenta de origen: {numero_cuenta}.', espera=1.5)
    paso_num += 1
    tiempos.start('5. Tipo de pago')
    if not seleccionar_tipo_pago_tc(driver, tipo_pago):
        print('  ❌ Error al seleccionar tipo de pago')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Tipo de pago: {tipo_pago}', f"Se seleccionó el tipo de pago: '{tipo_pago}'.", espera=1.5)
    paso_num += 1
    time.sleep(2)
    if tipo_pago.lower().strip() == 'otro':
        tiempos.start('6. Monto (manual)')
        if not ingresar_monto_pago_tc(driver, monto):
            print("  ❌ Error al ingresar monto (tipo 'Otro')")
            tiempos.stop()
            return False
        tiempos.stop()
        if reporte:
            reporte.capturar_paso(paso_num, f'Monto: Bs. {monto}', f'Se ingresó el monto manual de pago: Bs. {monto}.', espera=1.0)
        paso_num += 1
    else:
        tiempos.start('6. Monto (auto)')
        print(f"  ℹ️ Tipo '{tipo_pago}' → monto calculado automáticamente")
        print(f'  ℹ️ NO se ingresa monto manualmente')
        tiempos.stop()
        if reporte:
            reporte.capturar_paso(paso_num, f'Monto calculado automáticamente', f"El monto fue calculado automáticamente por la app al seleccionar el tipo de pago '{tipo_pago}'.", espera=1.0)
        paso_num += 1
    tiempos.start('7. Continuar (pago)')
    if not click_continuar_pago_tc(driver):
        print('  ❌ Error al clickear Continuar')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Continuar (pago)', 'Se hizo clic en Continuar. Se avanzó a la pantalla de verificación.', espera=1.5)
    paso_num += 1
    tiempos.start('8. Confirmar transacción')
    if not click_confirmar_transaccion_tc(driver):
        print('  ❌ Error al clickear Confirmar transacción')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Confirmar transacción', f"Se confirmó la transacción de pago de tarjeta de crédito por el tipo de pago '{tipo_pago}'.", espera=1.5)
    paso_num += 1
    tiempos.start('9. Volver al home')
    if not volver_home_tc(driver):
        print('  ⚠️ Error al volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Pago TC (Movimientos) finalizado', 'Se regresó exitosamente al home. El flujo de pago de tarjeta de crédito desde Movimientos ha terminado.', espera=1.5)
    paso_num += 1
    print('\n✅ PAGO DE T. CRÉDITO (desde Movimientos) COMPLETADO EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('tarjeta_de_credito_movimientos_pagar_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO COMPLETO: LOGIN + MOVIMIENTOS T. CRÉDITO → PAGAR + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    numero_cuenta = _input_cfg.get('numero_cuenta', '40-0-1189577-1')
    tipo_pago = _input_cfg.get('tipo_pago', 'Otro')
    monto_pago = _input_cfg.get('monto_pago', '100.00')
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Pago_TC_Desde_Movimientos')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f'🏦 Cuenta origen: {numero_cuenta}')
    print(f'📄 Tipo de pago: {tipo_pago}')
    if tipo_pago.lower().strip() == 'otro':
        print(f'💰 Monto a pagar: {monto_pago}')
    else:
        print(f'💰 Monto a pagar: (calculado automáticamente)')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Cuenta origen': numero_cuenta, 'Tipo de pago': tipo_pago, 'Monto': monto_pago if tipo_pago.lower().strip() == 'otro' else '(calculado automáticamente)'})
    login_ok = _input_cfg.get('login_ok', False)
    pago_ok = _input_cfg.get('pago_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            pago_ok = realizar_pago_desde_movimientos_tc(driver, numero_cuenta=numero_cuenta, tipo_pago=tipo_pago, monto=monto_pago, tiempos=tiempos, reporte=reporte, paso_inicial=6)
            if pago_ok:
                print('\n🎉 PAGO DE T. CRÉDITO EXITOSO!')
            else:
                print('\n❌ PAGO DE T. CRÉDITO FALLIDO')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and pago_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login          : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Pago T.Crédito : {('✅ OK' if pago_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

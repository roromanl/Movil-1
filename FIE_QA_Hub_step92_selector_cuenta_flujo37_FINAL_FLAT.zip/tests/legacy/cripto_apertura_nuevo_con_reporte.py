"""
Flujo Operación Cripto (botón central del home) + reporte Word.
Pasos: Login → Cripto (home) → Operación (Compra/Venta/Recepción/Envío)
       → Cerrar modal/link → Volver atrás → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import volver_atras_cripto__9c26a1d3b6 as volver_atras_cripto, volver_home__afd08848fd as volver_home
from framework.common.ui_helpers import _esta_en_home as _esta_en_home, _seleccionar_opcion_case_insensitive__f21faf0807 as _seleccionar_opcion_case_insensitive

def click_cripto_home(driver):
    print('  📝 Click en Cripto (home)...')
    time.sleep(2)
    try:
        cripto_btn = driver.find_element(AppiumBy.ID, 'home_btn_cripto')
        cripto_btn.click()
        print('  ✅ Click en Cripto (ID: home_btn_cripto)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        cripto_btn = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='home_btn_cripto' and @clickable='true']")
        cripto_btn.click()
        print('  ✅ Click en Cripto (XPATH resource-id)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        cripto_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Cripto\nCripto']")
        cripto_btn.click()
        print('  ✅ Click en Cripto (content-desc exacto)')
        time.sleep(3)
        return True
    except:
        pass
    if _seleccionar_opcion_case_insensitive(driver, 'Cripto', timeout=5, debug=True):
        print('  ✅ Click en Cripto (helper)')
        time.sleep(3)
        return True
    print('  ❌ Error al clickear Cripto')
    return False

def select_operacion_cripto(driver, operacion='Compra'):
    print(f"  📝 Click en acción cripto: '{operacion}'...")
    time.sleep(2)
    opciones_validas = ['Compra', 'Venta', 'Recepción', 'Envío']
    if operacion not in opciones_validas:
        print(f"  ❌ Acción inválida: '{operacion}'. Debe ser una de: {opciones_validas}")
        return False
    try:
        btn = driver.find_element(AppiumBy.XPATH, f"//*[starts-with(@content-desc, '{operacion}') and @clickable='true']")
        desc = (btn.get_attribute('content-desc') or '').replace('\n', ' | ')
        btn.click()
        print(f"  ✅ Click en '{operacion}' (starts-with) → '{desc[:70]}'")
        time.sleep(5)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{operacion}') and @clickable='true']")
        btn.click()
        print(f"  ✅ Click en '{operacion}' (contains)")
        time.sleep(5)
        return True
    except:
        pass
    if _seleccionar_opcion_case_insensitive(driver, operacion, timeout=5, debug=True):
        print(f"  ✅ Click en '{operacion}' (helper)")
        time.sleep(5)
        return True
    print(f"  ❌ No se encontró la acción: '{operacion}'")
    try:
        print('  🔍 Opciones disponibles:')
        opciones = driver.find_elements(AppiumBy.XPATH, "//*[@clickable='true' and @content-desc and string-length(@content-desc) > 3]")
        for o in opciones:
            desc = (o.get_attribute('content-desc') or '').replace('\n', ' | ')
            if len(desc) < 100:
                print(f'     - {desc}')
    except:
        pass
    return False

def cerrar_operacion_cripto(driver):
    print('  📝 Cerrando operación cripto...')
    time.sleep(3)
    try:
        cerrar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Cerrar']")
        cerrar_btn.click()
        print('  ✅ Click en Cerrar (content-desc)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        cerrar_btn = driver.find_element(AppiumBy.XPATH, "//android.view.View[@content-desc='Cerrar' and @clickable='true']")
        cerrar_btn.click()
        print('  ✅ Click en Cerrar (View)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        regresar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Regresar']")
        regresar_btn.click()
        print('  ✅ Click en Regresar')
        time.sleep(2)
        return True
    except:
        pass
    try:
        aceptar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Aceptar']")
        aceptar_btn.click()
        print('  ✅ Click en Aceptar')
        time.sleep(2)
        return True
    except:
        pass
    try:
        driver.back()
        print('  ✅ Back ejecutado')
        time.sleep(2)
        return True
    except Exception as e:
        print(f'  ❌ Error al cerrar operación: {e}')
        return False

def realizar_operacion_cripto(driver, operacion='Compra', reporte=None, tiempos=None, paso_inicial=6):
    print(f'\n🔷 INICIANDO OPERACIÓN CRIPTO: {operacion}')
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Click Cripto (home)')
    if not click_cripto_home(driver):
        print('  ❌ Error al clickear Cripto')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla de Criptomonedas', 'Se accedió a la pantalla principal de Criptomonedas desde el botón Cripto del home. Se muestran las opciones disponibles.', espera=1.5)
    paso_num += 1
    tiempos.start(f"2. Operación '{operacion}'")
    if not select_operacion_cripto(driver, operacion):
        print(f"  ❌ Error al seleccionar '{operacion}'")
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f"Operación '{operacion}' ejecutada", f"Se hizo clic en la operación '{operacion}' de criptomonedas. Se abre el link/formulario correspondiente.", espera=2.0)
    paso_num += 1
    tiempos.start('3. Cerrar link/modal')
    if not cerrar_operacion_cripto(driver):
        print('  ⚠️ Error al cerrar la operación')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Operación cerrada', 'Se cerró el link/formulario de la operación de criptomonedas.', espera=1.5)
    paso_num += 1
    tiempos.start('4. Volver atrás')
    if not volver_atras_cripto(driver):
        print('  ⚠️ Error al volver atrás')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Regreso a la pantalla anterior', 'Se regresó desde Criptomonedas a la pantalla anterior.', espera=1.0)
    paso_num += 1
    tiempos.start('5. Volver al home')
    if not volver_home(driver):
        print('  ⚠️ Error al volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Operación Cripto finalizado', f"Se regresó exitosamente al home. La operación '{operacion}' de criptomonedas ha terminado.", espera=1.5)
    paso_num += 1
    print(f"\n✅ OPERACIÓN CRIPTO '{operacion}' COMPLETADA EXITOSAMENTE")
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('cripto_apertura_nuevo_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO: LOGIN + OPERACIÓN CRIPTO (home) + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    OPERACION = _input_cfg.get('OPERACION', 'Compra')
    NOMBRE_PRUEBA = f'Cripto_{OPERACION}'
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f'🔷 Operación: {OPERACION}')
    print(f'📄 Nombre de la prueba: {NOMBRE_PRUEBA}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Operación cripto': OPERACION, 'Acceso': 'Botón Cripto del home (directo)'})
    login_ok = _input_cfg.get('login_ok', False)
    operacion_ok = _input_cfg.get('operacion_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            operacion_ok = realizar_operacion_cripto(driver, operacion=OPERACION, reporte=reporte, tiempos=tiempos, paso_inicial=6)
            if operacion_ok:
                print(f"\n🎉 OPERACIÓN CRIPTO '{OPERACION}' EXITOSA!")
            else:
                print(f"\n❌ OPERACIÓN CRIPTO '{OPERACION}' FALLIDA")
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and operacion_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login          : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Operación      : {('✅ OK' if operacion_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

"""
Flujo Cambio de Imagen de Seguridad + reporte Word.
Pasos: Login → Más → Configuraciones usuario → Cambio de imagen de seguridad
       → Seleccionar imagen → Continuar → Confirmar cambio
       → Continuar (éxito) → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import volver_home_imagen
from framework.common.ui_helpers import _esta_en_home as _esta_en_home, select_configuraciones_usuario

def click_mas_menu(driver):
    print('  📝 Click en menú Más...')
    time.sleep(2)
    try:
        mas_btn = driver.find_element(AppiumBy.ID, 'home_btn_mas')
        mas_btn.click()
        print('  ✅ Click en Más (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        mas_btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Más\nMás' and @clickable='true']")
        mas_btn.click()
        print('  ✅ Click en Más (content-desc exacto)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        mas_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Más') and @clickable='true']")
        mas_btn.click()
        print('  ✅ Click en Más (contains)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al clickear Más: {e}')
        return False

def select_cambio_imagen_seguridad(driver):
    print('  📝 Seleccionando Cambio de imagen de seguridad...')
    time.sleep(2)
    try:
        driver.swipe(500, 1500, 500, 800, 500)
        time.sleep(1)
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.ID, 'user_profile_settings_image')
        btn.click()
        print('  ✅ Click en Cambio de imagen de seguridad (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Imagen de seguridad')]")
        btn.click()
        print('  ✅ Click en Cambio de imagen de seguridad (content-desc)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al seleccionar Cambio de imagen de seguridad: {e}')
        return False

def select_imagen_seguridad(driver, imagen_id=None, index=0, max_scrolls=5, timeout=15):
    print(f'  📝 Seleccionando imagen de seguridad...')
    if imagen_id:
        print(f'     • ID: {imagen_id}')
    else:
        print(f'     • Índice: {index}')
    time.sleep(2)
    imagen_desc = None
    if imagen_id:
        try:
            imagen = driver.find_element(AppiumBy.ID, imagen_id)
            imagen_desc = imagen.get_attribute('content-desc') or imagen_id
            imagen.click()
            print(f'  ✅ Imagen seleccionada (ID exacto): {imagen_id}')
            time.sleep(2)
            driver._last_imagen_desc = imagen_desc
            return True
        except:
            pass
    if imagen_id:
        try:
            imagen = driver.find_element(AppiumBy.XPATH, f"//*[contains(@resource-id, '{imagen_id}') and @clickable='true']")
            rid = imagen.get_attribute('resource-id')
            imagen_desc = imagen.get_attribute('content-desc') or rid
            imagen.click()
            print(f'  ✅ Imagen seleccionada (ID contains): {rid}')
            time.sleep(2)
            driver._last_imagen_desc = imagen_desc
            return True
        except:
            pass
    try:
        imagenes = driver.find_elements(AppiumBy.XPATH, "//android.widget.ImageView[contains(@resource-id, 'securitysettings_select_imagen_ent_')]")
        print(f'  🔍 Imágenes encontradas: {len(imagenes)}')
        if imagenes:
            idx = index if len(imagenes) > index else 0
            rid = imagenes[idx].get_attribute('resource-id')
            imagen_desc = imagenes[idx].get_attribute('content-desc') or rid
            imagenes[idx].click()
            print(f'  ✅ Imagen seleccionada (índice {idx}): {rid}')
            time.sleep(2)
            driver._last_imagen_desc = imagen_desc
            return True
    except:
        pass
    print('  🔄 Haciendo scroll para buscar imagen...')
    for i in range(max_scrolls):
        try:
            driver.swipe(500, 1500, 500, 600, 500)
            time.sleep(1)
        except:
            pass
        try:
            if imagen_id:
                imagen = driver.find_element(AppiumBy.XPATH, f"//*[contains(@resource-id, '{imagen_id}') and @clickable='true']")
                imagen_desc = imagen.get_attribute('content-desc') or imagen_id
                imagen.click()
                print(f'  ✅ Imagen seleccionada (después de {i + 1} scrolls)')
                time.sleep(2)
                driver._last_imagen_desc = imagen_desc
                return True
            else:
                imagenes = driver.find_elements(AppiumBy.XPATH, "//android.widget.ImageView[contains(@resource-id, 'securitysettings_select_imagen_ent_')]")
                if imagenes and len(imagenes) > index:
                    imagen_desc = imagenes[index].get_attribute('content-desc') or ''
                    imagenes[index].click()
                    print(f'  ✅ Imagen #{index + 1} seleccionada (después de {i + 1} scrolls)')
                    time.sleep(2)
                    driver._last_imagen_desc = imagen_desc
                    return True
        except:
            pass
    try:
        imagenes = driver.find_elements(AppiumBy.XPATH, "//android.widget.ImageView[@clickable='true' and @content-desc]")
        print(f'  🔍 Imágenes por content-desc: {len(imagenes)}')
        if imagenes:
            imagen_desc = imagenes[0].get_attribute('content-desc') or ''
            imagenes[0].click()
            print('  ✅ Primera imagen con content-desc seleccionada')
            time.sleep(2)
            driver._last_imagen_desc = imagen_desc
            return True
    except:
        pass
    print(f'  ❌ No se encontró ninguna imagen')
    return False

def click_continuar_imagen(driver):
    print('  📝 Click en Continuar (selección)...')
    time.sleep(2)
    try:
        btn = driver.find_element(AppiumBy.ID, 'security_image_btn_continuar')
        btn.click()
        print('  ✅ Click en Continuar (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")
        btn.click()
        print('  ✅ Click en Continuar (content-desc)')
        time.sleep(3)
        return True
    except:
        try:
            btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Continuar') and @clickable='true']")
            btn.click()
            print('  ✅ Click en Continuar (texto)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Continuar: {e}')
            return False

def confirmar_cambio_imagen(driver, clave_temporal='123456'):
    print('  📝 Confirmando cambio de imagen...')
    time.sleep(3)
    try:
        driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, '¿Desea confirmar el cambio?')]")
        print('  ✅ Modal de confirmación detectado')
    except:
        print('  ⚠️ No se detectó modal de confirmación')
    try:
        btn = driver.find_element(AppiumBy.ID, 'shared_btn_confirmar_clave_temporal')
        btn.click()
        print('  ✅ Click en Confirmar cambio (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Confirmar cambio']")
        btn.click()
        print('  ✅ Click en Confirmar cambio (content-desc)')
        time.sleep(3)
        return True
    except:
        try:
            btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Confirmar cambio') and @clickable='true']")
            btn.click()
            print('  ✅ Click en Confirmar cambio (texto)')
            time.sleep(3)
            return True
        except:
            try:
                botones = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[@clickable='true']")
                if botones:
                    botones[-1].click()
                    print('  ✅ Click en Confirmar cambio (último botón)')
                    time.sleep(3)
                    return True
            except Exception as e:
                print(f'  ❌ Error al confirmar cambio: {e}')
                return False

def click_continuar_exito_imagen(driver):
    print('  📝 Click en Continuar (modal de éxito)...')
    time.sleep(3)
    try:
        btn = driver.find_element(AppiumBy.ID, 'security_image_btn_continuar_exito')
        btn.click()
        print('  ✅ Click en Continuar (ID)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")
        btn.click()
        print('  ✅ Click en Continuar (content-desc)')
        time.sleep(2)
        return True
    except:
        try:
            btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Continuar') and @clickable='true']")
            btn.click()
            print('  ✅ Click en Continuar (texto)')
            time.sleep(2)
            return True
        except Exception as e:
            print(f'  ⚠️ No se encontró el botón Continuar: {e}')
            return False

def realizar_cambio_imagen_seguridad(driver, imagen_id='securitysettings_select_imagen_ent_067', imagen_index=0, clave_temporal='123456', reporte=None, tiempos=None, paso_inicial=6):
    print(f'\n🖼️ INICIANDO CAMBIO DE IMAGEN DE SEGURIDAD')
    if imagen_id:
        print(f'📝 Imagen ID: {imagen_id}')
    else:
        print(f'📝 Imagen índice: {imagen_index}')
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Ir a Más')
    if not click_mas_menu(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Menú Más abierto', "Se accedió al menú 'Más' desde la barra de navegación inferior.", espera=1.5)
    paso_num += 1
    tiempos.start('2. Config. usuario')
    if not select_configuraciones_usuario(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Configuraciones de usuario', 'Se accedió a las Configuraciones de usuario.', espera=1.5)
    paso_num += 1
    tiempos.start('3. Cambio imagen')
    if not select_cambio_imagen_seguridad(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla de Cambio de Imagen de Seguridad', 'Se accedió a la pantalla de cambio de imagen de seguridad. Se muestra la galería de imágenes disponibles.', espera=1.5)
    paso_num += 1
    tiempos.start('4. Seleccionar imagen')
    if not select_imagen_seguridad(driver, imagen_id=imagen_id, index=imagen_index):
        print('  ⚠️ Imagen por defecto no encontrada; reintentando por index=0')
        if not select_imagen_seguridad(driver, imagen_id=None, index=0):
            tiempos.stop()
            return False
    tiempos.stop()
    if reporte:
        desc_imagen = getattr(driver, '_last_imagen_desc', '') or ''
        if imagen_id:
            reporte.capturar_paso(paso_num, f'Imagen seleccionada: {imagen_id}', f"Se seleccionó la imagen de seguridad con ID '{imagen_id}'. Descripción: {desc_imagen[:80]}", espera=1.5)
        else:
            reporte.capturar_paso(paso_num, f'Imagen seleccionada (índice {imagen_index})', f'Se seleccionó la imagen de seguridad #{imagen_index + 1}. Descripción: {desc_imagen[:80]}', espera=1.5)
    paso_num += 1
    tiempos.start('5. Continuar')
    if not click_continuar_imagen(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Continuar (selección)', 'Se hizo clic en Continuar tras seleccionar la imagen.', espera=1.5)
    paso_num += 1
    tiempos.start('6. Confirmar cambio')
    if not confirmar_cambio_imagen(driver, clave_temporal):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Cambio confirmado', 'Se confirmó el cambio de imagen de seguridad en el modal.', espera=1.5)
    paso_num += 1
    tiempos.start('7. Continuar (éxito)')
    if not click_continuar_exito_imagen(driver):
        print('  ⚠️ No se pudo hacer click en Continuar (modal de éxito)')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Modal de éxito aceptado', 'Se confirmó el mensaje de éxito del cambio de imagen.', espera=1.5)
    paso_num += 1
    tiempos.start('8. Volver al home')
    if not volver_home_imagen(driver):
        print('  ⚠️ No se pudo volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Cambio de Imagen finalizado', 'Se regresó exitosamente al home. El cambio de imagen de seguridad ha terminado.', espera=1.5)
    paso_num += 1
    print('\n✅ CAMBIO DE IMAGEN DE SEGURIDAD COMPLETADO EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('login_cambio_imagen_seguridad_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO: LOGIN + CAMBIO DE IMAGEN DE SEGURIDAD + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    clave_temporal = _input_cfg.get('clave_temporal', '123456')
    IMAGEN_ID = _input_cfg.get('IMAGEN_ID', 'securitysettings_select_imagen_ent_067')
    IMAGEN_INDEX = _input_cfg.get('IMAGEN_INDEX', 0)
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Cambio_Imagen_Seguridad')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    if IMAGEN_ID:
        print(f'🖼️ Imagen ID: {IMAGEN_ID}')
    else:
        print(f'🖼️ Imagen índice: {IMAGEN_INDEX}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Imagen ID': IMAGEN_ID or '(no especificado)', 'Imagen índice': IMAGEN_INDEX})
    login_ok = _input_cfg.get('login_ok', False)
    cambio_ok = _input_cfg.get('cambio_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            cambio_ok = realizar_cambio_imagen_seguridad(driver, imagen_id=IMAGEN_ID, imagen_index=IMAGEN_INDEX, clave_temporal=clave_temporal, reporte=reporte, tiempos=tiempos, paso_inicial=6)
            if cambio_ok:
                print('\n🎉 CAMBIO DE IMAGEN DE SEGURIDAD EXITOSO!')
            else:
                print('\n❌ CAMBIO DE IMAGEN DE SEGURIDAD FALLIDO')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and cambio_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login          : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Cambio imagen  : {('✅ OK' if cambio_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

"""
Flujo Detalle de Préstamo (vía Pagos) + reporte Word.
Pasos: Login → Pagos (home) → Pago de préstamo → Seleccionar préstamo
       → Detalles → Verificar pantalla → Obtener datos → Scroll
       → Regresar → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import volver_atras_detalle__d2aa01012d as volver_atras_detalle, volver_home__0104fb0f44 as volver_home
from framework.common.ui_helpers import _esta_en_home as _esta_en_home, _seleccionar_opcion_case_insensitive__f21faf0807 as _seleccionar_opcion_case_insensitive

def click_home_pagos(driver):
    print('  📝 Click en Pagos (home)...')
    time.sleep(2)
    try:
        pagos_btn = driver.find_element(AppiumBy.ID, 'home_btn_pagos')
        pagos_btn.click()
        print('  ✅ Click en Pagos (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        pagos_btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Pagos\nPagos' and @clickable='true']")
        pagos_btn.click()
        print('  ✅ Click en Pagos (content-desc)')
        time.sleep(3)
        return True
    except:
        pass
    if _seleccionar_opcion_case_insensitive(driver, 'Pagos', timeout=5):
        print('  ✅ Click en Pagos (helper)')
        time.sleep(3)
        return True
    print('  ❌ Error al clickear Pagos')
    return False

def click_pago_prestamo_opcion(driver):
    print("  📝 Click en 'Pago de préstamo'...")
    time.sleep(2)
    try:
        btn = driver.find_element(AppiumBy.ID, 'payments_option_loans')
        btn.click()
        print("  ✅ Click en 'Pago de préstamo' (ID: payments_option_loans)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='payments_option_loans' and @clickable='true']")
        btn.click()
        print("  ✅ Click en 'Pago de préstamo' (XPATH resource-id)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Pago de préstamo\nPago de préstamo']")
        btn.click()
        print("  ✅ Click en 'Pago de préstamo' (content-desc exacto)")
        time.sleep(3)
        return True
    except:
        pass
    if _seleccionar_opcion_case_insensitive(driver, 'Pago de préstamo', timeout=5, debug=True):
        print("  ✅ Click en 'Pago de préstamo' (helper)")
        time.sleep(3)
        return True
    print("  ❌ Error al clickear 'Pago de préstamo'")
    return False

def seleccionar_prestamo_por_numero(driver, numero_prestamo):
    print(f'  📝 Verificando préstamo seleccionado: {numero_prestamo}...')
    time.sleep(2)
    try:
        selector = driver.find_element(AppiumBy.ID, 'loan_payment_selector')
        hijo = selector.find_element(AppiumBy.XPATH, ".//android.widget.Button[@clickable='true']")
        desc_actual = hijo.get_attribute('content-desc') or ''
        print(f'  🔍 Préstamo actual: {desc_actual[:80]}...')
        if numero_prestamo in desc_actual:
            print(f'  ✅ Préstamo ya está seleccionado: {numero_prestamo}')
            return True
    except Exception as e:
        print(f'  ⚠️ No se pudo verificar el selector: {e}')
    print(f'  📝 Abriendo selector de préstamo para cambiar a: {numero_prestamo}...')
    abierto = False
    try:
        selector = driver.find_element(AppiumBy.ID, 'loan_payment_selector')
        hijo = selector.find_element(AppiumBy.XPATH, ".//android.widget.Button[@clickable='true']")
        hijo.click()
        print('  ✅ Click en selector de préstamo (hijo clickable)')
        abierto = True
        time.sleep(3)
    except:
        pass
    if not abierto:
        try:
            selector = driver.find_element(AppiumBy.ID, 'loan_payment_selector')
            selector.click()
            print('  ✅ Click en selector de préstamo (contenedor)')
            abierto = True
            time.sleep(3)
        except:
            pass
    if not abierto:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Selecciona tu préstamo') and @clickable='true']")
            selector.click()
            print('  ✅ Click en selector de préstamo (content-desc)')
            abierto = True
            time.sleep(3)
        except:
            pass
    if not abierto:
        print(f'  ❌ No se pudo abrir el selector de préstamo')
        return False
    time.sleep(2)

    def _buscar_prestamo():
        try:
            prestamo = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{numero_prestamo}') and @clickable='true']")
            prestamo.click()
            print(f'  ✅ Préstamo seleccionado: {numero_prestamo}')
            time.sleep(2)
            return True
        except:
            pass
        try:
            partes = numero_prestamo.split('-')
            if len(partes) >= 2:
                ultimo = partes[-1]
                prestamo = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{ultimo}') and @clickable='true']")
                prestamo.click()
                print(f'  ✅ Préstamo seleccionado (último segmento: {ultimo})')
                time.sleep(2)
                return True
        except:
            pass
        try:
            prestamos = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[contains(@resource-id, 'loan_payment_') and @clickable='true']")
            for p in prestamos:
                desc = p.get_attribute('content-desc') or ''
                if numero_prestamo in desc:
                    p.click()
                    print(f'  ✅ Préstamo seleccionado (iteración)')
                    time.sleep(2)
                    return True
        except:
            pass
        return False
    if _buscar_prestamo():
        return True
    print(f'  ❌ No se encontró el préstamo: {numero_prestamo}')
    return False

def click_detalles_prestamo(driver):
    print("  📝 Click en 'Detalles'...")
    time.sleep(2)
    try:
        btn = driver.find_element(AppiumBy.ID, 'loan_payment_details')
        btn.click()
        print("  ✅ Click en 'Detalles' (ID)")
        time.sleep(5)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='loan_payment_details']//android.widget.Button[@content-desc='Detalles']")
        btn.click()
        print("  ✅ Click en 'Detalles' (XPATH padre+hijo)")
        time.sleep(5)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Detalles' and @clickable='true']")
        btn.click()
        print("  ✅ Click en 'Detalles' (content-desc)")
        time.sleep(5)
        return True
    except:
        pass
    if _seleccionar_opcion_case_insensitive(driver, 'Detalles', timeout=5, debug=True):
        print("  ✅ Click en 'Detalles' (helper)")
        time.sleep(5)
        return True
    print("  ❌ Error al clickear 'Detalles'")
    return False

def verificar_detalle_prestamo(driver):
    print('  📝 Verificando pantalla de detalle de préstamo...')
    time.sleep(2)
    try:
        driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Pago de crédito']")
        print("  ✅ Pantalla verificada (título 'Pago de crédito')")
        return True
    except:
        pass
    try:
        driver.find_element(AppiumBy.XPATH, "//*[contains(translate(@content-desc, 'ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÑ', 'abcdefghijklmnopqrstuvwxyzáéíóúñ'), 'pago de crédito')]")
        print('  ✅ Pantalla verificada (título case-insensitive)')
        return True
    except:
        pass
    try:
        driver.find_element(AppiumBy.ID, 'shared_card_account_product')
        print("  ✅ Pantalla verificada (tarjeta 'shared_card_account_product')")
        return True
    except:
        pass
    try:
        driver.find_element(AppiumBy.ID, 'shared_card_credit_summary')
        print("  ✅ Pantalla verificada (resumen 'shared_card_credit_summary')")
        return True
    except:
        pass
    try:
        driver.find_element(AppiumBy.ID, 'product_loan_detail_pay')
        print("  ✅ Pantalla verificada (botón 'product_loan_detail_pay')")
        return True
    except:
        pass
    try:
        driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Préstamo:')]")
        print("  ✅ Pantalla verificada (contiene 'Préstamo:')")
        return True
    except:
        pass
    print('  ⚠️ No se pudo verificar la pantalla de detalle')
    return False

def obtener_datos_prestamo(driver):
    """Obtiene y muestra los datos del préstamo desde el detalle."""
    print('\n  📋 DATOS DEL PRÉSTAMO:')
    print('  ' + '-' * 50)
    campos_encontrados = 0
    try:
        tarjeta = driver.find_element(AppiumBy.ID, 'shared_card_account_product')
        desc = tarjeta.get_attribute('content-desc')
        if desc:
            print(f"  📌 Tarjeta: {desc.replace(chr(10), ' - ')}")
            campos_encontrados += 1
    except:
        pass
    try:
        resumen = driver.find_element(AppiumBy.ID, 'shared_card_credit_summary')
        desc = resumen.get_attribute('content-desc')
        if desc:
            lineas = desc.split(chr(10))
            print(f'  📊 Resumen ({len(lineas)} líneas):')
            for linea in lineas:
                print(f'     {linea}')
            campos_encontrados += 1
    except:
        pass
    try:
        pagar = driver.find_element(AppiumBy.ID, 'product_loan_detail_pay')
        desc = pagar.get_attribute('content-desc')
        if desc:
            print(f'  🔘 Botón: {desc}')
            campos_encontrados += 1
    except:
        pass
    try:
        prestamo_view = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Préstamo:')]")
        desc = prestamo_view.get_attribute('content-desc') or ''
        if desc:
            print(f'  📌 Préstamo: {desc}')
            campos_encontrados += 1
    except:
        pass
    try:
        num_view = driver.find_element(AppiumBy.XPATH, "//android.view.View[contains(@content-desc, '-') and string-length(@content-desc) < 20]")
        desc = num_view.get_attribute('content-desc') or ''
        if desc and '-' in desc:
            print(f'  📌 Número: {desc}')
            campos_encontrados += 1
    except:
        pass
    print('  ' + '-' * 50)
    print(f'  ℹ️ Campos capturados: {campos_encontrados}')
    return campos_encontrados > 0

def scroll_detalle_prestamo(driver, veces=1):
    print(f'  📝 Haciendo scroll hacia abajo ({veces} vez/veces)...')
    time.sleep(1)
    for i in range(veces):
        scrolleado = False
        try:
            driver.execute_script('mobile: scroll', {'direction': 'down'})
            print(f'  ✅ Scroll {i + 1} completado (mobile:scroll)')
            scrolleado = True
            time.sleep(1)
        except:
            pass
        if not scrolleado:
            try:
                driver.find_element(AppiumBy.ANDROID_UIAUTOMATOR, 'new UiScrollable(new UiSelector().scrollable(true)).scrollForward()')
                print(f'  ✅ Scroll {i + 1} completado (UiScrollable)')
                scrolleado = True
                time.sleep(1)
            except:
                pass
        if not scrolleado:
            try:
                driver.swipe(500, 1500, 500, 500, 500)
                print(f'  ✅ Scroll {i + 1} completado (swipe)')
                time.sleep(1)
            except Exception as e:
                print(f'  ⚠️ Error en scroll {i + 1}: {e}')
                return False
    return True

def scroll_y_mostrar_detalles(driver, scrolls=3):
    print('\n  📋 DETALLES ADICIONALES (con scroll):')
    print('  ' + '-' * 50)
    detalles_buscados = ['Día de pago', 'Estado', 'Tasa de interés corriente', 'Tasa de interés moratorio', 'Saldo capital', 'Fecha de desembolso', 'Número de operación', 'Plazo', 'Capital', 'Interés', 'Interés penal', 'Seguros', 'Total cuota a la fecha']
    encontrados = set()
    for intento in range(scrolls):
        for detalle in detalles_buscados:
            if detalle in encontrados:
                continue
            try:
                elemento = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{detalle}')]")
                desc = elemento.get_attribute('content-desc')
                if desc:
                    for linea in desc.split(chr(10)):
                        if detalle.lower() in linea.lower():
                            print(f'  📌 {linea.strip()}')
                            encontrados.add(detalle)
                            break
            except:
                pass
        if intento < scrolls - 1:
            scroll_detalle_prestamo(driver, veces=1)
    print('  ' + '-' * 50)
    print(f'  ℹ️ Detalles capturados: {len(encontrados)}/{len(detalles_buscados)}')
    if not encontrados:
        print('  ⚠️ No se capturó ningún detalle adicional')
        return False
    return True

def realizar_detalle_prestamo(driver, numero_prestamo='10-0-1145094-3', tiempos=None, reporte=None, paso_inicial=6):
    print(f'\n📋 INICIANDO DETALLE DE PRÉSTAMO (vía Pagos)')
    print(f'🏦 Préstamo: {numero_prestamo}')
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Click Pagos')
    if not click_home_pagos(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla Pagos', "Se accedió a la sección de 'Pagos' desde el home.", espera=2.0)
    paso_num += 1
    tiempos.start('2. Pago de préstamo')
    if not click_pago_prestamo_opcion(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla Pago de préstamo', "Se accedió a la pantalla 'Pago de préstamo'.", espera=2.0)
    paso_num += 1
    tiempos.start('3. Seleccionar préstamo')
    if not seleccionar_prestamo_por_numero(driver, numero_prestamo):
        print(f'  ⚠️ No se pudo verificar el préstamo {numero_prestamo}, continuando...')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Préstamo: {numero_prestamo}', f"Se verificó/seleccionó el préstamo con número '{numero_prestamo}'.", espera=1.5)
    paso_num += 1
    tiempos.start('4. Click Detalles')
    if not click_detalles_prestamo(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, "Click en 'Detalles'", "Se hizo clic en el botón 'Detalles'. Se abre la pantalla con la información detallada del préstamo.", espera=2.0)
    paso_num += 1
    tiempos.start('5. Verificar detalle')
    if not verificar_detalle_prestamo(driver):
        print('  ⚠️ No se pudo verificar la pantalla de detalle')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla de detalle verificada', "Se verificó la pantalla de detalle del préstamo (contiene tarjeta del préstamo, resumen y botón 'Pagar cuota').", espera=1.5)
    paso_num += 1
    tiempos.start('6. Obtener datos')
    if not obtener_datos_prestamo(driver):
        print('  ⚠️ Error al obtener datos del préstamo')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Datos del préstamo capturados', "Se capturaron los datos visibles del préstamo: tarjeta del préstamo, resumen con montos y botón 'Pagar cuota'.", espera=1.0)
    paso_num += 1
    tiempos.start('7. Scroll + detalles')
    if not scroll_y_mostrar_detalles(driver, scrolls=3):
        print('  ⚠️ Error al mostrar detalles adicionales')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Detalles adicionales (post-scroll)', 'Se hizo scroll para visualizar detalles adicionales del préstamo (día de pago, estado, tasas de interés, saldo capital, etc.).', espera=1.5)
    paso_num += 1
    tiempos.start('8. Volver atrás')
    if not volver_atras_detalle(driver):
        print('  ⚠️ Error al volver atrás')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Regreso a pantalla anterior', 'Se regresó a la pantalla anterior.', espera=1.0)
    paso_num += 1
    tiempos.start('9. Volver al home')
    if not volver_home(driver):
        print('  ⚠️ Error al volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Detalle Préstamo finalizado', 'Se regresó exitosamente al home. El flujo de detalle de préstamo desde Pagos ha terminado.', espera=1.5)
    paso_num += 1
    print('\n✅ DETALLE DE PRÉSTAMO COMPLETADO EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('pago_prestamo_detalle_desde_pagos_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO COMPLETO: LOGIN + PAGOS → PAGO DE PRÉSTAMO → DETALLE + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    numero_prestamo = _input_cfg.get('numero_prestamo', '10-0-1145094-3')
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Detalle_Prestamo_Desde_Pagos')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f'🏦 Préstamo: {numero_prestamo}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Préstamo': numero_prestamo})
    login_ok = _input_cfg.get('login_ok', False)
    detalle_ok = _input_cfg.get('detalle_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            detalle_ok = realizar_detalle_prestamo(driver, numero_prestamo=numero_prestamo, tiempos=tiempos, reporte=reporte, paso_inicial=6)
            if detalle_ok:
                print('\n🎉 DETALLE DE PRÉSTAMO EXITOSO!')
            else:
                print('\n❌ DETALLE DE PRÉSTAMO FALLIDO')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and detalle_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login          : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Detalle        : {('✅ OK' if detalle_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

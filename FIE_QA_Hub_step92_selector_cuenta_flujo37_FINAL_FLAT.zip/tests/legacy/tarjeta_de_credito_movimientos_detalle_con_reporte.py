"""
Flujo Detalle de Tarjeta de Crédito + reporte Word.
Pasos: Login → T. CRÉDITO → Movimientos (inferior) → Tab Detalle
       → Verificar detalle → Obtener datos → Scroll → Verificar
       → Regresar → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import volver_atras_tc__109533fdac as volver_atras_tc, volver_home__71a629aeab as volver_home
from framework.common.ui_helpers import _esta_en_home as _esta_en_home, _seleccionar_opcion_case_insensitive__f21faf0807 as _seleccionar_opcion_case_insensitive

def ir_a_tarjeta_credito(driver, max_intentos=8):
    print('  📝 Navegando a T. CRÉDITO...')
    time.sleep(3)
    texto_objetivo = 'T. CRÉDITO'

    def _buscar_en_pantalla():
        try:
            tc = driver.find_element(AppiumBy.XPATH, f"//android.view.View[@content-desc='{texto_objetivo}']")
            tc.click()
            print('  ✅ Click en T. CRÉDITO (content-desc exacto)')
            time.sleep(3)
            return True
        except:
            pass
        try:
            tc = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{texto_objetivo}') and @clickable='true']")
            tc.click()
            print('  ✅ Click en T. CRÉDITO (content-desc contains)')
            time.sleep(3)
            return True
        except:
            pass
        try:
            tc = driver.find_element(AppiumBy.XPATH, f"//*[contains(translate(@content-desc, 'ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÑ.', 'abcdefghijklmnopqrstuvwxyzáéíóúñ.'), 't. crédito') and @clickable='true']")
            tc.click()
            print('  ✅ Click en T. CRÉDITO (case-insensitive)')
            time.sleep(3)
            return True
        except:
            pass
        try:
            tc = driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{texto_objetivo}') and @clickable='true']")
            tc.click()
            print('  ✅ Click en T. CRÉDITO (texto)')
            time.sleep(3)
            return True
        except:
            pass
        return False
    if _buscar_en_pantalla():
        return True
    for intento in range(max_intentos):
        try:
            if intento % 2 == 0:
                print(f'  🔄 Scroll horizontal IZQUIERDA {intento // 2 + 1}...')
                driver.swipe(900, 1000, 200, 1000, 500)
            else:
                print(f'  🔄 Scroll horizontal DERECHA {intento // 2 + 1}...')
                driver.swipe(200, 1000, 900, 1000, 500)
            time.sleep(0.6)
            if _buscar_en_pantalla():
                return True
        except:
            pass
    print('  ❌ Error al seleccionar T. CRÉDITO')
    try:
        print('  🔍 Elementos visibles:')
        elementos = driver.find_elements(AppiumBy.XPATH, "//*[@clickable='true' and @content-desc and string-length(@content-desc) > 3]")
        for e in elementos[:15]:
            desc = (e.get_attribute('content-desc') or '').replace('\n', ' | ')
            if len(desc) < 80:
                print(f'     - {desc}')
    except:
        pass
    return False

def seleccionar_movimientos_inferior(driver):
    print("  📝 Seleccionando 'Movimientos' (opción inferior)...")
    time.sleep(2)
    try:
        movimientos = driver.find_element(AppiumBy.ID, 'credit_card_tab_movements')
        movimientos.click()
        print("  ✅ Click en 'Movimientos' (ID tab)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        movimientos = driver.find_element(AppiumBy.XPATH, "//android.view.View[@content-desc='Movimientos' and @clickable='true']")
        movimientos.click()
        print("  ✅ Click en 'Movimientos' (content-desc)")
        time.sleep(3)
        return True
    except:
        pass
    if _seleccionar_opcion_case_insensitive(driver, 'Movimientos', timeout=5, debug=True):
        print("  ✅ Click en 'Movimientos' (case-insensitive)")
        time.sleep(3)
        return True
    print("  ❌ Error al seleccionar 'Movimientos'")
    return False

def seleccionar_tab_tarjeta_credito(driver, tab_name='Detalle'):
    print(f"  📝 Seleccionando tab: '{tab_name}'...")
    time.sleep(4)
    tabs_map = {'Detalle': 'credit_card_tab_detail', 'Movimientos': 'credit_card_tab_movements', 'Extractos': 'credit_card_tab_extracts'}
    if tab_name not in tabs_map:
        print(f"  ❌ Tab '{tab_name}' no válido. Opciones: Detalle, Movimientos, Extractos")
        return False
    resource_id = tabs_map[tab_name]
    try:
        tab = driver.find_element(AppiumBy.ID, resource_id)
        tab.click()
        print(f"  ✅ Click en tab '{tab_name}' (ID)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        tab = driver.find_element(AppiumBy.XPATH, f"//*[@resource-id='{resource_id}']")
        tab.click()
        print(f"  ✅ Click en tab '{tab_name}' (XPATH resource-id)")
        time.sleep(3)
        return True
    except:
        pass
    if _seleccionar_opcion_case_insensitive(driver, tab_name, timeout=5, debug=True):
        print(f"  ✅ Click en tab '{tab_name}' (case-insensitive)")
        time.sleep(3)
        return True
    print(f"  ❌ Error al seleccionar tab '{tab_name}'")
    return False

def scroll_detalle_tarjeta(driver, veces=3):
    print(f'  📝 Haciendo scroll en detalle ({veces} veces)...')
    time.sleep(1)
    for i in range(veces):
        scrolleado = False
        try:
            driver.execute_script('mobile: scroll', {'direction': 'down'})
            print(f'  ✅ Scroll {i + 1} completado (mobile:scroll)')
            scrolleado = True
            time.sleep(0.5)
        except:
            pass
        if not scrolleado:
            try:
                driver.find_element(AppiumBy.ANDROID_UIAUTOMATOR, 'new UiScrollable(new UiSelector().scrollable(true)).scrollForward()')
                print(f'  ✅ Scroll {i + 1} completado (UiScrollable)')
                scrolleado = True
                time.sleep(0.5)
            except:
                pass
        if not scrolleado:
            try:
                driver.swipe(500, 1500, 500, 600, 800)
                print(f'  ✅ Scroll {i + 1} completado (swipe)')
                time.sleep(0.5)
            except Exception as e:
                print(f'  ⚠️ Error en scroll {i + 1}: {str(e)[:50]}')
    return True

def _buscar_elemento_detalle(driver, texto):
    texto_lower = texto.lower()
    try:
        return driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{texto}')]")
    except:
        pass
    try:
        return driver.find_element(AppiumBy.XPATH, f"//*[contains(translate(@content-desc, 'ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÑ', 'abcdefghijklmnopqrstuvwxyzáéíóúñ'), '{texto_lower}')]")
    except:
        pass
    try:
        return driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{texto}')]")
    except:
        pass
    return None

def verificar_detalle_tarjeta(driver):
    print('  📝 Verificando pantalla de detalle...')
    time.sleep(2)
    elementos_buscar = ['Fecha de último pago', 'Fecha de vencimiento', 'Número de tarjeta', 'Tipo de tarjeta', 'Tasa de interés', 'Cargos aplicados', 'Límite de tarjeta', 'Saldo']
    encontrados = 0
    for elemento in elementos_buscar:
        elem = _buscar_elemento_detalle(driver, elemento)
        if elem:
            print(f"  ✅ Elemento encontrado: '{elemento}'")
            encontrados += 1
    if encontrados >= 3:
        print(f'  ✅ Pantalla de detalle verificada ({encontrados} elementos)')
        return True
    else:
        print(f'  ⚠️ Solo se encontraron {encontrados} elementos de detalle')
        return False

def obtener_datos_detalle_tarjeta(driver):
    print('\n  📋 DATOS DEL DETALLE DE TARJETA:')
    print('  ' + '-' * 50)
    elementos = ['Fecha de último pago', 'Fecha de vencimiento', 'Número de tarjeta', 'Tipo de tarjeta', 'Tasa de interés', 'Cargos aplicados', 'Límite de tarjeta', 'Saldo']
    capturados = 0
    for elemento in elementos:
        elem = _buscar_elemento_detalle(driver, elemento)
        if elem:
            desc = elem.get_attribute('content-desc') or elem.get_attribute('text') or ''
            if desc:
                desc_limpio = desc.replace('\n', ' | ')
                print(f'  📌 {desc_limpio[:120]}')
                capturados += 1
    print('  ' + '-' * 50)
    print(f'  ℹ️ Campos capturados: {capturados}')
    return capturados > 0

def realizar_detalle_tarjeta_credito(driver, scroll_cantidad=3, tiempos=None, reporte=None, paso_inicial=6):
    print(f'\n💳 INICIANDO DETALLE DE TARJETA DE CRÉDITO')
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Ir a T. CRÉDITO')
    if not ir_a_tarjeta_credito(driver):
        print('  ❌ Error al ir a T. CRÉDITO')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla T. CRÉDITO', 'Se accedió a la sección de Tarjeta de Crédito desde el home.', espera=2.0)
    paso_num += 1
    print('  📝 Esperando carga de pantalla de T. CRÉDITO...')
    time.sleep(3)
    tiempos.start('2. Movimientos inferior')
    if not seleccionar_movimientos_inferior(driver):
        print("  ❌ Error al seleccionar 'Movimientos'")
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Opción Movimientos (inferior)', "Se seleccionó la opción 'Movimientos' en la parte inferior de la pantalla de Tarjeta de Crédito.", espera=1.5)
    paso_num += 1
    print('  📝 Esperando carga de movimientos...')
    time.sleep(3)
    tiempos.start('3. Tab Detalle')
    if not seleccionar_tab_tarjeta_credito(driver, 'Detalle'):
        print('  ⚠️ No se pudo seleccionar Detalle, continuando...')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Tab Detalle seleccionado', "Se seleccionó el tab 'Detalle' en la pantalla de Tarjeta de Crédito.", espera=1.5)
    paso_num += 1
    print('  📝 Esperando carga de detalle...')
    time.sleep(3)
    tiempos.start('4. Verificar detalle')
    if not verificar_detalle_tarjeta(driver):
        print('  ⚠️ No se pudo verificar la pantalla de detalle')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla de detalle verificada', 'Se verificó la pantalla de detalle de la tarjeta de crédito. Contiene los elementos esperados (fecha de pago, vencimiento, número de tarjeta, etc.).', espera=1.5)
    paso_num += 1
    tiempos.start('5. Obtener datos')
    if not obtener_datos_detalle_tarjeta(driver):
        print('  ⚠️ Error al obtener datos del detalle')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Datos del detalle capturados', 'Se capturaron los datos visibles del detalle de la tarjeta de crédito (fecha de último pago, vencimiento, límite, saldo, etc.).', espera=1.0)
    paso_num += 1
    tiempos.start('6. Scroll detalle')
    if not scroll_detalle_tarjeta(driver, max(1,min(int(scroll_cantidad or 3),10))):
        print('  ⚠️ Error al hacer scroll')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Scroll en pantalla de detalle', 'Se hizo scroll en la pantalla para visualizar el resto de los campos del detalle.', espera=1.0)
    paso_num += 1
    tiempos.start('7. Verificar post-scroll')
    print('  📝 Verificando elementos después del scroll...')
    time.sleep(2)
    try:
        elem = _buscar_elemento_detalle(driver, 'Límite de tarjeta')
        if elem:
            print('  ✅ Elementos de detalle visibles después del scroll')
        else:
            print('  ⚠️ No se encontraron elementos después del scroll')
    except:
        print('  ⚠️ No se encontraron elementos después del scroll')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Verificación post-scroll', "Se verificó que los elementos de detalle estén visibles tras el scroll (por ejemplo, 'Límite de tarjeta').", espera=1.0)
    paso_num += 1
    tiempos.start('8. Volver atrás')
    if not volver_atras_tc(driver):
        print('  ⚠️ Error al volver atrás')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Regreso a pantalla anterior', 'Se regresó a la pantalla anterior.', espera=1.0)
    paso_num += 1
    tiempos.start('9. Volver al home')
    if not volver_home(driver):
        print('  ⚠️ Error al volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Detalle TC finalizado', 'Se regresó exitosamente al home. El flujo de detalle de tarjeta de crédito ha terminado.', espera=1.5)
    paso_num += 1
    print('\n✅ DETALLE DE TARJETA DE CRÉDITO COMPLETADO EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('tarjeta_de_credito_movimientos_detalle_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO COMPLETO: LOGIN + DETALLE DE TARJETA DE CRÉDITO + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Detalle_Tarjeta_Credito')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={})
    login_ok = _input_cfg.get('login_ok', False)
    detalle_ok = _input_cfg.get('detalle_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            detalle_ok = realizar_detalle_tarjeta_credito(driver, tiempos=tiempos, reporte=reporte, paso_inicial=6)
            if detalle_ok:
                print('\n🎉 DETALLE DE TARJETA DE CRÉDITO EXITOSO!')
            else:
                print('\n❌ DETALLE DE TARJETA DE CRÉDITO FALLIDO')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and detalle_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login          : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Detalle        : {('✅ OK' if detalle_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

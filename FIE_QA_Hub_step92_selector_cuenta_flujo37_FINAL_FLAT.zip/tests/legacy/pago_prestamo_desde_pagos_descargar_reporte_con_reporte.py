"""
Flujo Descargar Reporte de Préstamo (vía Pagos) + reporte Word.
Pasos: Login → Pagos (home) → Pago de préstamo → Seleccionar préstamo
       → Detalles → Scroll al final → Descargar reporte → Cerrar reporte
       → Regresar → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import volver_atras_detalle__7684ec12c9 as volver_atras_detalle, volver_home__0104fb0f44 as volver_home
from framework.common.ui_helpers import _esta_en_home as _esta_en_home, _seleccionar_opcion_case_insensitive__7d45fd91e0 as _seleccionar_opcion_case_insensitive

def click_home_pagos(driver):
    """Click en el botón Pagos del bottom nav."""
    print('  📝 Click en Pagos (home)...')
    time.sleep(2)
    try:
        pagos_btn = driver.find_element(AppiumBy.ID, 'home_btn_pagos')
        pagos_btn.click()
        print('  ✅ Click en Pagos (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        pagos_btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Pagos\nPagos' and @clickable='true']")
        pagos_btn.click()
        print('  ✅ Click en Pagos (content-desc)')
        time.sleep(3)
        return True
    except:
        pass
    if _seleccionar_opcion_case_insensitive(driver, 'Pagos', timeout=5):
        print('  ✅ Click en Pagos (helper)')
        time.sleep(3)
        return True
    print('  ❌ Error al clickear Pagos')
    return False

def click_pago_prestamo_opcion(driver):
    """En la pantalla Pagos, click en 'Pago de préstamo'."""
    print("  📝 Click en 'Pago de préstamo'...")
    time.sleep(2)
    try:
        btn = driver.find_element(AppiumBy.ID, 'payments_option_loans')
        btn.click()
        print("  ✅ Click en 'Pago de préstamo' (ID: payments_option_loans)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='payments_option_loans' and @clickable='true']")
        btn.click()
        print("  ✅ Click en 'Pago de préstamo' (XPATH resource-id)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Pago de préstamo\nPago de préstamo']")
        btn.click()
        print("  ✅ Click en 'Pago de préstamo' (content-desc exacto)")
        time.sleep(3)
        return True
    except:
        pass
    if _seleccionar_opcion_case_insensitive(driver, 'Pago de préstamo', timeout=5, debug=True):
        print("  ✅ Click en 'Pago de préstamo' (helper)")
        time.sleep(3)
        return True
    print("  ❌ Error al clickear 'Pago de préstamo'")
    return False

def seleccionar_prestamo_por_numero(driver, numero_prestamo):
    """
    En la pantalla "Pago de préstamos", verifica/selecciona el préstamo.
    Si ya está preseleccionado, no hace nada.
    """
    print(f'  📝 Verificando préstamo seleccionado: {numero_prestamo}...')
    time.sleep(2)
    try:
        selector = driver.find_element(AppiumBy.ID, 'loan_payment_selector')
        hijo = selector.find_element(AppiumBy.XPATH, ".//android.widget.Button[@clickable='true']")
        desc_actual = hijo.get_attribute('content-desc') or ''
        print(f'  🔍 Préstamo actual: {desc_actual[:80]}...')
        if numero_prestamo in desc_actual:
            print(f'  ✅ Préstamo ya está seleccionado: {numero_prestamo}')
            return True
    except Exception as e:
        print(f'  ⚠️ No se pudo verificar el selector: {e}')
    print(f'  📝 Abriendo selector de préstamo para cambiar a: {numero_prestamo}...')
    abierto = False
    try:
        selector = driver.find_element(AppiumBy.ID, 'loan_payment_selector')
        hijo = selector.find_element(AppiumBy.XPATH, ".//android.widget.Button[@clickable='true']")
        hijo.click()
        print('  ✅ Click en selector de préstamo (hijo clickable)')
        abierto = True
        time.sleep(3)
    except:
        pass
    if not abierto:
        try:
            selector = driver.find_element(AppiumBy.ID, 'loan_payment_selector')
            selector.click()
            print('  ✅ Click en selector de préstamo (contenedor)')
            abierto = True
            time.sleep(3)
        except:
            pass
    if not abierto:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Selecciona tu préstamo') and @clickable='true']")
            selector.click()
            print('  ✅ Click en selector de préstamo (content-desc)')
            abierto = True
            time.sleep(3)
        except:
            pass
    if not abierto:
        print(f'  ❌ No se pudo abrir el selector de préstamo')
        return False
    time.sleep(2)

    def _buscar_prestamo():
        try:
            prestamo = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{numero_prestamo}') and @clickable='true']")
            prestamo.click()
            print(f'  ✅ Préstamo seleccionado: {numero_prestamo}')
            time.sleep(2)
            return True
        except:
            pass
        try:
            partes = numero_prestamo.split('-')
            if len(partes) >= 2:
                ultimo = partes[-1]
                prestamo = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{ultimo}') and @clickable='true']")
                prestamo.click()
                print(f'  ✅ Préstamo seleccionado (último segmento: {ultimo})')
                time.sleep(2)
                return True
        except:
            pass
        try:
            prestamos = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[contains(@resource-id, 'loan_payment_') and @clickable='true']")
            for p in prestamos:
                desc = p.get_attribute('content-desc') or ''
                if numero_prestamo in desc:
                    p.click()
                    print(f'  ✅ Préstamo seleccionado (iteración)')
                    time.sleep(2)
                    return True
        except:
            pass
        return False
    if _buscar_prestamo():
        return True
    print(f'  ❌ No se encontró el préstamo: {numero_prestamo}')
    return False

def click_detalles_prestamo(driver):
    """Click en el botón 'Detalles' de la pantalla 'Pago de préstamos'."""
    print("  📝 Click en 'Detalles'...")
    time.sleep(2)
    try:
        btn = driver.find_element(AppiumBy.ID, 'loan_payment_details')
        btn.click()
        print("  ✅ Click en 'Detalles' (ID)")
        time.sleep(5)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='loan_payment_details']//android.widget.Button[@content-desc='Detalles']")
        btn.click()
        print("  ✅ Click en 'Detalles' (XPATH padre+hijo)")
        time.sleep(5)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Detalles' and @clickable='true']")
        btn.click()
        print("  ✅ Click en 'Detalles' (content-desc)")
        time.sleep(5)
        return True
    except:
        pass
    if _seleccionar_opcion_case_insensitive(driver, 'Detalles', timeout=5, debug=True):
        print("  ✅ Click en 'Detalles' (helper)")
        time.sleep(5)
        return True
    print("  ❌ Error al clickear 'Detalles'")
    return False

def scroll_al_final_detalle(driver, scrolls=3):
    """
    Hace scroll hacia el final de la pantalla de detalle.
    Con 3 estrategias: mobile:scroll, UiScrollable, swipe.
    """
    print(f'  📝 Haciendo scroll al final de la pantalla ({scrolls} scrolls)...')
    time.sleep(1)
    for i in range(scrolls):
        scrolleado = False
        try:
            driver.execute_script('mobile: scroll', {'direction': 'down'})
            print(f'  ✅ Scroll {i + 1} completado (mobile:scroll)')
            scrolleado = True
            time.sleep(1)
        except:
            pass
        if not scrolleado:
            try:
                driver.find_element(AppiumBy.ANDROID_UIAUTOMATOR, 'new UiScrollable(new UiSelector().scrollable(true)).scrollForward()')
                print(f'  ✅ Scroll {i + 1} completado (UiScrollable)')
                scrolleado = True
                time.sleep(1)
            except:
                pass
        if not scrolleado:
            try:
                driver.swipe(500, 1500, 500, 500, 500)
                print(f'  ✅ Scroll {i + 1} completado (swipe)')
                scrolleado = True
                time.sleep(1)
            except Exception as e:
                print(f'  ⚠️ Error en scroll {i + 1}: {e}')
    return True

def click_descargar_reporte(driver, tipo_reporte='plan_pagos'):
    if tipo_reporte == 'plan_pagos':
        print("  📝 Click en 'Descargar plan de pagos'...")
        resource_id = 'credit_report_ta'
        content_desc = 'Descargar plan de pagos'
    elif tipo_reporte == 'pagos_realizados':
        print("  📝 Click en 'Descargar pagos realizados'...")
        resource_id = 'credit_report_ec'
        content_desc = 'Descargar pagos realizados'
    else:
        print(f"  ❌ Tipo de reporte '{tipo_reporte}' no válido")
        print(f"     Válidos: 'plan_pagos' | 'pagos_realizados'")
        return False
    time.sleep(2)
    try:
        btn = driver.find_element(AppiumBy.ID, resource_id)
        btn.click()
        print(f"  ✅ Click en '{content_desc}' (ID)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, f"//*[@resource-id='{resource_id}']")
        btn.click()
        print(f"  ✅ Click en '{content_desc}' (XPATH resource-id)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, f"//android.widget.Button[@content-desc='{content_desc}']")
        btn.click()
        print(f"  ✅ Click en '{content_desc}' (content-desc)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{content_desc}') and @clickable='true']")
        btn.click()
        print(f"  ✅ Click en '{content_desc}' (contains)")
        time.sleep(3)
        return True
    except Exception as e:
        print(f"  ❌ Error al clickear '{content_desc}': {e}")
        try:
            botones = driver.find_elements(AppiumBy.XPATH, "//*[@clickable='true' and @content-desc and string-length(@content-desc) > 3]")
            print(f'  🔍 Elementos visibles ({len(botones)}):')
            for o in botones[:10]:
                desc = (o.get_attribute('content-desc') or '').replace('\n', ' | ')
                if len(desc) < 80:
                    print(f'     - {desc}')
        except:
            pass
        return False

def cerrar_reporte_descargado(driver, timeout=10):
    print('  📝 Cerrando reporte descargado...')
    time.sleep(3)
    try:
        regresar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Regresar']")
        regresar.click()
        print('  ✅ Click en Regresar (reporte)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        cerrar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Cerrar']")
        cerrar.click()
        print('  ✅ Click en Cerrar (reporte)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        listo = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Listo']")
        listo.click()
        print('  ✅ Click en Listo (reporte)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        aceptar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Aceptar']")
        aceptar.click()
        print('  ✅ Click en Aceptar (reporte)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        driver.back()
        print('  ✅ Back ejecutado (reporte)')
        time.sleep(2)
        return True
    except:
        pass
    print('  ⚠️ No se pudo cerrar el reporte, continuando...')
    return True

def realizar_descargar_reporte_desde_pagos(driver, numero_prestamo='10-0-1145094-3', tipo_reporte='plan_pagos', tiempos=None, reporte=None, paso_inicial=6):
    tipo_reporte={'Plan de pagos':'plan de pagos','Pagos realizados':'pagos realizados'}.get(tipo_reporte,tipo_reporte)
    print(f'\n📄 INICIANDO DESCARGA DE REPORTE (desde Detalle)')
    print(f'🏦 Préstamo: {numero_prestamo}')
    print(f'📄 Tipo de reporte: {tipo_reporte}')
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Click Pagos')
    if not click_home_pagos(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla Pagos', "Se accedió a la sección de 'Pagos' desde el home.", espera=2.0)
    paso_num += 1
    tiempos.start('2. Pago de préstamo')
    if not click_pago_prestamo_opcion(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla Pago de préstamo', "Se accedió a la pantalla 'Pago de préstamo'.", espera=2.0)
    paso_num += 1
    tiempos.start('3. Seleccionar préstamo')
    if not seleccionar_prestamo_por_numero(driver, numero_prestamo):
        print(f'  ⚠️ No se pudo verificar el préstamo {numero_prestamo}, continuando...')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Préstamo: {numero_prestamo}', f"Se verificó/seleccionó el préstamo con número '{numero_prestamo}'.", espera=1.5)
    paso_num += 1
    tiempos.start('4. Click Detalles')
    if not click_detalles_prestamo(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, "Click en 'Detalles'", "Se hizo clic en el botón 'Detalles'. Se abre la pantalla con la información detallada del préstamo.", espera=2.0)
    paso_num += 1
    tiempos.start('5. Scroll al final')
    if not scroll_al_final_detalle(driver, scrolls=3):
        print('  ⚠️ Error al hacer scroll, continuando...')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Scroll al final del detalle', 'Se hizo scroll al final de la pantalla de detalle para acceder a los botones de descarga de reportes.', espera=1.5)
    paso_num += 1
    tiempos.start('6. Descargar reporte')
    if not click_descargar_reporte(driver, tipo_reporte):
        print('  ❌ Error al clickear el reporte')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        if tipo_reporte == 'plan_pagos':
            desc_reporte = 'plan de pagos'
        else:
            desc_reporte = 'pagos realizados'
        reporte.capturar_paso(paso_num, f'Descargar reporte: {desc_reporte}', f"Se hizo clic en el botón 'Descargar {desc_reporte}'. Se abrió el reporte en el visor.", espera=2.0)
    paso_num += 1
    tiempos.start('7. Cerrar reporte')
    if not cerrar_reporte_descargado(driver):
        print('  ⚠️ Error al cerrar el reporte, continuando...')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Reporte cerrado', 'Se cerró el visor del reporte descargado.', espera=1.5)
    paso_num += 1
    tiempos.start('8. Volver atrás')
    if not volver_atras_detalle(driver):
        print('  ⚠️ Error al volver atrás')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Regreso a pantalla anterior', 'Se regresó a la pantalla anterior.', espera=1.0)
    paso_num += 1
    tiempos.start('9. Volver al home')
    if not volver_home(driver):
        print('  ⚠️ Error al volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Descargar Reporte finalizado', 'Se regresó exitosamente al home. El flujo de descarga de reporte de préstamo ha terminado.', espera=1.5)
    paso_num += 1
    print('\n✅ DESCARGA DE REPORTE COMPLETADA EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('pago_prestamo_desde_pagos_descargar_reporte_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO COMPLETO: LOGIN + PAGOS → PAGO DE PRÉSTAMO → DETALLE → DESCARGAR REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    numero_prestamo = _input_cfg.get('numero_prestamo', '10-0-1145094-3')
    tipo_reporte = _input_cfg.get('tipo_reporte', 'plan_pagos')
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Descargar_Reporte_Prestamo_Desde_Pagos')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f'🏦 Préstamo: {numero_prestamo}')
    print(f'📄 Tipo de reporte: {tipo_reporte}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Préstamo': numero_prestamo, 'Tipo de reporte': tipo_reporte})
    login_ok = _input_cfg.get('login_ok', False)
    reporte_ok = _input_cfg.get('reporte_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            reporte_ok = realizar_descargar_reporte_desde_pagos(driver, numero_prestamo=numero_prestamo, tipo_reporte=tipo_reporte, tiempos=tiempos, reporte=reporte, paso_inicial=6)
            if reporte_ok:
                print('\n🎉 DESCARGA DE REPORTE EXITOSA!')
            else:
                print('\n❌ DESCARGA DE REPORTE FALLIDA')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and reporte_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login          : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Reporte        : {('✅ OK' if reporte_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

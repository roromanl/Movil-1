"""
Flujo Configuración de Notificaciones (DIRECTO desde menú Más)
+ reporte Word.
Pasos: Login → Más → Configuraciones usuario → Configuración de notificaciones (directo)
       → Cuenta → Sección Abono → Sección Retiro → Sección Info
       → Continuar → Continuar (éxito) → Volver atrás → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import volver_atras__ab97cca960 as volver_atras, volver_home__cedf942b12 as volver_home
from framework.common.ui_helpers import _esta_en_home as _esta_en_home

def click_mas_menu(driver):
    print('  📝 Click en menú Más...')
    time.sleep(2)
    wait = WebDriverWait(driver, 5)
    try:
        mas_btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'home_btn_mas')))
        mas_btn.click()
        print('  ✅ Click en Más (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        mas_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Más\nMás']")
        mas_btn.click()
        print('  ✅ Click en Más (content-desc)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al clickear Más: {e}')
        return False

def click_configuraciones_usuario(driver):
    print("  📝 Seleccionando 'Configuraciones de usuario'...")
    time.sleep(2)
    wait = WebDriverWait(driver, 10)
    try:
        btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'more_btn_usuario')))
        btn.click()
        print("  ✅ Click en 'Configuraciones de usuario' (ID)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Configuraciones de usuario')]")
        btn.click()
        print("  ✅ Click en 'Configuraciones de usuario' (content-desc)")
        time.sleep(3)
        return True
    except Exception as e:
        print(f"  ❌ Error al seleccionar 'Configuraciones de usuario': {e}")
        return False

def click_configuracion_notificaciones_directo(driver):
    """
    Click DIRECTO en 'Configuración de notificaciones' desde el menú Más.
    (Sin pasar por el buzón de Notificaciones).
    """
    print("  📝 Seleccionando 'Configuración de notificaciones' (directo)...")
    time.sleep(2)
    wait = WebDriverWait(driver, 10)
    try:
        btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'notifications_btn_configuracion')))
        btn.click()
        print("  ✅ Click en 'Configuración de notificaciones' (ID)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='notifications_btn_configuracion']//android.widget.Button")
        btn.click()
        print("  ✅ Click en 'Configuración' (XPATH resource-id)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Configuración de notificaciones')]")
        btn.click()
        print("  ✅ Click en 'Configuración' (content-desc)")
        time.sleep(3)
        return True
    except Exception as e:
        print(f"  ❌ Error al seleccionar 'Configuración de notificaciones': {e}")
        return False

def seleccionar_cuenta_notificaciones(driver, cuenta, timeout=15):
    print(f'  📝 Seleccionando cuenta: {cuenta}...')
    wait = WebDriverWait(driver, timeout)
    try:
        selector = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'notifications_select_cuenta')))
        selector.click()
        print('  ✅ Click en selector de cuenta (ID)')
        time.sleep(2)
    except:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='notifications_select_cuenta']")
            selector.click()
            print('  ✅ Click en selector de cuenta (XPATH)')
            time.sleep(2)
        except Exception as e:
            print(f'  ❌ Error al abrir selector de cuenta: {e}')
            return False
    try:
        opcion = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, f"//android.view.View[@content-desc='{cuenta}']")))
        opcion.click()
        print(f'  ✅ Cuenta seleccionada (exacta): {cuenta}')
        time.sleep(2)
        return True
    except:
        pass
    try:
        opcion = driver.find_element(AppiumBy.XPATH, f"//android.view.View[contains(@content-desc, '{cuenta}') and @clickable='true']")
        full_desc = opcion.get_attribute('content-desc')
        opcion.click()
        print(f'  ✅ Cuenta seleccionada (contains): {full_desc}')
        time.sleep(2)
        return True
    except Exception as e:
        print(f"  ❌ No se encontró la cuenta '{cuenta}': {e}")
        try:
            opciones = driver.find_elements(AppiumBy.XPATH, "//android.view.View[contains(@content-desc, '-') and @clickable='true']")
            print(f"  🔍 Cuentas disponibles: {[o.get_attribute('content-desc') for o in opciones[:10]]}")
        except:
            pass
        return False

def set_switch(driver, resource_id, desired_state, nombre, timeout=10):
    print(f"    • {nombre} -> {('ON' if desired_state else 'OFF')}")
    wait = WebDriverWait(driver, timeout)
    switch = None
    try:
        switch = wait.until(EC.presence_of_element_located((AppiumBy.ID, resource_id)))
        cls = switch.get_attribute('class') or ''
        if 'Switch' not in cls:
            print(f"      ⚠️ '{resource_id}' no es Switch (class={cls})")
            switch = None
    except:
        pass
    if switch is None:
        try:
            switch = driver.find_element(AppiumBy.XPATH, f"//android.widget.Switch[@resource-id='{resource_id}']")
        except Exception as e:
            print(f"      ❌ No se encontró '{nombre}': {e}")
            return False
    try:
        is_checked = switch.get_attribute('checked') == 'true'
        if is_checked == desired_state:
            print(f"      ℹ️ Ya está en {('ON' if desired_state else 'OFF')}")
            return True
        switch.click()
        time.sleep(0.6)
        nuevo = switch.get_attribute('checked') == 'true'
        if nuevo == desired_state:
            print(f"      ✅ Cambiado a {('ON' if desired_state else 'OFF')}")
            return True
        else:
            print(f'      ⚠️ No cambió al estado esperado')
            return False
    except Exception as e:
        print(f'      ❌ Error: {e}')
        return False

def editar_condicion(driver, resource_id_btn_editar, condicion, monto, timeout=15):
    print(f'    • Editando condición: {condicion} | Monto: {monto}')
    wait = WebDriverWait(driver, timeout)
    try:
        btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, resource_id_btn_editar)))
        btn.click()
        print('      ✅ Click en botón editar condición')
        time.sleep(2)
    except:
        try:
            btn = driver.find_element(AppiumBy.XPATH, f"//*[@resource-id='{resource_id_btn_editar}']")
            btn.click()
            print('      ✅ Click en botón editar (XPATH)')
            time.sleep(2)
        except Exception as e:
            print(f'      ❌ Error al abrir modal: {e}')
            return False
    try:
        wait.until(EC.presence_of_element_located((AppiumBy.XPATH, "//*[@content-desc='Establece las condiciones']")))
        print('      ✅ Modal abierto')
    except:
        print('      ⚠️ No se detectó el título del modal')
    condicion_map = {'Mayor': 'notifications_radio_condicion_1', 'Mayor igual': 'notifications_radio_condicion_2', 'Menor': 'notifications_radio_condicion_3', 'Menor igual': 'notifications_radio_condicion_4'}
    cond_norm = condicion.strip()
    if cond_norm not in condicion_map:
        print(f'      ❌ Condición inválida: {condicion}')
        return False
    try:
        radio = driver.find_element(AppiumBy.ID, condicion_map[cond_norm])
        radio.click()
        print(f'      ✅ Condición seleccionada: {cond_norm}')
        time.sleep(1)
    except:
        try:
            radio = driver.find_element(AppiumBy.XPATH, f"//android.widget.Button[@resource-id='{condicion_map[cond_norm]}']")
            radio.click()
            print(f'      ✅ Condición seleccionada (XPATH): {cond_norm}')
            time.sleep(1)
        except:
            try:
                radio = driver.find_element(AppiumBy.XPATH, f"//android.widget.Button[@content-desc='{cond_norm}']")
                radio.click()
                print(f'      ✅ Condición seleccionada (content-desc): {cond_norm}')
                time.sleep(1)
            except Exception as e:
                print(f'      ❌ No se pudo seleccionar condición: {e}')
    monto_ok = False
    try:
        input_monto = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='Monto']")
        input_monto.click()
        time.sleep(0.5)
        input_monto.clear()
        time.sleep(0.3)
        input_monto.send_keys(monto)
        print(f'      ✅ Monto ingresado: {monto} (hint)')
        monto_ok = True
    except Exception as e1:
        print(f"      ⚠️ hint='Monto' falló: {e1}")
    if not monto_ok:
        try:
            input_monto = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@resource-id='notifications_input_monto_condicion']//android.widget.EditText")
            input_monto.click()
            time.sleep(0.5)
            input_monto.clear()
            time.sleep(0.3)
            input_monto.send_keys(monto)
            print(f'      ✅ Monto ingresado: {monto} (hijo)')
            monto_ok = True
        except Exception as e2:
            print(f'      ⚠️ hijo falló: {e2}')
    if not monto_ok:
        try:
            padre = driver.find_element(AppiumBy.ID, 'notifications_input_monto_condicion')
            padre.click()
            time.sleep(0.5)
            driver.press_keycode(123)
            for _ in range(10):
                driver.press_keycode(67)
            time.sleep(0.3)
            for c in monto:
                if c == '.':
                    driver.press_keycode(56)
                else:
                    driver.press_keycode(7 + int(c))
            print(f'      ✅ Monto ingresado: {monto} (keycodes)')
            monto_ok = True
        except Exception as e3:
            print(f'      ❌ Monto falló: {e3}')
    try:
        driver.hide_keyboard()
    except:
        pass
    time.sleep(0.5)
    try:
        driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Establece las condiciones']")
        print('      ❌ El modal NO se cerró')
        return False
    except:
        print('      ✅ Modal cerrado correctamente')
        return True

def click_continuar_config(driver, timeout=15):
    print('  📝 Click en Continuar (config)...')
    wait = WebDriverWait(driver, timeout)
    try:
        btn = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//*[@resource-id='notifications_btn_continuar_config']//android.widget.Button[@content-desc='Continuar']")))
        btn.click()
        print('  ✅ Click en Continuar (config)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f"  ❌ No se encontró 'notifications_btn_continuar_config': {e}")
        try:
            candidatos = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")
            print(f"  🔍 Botones 'Continuar' visibles: {len(candidatos)}")
            for c in candidatos:
                print(f"     - id={c.get_attribute('resource-id')!r} enabled={c.get_attribute('enabled')}")
        except:
            pass
        return False

def click_continuar_exito_notif(driver, timeout=15):
    print('  📝 Click en Continuar (éxito)...')
    wait = WebDriverWait(driver, timeout)
    try:
        btn = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//*[@resource-id='notifications_btn_continuar_exito']//android.widget.Button[@content-desc='Continuar']")))
        btn.click()
        print('  ✅ Click en Continuar (éxito)')
        time.sleep(2)
        return True
    except:
        try:
            btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")
            btn.click()
            print('  ✅ Click en Continuar (éxito - fallback)')
            time.sleep(2)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Continuar (éxito): {e}')
            return False

def config_notificaciones_directo_flow(driver, cuenta='40-0-0792721-7', abono_estado=True, abono_condicion='Mayor', abono_monto='0.00', abono_push=True, abono_mail=False, retiro_estado=True, retiro_condicion='Mayor igual', retiro_monto='100.00', retiro_push=True, retiro_mail=True, info_push=True, info_mail=True, reporte=None, tiempos=None, paso_inicial=6):
    print(f'\n🔔 INICIANDO CONFIGURACIÓN DE NOTIFICACIONES (DIRECTO)')
    print(f'   Cuenta: {cuenta}')
    print(f'   Abono: estado={abono_estado} | {abono_condicion} {abono_monto} | push={abono_push} mail={abono_mail}')
    print(f'   Retiro: estado={retiro_estado} | {retiro_condicion} {retiro_monto} | push={retiro_push} mail={retiro_mail}')
    print(f'   Info: push={info_push} mail={info_mail}')
    print('=' * 60)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Ir a Más')
    if not click_mas_menu(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Menú Más abierto', "Se accedió al menú 'Más' desde la barra de navegación inferior.", espera=1.5)
    paso_num += 1
    tiempos.start('2. Configuraciones usuario')
    if not click_configuraciones_usuario(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Configuraciones de usuario', 'Se accedió a las Configuraciones de usuario.', espera=1.5)
    paso_num += 1
    tiempos.start('3. Configuración de notificaciones')
    if not click_configuracion_notificaciones_directo(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla de Configuración de Notificaciones (directo)', 'Se accedió directamente a la pantalla de Configuración de Notificaciones. Se muestra el selector de cuenta y las 3 secciones.', espera=1.5)
    paso_num += 1
    tiempos.start('4. Seleccionar cuenta')
    if not seleccionar_cuenta_notificaciones(driver, cuenta):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f"Cuenta '{cuenta}' seleccionada", f"Se seleccionó la cuenta '{cuenta}' para configurar sus notificaciones.", espera=1.5)
    paso_num += 1
    print('\n  📋 Sección: Recepción de abono en cuenta')
    tiempos.start('5. Sección Abono')
    set_switch(driver, 'notifications_toggle_estado_947891', abono_estado, 'Estado abono')
    if abono_estado:
        editar_condicion(driver, 'notifications_btn_editar_condicion_947891', abono_condicion, abono_monto)
        set_switch(driver, 'notifications_toggle_947891_push', abono_push, 'Push abono')
        set_switch(driver, 'notifications_toggle_947891_mail', abono_mail, 'Mail abono')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Sección Recepción de abono configurada', f"Se configuró la sección 'Recepción de abono en cuenta': estado={('ON' if abono_estado else 'OFF')}, condición='{abono_condicion} {abono_monto}', push={('ON' if abono_push else 'OFF')}, mail={('ON' if abono_mail else 'OFF')}.", espera=1.5)
    paso_num += 1
    print('\n  📋 Sección: Retiro en su cuenta')
    tiempos.start('6. Sección Retiro')
    set_switch(driver, 'notifications_toggle_estado_947892', retiro_estado, 'Estado retiro')
    if retiro_estado:
        editar_condicion(driver, 'notifications_btn_editar_condicion_947892', retiro_condicion, retiro_monto)
        set_switch(driver, 'notifications_toggle_947892_push', retiro_push, 'Push retiro')
        set_switch(driver, 'notifications_toggle_947892_mail', retiro_mail, 'Mail retiro')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Sección Retiro configurada', f"Se configuró la sección 'Retiro en su cuenta': estado={('ON' if retiro_estado else 'OFF')}, condición='{retiro_condicion} {retiro_monto}', push={('ON' if retiro_push else 'OFF')}, mail={('ON' if retiro_mail else 'OFF')}.", espera=1.5)
    paso_num += 1
    print('\n  📋 Sección: Notificaciones informativas')
    tiempos.start('7. Sección Info')
    set_switch(driver, 'notifications_toggle_info_push', info_push, 'Push info')
    set_switch(driver, 'notifications_toggle_info_mail', info_mail, 'Mail info')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Sección Notificaciones informativas configurada', f"Se configuraron las 'Notificaciones informativas': push={('ON' if info_push else 'OFF')}, mail={('ON' if info_mail else 'OFF')}.", espera=1.5)
    paso_num += 1
    tiempos.start('8. Continuar (config)')
    if not click_continuar_config(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Confirmación de configuración', 'Se hizo clic en Continuar. Se muestra la pantalla de confirmación.', espera=1.5)
    paso_num += 1
    print('  📝 Esperando pantalla de confirmación...')
    time.sleep(3)
    tiempos.start('9. Continuar (éxito)')
    if not click_continuar_exito_notif(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Modal de éxito aceptado', 'Se confirmó la configuración. Se muestra el mensaje de éxito.', espera=1.5)
    paso_num += 1
    print('  📝 Esperando volver a la pantalla principal...')
    time.sleep(2)
    tiempos.start('10. Volver atrás')
    if not volver_atras(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Regreso a la pantalla anterior', 'Se regresó a la pantalla anterior tras la confirmación.', espera=1.0)
    paso_num += 1
    tiempos.start('11. Volver al home')
    if not volver_home(driver):
        print('  ⚠️ No se pudo volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Configuración de Notificaciones (directo) finalizado', 'Se regresó exitosamente al home. La configuración de notificaciones ha terminado.', espera=1.5)
    paso_num += 1
    print('\n✅ CONFIGURACIÓN DE NOTIFICACIONES COMPLETADA EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('login_notificaciones_config_directo_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO: CONFIGURACIÓN DE NOTIFICACIONES (DIRECTO) + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    CUENTA = _input_cfg.get('CUENTA', '40-0-0792721-7')
    ABONO_ESTADO = _input_cfg.get('ABONO_ESTADO', True)
    ABONO_CONDICION = _input_cfg.get('ABONO_CONDICION', 'Mayor')
    ABONO_MONTO = _input_cfg.get('ABONO_MONTO', '0.00')
    ABONO_PUSH = _input_cfg.get('ABONO_PUSH', True)
    ABONO_MAIL = _input_cfg.get('ABONO_MAIL', False)
    RETIRO_ESTADO = _input_cfg.get('RETIRO_ESTADO', True)
    RETIRO_CONDICION = _input_cfg.get('RETIRO_CONDICION', 'Mayor igual')
    RETIRO_MONTO = _input_cfg.get('RETIRO_MONTO', '100.00')
    RETIRO_PUSH = _input_cfg.get('RETIRO_PUSH', True)
    RETIRO_MAIL = _input_cfg.get('RETIRO_MAIL', True)
    INFO_PUSH = _input_cfg.get('INFO_PUSH', True)
    INFO_MAIL = _input_cfg.get('INFO_MAIL', True)
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Config_Notificaciones_Directo')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f'💳 Cuenta: {CUENTA}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Cuenta': CUENTA, 'Abono': f"{('ON' if ABONO_ESTADO else 'OFF')} | {ABONO_CONDICION} {ABONO_MONTO} | push={('ON' if ABONO_PUSH else 'OFF')} mail={('ON' if ABONO_MAIL else 'OFF')}", 'Retiro': f"{('ON' if RETIRO_ESTADO else 'OFF')} | {RETIRO_CONDICION} {RETIRO_MONTO} | push={('ON' if RETIRO_PUSH else 'OFF')} mail={('ON' if RETIRO_MAIL else 'OFF')}", 'Info': f"push={('ON' if INFO_PUSH else 'OFF')} mail={('ON' if INFO_MAIL else 'OFF')}", 'Acceso': 'Login → Más → Configuraciones → Configuración de Notificaciones (DIRECTO)'})
    login_ok = _input_cfg.get('login_ok', False)
    config_ok = _input_cfg.get('config_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            config_ok = config_notificaciones_directo_flow(driver, cuenta=CUENTA, abono_estado=ABONO_ESTADO, abono_condicion=ABONO_CONDICION, abono_monto=ABONO_MONTO, abono_push=ABONO_PUSH, abono_mail=ABONO_MAIL, retiro_estado=RETIRO_ESTADO, retiro_condicion=RETIRO_CONDICION, retiro_monto=RETIRO_MONTO, retiro_push=RETIRO_PUSH, retiro_mail=RETIRO_MAIL, info_push=INFO_PUSH, info_mail=INFO_MAIL, reporte=reporte, tiempos=tiempos, paso_inicial=6)
            if config_ok:
                print('\n🎉 CONFIGURACIÓN EXITOSA!')
            else:
                print('\n❌ CONFIGURACIÓN FALLIDA')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and config_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login         : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Configuración : {('✅ OK' if config_ok else '❌ FALLÓ')}")
        print(f'   Carpeta       : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

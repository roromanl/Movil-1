"""
Flujo Productos Bancarios (Afiliar / Desafiliar) + reporte Word.
Pasos: Login → Más → Configuraciones usuario → Productos bancarios
       → Según acción:
         - Desafiliar: producto afiliado → Confirmar cambio → Continuar (éxito)
         - Afiliar: producto no afiliado → Continuar → Confirmar cambio → Continuar (éxito)
       → Volver atrás → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import volver_atras__d509cd9f4a as volver_atras, volver_home__eecb2a92cb as volver_home
from framework.common.ui_helpers import _esta_en_home as _esta_en_home

def click_mas_menu(driver):
    print('  📝 Click en menú Más...')
    time.sleep(2)
    wait = WebDriverWait(driver, 5)
    try:
        mas_btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'home_btn_mas')))
        mas_btn.click()
        print('  ✅ Click en Más (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        mas_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Más\nMás']")
        mas_btn.click()
        print('  ✅ Click en Más (content-desc)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al clickear Más: {e}')
        return False

def click_configuraciones_usuario(driver):
    print("  📝 Seleccionando 'Configuraciones de usuario'...")
    time.sleep(2)
    wait = WebDriverWait(driver, 10)
    try:
        btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'more_btn_usuario')))
        btn.click()
        print("  ✅ Click en 'Configuraciones de usuario' (ID)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Configuraciones de usuario')]")
        btn.click()
        print("  ✅ Click en 'Configuraciones de usuario' (content-desc)")
        time.sleep(3)
        return True
    except Exception as e:
        print(f"  ❌ Error al seleccionar 'Configuraciones de usuario': {e}")
        return False

def click_productos_bancarios(driver):
    print("  📝 Seleccionando 'Productos bancarios'...")
    time.sleep(2)
    wait = WebDriverWait(driver, 10)
    try:
        driver.swipe(500, 1500, 500, 800, 500)
        time.sleep(1)
    except:
        pass
    try:
        btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'user_profile_settings_products')))
        btn.click()
        print("  ✅ Click en 'Productos bancarios' (ID)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@resource-id='user_profile_settings_products']")
        btn.click()
        print("  ✅ Click en 'Productos bancarios' (XPATH)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Productos bancarios')]")
        btn.click()
        print("  ✅ Click en 'Productos bancarios' (content-desc)")
        time.sleep(3)
        return True
    except Exception as e:
        print(f"  ❌ Error al seleccionar 'Productos bancarios': {e}")
        return False

def desafiliar_producto(driver, nombre_producto, cuenta_sin_guiones, timeout=15):
    print(f'  📝 Desafiliando producto: {nombre_producto} | {cuenta_sin_guiones}')
    wait = WebDriverWait(driver, timeout)
    card = None
    try:
        card = wait.until(EC.presence_of_element_located((AppiumBy.XPATH, f"//android.view.View[contains(@content-desc, '{nombre_producto}') and contains(@content-desc, '{cuenta_sin_guiones}')]")))
        print(f'  ✅ Producto encontrado: {nombre_producto} ({cuenta_sin_guiones})')
    except:
        try:
            card = driver.find_element(AppiumBy.ID, f'user_banking_product_{cuenta_sin_guiones}')
            print(f'  ✅ Producto encontrado (ID): {cuenta_sin_guiones}')
        except Exception as e:
            print(f'  ❌ No se encontró el producto: {e}')
            return False
    try:
        btn = card.find_element(AppiumBy.XPATH, ".//android.widget.Button[@content-desc='Desafiliar producto']")
    except:
        try:
            btn = driver.find_element(AppiumBy.ID, f'user_banking_product_btn_eliminar_{cuenta_sin_guiones}')
        except Exception as e:
            print(f"  ❌ No se encontró el botón 'Desafiliar producto': {e}")
            return False
    try:
        btn.click()
        print("  ✅ Click en 'Desafiliar producto'")
        time.sleep(2)
        return True
    except Exception as e:
        print(f"  ❌ Error al clickear 'Desafiliar producto': {e}")
        return False

def afiliar_producto(driver, nombre_producto, cuenta, timeout=15):
    print(f'  📝 Seleccionando producto no afiliado: {nombre_producto} | {cuenta}')
    wait = WebDriverWait(driver, timeout)
    print("  🔄 Buscando sección 'Productos no afiliados'...")
    for intento in range(4):
        try:
            driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Productos no afiliados']")
            print("  ✅ Sección 'Productos no afiliados' visible")
            break
        except:
            print(f'  🔄 Scroll {intento + 1}...')
            try:
                driver.swipe(500, 1500, 500, 700, 500)
                time.sleep(1)
            except:
                pass
    try:
        driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'No hay productos no afiliados')]")
        print("  ⚠️ La app indica: 'No hay productos no afiliados'")
        return False
    except:
        pass
    boton_producto = None
    try:
        boton_producto = driver.find_element(AppiumBy.XPATH, f"//android.widget.Button[@content-desc and contains(@content-desc, '{nombre_producto}') and contains(@content-desc, '{cuenta}')]")
        print(f'  ✅ Producto encontrado por content-desc')
    except:
        pass
    if boton_producto is None:
        try:
            boton_producto = driver.find_element(AppiumBy.XPATH, f"//android.widget.Button[@resource-id='user_banking_product_{cuenta}']")
            print(f'  ✅ Producto encontrado por resource-id')
        except:
            pass
    if boton_producto is None:
        try:
            boton_producto = driver.find_element(AppiumBy.ID, f'user_banking_product_{cuenta}')
            print(f'  ✅ Producto encontrado por ID')
        except:
            pass
    if boton_producto is None:
        print(f"  ❌ No se encontró el producto '{nombre_producto}' ({cuenta})")
        try:
            productos = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[contains(@resource-id, 'user_banking_product_') and not(contains(@resource-id, 'btn_eliminar')) and not(contains(@resource-id, 'btn_continuar'))]")
            print(f"  🔍 Productos con 'user_banking_product_' ({len(productos)}):")
            for p in productos:
                rid = p.get_attribute('resource-id')
                desc = (p.get_attribute('content-desc') or '')[:60]
                print(f'     - id={rid!r} | desc={desc!r}')
        except Exception as e:
            print(f'     ⚠️ Error listando: {e}')
        return False
    try:
        checkbox = boton_producto.find_element(AppiumBy.XPATH, './/android.widget.CheckBox')
        is_checked = checkbox.get_attribute('checked') == 'true'
        if is_checked:
            print('  ℹ️ El checkbox ya estaba activado')
            return True
    except:
        checkbox = None
    try:
        driver.execute_script('mobile: scroll', {'elementId': boton_producto.id, 'toVisible': True})
        time.sleep(0.5)
    except:
        pass
    try:
        boton_producto.click()
        print('  ✅ Click en producto (Button padre)')
        time.sleep(1.5)
        if checkbox is not None:
            try:
                nuevo = checkbox.get_attribute('checked') == 'true'
                if nuevo:
                    print('  ✅ Checkbox confirmado como ACTIVADO')
                    return True
                else:
                    print('  ⚠️ Checkbox no cambió, probando click en checkbox...')
            except:
                pass
    except Exception as e:
        print(f'  ⚠️ Click en padre falló: {e}')
    if checkbox is not None:
        try:
            checkbox.click()
            print('  ✅ Click en CheckBox')
            time.sleep(1.5)
            nuevo = checkbox.get_attribute('checked') == 'true'
            if nuevo:
                print('  ✅ Checkbox confirmado como ACTIVADO')
                return True
        except Exception as e:
            print(f'  ❌ Click en CheckBox falló: {e}')
    if checkbox is not None:
        try:
            loc = checkbox.location
            size = checkbox.size
            x = loc['x'] + size['width'] // 2
            y = loc['y'] + size['height'] // 2
            print(f'  🎯 Tap en coordenadas: x={x}, y={y}')
            driver.tap([(x, y)])
            time.sleep(1.5)
            nuevo = checkbox.get_attribute('checked') == 'true'
            if nuevo:
                print('  ✅ Checkbox ACTIVADO (tap)')
                return True
        except Exception as e:
            print(f'  ❌ Tap por coordenadas falló: {e}')
    print('  ❌ No se pudo activar el checkbox')
    return False

def click_continuar_productos(driver, timeout=15):
    print('  📝 Click en Continuar (productos)...')
    wait = WebDriverWait(driver, timeout)
    try:
        btn = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//*[@resource-id='user_banking_product_btn_continuar']//android.widget.Button[@content-desc='Continuar']")))
        btn.click()
        print('  ✅ Click en Continuar')
        time.sleep(3)
        return True
    except:
        try:
            btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")
            btn.click()
            print('  ✅ Click en Continuar (fallback)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Continuar: {e}')
            return False

def click_confirmar_cambio(driver, timeout=15):
    print('  📝 Click en Confirmar cambio...')
    wait = WebDriverWait(driver, timeout)
    try:
        btn = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//*[@resource-id='shared_btn_confirmar_clave_temporal']//android.widget.Button[@content-desc='Confirmar cambio']")))
        btn.click()
        print('  ✅ Click en Confirmar cambio')
        time.sleep(3)
        return True
    except:
        try:
            btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Confirmar cambio']")
            btn.click()
            print('  ✅ Click en Confirmar cambio (fallback)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Confirmar cambio: {e}')
            return False

def click_continuar_exito_productos(driver, timeout=15):
    print('  📝 Click en Continuar (éxito)...')
    wait = WebDriverWait(driver, timeout)
    try:
        btn = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//*[@resource-id='user_banking_product_btn_continuar_exito']//android.widget.Button[@content-desc='Continuar']")))
        btn.click()
        print('  ✅ Click en Continuar (éxito)')
        time.sleep(2)
        return True
    except:
        try:
            btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")
            btn.click()
            print('  ✅ Click en Continuar (éxito - fallback)')
            time.sleep(2)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Continuar (éxito): {e}')
            return False

def productos_bancarios_flow(driver, accion='Desafiliar', nombre_producto='Prestamo (Bs.)', cuenta='10006438414', reporte=None, tiempos=None, paso_inicial=6):
    print(f'\n💼 INICIANDO PRODUCTOS BANCARIOS')
    print(f'   Acción: {accion}')
    print(f'   Producto: {nombre_producto}')
    print(f'   Cuenta: {cuenta}')
    print('=' * 60)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Ir a Más')
    if not click_mas_menu(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Menú Más abierto', "Se accedió al menú 'Más' desde la barra de navegación inferior.", espera=1.5)
    paso_num += 1
    tiempos.start('2. Configuraciones de usuario')
    if not click_configuraciones_usuario(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Configuraciones de usuario', 'Se accedió a las Configuraciones de usuario.', espera=1.5)
    paso_num += 1
    tiempos.start('3. Productos bancarios')
    if not click_productos_bancarios(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla de Productos Bancarios', 'Se accedió a la pantalla de Productos Bancarios. Se muestran los productos afiliados y no afiliados.', espera=2.0)
    paso_num += 1
    if accion.lower() == 'desafiliar':
        print('\n  📋 Sección: Productos afiliados')
        tiempos.start('4. Desafiliar producto')
        if not desafiliar_producto(driver, nombre_producto, cuenta):
            tiempos.stop()
            return False
        tiempos.stop()
        if reporte:
            reporte.capturar_paso(paso_num, f"Producto '{nombre_producto}' desafiliado", f"Se hizo clic en 'Desafiliar producto' para '{nombre_producto}' (cuenta: {cuenta}).", espera=1.5)
        paso_num += 1
        tiempos.start('5. Confirmar cambio')
        if not click_confirmar_cambio(driver):
            tiempos.stop()
            return False
        tiempos.stop()
        if reporte:
            reporte.capturar_paso(paso_num, 'Desafiliación confirmada', f"Se confirmó la desafiliación del producto '{nombre_producto}'.", espera=1.5)
        paso_num += 1
        print('  📝 Esperando pantalla de éxito...')
        time.sleep(3)
        tiempos.start('6. Continuar (éxito)')
        if not click_continuar_exito_productos(driver):
            tiempos.stop()
            return False
        tiempos.stop()
        if reporte:
            reporte.capturar_paso(paso_num, 'Modal de éxito aceptado', 'Se confirmó el mensaje de éxito de la desafiliación.', espera=1.5)
        paso_num += 1
    elif accion.lower() == 'afiliar':
        print('\n  📋 Sección: Productos no afiliados')
        tiempos.start('4. Afiliar producto')
        if not afiliar_producto(driver, nombre_producto, cuenta):
            tiempos.stop()
            return False
        tiempos.stop()
        if reporte:
            reporte.capturar_paso(paso_num, f"Producto '{nombre_producto}' seleccionado", f"Se seleccionó el checkbox del producto '{nombre_producto}' (cuenta: {cuenta}).", espera=1.5)
        paso_num += 1
        tiempos.start('5. Continuar (productos)')
        if not click_continuar_productos(driver):
            tiempos.stop()
            return False
        tiempos.stop()
        if reporte:
            reporte.capturar_paso(paso_num, 'Continuar (productos)', 'Se hizo clic en Continuar tras seleccionar el producto.', espera=1.5)
        paso_num += 1
        print('  📝 Esperando modal de confirmación...')
        time.sleep(3)
        tiempos.start('6. Confirmar cambio')
        if not click_confirmar_cambio(driver):
            tiempos.stop()
            return False
        tiempos.stop()
        if reporte:
            reporte.capturar_paso(paso_num, 'Afiliación confirmada', f"Se confirmó la afiliación del producto '{nombre_producto}'.", espera=1.5)
        paso_num += 1
        print('  📝 Esperando pantalla de éxito...')
        time.sleep(3)
        tiempos.start('7. Continuar (éxito)')
        if not click_continuar_exito_productos(driver):
            tiempos.stop()
            return False
        tiempos.stop()
        if reporte:
            reporte.capturar_paso(paso_num, 'Modal de éxito aceptado', 'Se confirmó el mensaje de éxito de la afiliación.', espera=1.5)
        paso_num += 1
    else:
        print(f"  ❌ Acción inválida: {accion}. Usa 'Afiliar' o 'Desafiliar'")
        return False
    print('  📝 Esperando volver a la pantalla principal...')
    time.sleep(2)
    tiempos.start('Volver atrás')
    if not volver_atras(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Regreso a la pantalla anterior', 'Se regresó a la pantalla anterior tras el cambio.', espera=1.0)
    paso_num += 1
    tiempos.start('Volver al home')
    if not volver_home(driver):
        print('  ⚠️ No se pudo volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Productos Bancarios finalizado', f"Se regresó exitosamente al home. La acción '{accion}' sobre '{nombre_producto}' ha terminado.", espera=1.5)
    paso_num += 1
    print(f'\n✅ {accion.upper()} DE PRODUCTO COMPLETADO EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('mas_usuario_productos_bancarios_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO: LOGIN + PRODUCTOS BANCARIOS + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    ACCION = _input_cfg.get('ACCION', 'Afiliar')
    NOMBRE_PRODUCTO = _input_cfg.get('NOMBRE_PRODUCTO', 'Prestamo (Bs.)')
    CUENTA = _input_cfg.get('CUENTA', '10006438414')
    NOMBRE_PRUEBA = f'Productos_Bancarios_{ACCION}'
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f'💼 Acción: {ACCION}')
    print(f'📦 Producto: {NOMBRE_PRODUCTO}')
    print(f'💳 Cuenta: {CUENTA}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Acción': ACCION, 'Producto': NOMBRE_PRODUCTO, 'Cuenta': CUENTA})
    login_ok = _input_cfg.get('login_ok', False)
    productos_ok = _input_cfg.get('productos_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            productos_ok = productos_bancarios_flow(driver, accion=ACCION, nombre_producto=NOMBRE_PRODUCTO, cuenta=CUENTA, reporte=reporte, tiempos=tiempos, paso_inicial=6)
            if productos_ok:
                print(f'\n🎉 {ACCION.upper()} DE PRODUCTO EXITOSO!')
            else:
                print(f'\n❌ {ACCION.upper()} DE PRODUCTO FALLIDO')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and productos_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login            : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   {ACCION} producto : {('✅ OK' if productos_ok else '❌ FALLÓ')}")
        print(f'   Carpeta          : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

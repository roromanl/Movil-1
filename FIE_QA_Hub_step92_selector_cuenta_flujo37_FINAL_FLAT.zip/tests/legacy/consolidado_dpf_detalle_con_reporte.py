"""
Flujo DPF (consulta de detalle) con:
  - Capturas de pantalla por cada paso
  - Reporte Word (.docx) con datos generales + capturas
  - Carpeta autogenerada con fecha/hora
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import volver_atras__28d030ad13 as volver_atras, volver_home__afd08848fd as volver_home
from framework.common.ui_helpers import _esta_en_home as _esta_en_home, _seleccionar_opcion_case_insensitive__f21faf0807 as _seleccionar_opcion_case_insensitive

def click_dpf_scroll_horizontal(driver):
    print("  📝 [PASO 1] Click en 'DPF'...")
    time.sleep(2)
    for intento in range(3):
        try:
            btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='DPF' and @clickable='true']")
            if btn.is_displayed():
                btn.click()
                print(f"  ✅ Click en 'DPF' (exacto) [intento {intento + 1}]")
                time.sleep(3)
                return True
        except:
            pass
        try:
            btn = driver.find_element(AppiumBy.XPATH, "//android.widget.HorizontalScrollView//*[@content-desc='DPF' and @clickable='true']")
            if btn.is_displayed():
                btn.click()
                print(f"  ✅ Click en 'DPF' (en HSV) [intento {intento + 1}]")
                time.sleep(3)
                return True
        except:
            pass
        if intento < 2:
            print(f'  ↩️  DPF no visible, scroll horizontal... (intento {intento + 1})')
            try:
                hsv = driver.find_element(AppiumBy.XPATH, '//android.widget.HorizontalScrollView')
                rect = hsv.rect
                start_x = rect['x'] + int(rect['width'] * 0.8)
                end_x = rect['x'] + int(rect['width'] * 0.2)
                center_y = rect['y'] + int(rect['height'] / 2)
                driver.swipe(start_x, center_y, end_x, center_y, 400)
                time.sleep(1)
            except Exception as e:
                print(f'    ⚠️ Error scroll: {e}')
    if _seleccionar_opcion_case_insensitive(driver, 'DPF', timeout=5, debug=True):
        print("  ✅ Click en 'DPF' (helper)")
        time.sleep(3)
        return True
    print("  ❌ No se encontró 'DPF'")
    return False

def seleccionar_cuenta_dpf(driver, numero_cuenta):
    print(f"  📝 [PASO 2] Seleccionando cuenta DPF: '{numero_cuenta}'...")
    time.sleep(2)
    try:
        cuenta = driver.find_element(AppiumBy.XPATH, f"//android.view.View[@clickable='true' and contains(translate(@content-desc, '\n\r', '  '), 'Depósito a plazo fijo') and contains(translate(@content-desc, '\n\r', '  '), '{numero_cuenta}')]")
        desc = (cuenta.get_attribute('content-desc') or '').replace('\n', ' | ')
        cuenta.click()
        print(f"  ✅ Cuenta DPF seleccionada (translate) → '{desc[:80]}'")
        time.sleep(3)
        return True
    except Exception as e:
        print(f'    ⚠️ Estrategia 1 falló: {str(e)[:80]}')
    try:
        cuenta = driver.find_element(AppiumBy.XPATH, f"//android.view.View[@clickable='true' and contains(translate(@content-desc, '\n\r', '  '), '{numero_cuenta}')]")
        cuenta.click()
        print(f'  ✅ Cuenta seleccionada (solo por número)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'    ⚠️ Estrategia 2 falló: {str(e)[:80]}')
    if _seleccionar_opcion_case_insensitive(driver, numero_cuenta, timeout=5, debug=True):
        print(f'  ✅ Cuenta seleccionada (helper)')
        time.sleep(3)
        return True
    print(f"  ❌ No se encontró la cuenta DPF: '{numero_cuenta}'")
    try:
        print('  🔍 Cards DPF visibles:')
        cards = driver.find_elements(AppiumBy.XPATH, "//android.view.View[@clickable='true' and contains(translate(@content-desc, '\n\r', '  '), 'Depósito')]")
        for c in cards:
            desc = (c.get_attribute('content-desc') or '').replace('\n', ' | ')
            print(f"     - desc='{desc[:90]}'")
    except:
        pass
    return False

def scroll_detalle_dpf(driver, cantidad=3, reporte=None, paso_inicial=3):
    print(f'  📝 [PASO 3] Haciendo scroll en detalle ({cantidad} swipes)...')
    time.sleep(2)
    paso_num = paso_inicial
    try:
        scroll_view = driver.find_element(AppiumBy.XPATH, "//android.widget.ScrollView[@scrollable='true']")
        rect = scroll_view.rect
        print(f'    📐 ScrollView bounds: {rect}')
        center_x = rect['x'] + int(rect['width'] / 2)
        start_y = rect['y'] + int(rect['height'] * 0.8)
        end_y = rect['y'] + int(rect['height'] * 0.2)
        for i in range(cantidad):
            driver.swipe(center_x, start_y, center_x, end_y, 500)
            print(f'    ✅ Swipe {i + 1}/{cantidad} ejecutado')
            time.sleep(1)
            if reporte:
                reporte.capturar_paso(paso_num, f'Scroll detalle #{i + 1}', f'Scroll #{i + 1} de la pantalla de detalle del DPF para revisar la información.', espera=0.5)
                paso_num += 1
        time.sleep(1)
        print('  ✅ Scroll de detalle completado')
        return (True, paso_num)
    except Exception as e:
        print(f'  ⚠️ Error en scroll detalle: {str(e)[:80]}')
    try:
        for i in range(cantidad):
            size = driver.get_window_size()
            x = int(size['width'] / 2)
            y_start = int(size['height'] * 0.8)
            y_end = int(size['height'] * 0.3)
            driver.swipe(x, y_start, x, y_end, 500)
            print(f'    ✅ Swipe genérico {i + 1}/{cantidad} ejecutado')
            time.sleep(1)
            if reporte:
                reporte.capturar_paso(paso_num, f'Scroll detalle #{i + 1}', f'Scroll #{i + 1} (fallback) en la pantalla de detalle.', espera=0.5)
                paso_num += 1
        return (True, paso_num)
    except Exception as e:
        print(f'  ❌ Error en scroll genérico: {str(e)[:80]}')
        return (False, paso_num)

def realizar_flujo_dpf(driver, numero_cuenta='70-1-0196899-6', scroll_cantidad=3, reporte=None, tiempos=None, paso_inicial=6):
    print(f'\n🏦 INICIANDO FLUJO DPF')
    print(f"📋 Cuenta a consultar: '{numero_cuenta}'")
    print(f'📋 Swipes en detalle: {scroll_cantidad}')
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    tiempos.start('1. Click DPF (scroll)')
    if not click_dpf_scroll_horizontal(driver):
        print('  ❌ Error en PASO 1: DPF')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_inicial, 'Selección DPF en scroll horizontal', "Se hizo clic en el botón 'DPF' del scroll horizontal de productos en el home.", espera=1.5)
    paso_inicial += 1
    print('  📝 Esperando carga de la lista DPF...')
    time.sleep(3)
    tiempos.start('2. Seleccionar cuenta DPF')
    if not seleccionar_cuenta_dpf(driver, numero_cuenta):
        print(f"  ❌ Error en PASO 2: cuenta '{numero_cuenta}'")
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_inicial, f"Cuenta DPF '{numero_cuenta}' seleccionada", f"Se seleccionó la cuenta de Depósito a Plazo Fijo con número '{numero_cuenta}'.", espera=1.5)
    paso_inicial += 1
    print('  📝 Esperando carga del detalle...')
    time.sleep(3)
    if reporte:
        reporte.capturar_paso(paso_inicial, 'Pantalla de detalle del DPF', 'Se muestra el detalle completo del DPF: datos generales, saldos, información del producto, plazos, intereses y fechas.', espera=1.0)
    paso_inicial += 1
    tiempos.start('3. Scroll detalle')
    ok_scroll, paso_inicial = scroll_detalle_dpf(driver, cantidad=scroll_cantidad, reporte=reporte, paso_inicial=paso_inicial)
    if not ok_scroll:
        print('  ⚠️ Error en PASO 3: scroll')
    tiempos.stop()
    print('  📝 Esperando fin del scroll...')
    time.sleep(2)
    tiempos.start('4. Volver atrás')
    if not volver_atras(driver):
        print('  ⚠️ Error en PASO 4: volver atrás')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_inicial, 'Regreso a la lista de DPF', 'Se regresó atrás a la pantalla anterior tras revisar el detalle.', espera=1.0)
    paso_inicial += 1
    tiempos.start('5. Volver al home')
    if not volver_home(driver):
        print('  ⚠️ Error en PASO 5: volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_inicial, 'Home - Flujo DPF finalizado', 'Se regresó exitosamente al home. El flujo de consulta del DPF ha terminado.', espera=1.5)
    paso_inicial += 1
    print(f'\n✅ FLUJO DPF COMPLETADO EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('consolidado_dpf_detalle_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO: LOGIN + DPF (consulta de detalle) + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    NUMERO_CUENTA_DPF = _input_cfg.get('NUMERO_CUENTA_DPF', '70-1-0196899-6')
    SCROLL_CANTIDAD = _input_cfg.get('SCROLL_CANTIDAD', 3)
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'DPF_Detalle')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f"🏦 Cuenta DPF: '{NUMERO_CUENTA_DPF}'")
    print(f'📄 Nombre de la prueba: {NOMBRE_PRUEBA}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Cuenta DPF': NUMERO_CUENTA_DPF, 'Cantidad de scrolls en detalle': SCROLL_CANTIDAD})
    login_ok = _input_cfg.get('login_ok', False)
    flujo_ok = _input_cfg.get('flujo_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            flujo_ok = realizar_flujo_dpf(driver, numero_cuenta=NUMERO_CUENTA_DPF, scroll_cantidad=SCROLL_CANTIDAD, reporte=reporte, tiempos=tiempos, paso_inicial=6)
            if flujo_ok:
                print(f'\n🎉 FLUJO DPF EXITOSO!')
            else:
                print(f'\n❌ FLUJO DPF FALLIDO')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and flujo_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login          : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Flujo DPF      : {('✅ OK' if flujo_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

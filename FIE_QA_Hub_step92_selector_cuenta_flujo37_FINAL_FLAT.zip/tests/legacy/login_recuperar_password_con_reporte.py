"""
Flujo Recuperación de Contraseña + reporte Word.
Pasos: Usuario + Continuar → ¿Olvidaste tu contraseña? → Pregunta 1 (modal)
       → Pregunta 2 (modal) → Pregunta 3 (texto) → Continuar → Nueva contraseña
       → Guardar → OTP → Confirmar → Iniciar sesión
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.ui_helpers import _seleccionar_opcion_case_insensitive__f21faf0807 as _seleccionar_opcion_case_insensitive

def ingresar_usuario(driver, username, reporte=None):
    print(f'\n🔑 [PASO 1] Ingresando usuario: {username}')
    wait = WebDriverWait(driver, 10)
    if reporte:
        reporte.capturar_paso(1, 'Pantalla inicial de Login', "Se muestra la pantalla de bienvenida con el campo 'Usuario' vacío.", espera=1.5)
    try:
        username_input = wait.until(EC.presence_of_element_located((AppiumBy.ID, 'login_input_usuario')))
        username_input.click()
        username_input.clear()
        username_input.send_keys(username)
        print(f'  ✅ Usuario ingresado')
    except:
        try:
            username_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='Usuario']")
            username_input.click()
            username_input.clear()
            username_input.send_keys(username)
            print(f'  ✅ Usuario ingresado (fallback)')
        except Exception as e:
            print(f'  ❌ Error al ingresar usuario: {e}')
            return False
    try:
        driver.hide_keyboard()
    except:
        pass
    time.sleep(0.5)
    if reporte:
        reporte.capturar_paso(2, 'Usuario ingresado', f"Se ingresó el usuario '{username}' en el campo correspondiente.", espera=1.0)
    try:
        continuar_btn = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")))
        continuar_btn.click()
        print('  ✅ Click en Continuar')
    except:
        try:
            continuar_btn = driver.find_element(AppiumBy.ACCESSIBILITY_ID, 'Continuar')
            continuar_btn.click()
            print('  ✅ Click en Continuar (Accessibility ID)')
        except:
            try:
                view_container = driver.find_element(AppiumBy.ID, 'login_btn_ingresar')
                continuar_btn = view_container.find_element(AppiumBy.XPATH, ".//android.widget.Button[@content-desc='Continuar']")
                continuar_btn.click()
                print('  ✅ Click en Continuar (dentro de login_btn_ingresar)')
            except Exception as e:
                print(f'  ❌ Error al clickear Continuar: {e}')
                return False
    time.sleep(5)
    return True

def click_olvidaste_password(driver, reporte=None):
    print(f"\n🔑 [PASO 2] Click en '¿Olvidaste tu contraseña?'")
    time.sleep(3)
    if reporte:
        reporte.capturar_paso(3, 'Pantalla de Contraseña', "Se avanzó a la pantalla de ingreso de contraseña. Se muestra el link '¿Olvidaste tu contraseña?'.", espera=1.5)
    clicked = False
    try:
        btn = driver.find_element(AppiumBy.ID, 'login_btn_olvidaste')
        btn.click()
        print("  ✅ Click en '¿Olvidaste tu contraseña?' (ID)")
        clicked = True
    except:
        pass
    if not clicked:
        try:
            btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='¿Olvidaste tu contraseña?']")
            btn.click()
            print("  ✅ Click en '¿Olvidaste tu contraseña?' (content-desc)")
            clicked = True
        except:
            pass
    if not clicked:
        try:
            btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Olvidaste') and @clickable='true']")
            btn.click()
            print("  ✅ Click en '¿Olvidaste tu contraseña?' (contains)")
            clicked = True
        except:
            pass
    if not clicked:
        if _seleccionar_opcion_case_insensitive(driver, 'Olvidaste', timeout=5, debug=True):
            print("  ✅ Click en '¿Olvidaste tu contraseña?' (helper)")
            clicked = True
    if clicked:
        time.sleep(3)
    return clicked

def seleccionar_pregunta_1(driver, respuesta):
    print(f"\n🔐 [PASO 3A] Seleccionando Pregunta 1: '{respuesta}'")
    time.sleep(2)
    try:
        btn = driver.find_element(AppiumBy.ID, 'recovery_select_pregunta_1')
        btn.click()
        print('  ✅ Click en Pregunta 1 (abrir modal)')
        time.sleep(2)
    except:
        try:
            btn = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='recovery_select_pregunta_1' and @clickable='true']")
            btn.click()
            print('  ✅ Click en Pregunta 1 (XPATH)')
            time.sleep(2)
        except Exception as e:
            print(f'  ❌ No se encontró Pregunta 1: {e}')
            return False
    time.sleep(2)
    if _seleccionar_opcion_case_insensitive(driver, respuesta, timeout=5, debug=True):
        print(f"  ✅ Pregunta 1 seleccionada: '{respuesta}'")
        time.sleep(2)
        return True
    try:
        opciones = driver.find_elements(AppiumBy.XPATH, "//android.widget.ScrollView[@is-collection='true']//*[@clickable='true']")
        print(f'    🔍 Opciones en modal: {len(opciones)}')
        for o in opciones:
            desc = (o.get_attribute('content-desc') or '').strip()
            if respuesta.lower() in desc.lower():
                o.click()
                print(f"  ✅ Pregunta 1 seleccionada (fallback): '{desc}'")
                time.sleep(2)
                return True
    except:
        pass
    print(f"  ❌ No se pudo seleccionar Pregunta 1: '{respuesta}'")
    return False

def seleccionar_pregunta_2(driver, respuesta):
    print(f"\n🔐 [PASO 3B] Seleccionando Pregunta 2: '{respuesta}'")
    time.sleep(2)
    try:
        btn = driver.find_element(AppiumBy.ID, 'recovery_select_pregunta_2')
        btn.click()
        print('  ✅ Click en Pregunta 2 (abrir modal)')
        time.sleep(2)
    except:
        try:
            btn = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='recovery_select_pregunta_2' and @clickable='true']")
            btn.click()
            print('  ✅ Click en Pregunta 2 (XPATH)')
            time.sleep(2)
        except Exception as e:
            print(f'  ❌ No se encontró Pregunta 2: {e}')
            return False
    time.sleep(2)
    if _seleccionar_opcion_case_insensitive(driver, respuesta, timeout=5, debug=True):
        print(f"  ✅ Pregunta 2 seleccionada: '{respuesta}'")
        time.sleep(2)
        return True
    try:
        opciones = driver.find_elements(AppiumBy.XPATH, "//android.widget.ScrollView[@is-collection='true']//*[@clickable='true']")
        for o in opciones:
            desc = (o.get_attribute('content-desc') or '').strip()
            if respuesta.lower() in desc.lower():
                o.click()
                print(f"  ✅ Pregunta 2 seleccionada (fallback): '{desc}'")
                time.sleep(2)
                return True
    except:
        pass
    print(f"  ❌ No se pudo seleccionar Pregunta 2: '{respuesta}'")
    return False

def escribir_respuesta_3(driver, respuesta):
    print(f"\n🔐 [PASO 3C] Escribiendo Pregunta 3: '{respuesta}'")
    time.sleep(2)
    try:
        field = driver.find_element(AppiumBy.ID, 'recovery_input_respuesta_personalizada')
        try:
            inner = field.find_element(AppiumBy.CLASS_NAME, 'android.widget.EditText')
            field = inner
        except:
            pass
        field.click()
        time.sleep(0.5)
        field.clear()
        field.send_keys(respuesta)
        print(f"  ✅ Respuesta personalizada escrita: '{respuesta}'")
    except:
        try:
            field = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@resource-id='recovery_input_respuesta_personalizada']/android.widget.EditText")
            field.click()
            time.sleep(0.5)
            field.clear()
            field.send_keys(respuesta)
            print(f'  ✅ Respuesta escrita (XPATH hijo)')
        except Exception as e:
            print(f'  ❌ Error al escribir Pregunta 3: {e}')
            return False
    try:
        driver.hide_keyboard()
        time.sleep(0.5)
    except:
        pass
    return True

def click_continuar_preguntas(driver):
    print(f"\n🔐 [PASO 3D] Click en 'Continuar' (preguntas)")
    time.sleep(2)
    try:
        driver.hide_keyboard()
        time.sleep(0.5)
    except:
        pass
    try:
        parent = driver.find_element(AppiumBy.ID, 'recovery_btn_continuar')
        btn = parent.find_element(AppiumBy.XPATH, ".//android.widget.Button[@content-desc='Continuar']")
        btn.click()
        print('  ✅ Click en Continuar (dentro de recovery_btn_continuar)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        btns = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar' and @clickable='true']")
        print(f"  🔍 Botones 'Continuar' encontrados: {len(btns)}")
        if btns:
            btns[-1].click()
            print('  ✅ Click en Continuar (último)')
            time.sleep(3)
            return True
    except:
        pass
    if _seleccionar_opcion_case_insensitive(driver, 'Continuar', timeout=5, debug=True):
        print('  ✅ Click en Continuar (helper)')
        time.sleep(3)
        return True
    print('  ❌ Error al clickear Continuar')
    return False

def ingresar_nueva_password(driver, password):
    print(f'\n🔐 [PASO 4] Ingresando nueva contraseña')
    time.sleep(2)
    try:
        field = driver.find_element(AppiumBy.ID, 'recovery_input_password')
        field.click()
        time.sleep(0.5)
        field.clear()
        field.send_keys(password)
        print('  ✅ Nueva contraseña ingresada')
    except:
        try:
            field = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='Nueva contraseña']")
            field.click()
            time.sleep(0.5)
            field.clear()
            field.send_keys(password)
            print('  ✅ Nueva contraseña ingresada (hint)')
        except Exception as e:
            print(f'  ❌ Error al ingresar contraseña: {e}')
            return False
    try:
        driver.hide_keyboard()
        time.sleep(0.5)
    except:
        pass
    try:
        field2 = driver.find_element(AppiumBy.ID, 'recovery_input_password_confirm')
        field2.click()
        time.sleep(0.5)
        field2.clear()
        field2.send_keys(password)
        print('  ✅ Confirmación ingresada')
    except:
        try:
            field2 = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='Confirmar contraseña']")
            field2.click()
            time.sleep(0.5)
            field2.clear()
            field2.send_keys(password)
            print('  ✅ Confirmación ingresada (hint)')
        except Exception as e:
            print(f'  ❌ Error al confirmar contraseña: {e}')
            return False
    try:
        driver.hide_keyboard()
        time.sleep(0.5)
    except:
        pass
    time.sleep(2)
    return True

def click_guardar_password(driver):
    print(f"\n🔐 [PASO 4b] Click en 'Guardar contraseña'")
    time.sleep(2)
    try:
        driver.hide_keyboard()
        time.sleep(0.5)
    except:
        pass
    try:
        parent = driver.find_element(AppiumBy.ID, 'recovery_btn_guardar')
        btn = parent.find_element(AppiumBy.XPATH, ".//android.widget.Button[@content-desc='Guardar contraseña']")
        if btn.is_enabled():
            btn.click()
            print("  ✅ Click en 'Guardar contraseña' (dentro del padre)")
            time.sleep(3)
            return True
        else:
            print("  ⚠️ Botón 'Guardar contraseña' deshabilitado")
    except:
        pass
    try:
        btns = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Guardar contraseña' and @clickable='true']")
        for b in btns:
            if b.is_enabled():
                b.click()
                print("  ✅ Click en 'Guardar contraseña'")
                time.sleep(3)
                return True
    except:
        pass
    if _seleccionar_opcion_case_insensitive(driver, 'Guardar contraseña', timeout=5, debug=True):
        print("  ✅ Click en 'Guardar contraseña' (helper)")
        time.sleep(3)
        return True
    print("  ❌ No se pudo clickear 'Guardar contraseña'")
    return False

def click_confirmar_otp(driver):
    print(f"\n🔐 [PASO 5b] Click en 'Confirmar' (OTP)")
    time.sleep(2)
    try:
        driver.hide_keyboard()
        time.sleep(0.5)
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Confirmar' and @clickable='true']")
        btn.click()
        print("  ✅ Click en 'Confirmar' (content-desc)")
        time.sleep(3)
        return True
    except:
        pass
    if _seleccionar_opcion_case_insensitive(driver, 'Confirmar', timeout=5, debug=True):
        print("  ✅ Click en 'Confirmar' (helper)")
        time.sleep(3)
        return True
    print("  ❌ No se pudo clickear 'Confirmar'")
    return False

def click_iniciar_sesion_final(driver):
    print(f"\n🔐 [PASO 6] Click en 'Iniciar sesión' (alerta final)")
    time.sleep(3)
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Iniciar sesión' and @clickable='true']")
        btn.click()
        print("  ✅ Click en 'Iniciar sesión'")
        time.sleep(3)
        return True
    except:
        pass
    if _seleccionar_opcion_case_insensitive(driver, 'Iniciar sesión', timeout=5, debug=True):
        print("  ✅ Click en 'Iniciar sesión' (helper)")
        time.sleep(3)
        return True
    print("  ❌ No se pudo clickear 'Iniciar sesión'")
    return False

def realizar_recuperacion_password(driver, username, respuesta_pregunta_1, respuesta_pregunta_2, respuesta_pregunta_3, nueva_password, codigo_otp, reporte=None, tiempos=None):
    print(f'\n🔐 INICIANDO RECUPERACIÓN DE CONTRASEÑA')
    print(f'👤 Usuario: {username}')
    print(f'🔑 P1: {respuesta_pregunta_1}')
    print(f'🔑 P2: {respuesta_pregunta_2}')
    print(f'🔑 P3: {respuesta_pregunta_3}')
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = 1
    tiempos.start('1. Usuario + Continuar')
    if not ingresar_usuario(driver, username, reporte=reporte):
        tiempos.stop()
        return False
    tiempos.stop()
    paso_num = 3
    tiempos.start('2. Olvidaste contraseña')
    if not click_olvidaste_password(driver, reporte=reporte):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla de Recuperación de Contraseña', 'Se accedió a la pantalla de recuperación con las preguntas de seguridad.', espera=1.5)
    paso_num += 1
    tiempos.start('3A. Pregunta 1')
    if not seleccionar_pregunta_1(driver, respuesta_pregunta_1):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f"Pregunta 1: '{respuesta_pregunta_1}'", f"Se seleccionó la respuesta '{respuesta_pregunta_1}' para la Pregunta 1.", espera=1.5)
    paso_num += 1
    tiempos.start('3B. Pregunta 2')
    if not seleccionar_pregunta_2(driver, respuesta_pregunta_2):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f"Pregunta 2: '{respuesta_pregunta_2}'", f"Se seleccionó la respuesta '{respuesta_pregunta_2}' para la Pregunta 2.", espera=1.5)
    paso_num += 1
    tiempos.start('3C. Pregunta 3')
    if not escribir_respuesta_3(driver, respuesta_pregunta_3):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f"Pregunta 3: '{respuesta_pregunta_3}'", f"Se escribió '{respuesta_pregunta_3}' en la Pregunta 3 (respuesta personalizada).", espera=1.0)
    paso_num += 1
    tiempos.start('3D. Continuar preguntas')
    if not click_continuar_preguntas(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Preguntas de seguridad enviadas', 'Se enviaron las respuestas de las 3 preguntas de seguridad. Se avanzó a la pantalla de nueva contraseña.', espera=1.5)
    paso_num += 1
    tiempos.start('4. Nueva contraseña')
    if not ingresar_nueva_password(driver, nueva_password):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Nueva contraseña ingresada', 'Se ingresó la nueva contraseña y su confirmación (campos enmascarados).', espera=1.0)
    paso_num += 1
    tiempos.start('4b. Guardar contraseña')
    if not click_guardar_password(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Contraseña guardada', "Se hizo clic en 'Guardar contraseña'. Se solicita el código OTP.", espera=1.5)
    paso_num += 1
    tiempos.start('5b. Confirmar OTP')
    if not click_confirmar_otp(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'OTP confirmado', 'Se confirmó el código OTP y se procesó el cambio de contraseña.', espera=1.5)
    paso_num += 1
    tiempos.start('6. Iniciar sesión')
    if not click_iniciar_sesion_final(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Contraseña restablecida exitosamente', "Se hizo clic en 'Iniciar sesión'. La contraseña fue restablecida correctamente. Se regresó al login.", espera=2.0)
    paso_num += 1
    print(f'\n✅ RECUPERACIÓN DE CONTRASEÑA COMPLETADA EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('login_recuperar_password_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO: RECUPERACIÓN DE CONTRASEÑA + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    USERNAME = _input_cfg.get('USERNAME', '76018956')
    RESPUESTA_P1 = _input_cfg.get('RESPUESTA_P1', 'El Caribe')
    RESPUESTA_P2 = _input_cfg.get('RESPUESTA_P2', 'Leer')
    RESPUESTA_P3 = _input_cfg.get('RESPUESTA_P3', 'respuesta')
    NUEVA_PASSWORD = _input_cfg.get('NUEVA_PASSWORD', 'Abc#1234')
    CODIGO_OTP = _input_cfg.get('CODIGO_OTP', '123456')
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Recuperar_Password')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {USERNAME}')
    print(f'🔑 P1: {RESPUESTA_P1}')
    print(f'🔑 P2: {RESPUESTA_P2}')
    print(f'🔑 P3: {RESPUESTA_P3}')
    print(f"🔒 Nueva password: {'*' * len(NUEVA_PASSWORD)}")
    print(f'📱 OTP: {CODIGO_OTP}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=USERNAME, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Usuario': USERNAME, 'Respuesta P1': RESPUESTA_P1, 'Respuesta P2': RESPUESTA_P2, 'Respuesta P3': RESPUESTA_P3, 'Código OTP': CODIGO_OTP})
    recuperacion_ok = _input_cfg.get('recuperacion_ok', False)
    try:
        recuperacion_ok = realizar_recuperacion_password(driver, username=USERNAME, respuesta_pregunta_1=RESPUESTA_P1, respuesta_pregunta_2=RESPUESTA_P2, respuesta_pregunta_3=RESPUESTA_P3, nueva_password=NUEVA_PASSWORD, codigo_otp=CODIGO_OTP, reporte=reporte, tiempos=tiempos)
        if recuperacion_ok:
            print('\n🎉 RECUPERACIÓN DE CONTRASEÑA EXITOSA!')
        else:
            print('\n❌ RECUPERACIÓN DE CONTRASEÑA FALLIDA')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if recuperacion_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Recuperación   : {('✅ OK' if recuperacion_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

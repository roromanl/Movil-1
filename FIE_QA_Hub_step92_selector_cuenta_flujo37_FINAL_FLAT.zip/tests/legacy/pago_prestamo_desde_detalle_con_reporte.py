"""
Flujo Pago de Préstamo (desde Detalle) + reporte Word.
Pasos: Login → Pagos (home) → Pago de préstamo → Seleccionar préstamo
       → Detalles → Pagar cuota → Cuenta origen → Monto → Continuar
       → Modal → Confirmar → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import volver_home_desde_confirmacion
from framework.common.ui_helpers import _esta_en_home as _esta_en_home, _seleccionar_opcion_case_insensitive__f21faf0807 as _seleccionar_opcion_case_insensitive

def click_home_pagos(driver):
    print('  📝 Click en Pagos (home)...')
    time.sleep(2)
    try:
        pagos_btn = driver.find_element(AppiumBy.ID, 'home_btn_pagos')
        pagos_btn.click()
        print('  ✅ Click en Pagos (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        pagos_btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Pagos\nPagos' and @clickable='true']")
        pagos_btn.click()
        print('  ✅ Click en Pagos (content-desc)')
        time.sleep(3)
        return True
    except:
        pass
    if _seleccionar_opcion_case_insensitive(driver, 'Pagos', timeout=5):
        print('  ✅ Click en Pagos (helper)')
        time.sleep(3)
        return True
    print('  ❌ Error al clickear Pagos')
    return False

def click_pago_prestamo_opcion(driver):
    """En la pantalla Pagos, click en 'Pago de préstamo'."""
    print("  📝 Click en 'Pago de préstamo'...")
    time.sleep(2)
    try:
        btn = driver.find_element(AppiumBy.ID, 'payments_option_loans')
        btn.click()
        print("  ✅ Click en 'Pago de préstamo' (ID: payments_option_loans)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='payments_option_loans' and @clickable='true']")
        btn.click()
        print("  ✅ Click en 'Pago de préstamo' (XPATH resource-id)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Pago de préstamo\nPago de préstamo']")
        btn.click()
        print("  ✅ Click en 'Pago de préstamo' (content-desc exacto)")
        time.sleep(3)
        return True
    except:
        pass
    if _seleccionar_opcion_case_insensitive(driver, 'Pago de préstamo', timeout=5, debug=True):
        print("  ✅ Click en 'Pago de préstamo' (helper)")
        time.sleep(3)
        return True
    print("  ❌ Error al clickear 'Pago de préstamo'")
    return False

def seleccionar_prestamo_por_numero(driver, numero_prestamo):
    print(f'  📝 Verificando préstamo seleccionado: {numero_prestamo}...')
    time.sleep(2)
    try:
        selector = driver.find_element(AppiumBy.ID, 'loan_payment_selector')
        hijo = selector.find_element(AppiumBy.XPATH, ".//android.widget.Button[@clickable='true']")
        desc_actual = hijo.get_attribute('content-desc') or ''
        print(f'  🔍 Préstamo actual: {desc_actual[:80]}...')
        if numero_prestamo in desc_actual:
            print(f'  ✅ Préstamo ya está seleccionado: {numero_prestamo}')
            return True
    except Exception as e:
        print(f'  ⚠️ No se pudo verificar el selector: {e}')
    print(f'  📝 Abriendo selector de préstamo para cambiar a: {numero_prestamo}...')
    abierto = False
    try:
        selector = driver.find_element(AppiumBy.ID, 'loan_payment_selector')
        hijo = selector.find_element(AppiumBy.XPATH, ".//android.widget.Button[@clickable='true']")
        hijo.click()
        print('  ✅ Click en selector de préstamo (hijo clickable)')
        abierto = True
        time.sleep(3)
    except:
        pass
    if not abierto:
        try:
            selector = driver.find_element(AppiumBy.ID, 'loan_payment_selector')
            selector.click()
            print('  ✅ Click en selector de préstamo (contenedor)')
            abierto = True
            time.sleep(3)
        except:
            pass
    if not abierto:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Selecciona tu préstamo') and @clickable='true']")
            selector.click()
            print('  ✅ Click en selector de préstamo (content-desc)')
            abierto = True
            time.sleep(3)
        except:
            pass
    if not abierto:
        print(f'  ❌ No se pudo abrir el selector de préstamo')
        return False
    time.sleep(2)

    def _buscar_prestamo():
        try:
            prestamo = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{numero_prestamo}') and @clickable='true']")
            prestamo.click()
            print(f'  ✅ Préstamo seleccionado: {numero_prestamo}')
            time.sleep(2)
            return True
        except:
            pass
        try:
            partes = numero_prestamo.split('-')
            if len(partes) >= 2:
                ultimo = partes[-1]
                prestamo = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{ultimo}') and @clickable='true']")
                prestamo.click()
                print(f'  ✅ Préstamo seleccionado (último segmento: {ultimo})')
                time.sleep(2)
                return True
        except:
            pass
        try:
            prestamos = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[contains(@resource-id, 'loan_payment_') and @clickable='true']")
            for p in prestamos:
                desc = p.get_attribute('content-desc') or ''
                if numero_prestamo in desc:
                    p.click()
                    print(f'  ✅ Préstamo seleccionado (iteración)')
                    time.sleep(2)
                    return True
        except:
            pass
        return False
    if _buscar_prestamo():
        return True
    print(f'  ❌ No se encontró el préstamo: {numero_prestamo}')
    return False

def click_detalles_prestamo(driver):
    """Click en el botón 'Detalles' de la pantalla 'Pago de préstamos'."""
    print("  📝 Click en 'Detalles'...")
    time.sleep(2)
    try:
        btn = driver.find_element(AppiumBy.ID, 'loan_payment_details')
        btn.click()
        print("  ✅ Click en 'Detalles' (ID)")
        time.sleep(5)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='loan_payment_details']//android.widget.Button[@content-desc='Detalles']")
        btn.click()
        print("  ✅ Click en 'Detalles' (XPATH padre+hijo)")
        time.sleep(5)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Detalles' and @clickable='true']")
        btn.click()
        print("  ✅ Click en 'Detalles' (content-desc)")
        time.sleep(5)
        return True
    except:
        pass
    if _seleccionar_opcion_case_insensitive(driver, 'Detalles', timeout=5, debug=True):
        print("  ✅ Click en 'Detalles' (helper)")
        time.sleep(5)
        return True
    print("  ❌ Error al clickear 'Detalles'")
    return False

def click_pagar_cuota_detalle(driver):
    print("  📝 Click en 'Pagar cuota' (desde detalle)...")
    time.sleep(3)
    try:
        btn = driver.find_element(AppiumBy.ID, 'product_loan_detail_pay')
        btn.click()
        print("  ✅ Click en 'Pagar cuota' (ID)")
        time.sleep(5)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='product_loan_detail_pay']//android.widget.Button[@content-desc='Pagar cuota']")
        btn.click()
        print("  ✅ Click en 'Pagar cuota' (XPATH padre+hijo)")
        time.sleep(5)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Pagar cuota']")
        btn.click()
        print("  ✅ Click en 'Pagar cuota' (content-desc)")
        time.sleep(5)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//*[contains(translate(@content-desc, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'pagar cuota') and @clickable='true']")
        btn.click()
        print("  ✅ Click en 'Pagar cuota' (case-insensitive)")
        time.sleep(5)
        return True
    except:
        pass
    if _seleccionar_opcion_case_insensitive(driver, 'Pagar cuota', timeout=5, debug=True):
        print("  ✅ Click en 'Pagar cuota' (helper)")
        time.sleep(5)
        return True
    print("  ❌ Error al clickear 'Pagar cuota'")
    return False

def seleccionar_cuenta_origen(driver, numero_cuenta='40-0-1189577-1', timeout=15):
    print(f'  📝 Seleccionando cuenta origen: {numero_cuenta}...')
    time.sleep(5)
    wait = WebDriverWait(driver, 5)
    try:
        selector = driver.find_element(AppiumBy.ID, 'loan_compose_origin')
        hijo = selector.find_element(AppiumBy.XPATH, ".//android.widget.Button[@clickable='true']")
        desc_actual = hijo.get_attribute('content-desc') or ''
        if numero_cuenta in desc_actual:
            print(f'  ✅ Cuenta ya está seleccionada: {numero_cuenta}')
            return True
    except:
        pass
    abierto = False
    try:
        selector = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'loan_compose_origin')))
        selector.click()
        print('  ✅ Click en selector de cuenta origen (ID)')
        abierto = True
        time.sleep(2)
    except:
        pass
    if not abierto:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='loan_compose_origin']")
            selector.click()
            print('  ✅ Click en selector de cuenta origen (XPATH)')
            abierto = True
            time.sleep(2)
        except:
            pass
    if not abierto:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Selecciona la cuenta de origen')]")
            selector.click()
            print('  ✅ Click en selector de cuenta origen (content-desc)')
            abierto = True
            time.sleep(2)
        except Exception as e:
            print(f'  ❌ Error al abrir selector de cuenta: {e}')
            return False
    try:
        cuenta = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, f"//android.widget.Button[contains(@content-desc, '{numero_cuenta}')]")))
        cuenta.click()
        print(f'  ✅ Cuenta seleccionada (completa): {numero_cuenta}')
        time.sleep(2)
        return True
    except:
        pass
    try:
        partes = numero_cuenta.split('-')
        if len(partes) >= 2:
            ultimo_segmento = partes[-1]
            cuenta = driver.find_element(AppiumBy.XPATH, f"//android.widget.Button[contains(@content-desc, '{ultimo_segmento}')]")
            cuenta.click()
            print(f'  ✅ Cuenta seleccionada (último segmento: {ultimo_segmento})')
            time.sleep(2)
            return True
    except:
        pass
    try:
        cuentas = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'CUENTA')]")
        if cuentas:
            cuentas[0].click()
            print('  ✅ Primera cuenta seleccionada (fallback)')
            time.sleep(2)
            return True
    except:
        pass
    print(f'  ❌ Error al seleccionar cuenta: {numero_cuenta}')
    return False

def ingresar_monto_pago(driver, monto='69.19'):
    print(f'  📝 Ingresando monto: {monto}...')
    time.sleep(2)
    edit_text = None
    try:
        edit_text = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Monto a pagar')]/following::android.widget.EditText[1]")
        print("  ✅ EditText encontrado (por label 'Monto a pagar')")
    except:
        pass
    if edit_text is None:
        try:
            edit_texts = driver.find_elements(AppiumBy.XPATH, '//android.widget.EditText')
            for et in edit_texts:
                try:
                    if et.is_displayed() and et.is_enabled():
                        edit_text = et
                except:
                    pass
            if edit_text:
                print(f'  ✅ EditText encontrado (único visible, total={len(edit_texts)})')
        except:
            pass
    if edit_text is None:
        try:
            edit_texts = driver.find_elements(AppiumBy.XPATH, '//android.widget.EditText')
            for et in edit_texts:
                texto = et.get_attribute('text') or ''
                solo_num = texto.replace(',', '').replace('.', '').replace('Bs.', '').replace(' ', '')
                if solo_num.isdigit() and len(solo_num) >= 1:
                    edit_text = et
                    print(f"  ✅ EditText encontrado (por text de monto: '{texto[:20]}')")
                    break
        except:
            pass
    if edit_text is None:
        print('  ❌ No se encontró el EditText de monto')
        try:
            print('  🔍 EditTexts visibles:')
            todos = driver.find_elements(AppiumBy.XPATH, '//android.widget.EditText')
            print(f'     Total: {len(todos)}')
            for i, et in enumerate(todos):
                try:
                    rid = et.get_attribute('resource-id') or '(sin id)'
                    hint = et.get_attribute('hint') or '(sin hint)'
                    texto = et.get_attribute('text') or '(vacío)'
                    print(f"     [{i}] id='{rid}', hint='{hint}', text='{texto[:30]}'")
                except:
                    pass
        except:
            pass
        return False
    try:
        edit_text.click()
        time.sleep(0.5)
        try:
            edit_text.clear()
        except:
            pass
        texto_actual = edit_text.get_attribute('text') or ''
        if texto_actual.strip():
            print(f"  ⚠️ Campo no vacío tras clear() ('{texto_actual[:20]}'), borrando con BACKSPACE...")
            driver.press_keycode(123)
            time.sleep(0.3)
            for _ in range(len(texto_actual) + 2):
                driver.press_keycode(67)
            time.sleep(0.3)
        edit_text.send_keys(monto)
        print(f'  ✅ Monto ingresado: {monto}')
        try:
            driver.hide_keyboard()
        except:
            pass
        time.sleep(0.5)
        return True
    except Exception as e:
        print(f'  ❌ Error al ingresar monto: {e}')
        return False

def click_continuar_pago(driver):
    print('  📝 Click en Continuar (pago)...')
    time.sleep(5)
    try:
        continuar = driver.find_element(AppiumBy.ID, 'loan_compose_continue')
        continuar.click()
        print('  ✅ Click en Continuar (ID)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        continuar = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='loan_compose_continue']//android.widget.Button[@content-desc='Continuar']")
        continuar.click()
        print('  ✅ Click en Continuar (XPATH)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        continuar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")
        continuar.click()
        print('  ✅ Click en Continuar (content-desc)')
        time.sleep(2)
        return True
    except Exception as e:
        print(f'  ❌ Error al clickear Continuar: {e}')
        return False

def click_continuar_modal_informativo(driver, timeout=15):
    """Click en Continuar del modal informativo."""
    print('  📝 Click en Continuar (modal informativo)...')
    time.sleep(5)
    wait = WebDriverWait(driver, 5)
    try:
        continuar = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")))
        continuar.click()
        print('  ✅ Click en Continuar (modal)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        continuar = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Continuar') and @clickable='true']")
        continuar.click()
        print('  ✅ Click en Continuar (modal - contains)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        continuar = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Continuar') and @clickable='true']")
        continuar.click()
        print('  ✅ Click en Continuar (modal - texto)')
        time.sleep(2)
        return True
    except Exception as e:
        print(f'  ❌ Error al clickear Continuar en modal: {e}')
        return False

def click_confirmar_transaccion(driver):
    print('  📝 Click en Confirmar transacción...')
    time.sleep(9)
    try:
        confirmar = driver.find_element(AppiumBy.ID, 'loan_verification_confirm')
        confirmar.click()
        print('  ✅ Click en Confirmar transacción (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        confirmar = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='loan_verification_confirm']//android.widget.Button[@content-desc='Confirmar la transacción']")
        confirmar.click()
        print('  ✅ Click en Confirmar transacción (XPATH)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        confirmar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Confirmar la transacción']")
        confirmar.click()
        print('  ✅ Click en Confirmar transacción (content-desc)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        confirmar = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Confirmar') and @clickable='true']")
        confirmar.click()
        print('  ✅ Click en Confirmar transacción (contains)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al clickear Confirmar transacción: {e}')
        return False

def realizar_pago_prestamo_desde_detalle(driver, numero_prestamo='10-0-1145094-3', numero_cuenta='40-0-1189577-1', monto='69.19', tiempos=None, reporte=None, paso_inicial=6):
    print(f'\n💰 INICIANDO PAGO DE PRÉSTAMO (desde Detalle)')
    print(f'🏦 Préstamo: {numero_prestamo}')
    print(f'🏦 Cuenta origen: {numero_cuenta}')
    print(f'💰 Monto: {monto}')
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Click Pagos')
    if not click_home_pagos(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla Pagos', "Se accedió a la sección de 'Pagos' desde el home.", espera=2.0)
    paso_num += 1
    tiempos.start('2. Pago de préstamo')
    if not click_pago_prestamo_opcion(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla Pago de préstamo', "Se accedió a la pantalla 'Pago de préstamo'.", espera=2.0)
    paso_num += 1
    tiempos.start('3. Seleccionar préstamo')
    if not seleccionar_prestamo_por_numero(driver, numero_prestamo):
        print(f'  ⚠️ No se pudo verificar el préstamo {numero_prestamo}, continuando...')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Préstamo: {numero_prestamo}', f"Se verificó/seleccionó el préstamo con número '{numero_prestamo}'.", espera=1.5)
    paso_num += 1
    tiempos.start('4. Click Detalles')
    if not click_detalles_prestamo(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, "Click en 'Detalles'", "Se hizo clic en el botón 'Detalles'. Se abre la pantalla con la información detallada del préstamo.", espera=2.0)
    paso_num += 1
    tiempos.start('5. Click Pagar cuota')
    if not click_pagar_cuota_detalle(driver):
        print("  ❌ Error al clickear 'Pagar cuota'")
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, "Click en 'Pagar cuota'", "Se hizo clic en el botón 'Pagar cuota' desde la pantalla de detalle del préstamo.", espera=2.0)
    paso_num += 1
    tiempos.start('6. Cuenta origen')
    if not seleccionar_cuenta_origen(driver, numero_cuenta):
        print('  ⚠️ Error al seleccionar cuenta origen, continuando...')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Cuenta origen: {numero_cuenta}', f'Se seleccionó la cuenta de origen: {numero_cuenta}.', espera=1.5)
    paso_num += 1
    tiempos.start('7. Monto')
    if not ingresar_monto_pago(driver, monto):
        print('  ❌ Error al ingresar monto')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Monto: Bs. {monto}', f'Se ingresó el monto del pago: Bs. {monto}.', espera=1.0)
    paso_num += 1
    tiempos.start('8. Continuar (pago)')
    if not click_continuar_pago(driver):
        print('  ❌ Error al clickear Continuar')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Continuar (pago)', 'Se hizo clic en Continuar. Se avanzó a la pantalla de verificación.', espera=1.5)
    paso_num += 1
    tiempos.start('9. Continuar (modal)')
    if not click_continuar_modal_informativo(driver):
        print('  ⚠️ Error al clickear Continuar en modal, continuando...')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Continuar (modal informativo)', 'Se confirmó el modal informativo haciendo clic en Continuar.', espera=1.5)
    paso_num += 1
    tiempos.start('10. Confirmar transacción')
    if not click_confirmar_transaccion(driver):
        print('  ❌ Error al clickear Confirmar transacción')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Confirmar transacción', f'Se confirmó la transacción de pago de préstamo por Bs. {monto}.', espera=1.5)
    paso_num += 1
    tiempos.start('11. Volver al home')
    if not volver_home_desde_confirmacion(driver):
        print('  ⚠️ Error al volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Pago Préstamo finalizado', 'Se regresó exitosamente al home. El flujo de pago de préstamo desde detalle ha terminado.', espera=1.5)
    paso_num += 1
    print('\n✅ PAGO DE PRÉSTAMO (desde Detalle) COMPLETADO EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('pago_prestamo_desde_detalle_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO COMPLETO: LOGIN + PAGOS → PAGO DE PRÉSTAMO → DETALLE → PAGAR + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    numero_prestamo = _input_cfg.get('numero_prestamo', '10-0-1145094-3')
    numero_cuenta = _input_cfg.get('numero_cuenta', '40-0-1189577-1')
    monto_pago = _input_cfg.get('monto_pago', '69.19')
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Pago_Prestamo_Desde_Detalle')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f'🏦 Préstamo: {numero_prestamo}')
    print(f'🏦 Cuenta origen: {numero_cuenta}')
    print(f'💰 Monto a pagar: {monto_pago}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Préstamo': numero_prestamo, 'Cuenta origen': numero_cuenta, 'Monto': f'Bs. {monto_pago}'})
    login_ok = _input_cfg.get('login_ok', False)
    pago_ok = _input_cfg.get('pago_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            pago_ok = realizar_pago_prestamo_desde_detalle(driver, numero_prestamo=numero_prestamo, numero_cuenta=numero_cuenta, monto=monto_pago, tiempos=tiempos, reporte=reporte, paso_inicial=6)
            if pago_ok:
                print('\n🎉 PAGO DE PRÉSTAMO EXITOSO!')
            else:
                print('\n❌ PAGO DE PRÉSTAMO FALLIDO')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and pago_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login          : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Pago préstamo  : {('✅ OK' if pago_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

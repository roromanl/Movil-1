"""
Flujo Consolidado / Últimos movimientos con búsqueda + reporte Word.
Incluye soporte para:
  - Búsqueda por N/d + monto + signo
  - Tipo de movimiento ("Todos", "Transferencias", "Estados de cuenta", etc.)
  - Filtros por fecha desde/hasta
  - Flujo especial para Estados de cuenta (descarga PDF)
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import re
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import go_back__27efe39dbb as go_back
from framework.common.ui_helpers import _esta_en_home as _esta_en_home, _seleccionar_opcion_case_insensitive__f21faf0807 as _seleccionar_opcion_case_insensitive, _ingresar_texto_en_campo as _ingresar_texto_en_campo

def select_account_type(driver, tipo_cuenta):
    print(f'  📝 Seleccionando tipo de cuenta: {tipo_cuenta}...')
    time.sleep(3)
    try:
        btn = driver.find_element(AppiumBy.XPATH, f"//*[@content-desc='{tipo_cuenta}' and @clickable='true']")
        btn.click()
        print(f"  ✅ Tipo de cuenta '{tipo_cuenta}' seleccionado (exacto)")
        time.sleep(2)
        return True
    except:
        pass
    if _seleccionar_opcion_case_insensitive(driver, tipo_cuenta, timeout=5, debug=False):
        print(f"  ✅ Tipo de cuenta '{tipo_cuenta}' seleccionado (case-insensitive)")
        time.sleep(2)
        return True
    print(f'  ❌ Error al seleccionar tipo de cuenta: {tipo_cuenta}')
    try:
        tabs = driver.find_elements(AppiumBy.XPATH, "//*[@clickable='true' and @content-desc and string-length(@content-desc) < 30]")
        print('  🔍 Tabs visibles:')
        for t in tabs[:10]:
            desc = (t.get_attribute('content-desc') or '').replace('\n', ' | ')
            print(f"     - '{desc}'")
    except:
        pass
    return False

def select_account_by_number(driver, numero_cuenta):
    print(f'  📝 Seleccionando cuenta: {numero_cuenta}...')
    time.sleep(2)
    try:
        cuenta = driver.find_element(AppiumBy.XPATH, f"//android.view.View[@clickable='true' and contains(translate(@content-desc, '\n\r', '  '), 'Cuenta') and contains(translate(@content-desc, '\n\r', '  '), '{numero_cuenta}')]")
        cuenta.click()
        print(f'  ✅ Cuenta seleccionada: {numero_cuenta}')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ No se encontró: {numero_cuenta}')
        return False

def click_buscar_movimientos(driver):
    print('  📝 Click en Buscar (abrir formulario)...')
    time.sleep(2)
    try:
        buscar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Buscar' and @clickable='true']")
        buscar_btn.click()
        print('  ✅ Click en Buscar (abrir - content-desc)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        buscar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Buscar') and @clickable='true']")
        buscar_btn.click()
        print('  ✅ Click en Buscar (abrir - texto)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        buscar_btns = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Buscar']")
        if buscar_btns:
            buscar_btns[0].click()
            print('  ✅ Click en Buscar (abrir - primer botón)')
            time.sleep(3)
            return True
    except:
        pass
    print('  ❌ Error al clickear Buscar')
    return False

def fill_criterio_busqueda(driver, criterio=''):
    if not criterio:
        print('  ℹ️ Criterio vacío - saltando campo')
        return True
    print(f'  📝 Ingresando criterio: {criterio}...')
    time.sleep(2)
    ok = _ingresar_texto_en_campo(driver, resource_id=None, valor=criterio, hints_alternativos=['Buscar por criterio', 'Buscar', 'criterio'])
    if ok:
        print(f'  ✅ Criterio ingresado: {criterio}')
    else:
        print(f'  ❌ Error al ingresar criterio')
    return ok

def select_tipo_movimiento(driver, tipo='Todos'):
    print(f'  📝 Seleccionando tipo: {tipo}...')
    time.sleep(2)
    tipos_validos = ['Todos', 'Abonos', 'Debitos', 'Transferencias', 'Pago de servicios', 'Giros', 'Prestamos', 'Estados de cuenta']
    if tipo not in tipos_validos:
        print(f"  ⚠️ Tipo '{tipo}' no está en la lista conocida, intentando igual...")
    try:
        driver.swipe(500, 800, 500, 500, 500)
        time.sleep(1)
    except:
        pass
    abierto = False
    for opcion in tipos_validos:
        try:
            tipo_field = driver.find_element(AppiumBy.XPATH, f"//*[@content-desc='{opcion}' and @clickable='true']")
            tipo_field.click()
            print(f"  ✅ Click en combo Tipo (opción actual: '{opcion}')")
            abierto = True
            time.sleep(2)
            break
        except:
            continue
    if not abierto:
        try:
            tipo_field = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Tipo']/following-sibling::*[@clickable='true']")
            tipo_field.click()
            print('  ✅ Click en combo Tipo (por label)')
            abierto = True
            time.sleep(2)
        except:
            pass
    if not abierto:
        print('  ❌ No se encontró el combo Tipo')
        return False
    time.sleep(2)
    if _seleccionar_opcion_case_insensitive(driver, tipo, timeout=5, debug=True):
        print(f'  ✅ Tipo seleccionado: {tipo}')
        time.sleep(1)
        return True
    print(f"  ❌ No se encontró la opción '{tipo}'")
    return False

def select_fecha(driver, campo, fecha):
    """
    Selecciona una fecha en el calendario con navegación hacia adelante y atrás.
    """
    print(f'  📝 Seleccionando fecha {campo}: {fecha}...')
    time.sleep(2)
    dia, mes, anio = fecha.split('/')
    dia_int = int(dia)
    mes_int = int(mes)
    anio_int = int(anio)
    meses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre']
    mes_nombre = meses[mes_int - 1]
    try:
        botones = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Elegir en calendario']")
        print(f"  🔍 Encontrados {len(botones)} botones 'Elegir en calendario'")
        if campo == 'Desde':
            if len(botones) > 0:
                botones[0].click()
                print(f"  ✅ Click en 'Elegir en calendario' para Desde")
            else:
                print(f'  ❌ No se encontró el botón para Desde')
                return False
        elif len(botones) > 1:
            botones[1].click()
            print(f"  ✅ Click en 'Elegir en calendario' para Hasta")
        else:
            print(f'  ❌ No se encontró el botón para Hasta')
            return False
        time.sleep(2)
    except Exception as e:
        print(f'  ❌ Error al buscar botones: {e}')
        return False
    time.sleep(3)

    def obtener_mes_actual():
        try:
            titulo_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Enero') or contains(@content-desc, 'Febrero') or contains(@content-desc, 'Marzo') or contains(@content-desc, 'Abril') or contains(@content-desc, 'Mayo') or contains(@content-desc, 'Junio') or contains(@content-desc, 'Julio') or contains(@content-desc, 'Agosto') or contains(@content-desc, 'Septiembre') or contains(@content-desc, 'Octubre') or contains(@content-desc, 'Noviembre') or contains(@content-desc, 'Diciembre')]")
            return titulo_btn.get_attribute('content-desc') or ''
        except:
            return None
    encontrado = False
    for intento in range(24):
        titulo_actual = obtener_mes_actual()
        print(f'  📅 Mes actual: {titulo_actual}')
        if titulo_actual and mes_nombre in titulo_actual and (str(anio_int) in titulo_actual):
            print(f'  ✅ Mes correcto: {mes_nombre} {anio_int}')
            encontrado = True
            break
        try:
            mes_actual = None
            for i, nombre_mes in enumerate(meses, 1):
                if nombre_mes in titulo_actual:
                    mes_actual = i
                    break
            anio_actual = None
            años = re.findall('\\d{4}', titulo_actual)
            if años:
                anio_actual = int(años[0])
            if mes_actual and anio_actual:
                diff_meses = (anio_int - anio_actual) * 12 + (mes_int - mes_actual)
                print(f'  📊 Diferencia de meses: {diff_meses}')
                if diff_meses > 0:
                    try:
                        siguiente_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Mes siguiente' and @clickable='true']")
                        siguiente_btn.click()
                        print(f'  🔄 Navegando al siguiente mes...')
                        time.sleep(1)
                    except:
                        try:
                            siguiente_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Mes siguiente']")
                            if siguiente_btn.get_attribute('enabled') == 'true':
                                siguiente_btn.click()
                                print(f'  🔄 Navegando al siguiente mes...')
                                time.sleep(1)
                            else:
                                print(f"  ⚠️ Botón 'Mes siguiente' deshabilitado")
                                break
                        except:
                            print(f'  ⚠️ No se pudo navegar al siguiente mes')
                            break
                elif diff_meses < 0:
                    try:
                        anterior_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Mes anterior' and @clickable='true']")
                        anterior_btn.click()
                        print(f'  🔄 Navegando al mes anterior...')
                        time.sleep(1)
                    except:
                        try:
                            anterior_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Mes anterior']")
                            if anterior_btn.get_attribute('enabled') == 'true':
                                anterior_btn.click()
                                print(f'  🔄 Navegando al mes anterior...')
                                time.sleep(1)
                            else:
                                print(f"  ⚠️ Botón 'Mes anterior' deshabilitado")
                                break
                        except:
                            print(f'  ⚠️ No se pudo navegar al mes anterior')
                            break
                else:
                    encontrado = True
                    break
            else:
                print(f'  ⚠️ No se pudo determinar mes/año actual: {titulo_actual}')
                try:
                    siguiente_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Mes siguiente' and @clickable='true']")
                    siguiente_btn.click()
                    print(f'  🔄 Navegando al siguiente mes (fallback)...')
                    time.sleep(1)
                except:
                    break
        except Exception as e:
            print(f'  ⚠️ Error en navegación: {e}')
            break
    if not encontrado:
        print(f'  ❌ No se encontró el mes {mes_nombre} {anio_int}')
        try:
            driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Cancelar']").click()
            time.sleep(1)
        except:
            pass
        return False
    print(f'  🔄 Haciendo scroll para mostrar todos los días...')
    try:
        driver.swipe(500, 1500, 500, 600, 500)
        time.sleep(1)
    except:
        pass
    time.sleep(1)
    seleccionado = False
    estrategias = [lambda: driver.find_element(AppiumBy.XPATH, f"//*[@text='{dia_int}' and @clickable='true']"), lambda: driver.find_element(AppiumBy.XPATH, f"//*[@content-desc='{dia_int}' and @clickable='true']"), lambda: driver.find_element(AppiumBy.XPATH, f"//*[@text='{dia}' and @clickable='true']"), lambda: driver.find_element(AppiumBy.XPATH, f"//*[@content-desc='{dia}' and @clickable='true']"), lambda: driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{dia_int}') and @clickable='true']"), lambda: driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{dia_int}') and @clickable='true']")]
    for i, estrategia in enumerate(estrategias, 1):
        try:
            dia_btn = estrategia()
            if dia_btn.is_displayed() and dia_btn.is_enabled():
                dia_btn.click()
                print(f'  ✅ Día {dia} seleccionado (estrategia {i})')
                seleccionado = True
                break
        except:
            pass
    if not seleccionado:
        try:
            print(f'  🔍 Buscando día {dia_int} entre todos los días...')
            dias = driver.find_elements(AppiumBy.XPATH, "//*[@clickable='true' and @content-desc and string-length(@content-desc) <= 2]")
            for d in dias:
                desc = d.get_attribute('content-desc') or ''
                if desc.isdigit() and int(desc) == dia_int:
                    d.click()
                    print(f'  ✅ Día {dia} seleccionado (búsqueda entre días)')
                    seleccionado = True
                    break
        except:
            pass
    if not seleccionado:
        print(f'  ❌ No se pudo seleccionar el día {dia}')
        try:
            driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Cancelar']").click()
            time.sleep(1)
        except:
            pass
        return False
    time.sleep(1)
    print(f'  📝 Buscando botón Aceptar para {campo}...')
    try:
        aceptar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Aceptar']")
        if aceptar_btn.is_displayed() and aceptar_btn.is_enabled():
            aceptar_btn.click()
            print(f'  ✅ Fecha {campo} confirmada (click en Aceptar)')
            time.sleep(2)
            return True
    except:
        try:
            aceptar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Aceptar') and @clickable='true']")
            aceptar_btn.click()
            print(f'  ✅ Fecha {campo} confirmada (click en Aceptar - texto)')
            time.sleep(2)
            return True
        except Exception as e:
            print(f'  ❌ No se encontró el botón Aceptar: {e}')
            return False

def click_buscar_ejecutar(driver):
    print('  📝 Ejecutando búsqueda...')
    time.sleep(2)
    try:
        buscar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.ScrollView//android.widget.Button[@content-desc='Buscar']")
        buscar_btn.click()
        print('  ✅ Click en Buscar (ScrollView)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        buscar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Buscar' and @clickable='true' and @selected='false']")
        buscar_btn.click()
        print('  ✅ Click en Buscar (selected=false)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        buscar_btns = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Buscar']")
        print(f"  📊 Botones 'Buscar' encontrados: {len(buscar_btns)}")
        if len(buscar_btns) >= 2:
            buscar_btn = buscar_btns[-1]
            buscar_btn.click()
            print('  ✅ Click en Buscar (último botón)')
            time.sleep(3)
            return True
    except:
        pass
    try:
        buscar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.ScrollView//*[contains(@text, 'Buscar') and @clickable='true']")
        buscar_btn.click()
        print('  ✅ Click en Buscar (texto)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al ejecutar búsqueda: {e}')
        return False

def select_movimiento_by_nd(driver, texto_busqueda, monto=None, signo=None, max_scrolls=10, pausa_scroll=0.8, debug=True):
    print(f"  📝 Buscando movimiento con: '{texto_busqueda}'...")
    if monto:
        print(f"  📝 Monto: {(signo if signo else '')}{monto}")
    else:
        print(f'  📝 Monto: (sin filtro)')
    time.sleep(2)
    texto_lower = texto_busqueda.lower() if texto_busqueda else ''
    monto_str = str(monto) if monto is not None else None
    contador = {'n': 0}

    def _listar_movimientos(tag=''):
        xpaths = ["//android.widget.Button[@resource-id='shared_btn_movimiento' and @clickable='true']", "//*[@resource-id='shared_btn_movimiento' and @clickable='true']", "//*[@resource-id='shared_btn_movimiento']", "//*[contains(@resource-id, 'shared_btn_movimiento') and @clickable='true']"]
        for xp in xpaths:
            try:
                movs = driver.find_elements(AppiumBy.XPATH, xp)
                if movs:
                    if debug:
                        print(f'    🔍 [{tag}] XPath → {len(movs)} elementos')
                    return movs
            except:
                pass
        return []

    def _buscar_en_lista_actual(tag=''):
        try:
            movimientos = _listar_movimientos(tag=tag)
            if debug and movimientos:
                for i, m in enumerate(movimientos[:5]):
                    d = (m.get_attribute('content-desc') or '').replace('\n', ' | ')
                    rid = m.get_attribute('resource-id') or ''
                    print(f"       [{i}] id='{rid}', desc='{d[:70]}'")
            if not movimientos:
                if debug:
                    print(f'    ⚠️ [{tag}] No se encontraron movimientos')
                return False
            for mov in movimientos:
                desc = mov.get_attribute('content-desc') or ''
                desc_lower = desc.lower()
                if texto_lower and texto_lower not in desc_lower:
                    continue
                if monto_str and monto_str not in desc:
                    continue
                if signo:
                    if signo == '+' and '+Bs.' not in desc:
                        continue
                    if signo == '-' and '-Bs.' not in desc:
                        continue
                mov.click()
                driver._last_movimiento_desc = desc
                print(f'  ✅ Movimiento seleccionado: {desc[:100]}...')
                time.sleep(3)
                return True
            return False
        except Exception as e:
            print(f'  ⚠️ Error buscando: {str(e)[:80]}')
            return False
    print('  🔄 Asegurando scroll al TOP...')
    for _ in range(3):
        try:
            driver.swipe(500, 800, 500, 1600, 300)
            time.sleep(0.3)
        except:
            pass
    time.sleep(0.5)
    contador['n'] += 1
    print(f"  🔍 [Intento {contador['n']}] Buscando en TOP...")
    if _buscar_en_lista_actual(tag='TOP'):
        return True
    print('  🔄 Scroll incremental buscando en cada paso...')
    for intento in range(max_scrolls):
        try:
            driver.swipe(500, 1600, 500, 800, 500)
            time.sleep(pausa_scroll)
            contador['n'] += 1
            print(f"  🔍 [Intento {contador['n']}] Después de scroll {intento + 1}/{max_scrolls}")
            if _buscar_en_lista_actual(tag=f'DOWN-{intento + 1}'):
                return True
        except:
            pass
    print('  🔄 Volviendo al TOP...')
    for _ in range(max_scrolls + 2):
        try:
            driver.swipe(500, 800, 500, 1600, 300)
            time.sleep(0.2)
        except:
            pass
    time.sleep(0.5)
    contador['n'] += 1
    print(f"  🔍 [Intento {contador['n']}] Buscando de nuevo en TOP...")
    if _buscar_en_lista_actual(tag='TOP-2'):
        return True
    if debug:
        print('\n  🔍 DEBUG FINAL - Movimientos visibles:')
        try:
            movs = _listar_movimientos(tag='DEBUG')
            print(f'  🔍 Total: {len(movs)}')
            for i, mov in enumerate(movs[:10]):
                desc = (mov.get_attribute('content-desc') or '').replace('\n', ' | ')
                rid = mov.get_attribute('resource-id') or ''
                print(f"    [{i}] id='{rid}' desc='{desc[:100]}'")
        except:
            pass
    print(f"  ❌ No se encontró movimiento: '{texto_busqueda}'")
    return False

def close_movement_modal(driver):
    print('  📝 Cerrando modal de movimiento...')
    time.sleep(3)
    try:
        driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Transferencia') or contains(@content-desc, 'Comprobante') or contains(@content-desc, 'N/d')]")
        print('  ✅ Modal detectado')
    except:
        print('  ⚠️ No se detectó modal')
    try:
        cerrar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Cerrar']")
        cerrar_btn.click()
        print('  ✅ Click en Cerrar')
        time.sleep(2)
        return True
    except:
        pass
    try:
        cerrar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Cerrar') and @clickable='true']")
        cerrar_btn.click()
        print('  ✅ Click en Cerrar (texto)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        regresar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Regresar']")
        regresar.click()
        print('  ✅ Click en Regresar')
        time.sleep(2)
        return True
    except:
        pass
    try:
        aceptar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Aceptar']")
        aceptar.click()
        print('  ✅ Click en Aceptar')
        time.sleep(2)
        return True
    except:
        pass
    try:
        driver.back()
        print('  ✅ Back')
        time.sleep(2)
        return True
    except:
        return False

def select_mes_referencia(driver, mes='Ago', anio='2026'):
    print(f'  📝 Seleccionando mes: {mes} {anio}...')
    time.sleep(2)
    try:
        elegir_mes_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Elegir mes']")
        elegir_mes_btn.click()
        print('  ✅ Click en Elegir mes')
        time.sleep(2)
    except:
        try:
            elegir_mes_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Elegir mes') and @clickable='true']")
            elegir_mes_btn.click()
            print('  ✅ Click en Elegir mes (texto)')
            time.sleep(2)
        except Exception as e:
            print(f'  ❌ Error: {e}')
            return False
    time.sleep(2)
    if _seleccionar_opcion_case_insensitive(driver, mes, timeout=5, debug=True):
        print(f'  ✅ Mes seleccionado: {mes}')
        time.sleep(2)
        return True
    print(f'  ❌ Error al seleccionar mes {mes}')
    return False

def click_descargar_pdf(driver):
    print('  📝 Click en Descargar pdf...')
    time.sleep(2)
    try:
        descargar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Descargar pdf']")
        descargar_btn.click()
        print('  ✅ Click en Descargar pdf (content-desc)')
        time.sleep(5)
        return True
    except:
        pass
    try:
        descargar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Descargar pdf') and @clickable='true']")
        descargar_btn.click()
        print('  ✅ Click en Descargar pdf (texto)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        descargar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Descargar') and @clickable='true']")
        descargar_btn.click()
        print('  ✅ Click en Descargar pdf (contains)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error: {e}')
        return False

def _normalizar_fecha_ui(value):
    v=str(value or '').strip().replace('-', '/')
    q=v.split('/')
    if len(q)!=3:return v
    if len(q[0])==4:y,m,d=q
    else:d,m,y=q
    return f'{int(d):02d}/{int(m):02d}/{int(y):04d}'

def realizar_consolidado_busqueda(driver, tipo_cuenta='AHORRO', numero_cuenta=None, criterio='', tipo_movimiento='Todos', fecha_desde='01/08/2026', fecha_hasta='31/08/2026', texto_movimiento=None, monto_movimiento=None, signo_movimiento=None, mes_referencia='Ago', anio_referencia='2026', movimiento_index=0, reporte=None, tiempos=None, paso_inicial=6):
    fecha_desde=_normalizar_fecha_ui(fecha_desde); fecha_hasta=_normalizar_fecha_ui(fecha_hasta)
    print(f'\n📊 INICIANDO CONSOLIDADO CON BÚSQUEDA')
    print(f'🏦 Tipo cuenta: {tipo_cuenta}')
    if numero_cuenta:
        print(f'🏦 Número cuenta: {numero_cuenta}')
    print(f'📝 Movimiento: {texto_movimiento}')
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Tipo de cuenta')
    if not select_account_type(driver, tipo_cuenta):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f"Cuenta '{tipo_cuenta}' seleccionada", f"Se seleccionó el tipo de cuenta '{tipo_cuenta}' desde el home.", espera=1.5)
    paso_num += 1
    if numero_cuenta:
        tiempos.start('2. Cuenta específica')
        if not select_account_by_number(driver, numero_cuenta):
            print(f'  ⚠️ No se pudo seleccionar {numero_cuenta}')
        tiempos.stop()
        if reporte:
            reporte.capturar_paso(paso_num, f"Cuenta '{numero_cuenta}' seleccionada", f"Se seleccionó la cuenta específica '{numero_cuenta}' para la consulta.", espera=1.5)
        paso_num += 1
    tiempos.start('3. Abrir formulario')
    if not click_buscar_movimientos(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Formulario de Búsqueda abierto', 'Se abrió el formulario de búsqueda con los filtros: criterio, tipo, fechas.', espera=1.5)
    paso_num += 1
    if criterio:
        tiempos.start('4. Criterio')
        if not fill_criterio_busqueda(driver, criterio):
            print('  ⚠️ Error al llenar criterio')
        tiempos.stop()
        time.sleep(2)
        if reporte:
            reporte.capturar_paso(paso_num, f"Criterio: '{criterio}'", f"Se ingresó '{criterio}' en el campo de criterio de búsqueda.", espera=1.0)
        paso_num += 1
    tiempos.start('5. Tipo movimiento')
    if not select_tipo_movimiento(driver, tipo_movimiento):
        print('  ⚠️ Error al seleccionar tipo')
    tiempos.stop()
    time.sleep(2)
    if reporte:
        reporte.capturar_paso(paso_num, f"Tipo: '{tipo_movimiento}'", f"Se seleccionó el tipo de movimiento '{tipo_movimiento}' en el filtro.", espera=1.0)
    paso_num += 1
    if tipo_movimiento == 'Estados de cuenta':
        print('  📝 Ejecutando flujo de Estados de cuenta...')
        tiempos.start('6. Mes referencia')
        if not select_mes_referencia(driver, mes_referencia, anio_referencia):
            print('  ⚠️ Error al seleccionar mes')
            tiempos.stop()
            return False
        tiempos.stop()
        if reporte:
            reporte.capturar_paso(paso_num, f'Mes: {mes_referencia} {anio_referencia}', f"Se seleccionó el mes de referencia '{mes_referencia} {anio_referencia}'.", espera=1.5)
        paso_num += 1
        tiempos.start('7. Descargar PDF')
        if not click_descargar_pdf(driver):
            print('  ⚠️ Error al descargar PDF')
            tiempos.stop()
            return False
        tiempos.stop()
        if reporte:
            reporte.capturar_paso(paso_num, 'Estado de cuenta descargado', 'El PDF del estado de cuenta se descargó correctamente.', espera=2.0)
        paso_num += 1
        tiempos.start('8. Volver atrás')
        go_back(driver)
        tiempos.stop()
        if reporte:
            reporte.capturar_paso(paso_num, 'Home - Flujo Estados de Cuenta finalizado', 'Se regresó al home tras descargar el estado de cuenta.', espera=1.5)
        paso_num += 1
        print('\n✅ ESTADOS DE CUENTA COMPLETADO EXITOSAMENTE')
        return True
    if fecha_desde:
        tiempos.start('6. Fecha Desde')
        if not select_fecha(driver, 'Desde', fecha_desde):
            print('  ⚠️ Error al seleccionar fecha Desde')
        tiempos.stop()
        if reporte:
            reporte.capturar_paso(paso_num, f'Fecha desde: {fecha_desde}', f'Se seleccionó la fecha Desde = {fecha_desde} en el calendario.', espera=1.0)
        paso_num += 1
    if fecha_hasta:
        tiempos.start('7. Fecha Hasta')
        if not select_fecha(driver, 'Hasta', fecha_hasta):
            print('  ⚠️ Error al seleccionar fecha Hasta')
        tiempos.stop()
        if reporte:
            reporte.capturar_paso(paso_num, f'Fecha hasta: {fecha_hasta}', f'Se seleccionó la fecha Hasta = {fecha_hasta} en el calendario.', espera=1.0)
        paso_num += 1
    tiempos.start('8. Ejecutar búsqueda')
    if not click_buscar_ejecutar(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Búsqueda ejecutada', 'Se ejecutó la búsqueda. Se muestra la lista de resultados según los filtros.', espera=2.0)
    paso_num += 1
    if not texto_movimiento:
        print('  ❌ Error: Debes especificar texto_movimiento')
        return False
    tiempos.start('9. Seleccionar movimiento')
    if not select_movimiento_by_nd(driver, texto_movimiento, monto_movimiento, signo_movimiento):
        print(f'  ❌ No se encontró el movimiento: {texto_movimiento}')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        desc_mov = getattr(driver, '_last_movimiento_desc', '')
        reporte.capturar_paso(paso_num, f"Movimiento '{texto_movimiento}' seleccionado", f"Se seleccionó el movimiento con N/d '{texto_movimiento}'. Detalle: {desc_mov[:120]}", espera=2.0)
    paso_num += 1
    tiempos.start('10. Cerrar modal')
    close_movement_modal(driver)
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Modal de movimiento cerrado', 'Se cerró el detalle del movimiento y se regresó a la lista de resultados.', espera=1.0)
    paso_num += 1
    tiempos.start('11. Volver atrás')
    go_back(driver)
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Consolidado finalizado', 'Se regresó al home tras completar la consulta del consolidado.', espera=1.5)
    paso_num += 1
    print('\n✅ CONSOLIDADO CON BÚSQUEDA COMPLETADO EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('consolidado_ultimos_movimientos_varios_busqueda_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO: LOGIN + CONSOLIDADO CON BÚSQUEDA + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    tipo_cuenta = _input_cfg.get('tipo_cuenta', 'C. AHORRO')
    numero_cuenta = _input_cfg.get('numero_cuenta', '40-0-1189577-1')
    texto_movimiento = _input_cfg.get('texto_movimiento', 'transferencia Prueba 3')
    criterio = _input_cfg.get('criterio', '')
    tipo_movimiento = _input_cfg.get('tipo_movimiento', 'Todos')
    fecha_desde = _input_cfg.get('fecha_desde', '09/09/2026')
    fecha_hasta = _input_cfg.get('fecha_hasta', '13/09/2026')
    monto_movimiento = _input_cfg.get('monto_movimiento', None)
    signo_movimiento = _input_cfg.get('signo_movimiento', None)
    mes_referencia = _input_cfg.get('mes_referencia', 'Ago')
    anio_referencia = _input_cfg.get('anio_referencia', '2026')
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Consolidado_Busqueda')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f'🏦 Tipo cuenta: {tipo_cuenta}')
    if numero_cuenta:
        print(f'🏦 Número cuenta: {numero_cuenta}')
    print(f'📋 Tipo: {tipo_movimiento}')
    print(f'📅 Desde: {fecha_desde}')
    print(f'📅 Hasta: {fecha_hasta}')
    print(f'📝 Movimiento: {texto_movimiento}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Tipo de cuenta': tipo_cuenta, 'Número de cuenta': numero_cuenta or '(no especificado)', 'Tipo de movimiento': tipo_movimiento, 'Fecha desde': fecha_desde, 'Fecha hasta': fecha_hasta, 'Texto de movimiento (N/d)': texto_movimiento or '(no especificado)', 'Monto': str(monto_movimiento) if monto_movimiento else '(no especificado)', 'Signo': signo_movimiento or '(no especificado)'})
    login_ok = _input_cfg.get('login_ok', False)
    consolidado_ok = _input_cfg.get('consolidado_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            consolidado_ok = realizar_consolidado_busqueda(driver, tipo_cuenta=tipo_cuenta, numero_cuenta=numero_cuenta, criterio=criterio, tipo_movimiento=tipo_movimiento, fecha_desde=fecha_desde, fecha_hasta=fecha_hasta, texto_movimiento=texto_movimiento, monto_movimiento=monto_movimiento, signo_movimiento=signo_movimiento, mes_referencia=mes_referencia, anio_referencia=anio_referencia, reporte=reporte, tiempos=tiempos, paso_inicial=6)
            if consolidado_ok:
                print('\n🎉 CONSOLIDADO CON BÚSQUEDA EXITOSO!')
            else:
                print('\n❌ CONSOLIDADO CON BÚSQUEDA FALLIDO')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and consolidado_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login          : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Consolidado    : {('✅ OK' if consolidado_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

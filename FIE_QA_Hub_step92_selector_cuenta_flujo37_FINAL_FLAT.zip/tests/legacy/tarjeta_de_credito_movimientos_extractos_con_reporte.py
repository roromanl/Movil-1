"""
Flujo Extractos de Tarjeta de Crédito + reporte Word.
Pasos: Login → T. CRÉDITO → Movimientos (inferior) → Tab Extractos
       → Mes → Consultar → Cerrar PDF → Regresar → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import volver_atras_tc__109533fdac as volver_atras_tc, volver_home__71a629aeab as volver_home
from framework.common.ui_helpers import _esta_en_home as _esta_en_home, _seleccionar_opcion_case_insensitive__f21faf0807 as _seleccionar_opcion_case_insensitive

def ir_a_tarjeta_credito(driver, max_intentos=8):
    print('  📝 Navegando a T. CRÉDITO...')
    time.sleep(3)
    texto_objetivo = 'T. CRÉDITO'

    def _buscar_en_pantalla():
        try:
            tc = driver.find_element(AppiumBy.XPATH, f"//android.view.View[@content-desc='{texto_objetivo}']")
            tc.click()
            print('  ✅ Click en T. CRÉDITO (content-desc exacto)')
            time.sleep(3)
            return True
        except:
            pass
        try:
            tc = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{texto_objetivo}') and @clickable='true']")
            tc.click()
            print('  ✅ Click en T. CRÉDITO (content-desc contains)')
            time.sleep(3)
            return True
        except:
            pass
        try:
            tc = driver.find_element(AppiumBy.XPATH, f"//*[contains(translate(@content-desc, 'ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÑ.', 'abcdefghijklmnopqrstuvwxyzáéíóúñ.'), 't. crédito') and @clickable='true']")
            tc.click()
            print('  ✅ Click en T. CRÉDITO (case-insensitive)')
            time.sleep(3)
            return True
        except:
            pass
        try:
            tc = driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{texto_objetivo}') and @clickable='true']")
            tc.click()
            print('  ✅ Click en T. CRÉDITO (texto)')
            time.sleep(3)
            return True
        except:
            pass
        return False
    if _buscar_en_pantalla():
        return True
    for intento in range(max_intentos):
        try:
            if intento % 2 == 0:
                print(f'  🔄 Scroll horizontal IZQUIERDA {intento // 2 + 1}...')
                driver.swipe(900, 1000, 200, 1000, 500)
            else:
                print(f'  🔄 Scroll horizontal DERECHA {intento // 2 + 1}...')
                driver.swipe(200, 1000, 900, 1000, 500)
            time.sleep(0.6)
            if _buscar_en_pantalla():
                return True
        except:
            pass
    print('  ❌ Error al seleccionar T. CRÉDITO')
    try:
        print('  🔍 Elementos visibles:')
        elementos = driver.find_elements(AppiumBy.XPATH, "//*[@clickable='true' and @content-desc and string-length(@content-desc) > 3]")
        for e in elementos[:15]:
            desc = (e.get_attribute('content-desc') or '').replace('\n', ' | ')
            if len(desc) < 80:
                print(f'     - {desc}')
    except:
        pass
    return False

def seleccionar_movimientos_inferior(driver):
    print("  📝 Seleccionando 'Movimientos' (opción inferior)...")
    time.sleep(2)
    try:
        movimientos = driver.find_element(AppiumBy.ID, 'credit_card_tab_movements')
        movimientos.click()
        print("  ✅ Click en 'Movimientos' (ID tab)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        movimientos = driver.find_element(AppiumBy.XPATH, "//android.view.View[@content-desc='Movimientos' and @clickable='true']")
        movimientos.click()
        print("  ✅ Click en 'Movimientos' (content-desc)")
        time.sleep(3)
        return True
    except:
        pass
    if _seleccionar_opcion_case_insensitive(driver, 'Movimientos', timeout=5, debug=True):
        print("  ✅ Click en 'Movimientos' (case-insensitive)")
        time.sleep(3)
        return True
    print("  ❌ Error al seleccionar 'Movimientos'")
    return False

def seleccionar_tab_tarjeta_credito(driver, tab_name='Extractos'):
    print(f"  📝 Seleccionando tab: '{tab_name}'...")
    time.sleep(2)
    tabs_map = {'Detalle': 'credit_card_tab_detail', 'Movimientos': 'credit_card_tab_movements', 'Extractos': 'credit_card_tab_extracts'}
    if tab_name not in tabs_map:
        print(f"  ❌ Tab '{tab_name}' no válido. Opciones: Detalle, Movimientos, Extractos")
        return False
    resource_id = tabs_map[tab_name]
    try:
        tab = driver.find_element(AppiumBy.ID, resource_id)
        tab.click()
        print(f"  ✅ Click en tab '{tab_name}' (ID)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        tab = driver.find_element(AppiumBy.XPATH, f"//*[@resource-id='{resource_id}']")
        tab.click()
        print(f"  ✅ Click en tab '{tab_name}' (XPATH resource-id)")
        time.sleep(3)
        return True
    except:
        pass
    if _seleccionar_opcion_case_insensitive(driver, tab_name, timeout=5, debug=True):
        print(f"  ✅ Click en tab '{tab_name}' (case-insensitive)")
        time.sleep(3)
        return True
    print(f"  ❌ Error al seleccionar tab '{tab_name}'")
    return False

def seleccionar_extractos_tc(driver):
    """Selecciona el tab 'Extractos'."""
    return seleccionar_tab_tarjeta_credito(driver, 'Extractos')

def seleccionar_mes_extracto(driver, mes=None, gestion=None):
    print('  📝 Verificando mes del extracto...')
    time.sleep(2)
    mes_actual = None
    try:
        selector = driver.find_element(AppiumBy.XPATH, "//*[@clickable='true' and contains(@content-desc, '/') and string-length(@content-desc) = 7]")
        mes_actual = selector.get_attribute('content-desc') or ''
        print(f'  ℹ️ Mes preseleccionado: {mes_actual}')
    except:
        print('  ⚠️ No se pudo leer el mes preseleccionado')
    if not mes and (not gestion):
        if mes_actual:
            print(f'  ✅ Usando mes preseleccionado: {mes_actual}')
            print(f'  ℹ️ NO se abre el calendario (mes dinámico)')
            return True
        else:
            print('  ❌ No hay mes seleccionado y no se pidió uno específico')
            return False
    print(f'  📝 Se pidió cambiar a: {mes}/{gestion}')
    meses_map = {'ene': '01', 'feb': '02', 'mar': '03', 'abr': '04', 'may': '05', 'jun': '06', 'jul': '07', 'ago': '08', 'sep': '09', 'oct': '10', 'nov': '11', 'dic': '12'}
    if mes.isdigit():
        mes_num = mes.zfill(2)
    else:
        mes_num = meses_map.get(mes.lower()[:3], None)
    if not mes_num:
        print(f"  ❌ Mes '{mes}' no válido")
        return False
    mes_formato = f'{mes_num}/{gestion}'
    try:
        selector.click()
        print(f'  ✅ Click en selector de mes')
        time.sleep(3)
    except:
        print('  ❌ No se pudo abrir el selector de mes')
        return False
    try:
        opcion = driver.find_element(AppiumBy.XPATH, f"//*[@content-desc='{mes_formato}' and @clickable='true']")
        opcion.click()
        print(f"  ✅ Mes '{mes_formato}' seleccionado")
        time.sleep(2)
        return True
    except:
        pass
    try:
        opcion = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{mes_formato}') and @clickable='true']")
        opcion.click()
        print(f"  ✅ Mes '{mes_formato}' seleccionado (contains)")
        time.sleep(2)
        return True
    except:
        pass
    try:
        opcion = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{mes}') and @clickable='true']")
        opcion.click()
        print(f"  ✅ Mes '{mes}' seleccionado (por nombre)")
        time.sleep(2)
        return True
    except:
        pass
    print(f"  ❌ No se pudo seleccionar el mes '{mes}/{gestion}'")
    return False

def click_consultar_extracto(driver):
    """Click en 'Consultar' con 3 estrategias."""
    print("  📝 Click en 'Consultar'...")
    time.sleep(2)
    try:
        consultar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Consultar']")
        consultar.click()
        print("  ✅ Click en 'Consultar' (content-desc)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        consultar = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Consultar') and @clickable='true']")
        consultar.click()
        print("  ✅ Click en 'Consultar' (texto)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        consultar = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Consultar') and @clickable='true']")
        consultar.click()
        print("  ✅ Click en 'Consultar' (contains)")
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al clickear Consultar: {e}')
        return False

def cerrar_pdf_extracto(driver):
    print('  📝 Cerrando PDF/visor de extracto...')
    time.sleep(3)
    try:
        cerrar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Cerrar']")
        cerrar.click()
        print('  ✅ Click en Cerrar (content-desc)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        regresar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Regresar']")
        regresar.click()
        print('  ✅ Click en Regresar')
        time.sleep(2)
        return True
    except:
        pass
    try:
        listo = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Listo']")
        listo.click()
        print('  ✅ Click en Listo')
        time.sleep(2)
        return True
    except:
        pass
    try:
        aceptar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Aceptar']")
        aceptar.click()
        print('  ✅ Click en Aceptar')
        time.sleep(2)
        return True
    except:
        pass
    try:
        driver.back()
        print('  ✅ Back ejecutado')
        time.sleep(2)
        return True
    except Exception as e:
        print(f'  ❌ Error al cerrar PDF: {e}')
        return False

def realizar_extractos_tarjeta_credito(driver, mes=None, gestion=None, tiempos=None, reporte=None, paso_inicial=6):
    print(f'\n📋 INICIANDO EXTRACTOS DE TARJETA DE CRÉDITO')
    if mes and gestion:
        print(f'📅 Mes solicitado: {mes} - Gestión: {gestion}')
    else:
        print(f'📅 Mes: (dinámico - usa el preseleccionado)')
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Ir a T. CRÉDITO')
    if not ir_a_tarjeta_credito(driver):
        print('  ❌ Error al ir a T. CRÉDITO')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla T. CRÉDITO', 'Se accedió a la sección de Tarjeta de Crédito desde el home.', espera=2.0)
    paso_num += 1
    print('  📝 Esperando carga de pantalla de T. CRÉDITO...')
    time.sleep(3)
    tiempos.start('2. Movimientos inferior')
    if not seleccionar_movimientos_inferior(driver):
        print("  ❌ Error al seleccionar 'Movimientos'")
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Opción Movimientos (inferior)', "Se seleccionó la opción 'Movimientos' en la parte inferior de la pantalla de Tarjeta de Crédito.", espera=1.5)
    paso_num += 1
    print('  📝 Esperando carga de movimientos...')
    time.sleep(3)
    tiempos.start('3. Tab Extractos')
    if not seleccionar_extractos_tc(driver):
        print('  ❌ Error al seleccionar Extractos')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Tab Extractos seleccionado', "Se seleccionó el tab 'Extractos' en la pantalla de Tarjeta de Crédito.", espera=1.5)
    paso_num += 1
    print('  📝 Esperando carga de extractos...')
    time.sleep(3)
    tiempos.start('4. Seleccionar mes')
    if not seleccionar_mes_extracto(driver, mes, gestion):
        print('  ❌ Error al seleccionar mes')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        if mes and gestion:
            desc_mes = f'Se seleccionó el mes/gestion: {mes}/{gestion}.'
        else:
            desc_mes = 'Se utilizó el mes preseleccionado dinámicamente por la aplicación.'
        reporte.capturar_paso(paso_num, f'Mes del extracto', f'{desc_mes}', espera=1.5)
    paso_num += 1
    time.sleep(2)
    tiempos.start('5. Consultar')
    if not click_consultar_extracto(driver):
        print('  ❌ Error al clickear Consultar')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Click en Consultar', "Se hizo clic en 'Consultar' para generar el extracto del mes seleccionado.", espera=2.0)
    paso_num += 1
    tiempos.start('6. Cerrar PDF')
    if not cerrar_pdf_extracto(driver):
        print('  ⚠️ Error al cerrar PDF, continuando...')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'PDF del extracto cerrado', 'Se cerró el visor del PDF del extracto.', espera=1.5)
    paso_num += 1
    tiempos.start('7. Volver atrás')
    if not volver_atras_tc(driver):
        print('  ⚠️ Error al volver atrás')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Regreso a pantalla anterior', 'Se regresó a la pantalla anterior.', espera=1.0)
    paso_num += 1
    tiempos.start('8. Volver al home')
    if not volver_home(driver):
        print('  ⚠️ Error al volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Extractos TC finalizado', 'Se regresó exitosamente al home. El flujo de extractos de tarjeta de crédito ha terminado.', espera=1.5)
    paso_num += 1
    print('\n✅ EXTRACTOS DE TARJETA DE CRÉDITO COMPLETADO EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('tarjeta_de_credito_movimientos_extractos_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO COMPLETO: LOGIN + EXTRACTOS DE TARJETA DE CRÉDITO + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    mes = _input_cfg.get('mes', 'Ago')
    gestion = _input_cfg.get('gestion', 2026)
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Extractos_Tarjeta_Credito')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f'📅 Mes: {mes} - Gestión: {gestion}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Mes': mes or 'Dinámico', 'Gestión': gestion or 'Dinámico'})
    login_ok = _input_cfg.get('login_ok', False)
    extractos_ok = _input_cfg.get('extractos_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            extractos_ok = realizar_extractos_tarjeta_credito(driver, mes=mes, gestion=gestion, tiempos=tiempos, reporte=reporte, paso_inicial=6)
            if extractos_ok:
                print('\n🎉 EXTRACTOS DE TARJETA DE CRÉDITO EXITOSO!')
            else:
                print('\n❌ EXTRACTOS DE TARJETA DE CRÉDITO FALLIDO')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and extractos_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login          : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Extractos      : {('✅ OK' if extractos_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

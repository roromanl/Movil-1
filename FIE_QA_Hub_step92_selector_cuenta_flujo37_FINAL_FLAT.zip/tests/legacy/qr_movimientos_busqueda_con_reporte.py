"""
Flujo Movimientos QR con Búsqueda + reporte Word.
Pasos: Login → QR → Movimientos QR → Buscar (formulario) → Criterio → Tipo
       → Fechas Desde/Hasta → Ejecutar búsqueda → Seleccionar movimiento
       → Cerrar modal → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import re
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import go_back_movimientos_qr
from framework.common.ui_helpers import _esta_en_home as _esta_en_home

def click_qr_menu(driver, timeout=10):
    print('  📝 Click en menú QR...')
    wait_t = time.time() + timeout
    while time.time() < wait_t:
        try:
            qr_btn = driver.find_element(AppiumBy.ID, 'home_btn_qr')
            try:
                hijo = qr_btn.find_element(AppiumBy.XPATH, ".//android.widget.Button[@content-desc='QR']")
                hijo.click()
                print('  ✅ Click en QR (hijo de home_btn_qr)')
                time.sleep(3)
                return True
            except:
                qr_btn.click()
                print('  ✅ Click en QR (home_btn_qr)')
                time.sleep(3)
                return True
        except:
            time.sleep(0.5)
    try:
        qr_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='QR' and @clickable='true']")
        qr_btn.click()
        print('  ✅ Click en QR (content-desc clickable)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        qr_btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='QR' and @clickable='true']")
        qr_btn.click()
        print('  ✅ Click en QR (View clickable)')
        time.sleep(3)
        return True
    except:
        pass
    print('  ❌ Error al clickear QR')
    return False

def select_movimientos_qr(driver):
    print('  📝 Seleccionando Movimientos QR...')
    time.sleep(2)
    try:
        movimientos_btn = driver.find_element(AppiumBy.ID, 'qr_btn_movimientos')
        movimientos_btn.click()
        print('  ✅ Click en Movimientos QR (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        movimientos_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Movimientos QR\nMovimientos QR']")
        movimientos_btn.click()
        print('  ✅ Click en Movimientos QR (content-desc exacto)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        movimientos_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Movimientos QR')]")
        movimientos_btn.click()
        print('  ✅ Click en Movimientos QR (content-desc parcial)')
        time.sleep(3)
        return True
    except:
        pass
    print('  ❌ Error al clickear Movimientos QR')
    return False

def click_buscar_movimientos_qr(driver):
    print('  📝 Click en Buscar (abrir formulario)...')
    time.sleep(2)
    try:
        buscar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Buscar' and @clickable='true']")
        buscar_btn.click()
        print('  ✅ Click en Buscar (abrir)')
        time.sleep(3)
        return True
    except:
        try:
            buscar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Buscar') and @clickable='true']")
            buscar_btn.click()
            print('  ✅ Click en Buscar (abrir - texto)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Buscar: {e}')
            return False

def fill_criterio_busqueda_qr(driver, criterio=''):
    if not criterio:
        print('  ℹ️ Criterio vacío - saltando campo')
        return True
    print(f'  📝 Ingresando criterio: {criterio}...')
    time.sleep(2)
    try:
        criterio_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='Buscar por criterio']")
        criterio_input.click()
        time.sleep(1)
        criterio_input.clear()
        criterio_input.send_keys(criterio)
        print(f'  ✅ Criterio ingresado: {criterio}')
        try:
            driver.hide_keyboard()
            time.sleep(1)
        except:
            pass
        return True
    except:
        try:
            criterio_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[contains(@hint, 'Buscar')]")
            criterio_input.click()
            time.sleep(1)
            criterio_input.clear()
            criterio_input.send_keys(criterio)
            print(f'  ✅ Criterio ingresado: {criterio}')
            try:
                driver.hide_keyboard()
                time.sleep(1)
            except:
                pass
            return True
        except Exception as e:
            print(f'  ❌ Error al ingresar criterio: {e}')
            return False

def select_tipo_movimiento_qr(driver, tipo='Todos'):
    print(f'  📝 Seleccionando tipo: {tipo}...')
    time.sleep(2)
    try:
        driver.swipe(500, 800, 500, 500, 500)
        time.sleep(1)
    except:
        pass
    try:
        tipo_field = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Todos' and @clickable='true']")
        tipo_field.click()
        print("  ✅ Click en 'Todos' (desplegar combo)")
        time.sleep(2)
    except:
        try:
            tipo_field = driver.find_element(AppiumBy.XPATH, "//*[@text='Todos' and @clickable='true']")
            tipo_field.click()
            print("  ✅ Click en 'Todos' (desplegar combo - texto)")
            time.sleep(2)
        except Exception as e:
            print(f"  ❌ No se encontró el campo 'Todos': {e}")
            return False
    time.sleep(2)
    try:
        opcion = driver.find_element(AppiumBy.XPATH, f"//*[@content-desc='{tipo}' and @clickable='true']")
        opcion.click()
        print(f'  ✅ Tipo seleccionado: {tipo}')
        time.sleep(1)
        return True
    except:
        try:
            opcion = driver.find_element(AppiumBy.XPATH, f"//*[@text='{tipo}' and @clickable='true']")
            opcion.click()
            print(f'  ✅ Tipo seleccionado: {tipo} (texto)')
            time.sleep(1)
            return True
        except:
            try:
                opcion = driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{tipo}') and @clickable='true']")
                opcion.click()
                print(f'  ✅ Tipo seleccionado: {tipo} (contains)')
                time.sleep(1)
                return True
            except Exception as e:
                print(f"  ❌ No se encontró la opción '{tipo}': {e}")
                return False

def select_fecha(driver, campo, fecha):
    print(f'  📝 Seleccionando fecha {campo}: {fecha}...')
    time.sleep(2)
    dia, mes, anio = fecha.split('/')
    dia_int = int(dia)
    mes_int = int(mes)
    anio_int = int(anio)
    meses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre']
    mes_nombre = meses[mes_int - 1]
    try:
        botones = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Elegir en calendario']")
        print(f"  🔍 Encontrados {len(botones)} botones 'Elegir en calendario'")
        if campo == 'Desde':
            if len(botones) > 0:
                botones[0].click()
                print(f"  ✅ Click en 'Elegir en calendario' para Desde")
            else:
                print(f'  ❌ No se encontró el botón para Desde')
                return False
        elif len(botones) > 1:
            botones[1].click()
            print(f"  ✅ Click en 'Elegir en calendario' para Hasta")
        else:
            print(f'  ❌ No se encontró el botón para Hasta')
            return False
        time.sleep(2)
    except Exception as e:
        print(f'  ❌ Error al buscar botones: {e}')
        return False
    time.sleep(3)

    def obtener_mes_actual():
        try:
            titulo_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Enero') or contains(@content-desc, 'Febrero') or contains(@content-desc, 'Marzo') or contains(@content-desc, 'Abril') or contains(@content-desc, 'Mayo') or contains(@content-desc, 'Junio') or contains(@content-desc, 'Julio') or contains(@content-desc, 'Agosto') or contains(@content-desc, 'Septiembre') or contains(@content-desc, 'Octubre') or contains(@content-desc, 'Noviembre') or contains(@content-desc, 'Diciembre')]")
            return titulo_btn.get_attribute('content-desc') or ''
        except:
            return None
    encontrado = False
    for intento in range(24):
        titulo_actual = obtener_mes_actual()
        print(f'  📅 Mes actual: {titulo_actual}')
        if titulo_actual and mes_nombre in titulo_actual and (str(anio_int) in titulo_actual):
            print(f'  ✅ Mes correcto: {mes_nombre} {anio_int}')
            encontrado = True
            break
        try:
            mes_actual = None
            for i, nombre_mes in enumerate(meses, 1):
                if nombre_mes in titulo_actual:
                    mes_actual = i
                    break
            anio_actual = None
            años = re.findall('\\d{4}', titulo_actual)
            if años:
                anio_actual = int(años[0])
            if mes_actual and anio_actual:
                diff_meses = (anio_int - anio_actual) * 12 + (mes_int - mes_actual)
                print(f'  📊 Diferencia de meses: {diff_meses}')
                if diff_meses > 0:
                    try:
                        siguiente_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Mes siguiente' and @clickable='true']")
                        siguiente_btn.click()
                        print(f'  🔄 Siguiente mes...')
                        time.sleep(1)
                    except:
                        print(f'  ⚠️ No se pudo navegar')
                        break
                elif diff_meses < 0:
                    try:
                        anterior_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Mes anterior' and @clickable='true']")
                        anterior_btn.click()
                        print(f'  🔄 Mes anterior...')
                        time.sleep(1)
                    except:
                        print(f'  ⚠️ No se pudo navegar')
                        break
                else:
                    encontrado = True
                    break
            else:
                print(f'  ⚠️ No se pudo determinar mes/año')
                break
        except Exception as e:
            print(f'  ⚠️ Error: {e}')
            break
    if not encontrado:
        print(f'  ❌ No se encontró el mes {mes_nombre} {anio_int}')
        try:
            driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Cancelar']").click()
            time.sleep(1)
        except:
            pass
        return False
    print(f'  🔄 Haciendo scroll para días...')
    try:
        driver.swipe(500, 1500, 500, 600, 500)
        time.sleep(1)
    except:
        pass
    time.sleep(1)
    seleccionado = False
    estrategias = [lambda: driver.find_element(AppiumBy.XPATH, f"//*[@text='{dia_int}' and @clickable='true']"), lambda: driver.find_element(AppiumBy.XPATH, f"//*[@content-desc='{dia_int}' and @clickable='true']"), lambda: driver.find_element(AppiumBy.XPATH, f"//*[@text='{dia}' and @clickable='true']"), lambda: driver.find_element(AppiumBy.XPATH, f"//*[@content-desc='{dia}' and @clickable='true']"), lambda: driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{dia_int}') and @clickable='true']"), lambda: driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{dia_int}') and @clickable='true']")]
    for i, estrategia in enumerate(estrategias, 1):
        try:
            dia_btn = estrategia()
            if dia_btn.is_displayed() and dia_btn.is_enabled():
                dia_btn.click()
                print(f'  ✅ Día {dia} seleccionado (estrategia {i})')
                seleccionado = True
                break
        except:
            pass
    if not seleccionado:
        try:
            dias = driver.find_elements(AppiumBy.XPATH, "//*[@clickable='true' and @content-desc and string-length(@content-desc) <= 2]")
            for d in dias:
                desc = d.get_attribute('content-desc') or ''
                if desc.isdigit() and int(desc) == dia_int:
                    d.click()
                    print(f'  ✅ Día {dia} seleccionado (búsqueda)')
                    seleccionado = True
                    break
        except:
            pass
    if not seleccionado:
        print(f'  ❌ No se pudo seleccionar el día {dia}')
        try:
            driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Cancelar']").click()
            time.sleep(1)
        except:
            pass
        return False
    time.sleep(1)
    try:
        aceptar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Aceptar']")
        if aceptar_btn.is_displayed() and aceptar_btn.is_enabled():
            aceptar_btn.click()
            print(f'  ✅ Fecha {campo} confirmada')
            time.sleep(2)
            return True
    except:
        try:
            aceptar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Aceptar') and @clickable='true']")
            aceptar_btn.click()
            print(f'  ✅ Fecha {campo} confirmada (texto)')
            time.sleep(2)
            return True
        except Exception as e:
            print(f'  ❌ No se encontró Aceptar: {e}')
            return False

def click_buscar_ejecutar_qr(driver):
    print('  📝 Ejecutando búsqueda...')
    time.sleep(2)
    try:
        driver.swipe(500, 1800, 500, 1200, 500)
        time.sleep(1)
    except:
        pass
    try:
        buscar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Buscar' and @clickable='true']")
        bounds = buscar_btn.get_attribute('bounds') or ''
        if '2022' in bounds and '2142' in bounds:
            buscar_btn.click()
            print('  ✅ Click en Buscar (ejecutar - botón de abajo)')
            time.sleep(3)
            return True
        else:
            print('  ⚠️ Encontrado el botón de arriba, buscando el de abajo...')
            botones = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Buscar' and @clickable='true']")
            if len(botones) >= 2:
                botones[1].click()
                print('  ✅ Click en Buscar (ejecutar - segundo botón)')
                time.sleep(3)
                return True
    except:
        pass
    try:
        driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='90 Días']")
        buscar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='90 Días']/following-sibling::android.widget.Button[@content-desc='Buscar']")
        buscar_btn.click()
        print('  ✅ Click en Buscar (ejecutar - después de 90 Días)')
        time.sleep(3)
        return True
    except:
        pass
    print('  ❌ Error al ejecutar búsqueda')
    return False

def buscar_y_seleccionar_movimiento_qr(driver, concepto=None, fecha=None, monto=None, index=0, max_scrolls=10, timeout=15):
    print(f'  📝 Buscando movimiento QR en resultados...')
    if concepto:
        print(f'     • Concepto: {concepto}')
    if fecha:
        print(f'     • Fecha: {fecha}')
    if monto:
        print(f'     • Monto: {monto}')
    if not (concepto or fecha or monto):
        print(f'     • Índice: {index + 1}')
    time.sleep(2)
    xpath_parts = ["//android.widget.Button[(contains(@resource-id, 'shared_tile_movement') or contains(@resource-id, 'qr_btn_movimiento_'))"]
    if concepto:
        xpath_parts.append(f" and contains(@content-desc, '{concepto}')")
    if fecha:
        xpath_parts.append(f" and contains(@content-desc, '{fecha}')")
    if monto:
        xpath_parts.append(f" and contains(@content-desc, '{monto}')")
    xpath_parts.append(']')
    xpath = ''.join(xpath_parts)
    print(f'     🔍 XPATH: {xpath[:140]}...')
    try:
        boton = driver.find_element(AppiumBy.XPATH, xpath)
        desc = boton.get_attribute('content-desc')
        print(f'  ✅ Movimiento encontrado: {desc!r}')
        driver._last_movimiento_desc = desc
        boton.click()
        print('  ✅ Click en movimiento')
        time.sleep(3)
        return True
    except:
        pass
    print(f'  🔄 Buscando con scroll hacia abajo (máx {max_scrolls})...')
    for i in range(max_scrolls):
        try:
            driver.swipe(500, 1500, 500, 600, 500)
            time.sleep(0.8)
        except:
            pass
        try:
            boton = driver.find_element(AppiumBy.XPATH, xpath)
            desc = boton.get_attribute('content-desc')
            print(f'  ✅ Movimiento encontrado (scroll {i + 1}): {desc!r}')
            driver._last_movimiento_desc = desc
            boton.click()
            print('  ✅ Click en movimiento')
            time.sleep(3)
            return True
        except:
            continue
    print('  🔄 Buscando con scroll hacia arriba...')
    for i in range(max_scrolls):
        try:
            driver.swipe(500, 600, 500, 1500, 500)
            time.sleep(0.8)
        except:
            pass
        try:
            boton = driver.find_element(AppiumBy.XPATH, xpath)
            desc = boton.get_attribute('content-desc')
            print(f'  ✅ Movimiento encontrado (scroll up {i + 1}): {desc!r}')
            driver._last_movimiento_desc = desc
            boton.click()
            print('  ✅ Click en movimiento')
            time.sleep(3)
            return True
        except:
            continue
    if not (concepto or fecha or monto):
        print(f'  ⚠️ No se encontró por scroll. Intentando por índice...')
        try:
            movimientos = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[(contains(@resource-id, 'shared_tile_movement') or contains(@resource-id, 'qr_btn_movimiento_'))]")
            print(f'     • Movimientos visibles: {len(movimientos)}')
            if len(movimientos) > index:
                desc = movimientos[index].get_attribute('content-desc')
                driver._last_movimiento_desc = desc
                movimientos[index].click()
                print(f'  ✅ Movimiento #{index + 1} seleccionado')
                time.sleep(3)
                return True
            elif movimientos:
                desc = movimientos[-1].get_attribute('content-desc')
                driver._last_movimiento_desc = desc
                movimientos[-1].click()
                print(f'  ✅ Último movimiento seleccionado')
                time.sleep(3)
                return True
        except:
            pass
    print('  ❌ No se encontró el movimiento solicitado')
    return False

def close_movement_qr_modal(driver):
    print('  📝 Cerrando modal de movimiento QR...')
    time.sleep(3)
    try:
        cerrar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Cerrar']")
        cerrar_btn.click()
        print('  ✅ Click en Cerrar')
        time.sleep(2)
        return True
    except:
        pass
    try:
        cerrar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Cerrar') and @clickable='true']")
        cerrar_btn.click()
        print('  ✅ Click en Cerrar (texto)')
        time.sleep(2)
        return True
    except:
        try:
            driver.back()
            time.sleep(2)
            print('  ✅ Back ejecutado')
            return True
        except:
            return False

def realizar_movimientos_qr_busqueda(driver, tipo_movimiento='Todos', fecha_desde=None, fecha_hasta=None, mov_concepto='', mov_monto='', mov_signo='', reporte=None, tiempos=None, paso_inicial=6):
    def _nf(v):
        x=str(v or '').strip().replace('-', '/');q=x.split('/')
        if len(q)!=3:return x
        if len(q[0])==4:y,m,d=q
        else:d,m,y=q
        return f'{int(d):02d}/{int(m):02d}/{int(y):04d}'
    fecha_desde=_nf(fecha_desde); fecha_hasta=_nf(fecha_hasta)
    criterio=''
    print(f'\n📱 INICIANDO MOVIMIENTOS QR CON BÚSQUEDA')
    print(f"🔍 Criterio: '{criterio}'" if criterio else '🔍 Sin criterio')
    print(f'📋 Tipo: {tipo_movimiento}')
    print(f'📅 Desde: {fecha_desde}')
    print(f'📅 Hasta: {fecha_hasta}')
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Click en menú QR')
    if not click_qr_menu(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Menú QR abierto', 'Se accedió al menú QR desde el home.', espera=1.5)
    paso_num += 1
    tiempos.start('2. Movimientos QR')
    if not select_movimientos_qr(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla de Movimientos QR', 'Se accedió a la lista de Movimientos QR.', espera=1.5)
    paso_num += 1
    tiempos.start('3. Abrir formulario Buscar')
    if not click_buscar_movimientos_qr(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Formulario de búsqueda abierto', 'Se abrió el formulario con los filtros: criterio, tipo de movimiento y fechas.', espera=1.5)
    paso_num += 1
    if criterio:
        tiempos.start('4. Criterio búsqueda')
        if not fill_criterio_busqueda_qr(driver, criterio):
            print('  ⚠️ Error al llenar criterio')
        tiempos.stop()
        time.sleep(2)
        if reporte:
            reporte.capturar_paso(paso_num, f"Criterio: '{criterio}'", f"Se ingresó '{criterio}' en el campo de criterio de búsqueda.", espera=1.0)
        paso_num += 1
    tiempos.start('5. Tipo movimiento')
    if not select_tipo_movimiento_qr(driver, tipo_movimiento):
        print('  ⚠️ Error al seleccionar tipo')
    tiempos.stop()
    time.sleep(2)
    if reporte:
        reporte.capturar_paso(paso_num, f"Tipo: '{tipo_movimiento}'", f"Se seleccionó el tipo de movimiento '{tipo_movimiento}'.", espera=1.0)
    paso_num += 1
    if fecha_desde:
        tiempos.start('6. Fecha Desde')
        if not select_fecha(driver, 'Desde', fecha_desde):
            print('  ⚠️ Error al seleccionar fecha Desde')
        tiempos.stop()
        if reporte:
            reporte.capturar_paso(paso_num, f'Fecha desde: {fecha_desde}', f'Se seleccionó la fecha Desde = {fecha_desde} en el calendario.', espera=1.0)
        paso_num += 1
    if fecha_hasta:
        tiempos.start('7. Fecha Hasta')
        if not select_fecha(driver, 'Hasta', fecha_hasta):
            print('  ⚠️ Error al seleccionar fecha Hasta')
        tiempos.stop()
        if reporte:
            reporte.capturar_paso(paso_num, f'Fecha hasta: {fecha_hasta}', f'Se seleccionó la fecha Hasta = {fecha_hasta} en el calendario.', espera=1.0)
        paso_num += 1
    tiempos.start('8. Ejecutar búsqueda')
    if not click_buscar_ejecutar_qr(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Búsqueda ejecutada', 'Se ejecutó la búsqueda. Se muestra la lista de Movimientos QR según los filtros.', espera=2.0)
    paso_num += 1
    tiempos.start('9. Seleccionar movimiento')
    mov_ok = buscar_y_seleccionar_movimiento_qr(driver, concepto=mov_concepto, fecha=None, monto=((str(mov_signo)+str(mov_monto)) if mov_signo and mov_monto else mov_monto), index=0)
    tiempos.stop()
    if reporte:
        if mov_ok:
            desc_mov = getattr(driver, '_last_movimiento_desc', '')
            reporte.capturar_paso(paso_num, 'Movimiento QR seleccionado', f'Se seleccionó el movimiento. Detalle: {desc_mov[:120]}', espera=2.0)
        else:
            reporte.capturar_paso(paso_num, 'Movimiento QR NO encontrado', 'No se encontró ningún movimiento QR con los criterios especificados.', espera=1.0)
    paso_num += 1
    if not mov_ok:
        print('  ⚠️ No se seleccionó ningún movimiento QR')
    tiempos.start('10. Cerrar modal')
    close_movement_qr_modal(driver)
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Modal de movimiento cerrado', 'Se cerró el detalle del movimiento QR y se regresó a la lista de resultados.', espera=1.0)
    paso_num += 1
    tiempos.start('11. Volver al home')
    if not go_back_movimientos_qr(driver):
        print('  ⚠️ No se pudo volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Movimientos QR finalizado', 'Se regresó exitosamente al home. El flujo de Movimientos QR con búsqueda ha terminado.', espera=1.5)
    print('\n✅ MOVIMIENTOS QR CON BÚSQUEDA COMPLETADOS EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('qr_movimientos_busqueda_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO: LOGIN + MOVIMIENTOS QR CON BÚSQUEDA + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    criterio = _input_cfg.get('criterio', '')
    tipo_movimiento = _input_cfg.get('tipo_movimiento', 'Todos')
    fecha_desde = _input_cfg.get('fecha_desde', '01/08/2026')
    fecha_hasta = _input_cfg.get('fecha_hasta', '17/09/2026')
    MOV_CONCEPTO = _input_cfg.get('MOV_CONCEPTO', None)
    MOV_FECHA = _input_cfg.get('MOV_FECHA', None)
    MOV_MONTO = _input_cfg.get('MOV_MONTO', None)
    MOV_INDEX = _input_cfg.get('MOV_INDEX', 0)
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Movimientos_QR_Busqueda')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f"🔍 Criterio busqueda: '{criterio}'" if criterio else '🔍 Sin criterio')
    print(f'📋 Tipo: {tipo_movimiento}')
    print(f'📅 Desde: {fecha_desde}')
    print(f'📅 Hasta: {fecha_hasta}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Criterio de búsqueda': criterio or '(vacío)', 'Tipo de movimiento': tipo_movimiento, 'Fecha desde': fecha_desde, 'Fecha hasta': fecha_hasta, 'Concepto del movimiento': MOV_CONCEPTO or '(no especificado)', 'Fecha del movimiento': MOV_FECHA or '(no especificada)', 'Monto del movimiento': MOV_MONTO or '(no especificado)', 'Índice fallback': MOV_INDEX})
    login_ok = _input_cfg.get('login_ok', False)
    movimientos_ok = _input_cfg.get('movimientos_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            movimientos_ok = realizar_movimientos_qr_busqueda(driver, criterio=criterio, tipo_movimiento=tipo_movimiento, fecha_desde=fecha_desde, fecha_hasta=fecha_hasta, mov_concepto=MOV_CONCEPTO, mov_fecha=MOV_FECHA, mov_monto=MOV_MONTO, mov_index=MOV_INDEX, reporte=reporte, tiempos=tiempos, paso_inicial=6)
            if movimientos_ok:
                print('\n🎉 MOVIMIENTOS QR CON BÚSQUEDA EXITOSO!')
            else:
                print('\n❌ MOVIMIENTOS QR CON BÚSQUEDA FALLIDO')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and movimientos_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login          : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Movimientos QR : {('✅ OK' if movimientos_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

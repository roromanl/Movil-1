"""
Flujo Transferencia a Nuevo Beneficiario + reporte Word.
Pasos: Login → Transferir → Nuevo beneficiario → Banco destino
       → Datos beneficiario (1) → Datos beneficiario (2) → Modal éxito
       → Cuenta origen → Monto → Concepto → Continuar → Confirmar → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import go_back_home__c4c30af8eb as go_back_home
from framework.common.ui_helpers import _esta_en_home as _esta_en_home

def navigate_to_transfer(driver):
    print('  📝 Navegando a Transferencias...')
    time.sleep(2)
    try:
        transfer_btn = driver.find_element(AppiumBy.ID, 'home_btn_transferir')
        transfer_btn.click()
        print('  ✅ Click en Transferir (ID)')
        time.sleep(3)
        return True
    except:
        try:
            transfer_btn = driver.find_element(AppiumBy.ACCESSIBILITY_ID, 'Transferir')
            transfer_btn.click()
            print('  ✅ Click en Transferir (Accessibility)')
            time.sleep(3)
            return True
        except:
            try:
                transfer_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Transferir') or contains(@content-desc, 'Transferir')]")
                transfer_btn.click()
                print('  ✅ Click en Transferir (XPATH)')
                time.sleep(3)
                return True
            except Exception as e:
                print(f'  ❌ Error al navegar a transferencias: {e}')
                return False

def click_nuevo_beneficiario(driver):
    print('  📝 Click en Nuevo Beneficiario...')
    time.sleep(4)
    try:
        nuevo_btn = driver.find_element(AppiumBy.ID, 'transfers_btn_new_beneficiary')
        nuevo_btn.click()
        print('  ✅ Click en Nuevo Beneficiario (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        nuevo_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Nuevo beneficiario' and @clickable='true']")
        nuevo_btn.click()
        print('  ✅ Click en Nuevo Beneficiario (content-desc)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        nuevo_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Nuevo beneficiario') and @clickable='true']")
        nuevo_btn.click()
        print('  ✅ Click en Nuevo Beneficiario (texto)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al clickear Nuevo Beneficiario: {e}')
        return False

def buscar_y_seleccionar_banco_fie(driver):
    """Busca FIE en transfers_bank_search, ejecuta búsqueda y selecciona el primer resultado."""
    print("  📝 Buscando banco por texto fijo 'FIE'...")
    try:
        campo=driver.find_element(AppiumBy.ID,'transfers_bank_search')
    except Exception:
        campo=driver.find_element(AppiumBy.XPATH,"//android.widget.EditText[@hint='Buscar']")
    campo.click();campo.clear();campo.send_keys('FIE');time.sleep(.5)
    # Lupa: primero acción Search del teclado Android; fallback Enter.
    try: driver.execute_script('mobile: performEditorAction', {'action':'search'}); print('  ✅ Lupa/Search ejecutada')
    except Exception:
        try: driver.press_keycode(66); print('  ✅ Búsqueda ejecutada con Enter')
        except Exception: pass
    time.sleep(1.2)
    resultados=driver.find_elements(AppiumBy.XPATH,"//android.widget.Button[starts-with(@resource-id,'transfers_bank_item_') and @clickable='true']")
    if not resultados:
        resultados=driver.find_elements(AppiumBy.XPATH,"//android.widget.Button[@clickable='true' and contains(@content-desc,'FIE')]")
    if not resultados:
        print('  ❌ No se encontraron bancos después de filtrar FIE');return False
    desc=resultados[0].get_attribute('content-desc') or '';resultados[0].click();time.sleep(1.5)
    print(f"  ✅ Primer banco filtrado seleccionado: {desc.replace(chr(10),' | ')}");return True

def completar_alta_beneficiario(driver, tipo_cuenta, cuenta_destino):
    """Selecciona tipo, ingresa cuenta destino, Continuar y Confirmar transacción."""
    mapping={'Cuenta corriente':'Cuenta corriente','Caja de Ahorro':'Cuenta de ahorros'}
    opcion=mapping.get(str(tipo_cuenta),str(tipo_cuenta))
    print(f'  📝 Tipo cuenta front={tipo_cuenta} -> app={opcion}')
    try:
        driver.find_element(AppiumBy.XPATH,"//*[@content-desc='Tipo de cuenta' and @clickable='true']").click();time.sleep(.5)
        opciones=driver.find_elements(AppiumBy.XPATH,f"//*[@content-desc='{opcion}' and @clickable='true']")
        if not opciones: print(f'  ❌ No se encontró tipo de cuenta {opcion}');return False
        opciones[0].click();time.sleep(.5)
        cuenta=driver.find_element(AppiumBy.XPATH,"//android.widget.EditText[@hint='Número de cuenta']")
        cuenta.click();cuenta.clear();cuenta.send_keys(str(cuenta_destino));time.sleep(.4)
        try:driver.hide_keyboard()
        except Exception:pass
        driver.find_element(AppiumBy.XPATH,"//android.widget.Button[@content-desc='Continuar' and @clickable='true']").click();time.sleep(1.5)
        # Pantalla Nuevo beneficiario: el botón está al pie (XML observado: bounds [194,2127][886,2232]).
        # Esperar a que cargue/complete OTP y localizar por content-desc, sin exigir clickable en el XPath.
        from selenium.webdriver.support.ui import WebDriverWait
        from selenium.webdriver.support import expected_conditions as EC
        xpath_confirmar = "//android.widget.Button[@content-desc='Confirmar transacción']"
        try:
            boton = WebDriverWait(driver, 15).until(EC.presence_of_element_located((AppiumBy.XPATH, xpath_confirmar)))
        except Exception:
            candidatos = driver.find_elements(AppiumBy.XPATH, "//*[@content-desc='Confirmar transacción']")
            if not candidatos:
                print('  ❌ No se encontró Confirmar transacción tras esperar 15 s')
                return False
            boton = candidatos[0]
        try:
            boton.click()
        except Exception:
            # Flutter/Appium puede exponer el nodo pero fallar el click nativo; usar el centro del bounds real.
            r = boton.rect
            driver.execute_script('mobile: clickGesture', {
                'x': int(r['x'] + r['width']/2),
                'y': int(r['y'] + r['height']/2)
            })
        time.sleep(1)
        xpath_exito = "//*[@content-desc='Cuenta de beneficiario fie guardada con éxito']"
        try:
            WebDriverWait(driver, 15).until(EC.presence_of_element_located((AppiumBy.XPATH, xpath_exito)))
        except Exception:
            print('  ❌ No apareció confirmación de alta exitosa'); return False
        try:
            continuar = WebDriverWait(driver, 10).until(EC.presence_of_element_located((AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")))
            try: continuar.click()
            except Exception:
                r=continuar.rect; driver.execute_script('mobile: clickGesture', {'x':int(r['x']+r['width']/2),'y':int(r['y']+r['height']/2)})
            WebDriverWait(driver, 10).until(EC.invisibility_of_element_located((AppiumBy.XPATH, xpath_exito)))
        except Exception as e:
            print(f'  ❌ Error cerrando modal de alta: {e}'); return False
        time.sleep(1.5); print('  ✅ Alta confirmada; continuando con transferencia'); return True
    except Exception as e:
        print(f'  ❌ Error alta beneficiario: {e}');return False

def select_source_account(driver, numero_cuenta, timeout=15):
    """Selecciona exclusivamente la cuenta origen dentro del modal ya abierto/abrible."""
    import re
    objetivo = re.sub(r'\D', '', str(numero_cuenta or ''))
    print(f'  📝 Seleccionando cuenta origen en modal: {numero_cuenta} -> {objetivo}')
    if not objetivo:
        print('  ❌ Número de cuenta origen vacío')
        return False

    def modal_abierto():
        try:
            return bool(driver.find_elements(AppiumBy.XPATH, "//*[@content-desc='Cuenta de origen']")) and bool(
                driver.find_elements(AppiumBy.XPATH, "//*[@content-desc='Selecciona la cuenta desde la que transferirás.']")
            )
        except Exception:
            return False

    # La pantalla previa tiene un Button cuyo content-desc inicia con 'Selecciona una cuenta'.
    # Solo abrirlo si el modal aún no está presente.
    if not modal_abierto():
        abiertos = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc,'Selecciona una cuenta') and @clickable='true']")
        if not abiertos:
            print('  ❌ No se encontró el selector que abre Cuenta de origen')
            return False
        try:
            abiertos[0].click()
        except Exception:
            r = abiertos[0].rect
            driver.execute_script('mobile: clickGesture', {'x':int(r['x']+r['width']/2),'y':int(r['y']+r['height']/2)})
        time.sleep(1.2)

    if not modal_abierto():
        print('  ❌ El modal Cuenta de origen no quedó visible')
        return False
    print('  ✅ Modal Cuenta de origen detectado')

    # Buscar SOLO dentro del modal: botones con descriptor de tipo de cuenta + número.
    candidatos = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[@clickable='true' and (contains(@content-desc,'CUENTA DE AHORROS') or contains(@content-desc,'CUENTA CORRIENTE'))]")
    print(f'  🔎 Opciones de cuenta origen encontradas: {len(candidatos)}')
    for pos, btn in enumerate(candidatos):
        try:
            desc = btn.get_attribute('content-desc') or ''
            cuentas = re.findall(r'\d{2}-\d-\d{7}-\d', desc)
            print(f"     [{pos}] {desc.replace(chr(10),' | ')}")
            for cuenta in cuentas:
                if re.sub(r'\D','',cuenta) == objetivo:
                    print(f'  🎯 Cuenta origen exacta encontrada: {cuenta}')
                    try:
                        btn.click()
                    except Exception:
                        r=btn.rect
                        driver.execute_script('mobile: clickGesture', {'x':int(r['x']+r['width']/2),'y':int(r['y']+r['height']/2)})
                    driver._last_origen_desc=desc
                    time.sleep(1.2)
                    print(f'  ✅ Cuenta origen seleccionada: {numero_cuenta}')
                    return True
        except Exception as e:
            print(f'  ⚠️ Error leyendo opción origen {pos}: {e}')

    try:
        xml=driver.page_source or ''
        presentes=re.findall(r'\d{2}-\d-\d{7}-\d',xml)
        print(f'  ℹ️ Cuentas visibles en XML del modal: {presentes}')
    except Exception:
        pass
    print(f'  ❌ Cuenta origen {numero_cuenta} no disponible en el modal')
    return False

def enter_amount(driver, monto):
    print(f'  📝 Ingresando monto: {monto}')
    time.sleep(2)
    try:
        amount_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='0.00']")
        amount_input.click()
        time.sleep(1)
        amount_input.clear()
        amount_input.send_keys(str(monto))
        print('  ✅ Monto ingresado')
        try:
            driver.hide_keyboard()
            print('  ✅ Teclado ocultado')
            time.sleep(1)
        except:
            try:
                driver.execute_script('mobile: clickGesture', {'x': 540, 'y': 1500})
                time.sleep(1)
            except:
                pass
        return True
    except:
        try:
            amount_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='Monto']")
            amount_input.click()
            time.sleep(1)
            amount_input.clear()
            amount_input.send_keys(str(monto))
            print('  ✅ Monto ingresado (fallback)')
            try:
                driver.hide_keyboard()
                print('  ✅ Teclado ocultado')
                time.sleep(1)
            except:
                pass
            return True
        except Exception as e:
            print(f'  ❌ Error al ingresar monto: {e}')
            return False

def enter_concept(driver, concepto):
    """Ingresa concepto en el EditText cuyo hint actual es 'Concepto'."""
    print(f'  📝 Ingresando concepto: {concepto}')
    time.sleep(0.7)
    concept_input = None
    estrategias = [
        "//android.widget.EditText[@hint='Concepto']",
        "//android.widget.EditText[@hint='Detalle']",
        "//android.widget.EditText[contains(@hint,'Concepto') or contains(@hint,'Detalle')]",
        "//*[@class='android.widget.EditText' and (@hint='Concepto' or @hint='Detalle')]",
    ]
    for i, xp in enumerate(estrategias, 1):
        try:
            candidatos = driver.find_elements(AppiumBy.XPATH, xp)
            for campo in candidatos:
                if campo.is_displayed() and campo.is_enabled():
                    concept_input = campo
                    print(f'  ✅ Campo Concepto localizado (estrategia {i})')
                    break
            if concept_input:
                break
        except Exception as e:
            print(f'  ⚠️ Estrategia Concepto {i} falló: {e}')
    if concept_input is None:
        # Diagnóstico: listar EditText visibles e hints reales.
        try:
            edits=driver.find_elements(AppiumBy.CLASS_NAME,'android.widget.EditText')
            print(f'  🔎 EditText visibles: {len(edits)}')
            for pos,e in enumerate(edits):
                print(f"     [{pos}] hint={e.get_attribute('hint')} text={e.get_attribute('text')}")
        except Exception:
            pass
        print("  ❌ No se encontró EditText con hint='Concepto' o hint='Detalle'")
        return False
    try:
        concept_input.click(); time.sleep(.3)
        try: concept_input.clear()
        except Exception: pass
        concept_input.send_keys(str(concepto))
        time.sleep(.4)
        valor = concept_input.get_attribute('text') or ''
        print(f'  📝 Valor leído en Concepto: {valor}')
        # La app transforma el concepto a mayúsculas. Comparar sin distinguir mayúsculas/minúsculas
        # y nunca volver a escribir, para evitar duplicar el contenido.
        esperado = str(concepto).strip().casefold()
        actual = str(valor).strip().casefold()
        if actual != esperado:
            print(f'  ❌ Concepto no coincide. Esperado={concepto} Actual={valor}')
            return False
        print('  ✅ Concepto ingresado y verificado (comparación sin distinguir mayúsculas)')
    except Exception as e:
        print(f'  ❌ Error al escribir Concepto: {e}')
        return False
    try:
        driver.hide_keyboard(); time.sleep(.5)
    except Exception:
        try: driver.press_keycode(4); time.sleep(.5)
        except Exception: pass
    return True

def click_continuar_transfer(driver):
    print('  📝 Click en Continuar (transferencia)...')
    time.sleep(1)
    try:
        driver.hide_keyboard()
        time.sleep(1)
    except:
        pass
    try:
        continuar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")
        continuar_btn.click()
        print('  ✅ Click en Continuar')
        time.sleep(3)
        return True
    except:
        try:
            continuar_btn = driver.find_element(AppiumBy.ACCESSIBILITY_ID, 'Continuar')
            continuar_btn.click()
            print('  ✅ Click en Continuar (Accessibility)')
            time.sleep(3)
            return True
        except:
            print('  ❌ Error al clickear Continuar')
            return False

def click_confirmar(driver):
    print('  📝 Click en Confirmar...')
    time.sleep(1)
    try:
        confirmar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Confirmar')]")
        confirmar_btn.click()
        print('  ✅ Click en Confirmar')
        time.sleep(3)
        return True
    except:
        print('  ❌ Error al clickear Confirmar')
        return False

def verify_transfer_success(driver):
    print('  📝 Verificando transferencia...')
    time.sleep(3)
    try:
        driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Transferencia exitosa')]")
        print('  ✅ TRANSFERENCIA EXITOSA!')
        return True
    except:
        pass
    print('  ⚠️ No se pudo verificar el estado de la transferencia')
    return False

def scroll_movimientos(driver, scrolls=3):
    print(f'  📝 Haciendo scroll para ver movimientos...')
    time.sleep(2)
    for i in range(scrolls):
        try:
            driver.swipe(500, 1200, 500, 400, 500)
            time.sleep(1)
            print(f'  🔄 Scroll {i + 1}/{scrolls}')
        except:
            pass
    print('  ✅ Scroll completado')
    return True

def volver_comprobante_a_home(driver, timeout=15):
    """Secuencia real: Comprobante -> Nueva transferencia -> pantalla Transferir -> Inicio -> Home."""
    print("  🔄 Cerrando comprobante mediante 'Nueva transferencia'...")
    nueva = driver.find_elements(AppiumBy.ACCESSIBILITY_ID, 'Nueva transferencia')
    if not nueva:
        nueva = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Nueva transferencia' and @clickable='true']")
    if not nueva:
        print("  ❌ No se encontró 'Nueva transferencia' en el comprobante")
        return False
    try:
        nueva[0].click()
    except Exception:
        r=nueva[0].rect
        driver.execute_script('mobile: clickGesture', {'x':int(r['x']+r['width']/2),'y':int(r['y']+r['height']/2)})
    print("  ✅ Click en Nueva transferencia")
    time.sleep(2)

    # Ahora sí debe existir la barra inferior de navegación.
    for intento in range(1, 8):
        try:
            candidatos = driver.find_elements(AppiumBy.XPATH, "//*[@clickable='true' and contains(@content-desc,'Inicio')]")
            print(f'  🔎 Intento {intento}/7: candidatos Inicio={len(candidatos)}')
            for btn in candidatos:
                desc=(btn.get_attribute('content-desc') or '').replace('\r','')
                lineas=[x.strip() for x in desc.split('\n') if x.strip()]
                # Admite tanto Inicio como Inicio\nInicio, según la jerarquía expuesta por Appium.
                if not lineas or any(x != 'Inicio' for x in lineas):
                    continue
                print(f"  🎯 Botón Inicio localizado: {desc.replace(chr(10),' | ')}")
                try:
                    btn.click()
                except Exception:
                    r=btn.rect
                    driver.execute_script('mobile: clickGesture', {'x':int(r['x']+r['width']/2),'y':int(r['y']+r['height']/2)})
                time.sleep(2)
                # Confirmar que Transferir dejó de estar seleccionado.
                transfer=driver.find_elements(AppiumBy.ID,'home_btn_transferir')
                selected=(transfer[0].get_attribute('selected') or '').lower() if transfer else ''
                if selected != 'true':
                    print('  ✅ Regreso a Home confirmado')
                    return True
                print('  ⚠️ Inicio pulsado, pero Transferir sigue seleccionado')
        except Exception as e:
            print(f'  ⚠️ Error buscando Inicio: {e}')
        time.sleep(1)
    print('  ❌ No fue posible regresar a Home después de Nueva transferencia')
    return False

def realizar_transferencia_nuevo_beneficiario(driver, destino_numero_cuenta, tipo_cuenta, origen_numero_cuenta, monto=1, concepto='Transferencia nuevo beneficiario', tiempos=None, reporte=None, paso_inicial=6):
    if tiempos is None: tiempos=Tiempos()
    paso_num=paso_inicial
    def ejecutar(etapa,titulo,descripcion,fn):
        nonlocal paso_num
        tiempos.start(etapa)
        try: ok=bool(fn())
        except Exception as e: ok=False; print(f'  ❌ {etapa}: {e}')
        finally: tiempos.stop()
        if reporte:
            reporte.capturar_paso(paso_num,titulo+('' if ok else ' - ERROR'),descripcion if ok else descripcion+' La ejecución se detuvo en este punto.',espera=.5)
        paso_num+=1
        return ok
    if not ejecutar('1. Navegar a Transferencias','Pantalla Transferencias','Se accedió a Transferencias.',lambda:navigate_to_transfer(driver)): return False
    if not ejecutar('2. Nuevo beneficiario','Nuevo beneficiario','Se abrió el alta de nuevo beneficiario.',lambda:click_nuevo_beneficiario(driver)): return False
    if not ejecutar('3. Buscar banco FIE','Banco FIE seleccionado','Se buscó y seleccionó Banco FIE.',lambda:buscar_y_seleccionar_banco_fie(driver)): return False
    if not ejecutar('4. Alta cuenta beneficiario','Alta beneficiario confirmada','Se registró y confirmó la cuenta del beneficiario.',lambda:completar_alta_beneficiario(driver,tipo_cuenta,destino_numero_cuenta)): return False
    # Igual que flujo 37: abrir explícitamente el selector de Cuenta de origen y seleccionar la cuenta configurada.
    if not ejecutar('5. Seleccionar cuenta origen','Cuenta origen seleccionada',f'Se abrió el modal y se seleccionó la cuenta origen {origen_numero_cuenta}.',lambda:select_source_account(driver,origen_numero_cuenta)): return False
    if not ejecutar('6. Ingresar monto',f'Monto: Bs. {monto}',f'Se ingresó el monto Bs. {monto}.',lambda:enter_amount(driver,monto)): return False
    if not ejecutar('7. Ingresar concepto',f'Concepto: {concepto}',f'Se ingresó el concepto {concepto}.',lambda:enter_concept(driver,concepto)): return False
    if not ejecutar('8. Continuar','Continuar transferencia','Se avanzó a la verificación.',lambda:click_continuar_transfer(driver)): return False
    if not ejecutar('9. Confirmar','Confirmar transferencia',f'Se confirmó la transferencia por Bs. {monto}.',lambda:click_confirmar(driver)): return False
    if not ejecutar('10. Verificar transferencia','Resultado transferencia','Se verificó la transferencia.',lambda:verify_transfer_success(driver)): return False
    return ejecutar('11. Regresar Home','Home - Nuevo beneficiario finalizado','Se completó alta, transferencia y retorno al Home.',lambda:volver_comprobante_a_home(driver))

if __name__ == '__main__':
    _input_cfg = load_input_defaults('transfer_nuevo_beneficiario_fie_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO COMPLETO: LOGIN + TRANSFERENCIA A NUEVO BENEFICIARIO + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    monto = _input_cfg.get('monto', 1)
    concepto = _input_cfg.get('concepto', 'Transferencia a nuevo beneficiario')
    NOMBRE_BENEFICIARIO = _input_cfg.get('NOMBRE_BENEFICIARIO', 'ABRAHAM CHARCAS QUISPE')
    CUENTA_BENEFICIARIO = _input_cfg.get('CUENTA_BENEFICIARIO', '60000003916')
    CI_NIT = _input_cfg.get('CI_NIT', '4803327')
    TIPO_CUENTA_BENEFICIARIO = _input_cfg.get('TIPO_CUENTA_BENEFICIARIO', 'Cuenta corriente')
    BANCO_DESTINO = _input_cfg.get('BANCO_DESTINO', 'Banco Fie')
    ORIGEN_NUMERO_CUENTA = _input_cfg.get('ORIGEN_NUMERO_CUENTA', None)
    ORIGEN_TIPO_CUENTA = _input_cfg.get('ORIGEN_TIPO_CUENTA', 'CUENTA DE AHORRO')
    ORIGEN_INDEX = _input_cfg.get('ORIGEN_INDEX', 0)
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Transferencia_Nuevo_Beneficiario')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f'💰 Monto: Bs. {monto}')
    print(f'📝 Concepto: {concepto}')
    print(f'👤 Beneficiario: {NOMBRE_BENEFICIARIO}')
    print(f'🏦 Cuenta: {CUENTA_BENEFICIARIO}')
    print(f'🆔 CI/NIT: {CI_NIT}')
    print(f'📋 Tipo cuenta: {TIPO_CUENTA_BENEFICIARIO}')
    print(f'🏛️  Banco destino: {BANCO_DESTINO}')
    print(f'🎯 Origen: cuenta={ORIGEN_NUMERO_CUENTA}, tipo={ORIGEN_TIPO_CUENTA}, index={ORIGEN_INDEX}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Monto': f'Bs. {monto}', 'Concepto': concepto, 'Beneficiario': NOMBRE_BENEFICIARIO, 'Cuenta beneficiario': CUENTA_BENEFICIARIO, 'CI/NIT': CI_NIT, 'Tipo de cuenta': TIPO_CUENTA_BENEFICIARIO, 'Banco destino': BANCO_DESTINO, 'Origen - Número': ORIGEN_NUMERO_CUENTA or 'N/A', 'Origen - Tipo': ORIGEN_TIPO_CUENTA or 'N/A', 'Origen - Índice': ORIGEN_INDEX})
    login_ok = _input_cfg.get('login_ok', False)
    transfer_ok = _input_cfg.get('transfer_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            transfer_ok = realizar_transferencia_nuevo_beneficiario(driver, monto=monto, concepto=concepto, nombre_beneficiario=NOMBRE_BENEFICIARIO, cuenta_beneficiario=CUENTA_BENEFICIARIO, ci_nit=CI_NIT, tipo_cuenta_beneficiario=TIPO_CUENTA_BENEFICIARIO, banco_destino=BANCO_DESTINO, origen_numero_cuenta=ORIGEN_NUMERO_CUENTA, origen_tipo_cuenta=ORIGEN_TIPO_CUENTA, origen_index=ORIGEN_INDEX, tiempos=tiempos, reporte=reporte, paso_inicial=6)
            if transfer_ok:
                print('\n🎉 TRANSFERENCIA A NUEVO BENEFICIARIO EXITOSA!')
            else:
                print('\n❌ TRANSFERENCIA A NUEVO BENEFICIARIO FALLIDA')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and transfer_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login          : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Transferencia  : {('✅ OK' if transfer_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

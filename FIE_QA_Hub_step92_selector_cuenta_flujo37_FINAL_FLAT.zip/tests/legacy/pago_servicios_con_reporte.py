"""
Flujo Pago de Servicios + reporte Word.
Pasos: Login → Pagos → Pago de servicios → Nuevo pago
       → Buscar servicio → Seleccionar → Tipo búsqueda → Datos
       → Contrato → Servicio a pagar → Cuenta origen → Continuar
       → Confirmar → Cerrar → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import go_back_home__37b63a23bd as go_back_home
from framework.common.ui_helpers import _esta_en_home as _esta_en_home, _seleccionar_opcion_case_insensitive__f21faf0807 as _seleccionar_opcion_case_insensitive, _ingresar_texto_en_campo as _ingresar_texto_en_campo

def click_pagos_menu(driver):
    print('  📝 Click en Pagos...')
    time.sleep(2)
    if _seleccionar_opcion_case_insensitive(driver, 'Pagos', timeout=5, debug=True):
        print('  ✅ Click en Pagos')
        time.sleep(3)
        return True
    print('  ❌ Error al clickear Pagos')
    return False

def select_pago_servicios(driver):
    print('  📝 Seleccionando Pago de servicios...')
    time.sleep(2)
    try:
        servicio_btn = driver.find_element(AppiumBy.ID, 'payments_option_service')
        servicio_btn.click()
        print('  ✅ Click en Pago de servicios (ID)')
        time.sleep(3)
        return True
    except:
        pass
    if _seleccionar_opcion_case_insensitive(driver, 'Pago de servicios', timeout=5, debug=True):
        print('  ✅ Click en Pago de servicios')
        time.sleep(3)
        return True
    print('  ❌ Error al seleccionar Pago de servicios')
    return False

def click_nuevo_pago(driver):
    print('  📝 Click en Nuevo pago...')
    time.sleep(2)
    try:
        nuevo_pago_btn = driver.find_element(AppiumBy.ID, 'payments_service_btn_new')
        nuevo_pago_btn.click()
        print('  ✅ Click en Nuevo pago (ID)')
        time.sleep(3)
        return True
    except:
        pass
    if _seleccionar_opcion_case_insensitive(driver, 'Nuevo pago', timeout=5, debug=True):
        print('  ✅ Click en Nuevo pago')
        time.sleep(3)
        return True
    print('  ❌ Error al clickear Nuevo pago')
    return False

def search_service(driver, servicio='boa'):
    print(f'  📝 Buscando servicio: {servicio}...')
    time.sleep(2)
    ok = _ingresar_texto_en_campo(driver, resource_id=None, valor=servicio, hints_alternativos=['Empresa o servicio', 'Empresa', 'Servicio'])
    if ok:
        print(f'  ✅ Servicio buscado: {servicio}')
        time.sleep(2)
    else:
        print(f'  ❌ Error al buscar servicio')
    return ok

def select_service(driver, servicio='BOA'):
    print(f'  📝 Seleccionando servicio: {servicio}...')
    time.sleep(2)
    try:
        service_btn = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{servicio}') and @clickable='true']")
        service_btn.click()
        print(f'  ✅ Servicio seleccionado: {servicio} (content-desc)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        service_btn = driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{servicio}') and @clickable='true']")
        service_btn.click()
        print(f'  ✅ Servicio seleccionado: {servicio} (texto)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        servicio_lower = servicio.lower()
        service_btn = driver.find_element(AppiumBy.XPATH, f"//*[contains(translate(@content-desc, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '{servicio_lower}') and @clickable='true']")
        service_btn.click()
        print(f'  ✅ Servicio seleccionado: {servicio} (case-insensitive)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        service_btns = driver.find_elements(AppiumBy.XPATH, "//*[contains(@resource-id, 'payments_company_') and @clickable='true']")
        if service_btns:
            service_btns[0].click()
            print(f'  ✅ Primer servicio disponible seleccionado (fallback)')
            time.sleep(3)
            return True
    except:
        pass
    print(f'  ❌ Error al seleccionar servicio: {servicio}')
    return False

def select_tipo_busqueda(driver, tipo='Pago boleto'):
    print(f'  📝 [MODAL 1] Seleccionando Tipo de búsqueda: {tipo}...')
    time.sleep(2)
    abierto = False
    try:
        tipo_btn = driver.find_element(AppiumBy.ID, 'payments_select_criteria_productoId')
        tipo_btn.click()
        print("  ✅ Click en 'Selecciona una opción' (ID)")
        abierto = True
        time.sleep(2)
    except:
        pass
    if not abierto:
        try:
            tipo_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Selecciona una opción']")
            tipo_btn.click()
            print("  ✅ Click en 'Selecciona una opción' (content-desc)")
            abierto = True
            time.sleep(2)
        except:
            pass
    if not abierto:
        if _seleccionar_opcion_case_insensitive(driver, 'Selecciona una opción', timeout=5):
            print("  ✅ Click en 'Selecciona una opción' (helper)")
            abierto = True
            time.sleep(2)
    if not abierto:
        print('  ❌ Error al abrir selector de tipo')
        return False
    time.sleep(1)
    if _seleccionar_opcion_case_insensitive(driver, tipo, timeout=5, debug=True):
        print(f'  ✅ Tipo seleccionado: {tipo}')
        time.sleep(2)
        return True
    print(f'  ❌ Error al seleccionar tipo: {tipo}')
    return False

def select_contrato_modal(driver, codigo_orden='1234'):
    print('  📝 [MODAL 1] Seleccionando Contrato...')
    time.sleep(5)
    abierto = False
    try:
        contrato_btn = driver.find_element(AppiumBy.ID, 'payments_select_service_contract')
        contrato_btn.click()
        print("  ✅ Click en 'Selecciona un contrato' (ID)")
        abierto = True
        time.sleep(2)
    except:
        pass
    if not abierto:
        if _seleccionar_opcion_case_insensitive(driver, 'Selecciona un contrato', timeout=5):
            print("  ✅ Click en 'Selecciona un contrato' (helper)")
            abierto = True
            time.sleep(2)
    if not abierto:
        print('  ❌ Error al abrir selector de contrato')
        return False
    time.sleep(1)
    try:
        contrato = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{codigo_orden}') and @clickable='true']")
        contrato.click()
        print(f'  ✅ Contrato seleccionado (código: {codigo_orden})')
        time.sleep(2)
        return True
    except:
        pass
    try:
        contrato = driver.find_element(AppiumBy.XPATH, "//android.view.View[contains(@content-desc, 'Código de orden') and @clickable='true']")
        contrato.click()
        print("  ✅ Contrato seleccionado (por descripción 'Código de orden')")
        time.sleep(2)
        return True
    except:
        pass
    try:
        contrato = driver.find_element(AppiumBy.XPATH, "//android.view.View[@clickable='true' and contains(@content-desc, 'Código')]")
        contrato.click()
        print("  ✅ Contrato seleccionado (primer elemento con 'Código')")
        time.sleep(2)
        return True
    except:
        pass
    try:
        opciones = driver.find_elements(AppiumBy.XPATH, "//android.view.View[@clickable='true' and string-length(@content-desc) > 5]")
        if opciones:
            opciones[0].click()
            print('  ✅ Primer contrato disponible seleccionado (fallback)')
            time.sleep(2)
            return True
    except:
        pass
    print('  ❌ Error al seleccionar contrato')
    return False

def select_tipo_servicio_modal(driver):
    """MODAL 3: Seleccionar Servicio a pagar."""
    print('  📝 [MODAL 3] Seleccionando Servicio a pagar...')
    time.sleep(3)
    abierto = False
    if _seleccionar_opcion_case_insensitive(driver, 'Selecciona un servicio', timeout=5):
        print("  ✅ Click en 'Selecciona un servicio'")
        abierto = True
        time.sleep(2)
    if not abierto:
        print('  ❌ Error al abrir selector de servicio')
        return False
    time.sleep(1)
    try:
        opcion = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Monto:') and @clickable='true']")
        opcion.click()
        print("  ✅ Servicio seleccionado (por 'Monto:')")
        time.sleep(2)
        return True
    except:
        pass
    try:
        opcion = driver.find_element(AppiumBy.XPATH, "//android.view.View[@clickable='true' and contains(@content-desc, 'Orden')]")
        opcion.click()
        print("  ✅ Servicio seleccionado (por 'Orden')")
        time.sleep(2)
        return True
    except:
        pass
    try:
        opciones = driver.find_elements(AppiumBy.XPATH, "//android.view.View[@clickable='true']")
        for opcion in opciones:
            desc = opcion.get_attribute('content-desc') or ''
            for keyword in ['Monto', 'Orden', 'Pago', 'Bs.']:
                if keyword in desc:
                    opcion.click()
                    print(f"  ✅ Servicio seleccionado (keyword '{keyword}'): {desc[:50]}...")
                    time.sleep(2)
                    return True
    except:
        pass
    try:
        opciones = driver.find_elements(AppiumBy.XPATH, "//android.view.View[@clickable='true' and string-length(@content-desc) > 5]")
        if opciones:
            opciones[0].click()
            print('  ✅ Primer servicio disponible seleccionado (fallback)')
            time.sleep(2)
            return True
    except:
        pass
    print('  ❌ Error al seleccionar servicio')
    return False

def select_cuenta_origen_modal(driver, numero_cuenta=None):
    if numero_cuenta:
        try:
            cuenta = WebDriverWait(driver,15).until(EC.element_to_be_clickable((AppiumBy.XPATH, f"//*[contains(@content-desc, '{numero_cuenta}') and @clickable='true']")))
            cuenta.click(); print(f'  ✅ Cuenta origen seleccionada: {numero_cuenta}'); time.sleep(2); return True
        except Exception as e:
            print(f'  ❌ No se encontró la cuenta origen {numero_cuenta}: {e}'); return False
    """MODAL 3: Seleccionar Cuenta de origen."""
    print('  📝 [MODAL 3] Seleccionando Cuenta de origen...')
    time.sleep(2)
    abierto = False
    if _seleccionar_opcion_case_insensitive(driver, 'Selecciona una cuenta', timeout=5):
        print("  ✅ Click en 'Selecciona una cuenta'")
        abierto = True
        time.sleep(2)
    if not abierto:
        print('  ❌ Error al abrir selector de cuenta')
        return False
    time.sleep(1)
    try:
        cuenta = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'CUENTA DE AHORROS') and @clickable='true']")
        cuenta.click()
        print('  ✅ Cuenta seleccionada: CUENTA DE AHORROS')
        time.sleep(2)
        return True
    except:
        pass
    try:
        cuenta = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'CUENTA CORRIENTE') and @clickable='true']")
        cuenta.click()
        print('  ✅ Cuenta seleccionada: CUENTA CORRIENTE')
        time.sleep(2)
        return True
    except:
        pass
    try:
        cuenta = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'CUENTA') and @clickable='true']")
        cuenta.click()
        print('  ✅ Cuenta seleccionada (primera disponible)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        cuentas = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[@clickable='true']")
        if cuentas:
            cuentas[0].click()
            print('  ✅ Primer elemento seleccionado (fallback)')
            time.sleep(2)
            return True
    except:
        pass
    print('  ❌ Error al seleccionar cuenta')
    return False

def fill_payment_data(driver, codigo_orden='1234', razon_social='abcd', nit_cliente='123456'):
    print('  📝 Llenando datos del pago...')
    time.sleep(2)
    ok_codigo = _ingresar_texto_en_campo(driver, resource_id=None, valor=codigo_orden, hints_alternativos=['Código de orden', 'Código', 'codigo'])
    if ok_codigo:
        print(f'  ✅ Código de orden: {codigo_orden}')
    else:
        print(f'  ⚠️ Error al ingresar código de orden')
    ok_razon = _ingresar_texto_en_campo(driver, resource_id=None, valor=razon_social, hints_alternativos=['Razon social', 'Razón social', 'Razon'])
    if ok_razon:
        print(f'  ✅ Razón social: {razon_social}')
    else:
        print(f'  ⚠️ Error al ingresar razón social')
    ok_nit = _ingresar_texto_en_campo(driver, resource_id=None, valor=nit_cliente, hints_alternativos=['Nit cliente', 'Nit', 'NIT'])
    if ok_nit:
        print(f'  ✅ Nit cliente: {nit_cliente}')
    else:
        print(f'  ⚠️ Error al ingresar Nit cliente')
    return click_continuar(driver, 'datos pago')

def click_continuar(driver, step='datos pago'):
    """Click en el botón Continuar con 3 estrategias + retry."""
    print(f'  📝 Click en Continuar ({step})...')
    time.sleep(2)
    wait = WebDriverWait(driver, 5)
    try:
        continuar_btn = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")))
        continuar_btn.click()
        print(f'  ✅ Click en Continuar ({step})')
        time.sleep(3)
        return True
    except:
        pass
    try:
        continuar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Continuar') and @clickable='true']")
        continuar_btn.click()
        print(f'  ✅ Click en Continuar ({step} - texto)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        continuar_btn = driver.find_element(AppiumBy.ACCESSIBILITY_ID, 'Continuar')
        continuar_btn.click()
        print(f'  ✅ Click en Continuar ({step} - accessibility)')
        time.sleep(3)
        return True
    except:
        pass
    time.sleep(2)
    try:
        continuar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")
        continuar_btn.click()
        print(f'  ✅ Click en Continuar ({step} - retry)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al clickear Continuar ({step}): {e}')
        return False

def click_confirmar_pago(driver):
    """Click en Confirmar la transacción con 4 estrategias."""
    print('  📝 Click en Confirmar la transacción...')
    time.sleep(8)
    try:
        confirmar_btn = driver.find_element(AppiumBy.ID, 'service_payment_verification_confirm')
        confirmar_btn.click()
        print('  ✅ Click en Confirmar la transacción (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        confirmar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Confirmar la transacción']")
        confirmar_btn.click()
        print('  ✅ Click en Confirmar la transacción (content-desc)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        confirmar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Confirmar') and @clickable='true']")
        confirmar_btn.click()
        print('  ✅ Click en Confirmar (texto)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        confirmar_btn = driver.find_element(AppiumBy.ACCESSIBILITY_ID, 'Confirmar')
        confirmar_btn.click()
        print('  ✅ Click en Confirmar (accessibility)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al clickear Confirmar: {e}')
        return False

def close_comprobante(driver):
    """Cierra el comprobante con 5 estrategias."""
    print('  📝 Cerrando comprobante...')
    time.sleep(6)
    try:
        cerrar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Cerrar']")
        cerrar_btn.click()
        print('  ✅ Click en Cerrar (content-desc)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        cerrar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Cerrar') and @clickable='true']")
        cerrar_btn.click()
        print('  ✅ Click en Cerrar (texto)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        regresar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Regresar']")
        regresar.click()
        print('  ✅ Click en Regresar')
        time.sleep(2)
        return True
    except:
        pass
    try:
        aceptar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Aceptar']")
        aceptar.click()
        print('  ✅ Click en Aceptar')
        time.sleep(2)
        return True
    except:
        pass
    try:
        cerrar_btn = driver.find_element(AppiumBy.ACCESSIBILITY_ID, 'Cerrar')
        cerrar_btn.click()
        print('  ✅ Click en Cerrar (accessibility)')
        time.sleep(2)
        return True
    except:
        try:
            driver.back()
            print('  ✅ Back ejecutado')
            time.sleep(2)
            return True
        except Exception as e:
            print(f'  ❌ Error al cerrar comprobante: {e}')
            return False

def realizar_pago_servicios(driver, servicio='boa', tipo_busqueda='Pago Boleto', codigo_orden='1234', razon_social='abcd', nit_cliente='123456', numero_cuenta=None, tiempos=None, reporte=None, paso_inicial=6):
    print(f'\n💳 INICIANDO PAGO DE SERVICIOS')
    print(f'🏢 Servicio: {servicio}')
    print(f'📋 Tipo búsqueda: {tipo_busqueda}')
    print(f'📝 Código orden: {codigo_orden}')
    print(f'👤 Razón social: {razon_social}')
    print(f'🆔 Nit cliente: {nit_cliente}')
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Click Pagos')
    if not click_pagos_menu(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Menú Pagos abierto', "Se accedió al menú de 'Pagos' desde el home.", espera=2.0)
    paso_num += 1
    tiempos.start('2. Pago de servicios')
    if not select_pago_servicios(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla Pago de servicios', "Se accedió a la pantalla de 'Pago de servicios'.", espera=2.0)
    paso_num += 1
    tiempos.start('3. Nuevo pago')
    if not click_nuevo_pago(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Nuevo pago iniciado', "Se hizo clic en 'Nuevo pago' para iniciar el flujo de pago de servicios.", espera=1.5)
    paso_num += 1
    tiempos.start('4. Buscar servicio')
    if not search_service(driver, servicio):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Búsqueda de servicio: {servicio}', f"Se ingresó el nombre del servicio a buscar: '{servicio}'.", espera=1.5)
    paso_num += 1
    tiempos.start('5. Seleccionar servicio')
    if not select_service(driver, servicio.upper()):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Servicio seleccionado: {servicio.upper()}', f"Se seleccionó el servicio '{servicio.upper()}' de la lista de resultados.", espera=1.5)
    paso_num += 1
    tiempos.start('6. Tipo búsqueda')
    if not select_tipo_busqueda(driver, tipo_busqueda):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Tipo de búsqueda: {tipo_busqueda}', f"Se seleccionó el tipo de búsqueda: '{tipo_busqueda}'.", espera=1.5)
    paso_num += 1
    tiempos.start('7. Llenar datos')
    if not fill_payment_data(driver, codigo_orden, razon_social, nit_cliente):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Datos del pago ingresados', f"Se ingresaron los datos del pago: Código de orden: '{codigo_orden}', Razón social: '{razon_social}', Nit cliente: '{nit_cliente}'.", espera=1.5)
    paso_num += 1
    tiempos.start('8. Seleccionar contrato')
    if not select_contrato_modal(driver, codigo_orden):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Contrato seleccionado', f"Se seleccionó el contrato correspondiente al código de orden: '{codigo_orden}'.", espera=1.5)
    paso_num += 1
    tiempos.start('9. Servicio a pagar')
    if not select_tipo_servicio_modal(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Servicio a pagar seleccionado', 'Se seleccionó el servicio específico a pagar (con el monto).', espera=1.5)
    paso_num += 1
    tiempos.start('10. Cuenta origen')
    if not select_cuenta_origen_modal(driver, numero_cuenta):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Cuenta de origen seleccionada', 'Se seleccionó la cuenta de origen para el pago.', espera=1.5)
    paso_num += 1
    tiempos.start('11. Continuar modales')
    if not click_continuar(driver, 'después de modales'):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Continuar (después de modales)', 'Se hizo clic en Continuar tras completar los modales. Se avanzó a la pantalla de verificación.', espera=1.5)
    paso_num += 1
    tiempos.start('12. Confirmar transacción')
    if not click_confirmar_pago(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Confirmar transacción', f"Se confirmó la transacción de pago de servicios del servicio '{servicio.upper()}'.", espera=1.5)
    paso_num += 1
    tiempos.start('13. Cerrar comprobante')
    close_comprobante(driver)
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Comprobante cerrado', 'Se cerró el comprobante de pago generado.', espera=1.5)
    paso_num += 1
    tiempos.start('14. Volver al home')
    if not go_back_home(driver):
        print('  ⚠️ No se pudo volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Pago de Servicios finalizado', 'Se regresó exitosamente al home. El flujo de pago de servicios ha terminado.', espera=1.5)
    paso_num += 1
    print('\n✅ PAGO DE SERVICIOS COMPLETADO EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('pago_servicios_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO COMPLETO: LOGIN + PAGO DE SERVICIOS + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    servicio = _input_cfg.get('servicio', 'boa')
    tipo_busqueda = _input_cfg.get('tipo_busqueda', 'Pago boleto')
    codigo_orden = _input_cfg.get('codigo_orden', '1234')
    razon_social = _input_cfg.get('razon_social', 'abcd')
    nit_cliente = _input_cfg.get('nit_cliente', '123456')
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Pago_Servicios')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f'🏢 Servicio: {servicio}')
    print(f'📋 Tipo de búsqueda: {tipo_busqueda}')
    print(f'📝 Código de orden: {codigo_orden}')
    print(f'👤 Razón social: {razon_social}')
    print(f'🆔 Nit cliente: {nit_cliente}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Servicio': servicio, 'Tipo de búsqueda': tipo_busqueda, 'Código de orden': codigo_orden, 'Razón social': razon_social, 'Nit cliente': nit_cliente})
    login_ok = _input_cfg.get('login_ok', False)
    pago_ok = _input_cfg.get('pago_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            pago_ok = realizar_pago_servicios(driver, servicio=servicio, tipo_busqueda=tipo_busqueda, codigo_orden=codigo_orden, razon_social=razon_social, nit_cliente=nit_cliente, tiempos=tiempos, reporte=reporte, paso_inicial=6)
            if pago_ok:
                print('\n🎉 PAGO DE SERVICIOS EXITOSO!')
            else:
                print('\n❌ PAGO DE SERVICIOS FALLIDO')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and pago_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login          : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Pago servicios : {('✅ OK' if pago_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

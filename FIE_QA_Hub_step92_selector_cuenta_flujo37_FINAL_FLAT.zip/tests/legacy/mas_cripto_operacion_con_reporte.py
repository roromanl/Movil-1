import time
from appium.webdriver.common.appiumby import AppiumBy
from tests.legacy.cripto_apertura_flow_con_reporte import realizar_operacion_cripto_scroll

def realizar_operacion_cripto_mas(driver, operacion='Compra', reporte=None, tiempos=None, paso_inicial=6):
    print(f'\n🪙 CRIPTO vía MÁS - {operacion}')
    try:
        driver.find_element(AppiumBy.ID,'home_btn_mas').click();time.sleep(2)
    except Exception:
        driver.find_element(AppiumBy.XPATH,"//*[@resource-id='home_btn_mas' and @clickable='true']").click();time.sleep(2)
    try:
        driver.find_element(AppiumBy.ID,'more_btn_cripto').click();time.sleep(2)
    except Exception:
        driver.find_element(AppiumBy.XPATH,"//*[@resource-id='more_btn_cripto' and @clickable='true']").click();time.sleep(2)
    return realizar_operacion_cripto_scroll(driver,operacion=operacion,reporte=reporte,tiempos=tiempos,paso_inicial=paso_inicial)

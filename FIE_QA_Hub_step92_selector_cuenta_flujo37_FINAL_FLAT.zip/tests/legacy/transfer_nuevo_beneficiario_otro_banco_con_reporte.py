"""
Flujo Transferencia a Nuevo Beneficiario en Otro Banco + reporte Word.
Pasos: Login → Transferir → Nuevo beneficiario → Banco destino
       → Datos beneficiario (1) → Confirmar → Modal éxito
       → Cuenta origen → Monto → Concepto → Continuar → Scroll
       → Confirmar → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import go_back_home__c4c30af8eb as go_back_home
from framework.common.ui_helpers import _esta_en_home as _esta_en_home

def navigate_to_transfer(driver):
    print('  📝 Navegando a Transferencias...')
    time.sleep(2)
    try:
        transfer_btn = driver.find_element(AppiumBy.ID, 'home_btn_transferir')
        transfer_btn.click()
        print('  ✅ Click en Transferir (ID)')
        time.sleep(3)
        return True
    except:
        try:
            transfer_btn = driver.find_element(AppiumBy.ACCESSIBILITY_ID, 'Transferir')
            transfer_btn.click()
            print('  ✅ Click en Transferir (Accessibility)')
            time.sleep(3)
            return True
        except:
            try:
                transfer_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Transferir') or contains(@content-desc, 'Transferir')]")
                transfer_btn.click()
                print('  ✅ Click en Transferir (XPATH)')
                time.sleep(3)
                return True
            except Exception as e:
                print(f'  ❌ Error al navegar a transferencias: {e}')
                return False

def click_nuevo_beneficiario(driver):
    print('  📝 Click en Nuevo Beneficiario...')
    time.sleep(4)
    try:
        nuevo_btn = driver.find_element(AppiumBy.ID, 'transfers_btn_new_beneficiary')
        nuevo_btn.click()
        print('  ✅ Click en Nuevo Beneficiario (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        nuevo_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Nuevo beneficiario' and @clickable='true']")
        nuevo_btn.click()
        print('  ✅ Click en Nuevo Beneficiario (content-desc)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        nuevo_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Nuevo beneficiario') and @clickable='true']")
        nuevo_btn.click()
        print('  ✅ Click en Nuevo Beneficiario (texto)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al clickear Nuevo Beneficiario: {e}')
        return False

def select_banco_destino(driver, nombre_banco='Banco Fie', timeout=15):
    print(f"  📝 Seleccionando banco destino: '{nombre_banco}'...")
    time.sleep(3)
    if not nombre_banco:
        print('  ❌ Nombre de banco vacío')
        return False
    try:
        banco_btn = driver.find_element(AppiumBy.XPATH, f"//android.widget.Button[contains(@content-desc, '{nombre_banco}') and @clickable='true']")
        desc = banco_btn.get_attribute('content-desc')
        banco_btn.click()
        print(f'  ✅ Banco seleccionado (Button content-desc)')
        print(f'     {desc[:80]}...')
        time.sleep(2)
        return True
    except:
        pass
    try:
        banco_btn = driver.find_element(AppiumBy.XPATH, f"//android.view.View[contains(@content-desc, '{nombre_banco}') and @clickable='true']")
        desc = banco_btn.get_attribute('content-desc')
        banco_btn.click()
        print(f'  ✅ Banco seleccionado (View content-desc)')
        print(f'     {desc[:80]}...')
        time.sleep(2)
        return True
    except:
        pass
    try:
        banco_btn = driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{nombre_banco}') and @clickable='true']")
        banco_btn.click()
        print(f'  ✅ Banco seleccionado (text contains)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        banco_btn = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{nombre_banco}') and @clickable='true']")
        desc = banco_btn.get_attribute('content-desc')
        banco_btn.click()
        print(f'  ✅ Banco seleccionado (cualquier elemento)')
        print(f'     {desc[:80]}...')
        time.sleep(2)
        return True
    except:
        pass
    texto_min = nombre_banco.lower()
    try:
        banco_btn = driver.find_element(AppiumBy.XPATH, f"//*[contains(translate(@content-desc, 'ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÑ', 'abcdefghijklmnopqrstuvwxyzáéíóúñ'), '{texto_min}') and @clickable='true']")
        desc = banco_btn.get_attribute('content-desc')
        banco_btn.click()
        print(f'  ✅ Banco seleccionado (case-insensitive)')
        print(f'     {desc[:80]}...')
        time.sleep(2)
        return True
    except:
        pass
    print('  🔄 Haciendo scroll para buscar el banco...')
    for i in range(5):
        try:
            driver.swipe(500, 1500, 500, 600, 500)
            time.sleep(0.8)
        except:
            pass
        try:
            banco_btn = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{nombre_banco}') and @clickable='true']")
            banco_btn.click()
            print(f'  ✅ Banco seleccionado (después de {i + 1} scrolls)')
            time.sleep(2)
            return True
        except:
            continue
    print(f"  ❌ No se encontró el banco '{nombre_banco}'")
    try:
        bancos = driver.find_elements(AppiumBy.XPATH, "//*[@clickable='true' and @content-desc and string-length(@content-desc) > 3]")
        print(f'  🔍 Elementos clickables visibles ({len(bancos)}):')
        for b in bancos[:20]:
            desc = (b.get_attribute('content-desc') or '').replace('\n', ' | ')
            if desc and len(desc) < 80:
                print(f'     - {desc}')
    except:
        pass
    return False

def fill_beneficiary_data_otro_banco_parte1(driver, nombre, cuenta, ci_nit, tipo_cuenta='Cuenta corriente'):
    print('  📝 Ingresando datos del beneficiario (paso 1)...')
    time.sleep(3)
    try:
        tipo_cuenta_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Tipo de cuenta') and @clickable='true']")
        tipo_cuenta_btn.click()
        print('  ✅ Click en Tipo de cuenta')
        time.sleep(2)
        try:
            cuenta_tipo = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{tipo_cuenta}') and @clickable='true']")
            cuenta_tipo.click()
            print(f'  ✅ Tipo cuenta: {tipo_cuenta}')
            time.sleep(1)
        except:
            try:
                cuenta_tipo = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Cuenta de ahorros') and @clickable='true']")
                cuenta_tipo.click()
                print('  ✅ Tipo cuenta: Cuenta de ahorros (fallback)')
                time.sleep(1)
            except:
                pass
    except:
        print('  ℹ️ Tipo de cuenta ya seleccionado o no visible')
    try:
        cuenta_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='Número de cuenta']")
        cuenta_input.click()
        time.sleep(1)
        cuenta_input.clear()
        cuenta_input.send_keys(cuenta)
        print(f'  ✅ Número de cuenta: {cuenta}')
        try:
            driver.hide_keyboard()
            time.sleep(1)
        except:
            pass
    except:
        try:
            cuenta_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[contains(@hint, 'Número de cuenta')]")
            cuenta_input.click()
            time.sleep(1)
            cuenta_input.clear()
            cuenta_input.send_keys(cuenta)
            print(f'  ✅ Número de cuenta: {cuenta}')
            try:
                driver.hide_keyboard()
                time.sleep(1)
            except:
                pass
        except Exception as e:
            print(f'  ❌ Error al ingresar cuenta: {e}')
            return False
    try:
        nombre_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='Beneficiario']")
        nombre_input.click()
        time.sleep(1)
        nombre_input.clear()
        nombre_input.send_keys(nombre)
        print(f'  ✅ Nombre: {nombre}')
        try:
            driver.hide_keyboard()
            time.sleep(1)
        except:
            pass
    except:
        try:
            nombre_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[contains(@hint, 'Beneficiario')]")
            nombre_input.click()
            time.sleep(1)
            nombre_input.clear()
            nombre_input.send_keys(nombre)
            print(f'  ✅ Nombre: {nombre}')
            try:
                driver.hide_keyboard()
                time.sleep(1)
            except:
                pass
        except Exception as e:
            print(f'  ⚠️ Error al ingresar nombre: {e}')
            try:
                nombre_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='Nombre del beneficiario']")
                nombre_input.click()
                time.sleep(1)
                nombre_input.clear()
                nombre_input.send_keys(nombre)
                print(f'  ✅ Nombre: {nombre}')
                try:
                    driver.hide_keyboard()
                    time.sleep(1)
                except:
                    pass
            except:
                pass
    try:
        ci_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='Ci o nit del beneficiario']")
        ci_input.click()
        time.sleep(1)
        ci_input.clear()
        ci_input.send_keys(ci_nit)
        print(f'  ✅ CI/NIT: {ci_nit}')
        try:
            driver.hide_keyboard()
            time.sleep(1)
        except:
            pass
    except:
        try:
            ci_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[contains(@hint, 'Ci o nit')]")
            ci_input.click()
            time.sleep(1)
            ci_input.clear()
            ci_input.send_keys(ci_nit)
            print(f'  ✅ CI/NIT: {ci_nit}')
            try:
                driver.hide_keyboard()
                time.sleep(1)
            except:
                pass
        except Exception as e:
            print(f'  ⚠️ Error al ingresar CI/NIT: {e}')
    print('  📝 Buscando botón Continuar...')
    time.sleep(2)
    try:
        continuar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")
        continuar_btn.click()
        print('  ✅ Click en Continuar (validación)')
        time.sleep(3)
        return True
    except:
        try:
            continuar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Continuar') and @clickable='true']")
            continuar_btn.click()
            print('  ✅ Click en Continuar (validación - texto)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Continuar: {e}')
            return False

def confirmar_transaccion_otro_banco(driver):
    """Espera la clave temporal y confirma la transacción."""
    print('  📝 Confirmando transacción (paso 2)...')
    time.sleep(3)
    print('  ⏳ Esperando clave temporal...')
    time.sleep(3)
    print('  📝 Buscando botón Confirmar transacción...')
    time.sleep(2)
    try:
        confirmar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Confirmar transacción']")
        confirmar_btn.click()
        print('  ✅ Click en Confirmar transacción')
        time.sleep(3)
        return True
    except:
        try:
            confirmar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Confirmar') and @clickable='true']")
            confirmar_btn.click()
            print('  ✅ Click en Confirmar transacción (texto)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Confirmar transacción: {e}')
            return False

def handle_success_modal_otro_banco(driver):
    print('  📝 Manejando modal de éxito...')
    time.sleep(3)
    try:
        driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Cuenta de beneficiario') and contains(@content-desc, 'guardada con éxito')]")
        print('  ✅ Mensaje de éxito detectado')
        time.sleep(1)
    except:
        try:
            driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'guardada con éxito')]")
            print('  ✅ Mensaje de éxito detectado (texto)')
            time.sleep(1)
        except:
            print('  ⚠️ No se detectó mensaje de éxito')
            return True
    try:
        continuar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")
        continuar_btn.click()
        print('  ✅ Click en Continuar (modal éxito)')
        time.sleep(2)
        return True
    except:
        try:
            continuar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Continuar') and @clickable='true']")
            continuar_btn.click()
            print('  ✅ Click en Continuar (modal éxito - texto)')
            time.sleep(2)
            return True
        except:
            print('  ⚠️ No se encontró botón Continuar en modal')
            return True

def select_source_account(driver, numero_cuenta=None, tipo_cuenta=None, index=0):
    print('  📝 Seleccionando cuenta origen...')
    time.sleep(3)
    try:
        account_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Selecciona una cuenta')]")
        account_btn.click()
        print("  ✅ Click en 'Selecciona una cuenta'")
        time.sleep(2)
    except:
        try:
            account_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Selecciona una cuenta') and @clickable='true']")
            account_btn.click()
            print("  ✅ Click en 'Selecciona una cuenta' (por texto)")
            time.sleep(2)
        except Exception as e:
            print(f"  ❌ No se encontró 'Selecciona una cuenta': {e}")
            return False
    print('  ⏳ Esperando modal de cuentas...')
    time.sleep(2)
    seleccionado = False
    if numero_cuenta:
        try:
            account_btn = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{numero_cuenta}') and @clickable='true']")
            account_btn.click()
            print(f'  ✅ Cuenta origen seleccionada por número: {numero_cuenta}')
            seleccionado = True
        except:
            pass
    if tipo_cuenta and (not seleccionado):
        try:
            account_btn = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{tipo_cuenta}') and @clickable='true']")
            account_btn.click()
            print(f'  ✅ Cuenta origen seleccionada por tipo: {tipo_cuenta}')
            seleccionado = True
        except:
            pass
    if not seleccionado:
        try:
            account_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'CUENTA CORRIENTE') and @clickable='true']")
            account_btn.click()
            print('  ✅ Cuenta CORRIENTE seleccionada (fallback)')
            seleccionado = True
        except:
            pass
    if not seleccionado:
        try:
            account_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'CUENTA DE AHORRO') and @clickable='true']")
            account_btn.click()
            print('  ✅ Cuenta AHORRO seleccionada (fallback)')
            seleccionado = True
        except:
            pass
    if not seleccionado:
        print('  ❌ No se encontró cuenta origen para seleccionar')
        return False
    time.sleep(2)
    return True

def enter_amount(driver, monto):
    print(f'  📝 Ingresando monto: {monto}')
    time.sleep(2)
    monto_input = None
    try:
        monto_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='0.00']")
        print("     ✅ Encontrado por hint '0.00'")
    except:
        pass
    if not monto_input:
        try:
            monto_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='Monto']")
            print("     ✅ Encontrado por hint 'Monto'")
        except:
            pass
    if not monto_input:
        try:
            edits = driver.find_elements(AppiumBy.CLASS_NAME, 'android.widget.EditText')
            for e in edits:
                bounds = e.get_attribute('bounds') or ''
                if '13' in bounds and '14' in bounds:
                    monto_input = e
                    print('     ✅ Encontrado por bounds (Y 13xx-14xx)')
                    break
        except:
            pass
    if not monto_input:
        try:
            edits = driver.find_elements(AppiumBy.CLASS_NAME, 'android.widget.EditText')
            if edits:
                monto_input = edits[0]
                print('     ✅ Encontrado como primer EditText')
        except:
            pass
    if not monto_input:
        print('  ❌ No se encontró el campo de monto')
        return False
    try:
        monto_input.click()
        time.sleep(1)
        monto_input.clear()
        time.sleep(0.5)
        monto_input.send_keys(str(monto))
        print('  ✅ Monto ingresado')
    except Exception as e:
        print(f'  ⚠️ Error al escribir monto: {e}')
        return False
    try:
        driver.hide_keyboard()
        time.sleep(1)
    except:
        try:
            driver.execute_script('mobile: clickGesture', {'x': 540, 'y': 1500})
            time.sleep(1)
        except:
            pass
    return True

def enter_concept(driver, concepto):
    print(f'  📝 Ingresando concepto: {concepto}')
    time.sleep(2)
    concept_input = None
    try:
        concept_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='Mín. 5 Caracteres']")
        print("     ✅ Encontrado por hint 'Mín. 5 Caracteres'")
    except:
        pass
    if not concept_input:
        try:
            concept_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='Min. 5 Caracteres']")
            print("     ✅ Encontrado por hint 'Min. 5 Caracteres'")
        except:
            pass
    if not concept_input:
        try:
            concept_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='Describe el concepto']")
            print("     ✅ Encontrado por hint 'Describe el concepto'")
        except:
            pass
    if not concept_input:
        try:
            concept_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[contains(@hint, 'Caracteres')]")
            print("     ✅ Encontrado por hint contains 'Caracteres'")
        except:
            pass
    if not concept_input:
        try:
            concept_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[contains(@hint, 'oncepto')]")
            print("     ✅ Encontrado por hint contains 'oncepto'")
        except:
            pass
    if not concept_input:
        try:
            edits = driver.find_elements(AppiumBy.CLASS_NAME, 'android.widget.EditText')
            for e in edits:
                bounds = e.get_attribute('bounds') or ''
                if '1590' in bounds or ('16' in bounds and '17' in bounds):
                    concept_input = e
                    print('     ✅ Encontrado por bounds (Y 15xx-17xx)')
                    break
        except:
            pass
    if not concept_input:
        try:
            edits = driver.find_elements(AppiumBy.CLASS_NAME, 'android.widget.EditText')
            if edits:
                concept_input = edits[-1]
                print('     ✅ Encontrado como último EditText')
        except:
            pass
    if not concept_input:
        print('  ❌ No se encontró el campo de concepto')
        return False
    try:
        concept_input.click()
        time.sleep(1)
        concept_input.clear()
        time.sleep(0.5)
        concept_input.send_keys(concepto)
        print('  ✅ Concepto ingresado')
    except Exception as e:
        print(f'  ⚠️ Error al escribir concepto: {e}')
        return False
    try:
        driver.hide_keyboard()
        time.sleep(1)
    except:
        try:
            driver.execute_script('mobile: clickGesture', {'x': 540, 'y': 1500})
            time.sleep(1)
        except:
            pass
    return True

def click_continuar_transfer(driver):
    print('  📝 Click en Continuar (transferencia)...')
    time.sleep(2)
    try:
        driver.hide_keyboard()
        time.sleep(1)
    except:
        pass
    try:
        continuar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")
        continuar_btn.click()
        print('  ✅ Click en Continuar')
        time.sleep(3)
        return True
    except:
        try:
            continuar_btn = driver.find_element(AppiumBy.ACCESSIBILITY_ID, 'Continuar')
            continuar_btn.click()
            print('  ✅ Click en Continuar (Accessibility)')
            time.sleep(3)
            return True
        except:
            print('  ❌ Error al clickear Continuar')
            return False

def scroll_movimientos(driver, scrolls=3):
    print(f'  📝 Haciendo scroll para ver movimientos...')
    time.sleep(2)
    for i in range(scrolls):
        try:
            driver.swipe(500, 1200, 500, 400, 500)
            time.sleep(1)
            print(f'  🔄 Scroll {i + 1}/{scrolls}')
        except:
            pass
    print('  ✅ Scroll completado')
    return True

def click_confirmar(driver):
    print('  📝 Click en Confirmar...')
    time.sleep(3)
    try:
        confirmar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Confirmar')]")
        confirmar_btn.click()
        print('  ✅ Click en Confirmar')
        time.sleep(3)
        return True
    except:
        print('  ❌ Error al clickear Confirmar')
        return False

def verify_transfer_success(driver):
    print('  📝 Verificando transferencia...')
    time.sleep(3)
    try:
        driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Transferencia exitosa')]")
        print('  ✅ TRANSFERENCIA EXITOSA!')
        return True
    except:
        pass
    print('  ⚠️ No se pudo verificar el estado de la transferencia')
    return False

def realizar_transferencia_nuevo_beneficiario_otro_banco(driver, monto, concepto, nombre_beneficiario, cuenta_beneficiario, ci_nit, nombre_banco='Banco Bisa', tipo_cuenta_beneficiario='Cuenta corriente', origen_numero_cuenta=None, origen_tipo_cuenta=None, origen_index=0, tiempos=None, reporte=None, paso_inicial=6):
    print(f'\n💰 INICIANDO TRANSFERENCIA A NUEVO BENEFICIARIO EN OTRO BANCO de Bs. {monto}')
    print(f'🏦 Banco: {nombre_banco}')
    print(f'👤 Beneficiario: {nombre_beneficiario}')
    print(f'🏦 Cuenta: {cuenta_beneficiario}')
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Navegar a Transferencias')
    if not navigate_to_transfer(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla Transferencias', "Se accedió a la pantalla de Transferencias desde el home. Se muestra el botón 'Nuevo beneficiario'.", espera=2.0)
    paso_num += 1
    tiempos.start('2. Nuevo Beneficiario')
    if not click_nuevo_beneficiario(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Nuevo Beneficiario - Selección de banco', "Se accedió al flujo de 'Nuevo beneficiario'. Se muestra la lista de bancos destino disponibles.", espera=1.5)
    paso_num += 1
    tiempos.start('3. Seleccionar banco destino')
    if not select_banco_destino(driver, nombre_banco=nombre_banco):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Banco destino: {nombre_banco}', f"Se seleccionó el banco destino: '{nombre_banco}'.", espera=1.5)
    paso_num += 1
    tiempos.start('4. Datos beneficiario (1)')
    if not fill_beneficiary_data_otro_banco_parte1(driver, nombre_beneficiario, cuenta_beneficiario, ci_nit, tipo_cuenta_beneficiario):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Datos del beneficiario', f'Se ingresaron los datos del beneficiario: Nombre: {nombre_beneficiario}, Cuenta: {cuenta_beneficiario}, CI/NIT: {ci_nit}, Tipo: {tipo_cuenta_beneficiario}.', espera=1.5)
    paso_num += 1
    tiempos.start('5. Confirmar transacción')
    if not confirmar_transaccion_otro_banco(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Confirmar transacción', 'Se confirmó la transacción con la clave temporal. Se validó el alta del nuevo beneficiario.', espera=1.5)
    paso_num += 1
    tiempos.start('6. Modal de éxito')
    handle_success_modal_otro_banco(driver)
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Modal - Beneficiario guardado', 'Se mostró el modal confirmando que la cuenta del beneficiario fue guardada con éxito.', espera=1.5)
    paso_num += 1
    tiempos.start('7. Seleccionar cuenta origen')
    if not select_source_account(driver, numero_cuenta=origen_numero_cuenta, tipo_cuenta=origen_tipo_cuenta, index=origen_index):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        detalle_origen = []
        if origen_numero_cuenta:
            detalle_origen.append(f'Número: {origen_numero_cuenta}')
        if origen_tipo_cuenta:
            detalle_origen.append(f'Tipo: {origen_tipo_cuenta}')
        if not detalle_origen:
            detalle_origen.append(f'Índice: {origen_index}')
        reporte.capturar_paso(paso_num, 'Cuenta origen seleccionada', f"Se seleccionó la cuenta de origen. {' | '.join(detalle_origen)}.", espera=1.5)
    paso_num += 1
    tiempos.start('8. Ingresar monto')
    if not enter_amount(driver, monto):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Monto: Bs. {monto}', f'Se ingresó el monto de la transferencia: Bs. {monto}.', espera=1.0)
    paso_num += 1
    tiempos.start('9. Ingresar concepto')
    if not enter_concept(driver, concepto):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Concepto: {concepto}', f"Se ingresó el concepto de la transferencia: '{concepto}'.", espera=1.0)
    paso_num += 1
    tiempos.start('10. Continuar')
    if not click_continuar_transfer(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Continuar (datos completos)', 'Se hizo clic en Continuar. Se avanzó a la pantalla de verificación.', espera=1.5)
    paso_num += 1
    tiempos.start('11. Scroll pantalla')
    scroll_movimientos(driver, scrolls=1)
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Scroll en pantalla de verificación', 'Se hizo scroll en la pantalla para verificar el detalle de la transacción.', espera=1.0)
    paso_num += 1
    tiempos.start('12. Confirmar')
    if not click_confirmar(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Confirmar transferencia', f"Se confirmó la transferencia por Bs. {monto} al beneficiario '{nombre_beneficiario}' en {nombre_banco}.", espera=1.5)
    paso_num += 1
    tiempos.start('13. Verificar transferencia')
    success = verify_transfer_success(driver)
    tiempos.stop()
    if reporte:
        estado_txt = 'exitosa' if success else 'con estado desconocido'
        reporte.capturar_paso(paso_num, f'Pantalla de resultado - {estado_txt}', f'Se verificó el resultado de la transferencia: {estado_txt}.', espera=1.5)
    paso_num += 1
    tiempos.start('14. Volver al home')
    go_back_home(driver)
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Nuevo Beneficiario Otro Banco finalizado', 'Se regresó exitosamente al home. El flujo de transferencia a un nuevo beneficiario en otro banco ha terminado.', espera=1.5)
    paso_num += 1
    if success:
        print('\n✅ TRANSFERENCIA A NUEVO BENEFICIARIO EN OTRO BANCO COMPLETADA EXITOSAMENTE')
    else:
        print('\n⚠️ TRANSFERENCIA A NUEVO BENEFICIARIO EN OTRO BANCO COMPLETADA (estado desconocido)')
    return success
if __name__ == '__main__':
    _input_cfg = load_input_defaults('transfer_nuevo_beneficiario_otro_banco_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO COMPLETO: LOGIN + TRANSFERENCIA A NUEVO BENEFICIARIO EN OTRO BANCO + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    monto = _input_cfg.get('monto', 1)
    concepto = _input_cfg.get('concepto', 'Transferencia a nuevo beneficiario otro banco')
    NOMBRE_BENEFICIARIO = _input_cfg.get('NOMBRE_BENEFICIARIO', 'JUAN PEREZ GONZALES I')
    CUENTA_BENEFICIARIO = _input_cfg.get('CUENTA_BENEFICIARIO', '10000012345680')
    CI_NIT = _input_cfg.get('CI_NIT', '1234567')
    NOMBRE_BANCO = _input_cfg.get('NOMBRE_BANCO', 'Banco Bisa')
    TIPO_CUENTA_BENEFICIARIO = _input_cfg.get('TIPO_CUENTA_BENEFICIARIO', 'Cuenta corriente')
    ORIGEN_NUMERO_CUENTA = _input_cfg.get('ORIGEN_NUMERO_CUENTA', None)
    ORIGEN_TIPO_CUENTA = _input_cfg.get('ORIGEN_TIPO_CUENTA', 'CUENTA DE AHORRO')
    ORIGEN_INDEX = _input_cfg.get('ORIGEN_INDEX', 0)
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Transferencia_Nuevo_Beneficiario_Otro_Banco')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f'💰 Monto: Bs. {monto}')
    print(f'📝 Concepto: {concepto}')
    print(f'🏦 Banco destino: {NOMBRE_BANCO}')
    print(f'👤 Beneficiario: {NOMBRE_BENEFICIARIO}')
    print(f'🏦 Cuenta: {CUENTA_BENEFICIARIO}')
    print(f'🆔 CI/NIT: {CI_NIT}')
    print(f'📋 Tipo cuenta: {TIPO_CUENTA_BENEFICIARIO}')
    print(f'🎯 Origen: cuenta={ORIGEN_NUMERO_CUENTA}, tipo={ORIGEN_TIPO_CUENTA}, index={ORIGEN_INDEX}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Monto': f'Bs. {monto}', 'Concepto': concepto, 'Banco destino': NOMBRE_BANCO, 'Beneficiario': NOMBRE_BENEFICIARIO, 'Cuenta beneficiario': CUENTA_BENEFICIARIO, 'CI/NIT': CI_NIT, 'Tipo de cuenta': TIPO_CUENTA_BENEFICIARIO, 'Origen - Número': ORIGEN_NUMERO_CUENTA or 'N/A', 'Origen - Tipo': ORIGEN_TIPO_CUENTA or 'N/A', 'Origen - Índice': ORIGEN_INDEX})
    login_ok = _input_cfg.get('login_ok', False)
    transfer_ok = _input_cfg.get('transfer_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            transfer_ok = realizar_transferencia_nuevo_beneficiario_otro_banco(driver, monto=monto, concepto=concepto, nombre_beneficiario=NOMBRE_BENEFICIARIO, cuenta_beneficiario=CUENTA_BENEFICIARIO, ci_nit=CI_NIT, nombre_banco=NOMBRE_BANCO, tipo_cuenta_beneficiario=TIPO_CUENTA_BENEFICIARIO, origen_numero_cuenta=ORIGEN_NUMERO_CUENTA, origen_tipo_cuenta=ORIGEN_TIPO_CUENTA, origen_index=ORIGEN_INDEX, tiempos=tiempos, reporte=reporte, paso_inicial=6)
            if transfer_ok:
                print('\n🎉 TRANSFERENCIA A NUEVO BENEFICIARIO EN OTRO BANCO EXITOSA!')
            else:
                print('\n❌ TRANSFERENCIA A NUEVO BENEFICIARIO EN OTRO BANCO FALLIDA')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and transfer_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login          : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Transferencia  : {('✅ OK' if transfer_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

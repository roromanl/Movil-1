"""
Flujo Apertura Cripto (botón directo del home) + reporte Word.
Pasos: Login → Cripto (home) → Modal Alerta → Abrir cripto fie →
       Cerrar link externo → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import volver_home_cripto
from framework.common.ui_helpers import _esta_en_home as _esta_en_home, _seleccionar_opcion_case_insensitive__2f3c9d8754 as _seleccionar_opcion_case_insensitive

def click_cripto_home(driver):
    print('  📝 Click en Cripto (home)...')
    time.sleep(2)
    try:
        cripto_btn = driver.find_element(AppiumBy.ID, 'home_btn_cripto')
        cripto_btn.click()
        print('  ✅ Click en Cripto (ID: home_btn_cripto)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        cripto_btn = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='home_btn_cripto' and @clickable='true']")
        cripto_btn.click()
        print('  ✅ Click en Cripto (XPATH resource-id)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        cripto_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Cripto\nCripto']")
        cripto_btn.click()
        print('  ✅ Click en Cripto (content-desc exacto)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        contenedor = driver.find_element(AppiumBy.ID, 'shared_row_quick_actions')
        cripto_btn = contenedor.find_element(AppiumBy.XPATH, ".//android.widget.Button[contains(@content-desc, 'Cripto')]")
        cripto_btn.click()
        print('  ✅ Click en Cripto (dentro de shared_row_quick_actions)')
        time.sleep(3)
        return True
    except:
        pass
    if _seleccionar_opcion_case_insensitive(driver, 'Cripto', timeout=5, debug=True):
        print('  ✅ Click en Cripto (case-insensitive)')
        time.sleep(3)
        return True
    print('  ❌ Error al clickear Cripto')
    return False

def click_abrir_cripto_fie(driver):
    print("  📝 Click en 'Abrir cripto fie' (modal Alerta)...")
    time.sleep(2)
    try:
        driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Cripto fie']")
        print("  ✅ Modal 'Alerta' detectado (título 'Cripto fie')")
    except:
        print("  ⚠️ No se detectó el título 'Cripto fie' del modal, continuando...")
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Abrir cripto fie']")
        btn.click()
        print("  ✅ Click en 'Abrir cripto fie' (content-desc exacto)")
        time.sleep(5)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(translate(@content-desc, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'abrir cripto fie')]")
        btn.click()
        print("  ✅ Click en 'Abrir cripto fie' (case-insensitive)")
        time.sleep(5)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Abrir') and @clickable='true']")
        btn.click()
        print("  ✅ Click en botón con 'Abrir' (fallback)")
        time.sleep(5)
        return True
    except:
        pass
    if _seleccionar_opcion_case_insensitive(driver, 'Abrir cripto fie', timeout=5, debug=True):
        print("  ✅ Click en 'Abrir cripto fie' (helper)")
        time.sleep(5)
        return True
    print("  ❌ Error al clickear 'Abrir cripto fie'")
    return False

def cerrar_link_externo(driver):
    print('  📝 Cerrando link externo...')
    time.sleep(4)
    try:
        contextos = driver.contexts
        print(f'  🔍 Contextos disponibles: {contextos}')
        for ctx in contextos:
            if 'WEBVIEW' in ctx:
                try:
                    driver.switch_to.context(ctx)
                    print(f'  ℹ️ Cambiado a contexto: {ctx}')
                    time.sleep(1)
                    try:
                        driver.find_element(AppiumBy.XPATH, "//*[@id='close' or @class='close' or contains(@aria-label, 'Close') or contains(@aria-label, 'Cerrar')]").click()
                        print('  ✅ Link cerrado desde web')
                        time.sleep(2)
                        driver.switch_to.context('NATIVE_APP')
                        return True
                    except:
                        pass
                    driver.switch_to.context('NATIVE_APP')
                except:
                    pass
    except:
        pass
    try:
        cerrar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Cerrar']")
        cerrar_btn.click()
        print('  ✅ Click en Cerrar (content-desc)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        cerrar_btn = driver.find_element(AppiumBy.XPATH, "//android.view.View[@content-desc='Cerrar' and @clickable='true']")
        cerrar_btn.click()
        print('  ✅ Click en Cerrar (View)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        regresar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Regresar']")
        regresar.click()
        print('  ✅ Click en Regresar')
        time.sleep(2)
        return True
    except:
        pass
    try:
        aceptar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Aceptar']")
        aceptar.click()
        print('  ✅ Click en Aceptar')
        time.sleep(2)
        return True
    except:
        pass
    try:
        for i in range(2):
            driver.back()
            print(f'  ✅ Back {i + 1} ejecutado')
            time.sleep(1.5)
        return True
    except Exception as e:
        print(f'  ⚠️ Error al cerrar link: {e}')
        return False

def realizar_apertura_cripto(driver, reporte=None, tiempos=None, paso_inicial=6):
    print(f'\n🔷 INICIANDO APERTURA CRIPTO')
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Click Cripto (home)')
    if not click_cripto_home(driver):
        print('  ❌ Error al clickear Cripto')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Modal Alerta - Cripto fie', "Se abrió el modal 'Alerta' con el título 'Cripto fie' solicitando confirmación para abrir el servicio de criptomonedas.", espera=1.5)
    paso_num += 1
    tiempos.start('2. Abrir cripto fie')
    if not click_abrir_cripto_fie(driver):
        print("  ❌ Error al clickear 'Abrir cripto fie'")
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Servicio Cripto abierto', "Se hizo clic en 'Abrir cripto fie'. Se abre el link/servicio externo de criptomonedas.", espera=2.0)
    paso_num += 1
    tiempos.start('3. Cerrar link')
    if not cerrar_link_externo(driver):
        print('  ⚠️ No se pudo cerrar el link, continuando...')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Link externo cerrado', 'Se cerró el link/servicio externo de criptomonedas y se regresó a la app.', espera=1.5)
    paso_num += 1
    tiempos.start('4. Volver al home')
    if not volver_home_cripto(driver):
        print('  ⚠️ No se pudo volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Apertura Cripto finalizado', 'Se regresó exitosamente al home. El flujo de apertura de Cripto ha terminado.', espera=1.5)
    paso_num += 1
    print('\n✅ APERTURA CRIPTO COMPLETADA EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('cripto_apertura_directo_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO: LOGIN + APERTURA CRIPTO (botón directo) + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Apertura_Cripto')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Acceso': 'Botón Cripto del home', 'Modal inicial': 'Alerta - Cripto fie', 'Acción': 'Abrir cripto fie'})
    login_ok = _input_cfg.get('login_ok', False)
    cripto_ok = _input_cfg.get('cripto_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            cripto_ok = realizar_apertura_cripto(driver, reporte=reporte, tiempos=tiempos, paso_inicial=6)
            if cripto_ok:
                print('\n🎉 APERTURA CRIPTO EXITOSA!')
            else:
                print('\n❌ APERTURA CRIPTO FALLIDA')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and cripto_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login           : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Apertura Cripto : {('✅ OK' if cripto_ok else '❌ FALLÓ')}")
        print(f'   Carpeta         : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

"""
Flujo Estado de Cuenta del último mes con:
  - Capturas de pantalla por cada paso
  - Reporte Word (.docx) con datos generales + capturas
  - Carpeta autogenerada con fecha/hora
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import go_back__0ec9d4708b as go_back, go_back_home__0684e34fc0 as go_back_home
from framework.common.ui_helpers import _esta_en_home as _esta_en_home, _seleccionar_opcion_case_insensitive__f21faf0807 as _seleccionar_opcion_case_insensitive

def select_account_type(driver, tipo_cuenta):
    print(f'  📝 Seleccionando cuenta: {tipo_cuenta}...')
    time.sleep(3)
    if _seleccionar_opcion_case_insensitive(driver, tipo_cuenta, timeout=5):
        print(f'  ✅ Cuenta {tipo_cuenta} seleccionada')
        time.sleep(3)
        return True
    print(f'  ❌ Error al seleccionar cuenta {tipo_cuenta}')
    try:
        opciones = driver.find_elements(AppiumBy.XPATH, "//*[@clickable='true' and @content-desc and string-length(@content-desc) > 3]")
        print(f'  🔍 Opciones visibles ({len(opciones)}):')
        for o in opciones[:15]:
            desc = (o.get_attribute('content-desc') or '').replace('\n', ' | ')
            if len(desc) < 80:
                print(f'     - {desc}')
    except:
        pass
    return False

def click_estado_cuenta_ultimo_mes(driver, max_scrolls=8, pausa_scroll=0.6, debug=True):
    print("  📝 Buscando 'Estado de cuenta del último mes'...")
    texto_objetivo = 'Estado de cuenta del último mes'
    texto_lower = texto_objetivo.lower()
    variantes = ['Estado de cuenta del último mes', 'Estado de Cuenta del Último Mes', 'estado de cuenta del ultimo mes']

    def _buscar_sin_scroll():
        """Busca el elemento en la pantalla actual con múltiples estrategias."""
        for texto in variantes:
            try:
                btn = driver.find_element(AppiumBy.XPATH, f"//*[@content-desc='{texto}' and @clickable='true']")
                if btn.is_displayed():
                    btn.click()
                    print(f"  ✅ Click en '{texto}' (content-desc exacto)")
                    time.sleep(5)
                    return True
            except:
                pass
        for texto in variantes:
            try:
                btn = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{texto}') and @clickable='true']")
                if btn.is_displayed():
                    btn.click()
                    print(f"  ✅ Click en '{texto}' (contains)")
                    time.sleep(5)
                    return True
            except:
                pass
        try:
            btn = driver.find_element(AppiumBy.XPATH, f"//*[contains(translate(@content-desc, 'ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÑ', 'abcdefghijklmnopqrstuvwxyzáéíóúñ'), '{texto_lower}') and @clickable='true']")
            if btn.is_displayed():
                btn.click()
                print(f"  ✅ Click en 'Estado de cuenta' (case-insensitive)")
                time.sleep(5)
                return True
        except:
            pass
        try:
            btn = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, 'Estado de cuenta') and @clickable='true']")
            if btn.is_displayed():
                btn.click()
                print(f"  ✅ Click en 'Estado de cuenta...' (contains parcial)")
                time.sleep(5)
                return True
        except:
            pass
        try:
            btn = driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{texto_objetivo}') and @clickable='true']")
            if btn.is_displayed():
                btn.click()
                print(f"  ✅ Click en 'Estado de cuenta' (texto)")
                time.sleep(5)
                return True
        except:
            pass
        return False
    print('  🔍 Buscando sin scroll...')
    if _buscar_sin_scroll():
        return True
    print('  🔄 Buscando con scroll incremental...')
    for intento in range(max_scrolls):
        try:
            driver.swipe(500, 1200, 500, 700, 500)
            time.sleep(pausa_scroll)
            print(f'    Scroll {intento + 1}/{max_scrolls}')
            if _buscar_sin_scroll():
                return True
        except Exception as e:
            print(f'  ⚠️ Error en scroll {intento + 1}: {e}')
    print('  🔄 Volviendo arriba...')
    for _ in range(max_scrolls + 2):
        try:
            driver.swipe(500, 700, 500, 1200, 300)
            time.sleep(0.3)
        except:
            pass
    time.sleep(0.5)
    if _buscar_sin_scroll():
        return True
    if debug:
        print('  🔍 DEBUG - Elementos clickables visibles:')
        try:
            elementos = driver.find_elements(AppiumBy.XPATH, "//*[@clickable='true' and @content-desc]")
            print(f'  🔍 Total clickables con content-desc: {len(elementos)}')
            for i, elem in enumerate(elementos):
                desc = (elem.get_attribute('content-desc') or '').replace('\n', ' | ')
                if desc and len(desc) < 120:
                    print(f"    [{i}] '{desc}'")
            tiene_estado = any(('estado' in (e.get_attribute('content-desc') or '').lower() for e in elementos))
            if not tiene_estado:
                print("\n  🚨 NO hay ningún elemento con 'estado' en content-desc")
                print('  📄 Primeros 4000 chars del page_source:')
                try:
                    ps = driver.page_source
                    print(ps[:4000])
                except:
                    pass
        except Exception as e:
            print(f'  ⚠️ Error en debug: {e}')
    print("  ❌ No se encontró 'Estado de cuenta del último mes'")
    return False

def handle_pdf_download(driver, espera_inicial=5, espera_descarga=5, espera_final=5):
    print('  📝 Procesando descarga del PDF...')
    time.sleep(espera_inicial)
    modal_descarga = False
    try:
        driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Descargando') or contains(@text, 'Descargando') or contains(@content-desc, 'descargando') or contains(@text, 'descargando')]")
        print('  ⏳ Descargando PDF...')
        modal_descarga = True
        time.sleep(espera_descarga)
    except:
        print('  ℹ️ No se detectó indicador de descarga')
    boton_cerrado = False
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Aceptar']")
        btn.click()
        print('  ✅ Click en Aceptar (modal descarga)')
        time.sleep(2)
        boton_cerrado = True
    except:
        pass
    if not boton_cerrado:
        try:
            btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@text, 'Aceptar')]")
            btn.click()
            print('  ✅ Click en Aceptar (texto - modal descarga)')
            time.sleep(2)
            boton_cerrado = True
        except:
            pass
    if not boton_cerrado:
        try:
            btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Continuar') or contains(@text, 'Continuar')]")
            btn.click()
            print('  ✅ Click en Continuar (modal descarga)')
            time.sleep(2)
            boton_cerrado = True
        except:
            pass
    if not boton_cerrado:
        try:
            btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Cerrar']")
            btn.click()
            print('  ✅ Click en Cerrar (modal descarga)')
            time.sleep(2)
            boton_cerrado = True
        except:
            pass
    if not boton_cerrado:
        try:
            btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Regresar']")
            btn.click()
            print('  ✅ Click en Regresar (modal descarga)')
            time.sleep(2)
            boton_cerrado = True
        except:
            pass
    if not boton_cerrado:
        if modal_descarga:
            print('  ⚠️ Se detectó descarga pero no se encontró botón de cierre')
        else:
            print('  ℹ️ No se detectó modal de descarga')
    print(f'  ⏳ Esperando finalización de descarga ({espera_final}s)...')
    time.sleep(espera_final)
    return True

def realizar_estado_cuenta(driver, tipo_cuenta='AHORRO', reporte=None, tiempos=None, paso_inicial=6):
    print(f'\n📄 INICIANDO ESTADO DE CUENTA DEL ÚLTIMO MES - {tipo_cuenta}')
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Tipo de cuenta')
    if not select_account_type(driver, tipo_cuenta):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f"Cuenta '{tipo_cuenta}' seleccionada", f"Se seleccionó la cuenta '{tipo_cuenta}' desde el home para consultar su estado de cuenta.", espera=1.5)
    paso_num += 1
    time.sleep(3)
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla de cuenta - Opciones disponibles', "Se muestra la pantalla de la cuenta con las opciones disponibles, incluyendo 'Estado de cuenta del último mes'.", espera=1.0)
    paso_num += 1
    tiempos.start('2. Estado de cuenta')
    if not click_estado_cuenta_ultimo_mes(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Estado de cuenta solicitado', "Se hizo clic en 'Estado de cuenta del último mes'. El sistema ha comenzado a generar/descargar el PDF.", espera=1.0)
    paso_num += 1
    tiempos.start('3. Descarga PDF')
    handle_pdf_download(driver)
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Descarga de PDF finalizada', 'El estado de cuenta se ha descargado correctamente. Se muestra la pantalla tras el proceso de descarga.', espera=1.0)
    paso_num += 1
    tiempos.start('4. Volver atrás')
    go_back(driver)
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Regreso a la cuenta', 'Se regresó a la pantalla anterior tras completar la descarga.', espera=1.0)
    paso_num += 1
    tiempos.start('5. Volver al home')
    go_back_home(driver)
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo finalizado', 'Se regresó exitosamente al home. El flujo de estado de cuenta ha terminado.', espera=1.5)
    paso_num += 1
    print('\n✅ ESTADO DE CUENTA DESCARGADO EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('consolidado_estado_cuenta_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO: LOGIN + ESTADO DE CUENTA + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    tipo_cuenta = _input_cfg.get('tipo_cuenta', 'C. CORRIENTES')
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Estado_Cuenta')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f'🏦 Cuenta: {tipo_cuenta}')
    print(f'📄 Estado de cuenta: Último mes')
    print(f'📄 Nombre de la prueba: {NOMBRE_PRUEBA}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Cuenta consultada': tipo_cuenta, 'Tipo de estado de cuenta': 'Último mes'})
    login_ok = _input_cfg.get('login_ok', False)
    estado_cuenta_ok = _input_cfg.get('estado_cuenta_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            estado_cuenta_ok = realizar_estado_cuenta(driver, tipo_cuenta=tipo_cuenta, reporte=reporte, tiempos=tiempos, paso_inicial=6)
            if estado_cuenta_ok:
                print('\n🎉 ESTADO DE CUENTA DESCARGADO EXITOSAMENTE!')
            else:
                print('\n❌ DESCARGA DE ESTADO DE CUENTA FALLIDA')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and estado_cuenta_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login          : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Estado cuenta  : {('✅ OK' if estado_cuenta_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

"""
Flujo Búsqueda de Movimientos T. Crédito + reporte Word.
Pasos: Login → T. CRÉDITO → Movimientos (inferior) → Lupa
       → Búsqueda → Consumo → Fecha Desde → Fecha Hasta → Buscar
       → Seleccionar movimiento → Detalle → Cerrar → Regresar → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import re
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import volver_atras_tc__e16eee4353 as volver_atras_tc, volver_home__71a629aeab as volver_home
from framework.common.ui_helpers import _esta_en_home as _esta_en_home, _seleccionar_opcion_case_insensitive__f21faf0807 as _seleccionar_opcion_case_insensitive, _ingresar_texto_en_campo as _ingresar_texto_en_campo

def ir_a_tarjeta_credito(driver, max_intentos=8):
    print('  📝 Navegando a T. CRÉDITO...')
    time.sleep(3)
    texto_objetivo = 'T. CRÉDITO'

    def _buscar_en_pantalla():
        try:
            tc = driver.find_element(AppiumBy.XPATH, f"//android.view.View[@content-desc='{texto_objetivo}']")
            tc.click()
            print('  ✅ Click en T. CRÉDITO (content-desc exacto)')
            time.sleep(3)
            return True
        except:
            pass
        try:
            tc = driver.find_element(AppiumBy.XPATH, f"//*[contains(translate(@content-desc, 'ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÑ.', 'abcdefghijklmnopqrstuvwxyzáéíóúñ.'), 't. crédito') and @clickable='true']")
            tc.click()
            print('  ✅ Click en T. CRÉDITO (case-insensitive)')
            time.sleep(3)
            return True
        except:
            pass
        try:
            tc = driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{texto_objetivo}') and @clickable='true']")
            tc.click()
            print('  ✅ Click en T. CRÉDITO (texto)')
            time.sleep(3)
            return True
        except:
            pass
        try:
            tc = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, 'CRÉDITO') and @clickable='true']")
            tc.click()
            print('  ✅ Click en T. CRÉDITO (contains CRÉDITO)')
            time.sleep(3)
            return True
        except:
            pass
        return False
    if _buscar_en_pantalla():
        return True
    for intento in range(max_intentos):
        try:
            if intento % 2 == 0:
                print(f'  🔄 Scroll horizontal IZQUIERDA {intento // 2 + 1}...')
                driver.swipe(900, 1000, 200, 1000, 500)
            else:
                print(f'  🔄 Scroll horizontal DERECHA {intento // 2 + 1}...')
                driver.swipe(200, 1000, 900, 1000, 500)
            time.sleep(0.6)
            if _buscar_en_pantalla():
                return True
        except:
            pass
    print('  ❌ Error al seleccionar T. CRÉDITO')
    return False

def seleccionar_movimientos_inferior(driver):
    print("  📝 Seleccionando 'Movimientos' (opción inferior)...")
    time.sleep(2)
    try:
        movimientos = driver.find_element(AppiumBy.ID, 'credit_card_tab_movements')
        movimientos.click()
        print("  ✅ Click en 'Movimientos' (ID tab)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        movimientos = driver.find_element(AppiumBy.XPATH, "//android.view.View[@content-desc='Movimientos' and @clickable='true']")
        movimientos.click()
        print("  ✅ Click en 'Movimientos' (content-desc)")
        time.sleep(3)
        return True
    except:
        pass
    if _seleccionar_opcion_case_insensitive(driver, 'Movimientos', timeout=5, debug=True):
        print("  ✅ Click en 'Movimientos' (case-insensitive)")
        time.sleep(3)
        return True
    print("  ❌ Error al seleccionar 'Movimientos'")
    return False

def click_lupa_busqueda(driver):
    print('  📝 Click en lupa (búsqueda de movimientos)...')
    time.sleep(2)
    try:
        contenedor = driver.find_element(AppiumBy.XPATH, "//android.view.View[@content-desc='Movimientos']")
        botones = contenedor.find_elements(AppiumBy.XPATH, './/android.widget.Button')
        print(f"  🔍 Buttons dentro de 'Movimientos': {len(botones)}")
        for i, btn in enumerate(botones):
            bounds = btn.get_attribute('bounds') or ''
            text = btn.get_attribute('text') or ''
            desc = btn.get_attribute('content-desc') or ''
            match = re.findall('\\d+', bounds)
            if len(match) == 4:
                x1, y1, x2, y2 = map(int, match)
                ancho = x2 - x1
                alto = y2 - y1
                if ancho < 200 and alto < 200 and (x1 > 850) and (y1 < 1700):
                    print(f"  🔍 Candidato lupa: bounds={bounds}, text='{text}', desc='{desc}'")
                    btn.click()
                    print(f'  ✅ Click en lupa (por análisis de bounds)')
                    time.sleep(3)
                    return True
    except Exception as e:
        print(f'  ⚠️ Estrategia 1 falló: {str(e)[:80]}')
    try:
        x = (912 + 1038) // 2
        y = (1557 + 1683) // 2
        print(f'  🎯 Tap por coordenadas conocidas: ({x}, {y})')
        driver.execute_script('mobile: tap', {'x': x, 'y': y})
        print(f'  ✅ Tap ejecutado en coordenadas')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ⚠️ Estrategia 2 falló: {str(e)[:80]}')
    try:
        lupa = driver.find_element(AppiumBy.XPATH, "//android.view.View[@content-desc='Movimientos']/android.widget.Button[1]")
        lupa.click()
        print('  ✅ Click en lupa (primer Button hijo directo)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ⚠️ Estrategia 3 falló: {str(e)[:80]}')
    try:
        botones = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[@clickable='true']")
        candidatos = []
        for btn in botones:
            bounds = btn.get_attribute('bounds') or ''
            match = re.findall('\\d+', bounds)
            if len(match) == 4:
                x1, y1, x2, y2 = map(int, match)
                ancho = x2 - x1
                alto = y2 - y1
                if ancho < 200 and alto < 200:
                    candidatos.append((y1, -x1, btn, bounds))
        if candidatos:
            candidatos.sort()
            _, _, btn, bounds = candidatos[0]
            btn.click()
            print(f'  ✅ Click en lupa (candidato más arriba-derecha: {bounds})')
            time.sleep(3)
            return True
    except Exception as e:
        print(f'  ⚠️ Estrategia 4 falló: {str(e)[:80]}')
    print('  ❌ No se pudo clickear la lupa')
    return False

def ingresar_busqueda(driver, texto_busqueda=None):
    if not texto_busqueda:
        print(f'  ℹ️ Búsqueda de texto vacía - saltando campo')
        return True
    print(f"  📝 Ingresando búsqueda: '{texto_busqueda}'...")
    time.sleep(2)
    ok = _ingresar_texto_en_campo(driver, resource_id=None, valor=texto_busqueda, hints_alternativos=['Buscar', 'buscar'])
    if ok:
        print(f"  ✅ Búsqueda ingresada: '{texto_busqueda}'")
    else:
        print(f'  ❌ Error al ingresar búsqueda')
    return ok

def seleccionar_consumo(driver, consumo='Todos'):
    print(f"  📝 Seleccionando consumo: '{consumo}'...")
    time.sleep(2)
    try:
        combo = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Consumos']")
        combo.click()
        print("  ✅ Click en combo 'Consumos'")
        time.sleep(2)
    except:
        try:
            combo = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Consumo') and @clickable='true']")
            combo.click()
            print("  ✅ Click en combo 'Consumo' (contains)")
            time.sleep(2)
        except Exception as e:
            print(f'  ❌ Error al abrir combo: {e}')
            return False
    if _seleccionar_opcion_case_insensitive(driver, consumo, timeout=5, debug=True):
        print(f"  ✅ Consumo seleccionado: '{consumo}'")
        time.sleep(2)
        return True
    print(f"  ❌ Error al seleccionar consumo: '{consumo}'")
    return False

def select_fecha(driver, campo, fecha):
    print(f'  📝 Seleccionando fecha {campo}: {fecha}...')
    time.sleep(2)
    dia, mes, anio = fecha.split('/')
    dia_int = int(dia)
    mes_int = int(mes)
    anio_int = int(anio)
    meses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre']
    mes_nombre = meses[mes_int - 1]
    abierto = False
    try:
        fechas_views = driver.find_elements(AppiumBy.XPATH, "//android.view.View[@clickable='true' and contains(@content-desc, '/') and string-length(@content-desc) = 10]")
        print(f'  🔍 Campos de fecha encontrados: {len(fechas_views)}')
        if campo == 'Desde':
            if len(fechas_views) > 0:
                fechas_views[0].click()
                print(f'  ✅ Click en fecha {campo} (primer View)')
                abierto = True
            else:
                print(f'  ❌ No se encontró el campo para {campo}')
                return False
        elif len(fechas_views) > 1:
            fechas_views[1].click()
            print(f'  ✅ Click en fecha {campo} (segundo View)')
            abierto = True
        else:
            print(f'  ❌ No se encontró el campo para {campo}')
            return False
        if abierto:
            time.sleep(3)
    except Exception as e:
        print(f'  ❌ Error al abrir fecha {campo}: {e}')
        return False
    time.sleep(3)

    def obtener_mes_actual():
        try:
            titulo_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Enero') or contains(@content-desc, 'Febrero') or contains(@content-desc, 'Marzo') or contains(@content-desc, 'Abril') or contains(@content-desc, 'Mayo') or contains(@content-desc, 'Junio') or contains(@content-desc, 'Julio') or contains(@content-desc, 'Agosto') or contains(@content-desc, 'Septiembre') or contains(@content-desc, 'Octubre') or contains(@content-desc, 'Noviembre') or contains(@content-desc, 'Diciembre')]")
            return titulo_btn.get_attribute('content-desc') or ''
        except:
            return None
    encontrado = False
    for intento in range(24):
        titulo_actual = obtener_mes_actual()
        print(f'  📅 Mes actual: {titulo_actual}')
        if titulo_actual and mes_nombre in titulo_actual and (str(anio_int) in titulo_actual):
            print(f'  ✅ Mes correcto: {mes_nombre} {anio_int}')
            encontrado = True
            break
        try:
            mes_actual = None
            for i, nombre_mes in enumerate(meses, 1):
                if nombre_mes in titulo_actual:
                    mes_actual = i
                    break
            anios = re.findall('\\d{4}', titulo_actual)
            anio_actual = None
            if anios:
                anio_actual = int(anios[0])
            if mes_actual and anio_actual:
                diff_meses = (anio_int - anio_actual) * 12 + (mes_int - mes_actual)
                print(f'  📊 Diferencia de meses: {diff_meses}')
                if diff_meses > 0:
                    try:
                        siguiente_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Mes siguiente' and @clickable='true']")
                        siguiente_btn.click()
                        print(f'  🔄 Navegando al siguiente mes...')
                        time.sleep(1)
                    except:
                        try:
                            siguiente_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Mes siguiente']")
                            if siguiente_btn.get_attribute('enabled') == 'true':
                                siguiente_btn.click()
                                time.sleep(1)
                            else:
                                print(f"  ⚠️ Botón 'Mes siguiente' deshabilitado")
                                break
                        except:
                            print(f'  ⚠️ No se pudo navegar al siguiente mes')
                            break
                elif diff_meses < 0:
                    try:
                        anterior_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Mes anterior' and @clickable='true']")
                        anterior_btn.click()
                        print(f'  🔄 Navegando al mes anterior...')
                        time.sleep(1)
                    except:
                        try:
                            anterior_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Mes anterior']")
                            if anterior_btn.get_attribute('enabled') == 'true':
                                anterior_btn.click()
                                time.sleep(1)
                            else:
                                print(f"  ⚠️ Botón 'Mes anterior' deshabilitado")
                                break
                        except:
                            print(f'  ⚠️ No se pudo navegar al mes anterior')
                            break
                else:
                    encontrado = True
                    break
            else:
                print(f'  ⚠️ No se pudo parsear mes/año: {titulo_actual}')
                break
        except Exception as e:
            print(f'  ⚠️ Error en navegación: {e}')
            break
    if not encontrado:
        print(f'  ❌ No se encontró el mes {mes_nombre} {anio_int}')
        try:
            driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Cancelar']").click()
            time.sleep(1)
        except:
            pass
        return False
    try:
        driver.swipe(500, 1500, 500, 600, 500)
        time.sleep(1)
    except:
        pass
    time.sleep(1)
    seleccionado = False
    estrategias = [lambda: driver.find_element(AppiumBy.XPATH, f"//*[@text='{dia_int}' and @clickable='true']"), lambda: driver.find_element(AppiumBy.XPATH, f"//*[@content-desc='{dia_int}' and @clickable='true']"), lambda: driver.find_element(AppiumBy.XPATH, f"//*[@text='{dia}' and @clickable='true']"), lambda: driver.find_element(AppiumBy.XPATH, f"//*[@content-desc='{dia}' and @clickable='true']"), lambda: driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{dia_int}') and @clickable='true']"), lambda: driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{dia_int}') and @clickable='true']")]
    for i, estrategia in enumerate(estrategias, 1):
        try:
            dia_btn = estrategia()
            if dia_btn.is_displayed() and dia_btn.is_enabled():
                dia_btn.click()
                print(f'  ✅ Día {dia} seleccionado (estrategia {i})')
                seleccionado = True
                break
        except:
            pass
    if not seleccionado:
        try:
            dias = driver.find_elements(AppiumBy.XPATH, "//*[@clickable='true' and @content-desc and string-length(@content-desc) <= 2]")
            for d in dias:
                desc = d.get_attribute('content-desc') or ''
                if desc.isdigit() and int(desc) == dia_int:
                    d.click()
                    print(f'  ✅ Día {dia} seleccionado (búsqueda entre días)')
                    seleccionado = True
                    break
        except:
            pass
    if not seleccionado:
        print(f'  ❌ No se pudo seleccionar el día {dia}')
        return False
    time.sleep(1)
    print(f'  📝 Buscando botón Aceptar/OK...')
    try:
        aceptar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Aceptar']")
        if aceptar_btn.is_displayed() and aceptar_btn.is_enabled():
            aceptar_btn.click()
            print(f'  ✅ Fecha {campo} confirmada')
            time.sleep(2)
            return True
    except:
        pass
    try:
        aceptar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='OK']")
        aceptar_btn.click()
        print(f'  ✅ Fecha {campo} confirmada (OK)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        aceptar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Aceptar') and @clickable='true']")
        aceptar_btn.click()
        print(f'  ✅ Fecha {campo} confirmada (texto)')
        time.sleep(2)
        return True
    except:
        print(f'  ⚠️ No se encontró botón Aceptar, continuando...')
        return True

def click_buscar_modal(driver):
    print("  📝 Click en 'Buscar' (modal)...")
    time.sleep(2)
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Buscar']")
        btn.click()
        print("  ✅ Click en 'Buscar'")
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Buscar') and @clickable='true']")
        btn.click()
        print("  ✅ Click en 'Buscar' (contains)")
        time.sleep(3)
        return True
    except Exception as e:
        print(f"  ❌ Error al clickear 'Buscar': {e}")
        return False

def select_movimiento_by_nd(driver, texto_busqueda=None, monto=None, signo=None, max_scrolls=10, pausa_scroll=0.6, debug=True):
    print(f'  📝 Buscando movimiento...')
    if texto_busqueda:
        print(f"     • Texto: '{texto_busqueda}'")
    if monto is not None:
        print(f"     • Monto: {(signo if signo else '')}{monto}")
    time.sleep(2)
    texto_lower = texto_busqueda.lower() if texto_busqueda else ''
    monto_str = str(monto) if monto is not None else ''

    def _monto_coincide(desc):
        if not monto_str:
            return True
        if monto_str in desc:
            return True
        if '.' not in monto_str:
            variantes = [f'{monto_str}.00', f'{monto_str}.0', f'{monto_str}.000']
            for v in variantes:
                if v in desc:
                    return True
        if '.' in monto_str:
            entero = monto_str.split('.')[0]
            if entero and entero in desc:
                return True
        if signo:
            formato_con_signo = f'{signo}Bs. {monto_str}'
            if formato_con_signo in desc:
                return True
        return False

    def _buscar_en_lista_actual():
        try:
            movimientos = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[@resource-id='shared_btn_movimiento' and @clickable='true']")
            print(f'    🔍 Movimientos en pantalla: {len(movimientos)}')
            for mov in movimientos:
                desc = mov.get_attribute('content-desc') or ''
                desc_lower = desc.lower()
                if texto_lower and texto_lower not in desc_lower:
                    continue
                if monto_str and (not _monto_coincide(desc)):
                    continue
                if signo:
                    if signo == '+' and '+Bs.' not in desc:
                        continue
                    if signo == '-' and '-Bs.' not in desc:
                        continue
                mov.click()
                print(f'  ✅ Movimiento seleccionado: {desc[:80]}...')
                time.sleep(3)
                return True
            if not texto_lower and (not monto_str) and (not signo):
                if movimientos:
                    desc = movimientos[0].get_attribute('content-desc') or ''
                    movimientos[0].click()
                    print(f'  ✅ Primer movimiento seleccionado (sin filtros)')
                    print(f'     {desc[:80]}...')
                    time.sleep(3)
                    return True
            return False
        except Exception as e:
            print(f'  ⚠️ Error buscando: {e}')
            return False
    print('  🔍 Buscando en pantalla actual...')
    if _buscar_en_lista_actual():
        return True
    print('  🔄 Buscando con scroll incremental...')
    for intento in range(max_scrolls):
        try:
            driver.swipe(500, 1500, 500, 700, 500)
            time.sleep(pausa_scroll)
            print(f'    Scroll {intento + 1}/{max_scrolls}')
            if _buscar_en_lista_actual():
                return True
        except:
            pass
    print('  🔄 Scroll hacia arriba por si acaso...')
    for intento in range(3):
        try:
            driver.swipe(500, 700, 500, 1500, 500)
            time.sleep(pausa_scroll)
            if _buscar_en_lista_actual():
                return True
        except:
            pass
    print(f'  ❌ No se encontró movimiento con los criterios especificados')
    if debug:
        print('  🔍 Movimientos disponibles (debug):')
        try:
            movimientos = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[@resource-id='shared_btn_movimiento']")
            print(f'  🔍 Total en pantalla: {len(movimientos)}')
            for i, mov in enumerate(movimientos[:10]):
                desc = mov.get_attribute('content-desc') or ''
                print(f'    [{i}] {desc[:100]}...')
        except:
            pass
    return False

def verificar_detalle_transaccion(driver):
    print('  📝 Verificando modal de detalle...')
    time.sleep(2)
    try:
        driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Detalle de Transacción']")
        print('  ✅ Modal de detalle abierto')
        return True
    except:
        pass
    try:
        driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Referencia')]")
        print("  ✅ Modal de detalle abierto (por 'Referencia')")
        return True
    except:
        print('  ⚠️ No se pudo verificar el modal de detalle')
        return False

def cerrar_modal_detalle(driver):
    """Cierra el modal de detalle con 4 estrategias."""
    print('  📝 Cerrando modal de detalle...')
    time.sleep(2)
    try:
        cerrar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Cerrar']")
        cerrar.click()
        print('  ✅ Click en Cerrar (content-desc)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        cerrar = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Cerrar') and @clickable='true']")
        cerrar.click()
        print('  ✅ Click en Cerrar (texto)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        driver.back()
        print('  ✅ Back ejecutado')
        time.sleep(2)
        return True
    except:
        pass
    return False

def _normalizar_fecha_ui(value):
    v=str(value or '').strip().replace('-', '/')
    q=v.split('/')
    if len(q)!=3:return v
    if len(q[0])==4:y,m,d=q
    else:d,m,y=q
    return f'{int(d):02d}/{int(m):02d}/{int(y):04d}'

def realizar_busqueda_movimientos_tc(driver, texto_busqueda=None, tipo_consumo='Todos', fecha_desde=None, fecha_hasta=None, texto_movimiento=None, monto_movimiento=None, signo_movimiento=None, tiempos=None, reporte=None, paso_inicial=6):
    fecha_desde=_normalizar_fecha_ui(fecha_desde); fecha_hasta=_normalizar_fecha_ui(fecha_hasta)
    print(f'\n🔍 INICIANDO BÚSQUEDA DE MOVIMIENTOS T. CRÉDITO')
    print(f"🔎 Búsqueda: {(texto_busqueda if texto_busqueda else '(vacío)')}")
    print(f'📋 Consumo: {tipo_consumo}')
    if fecha_desde:
        print(f'📅 Desde: {fecha_desde}')
    if fecha_hasta:
        print(f'📅 Hasta: {fecha_hasta}')
    if texto_movimiento:
        print(f'📝 Movimiento: {texto_movimiento}')
    if monto_movimiento:
        print(f"💰 Monto: {(signo_movimiento if signo_movimiento else '')}{monto_movimiento}")
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Ir a T. CRÉDITO')
    if not ir_a_tarjeta_credito(driver):
        print('  ❌ Error al ir a T. CRÉDITO')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla T. CRÉDITO', 'Se accedió a la sección de Tarjeta de Crédito desde el home.', espera=2.0)
    paso_num += 1
    print('  📝 Esperando carga de pantalla de T. CRÉDITO...')
    time.sleep(3)
    tiempos.start('2. Movimientos inferior')
    if not seleccionar_movimientos_inferior(driver):
        print("  ❌ Error al seleccionar 'Movimientos'")
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Opción Movimientos (inferior)', "Se seleccionó la opción 'Movimientos' en la parte inferior de la pantalla de Tarjeta de Crédito.", espera=1.5)
    paso_num += 1
    print('  📝 Esperando carga de movimientos...')
    time.sleep(3)
    tiempos.start('3. Click lupa')
    if not click_lupa_busqueda(driver):
        print('  ❌ Error al clickear la lupa')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Lupa de búsqueda abierta', 'Se hizo clic en la lupa para abrir el modal de búsqueda de movimientos.', espera=2.0)
    paso_num += 1
    print('  📝 Esperando carga del modal de búsqueda...')
    time.sleep(3)
    if texto_busqueda:
        tiempos.start('4. Texto búsqueda')
        if not ingresar_busqueda(driver, texto_busqueda):
            print('  ⚠️ Error al ingresar texto de búsqueda, continuando...')
        tiempos.stop()
        if reporte:
            reporte.capturar_paso(paso_num, f"Texto de búsqueda: '{texto_busqueda}'", f"Se ingresó el texto de búsqueda: '{texto_busqueda}'.", espera=1.0)
        paso_num += 1
    tiempos.start('5. Tipo consumo')
    if not seleccionar_consumo(driver, tipo_consumo):
        print('  ⚠️ Error al seleccionar consumo, continuando...')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Consumo: {tipo_consumo}', f"Se seleccionó el tipo de consumo: '{tipo_consumo}'.", espera=1.0)
    paso_num += 1
    if fecha_desde:
        tiempos.start('6. Fecha Desde')
        if not select_fecha(driver, 'Desde', fecha_desde):
            print('  ⚠️ Error al seleccionar fecha Desde, continuando...')
        tiempos.stop()
        if reporte:
            reporte.capturar_paso(paso_num, f'Fecha Desde: {fecha_desde}', f'Se seleccionó la fecha Desde: {fecha_desde}.', espera=1.0)
        paso_num += 1
    if fecha_hasta:
        tiempos.start('7. Fecha Hasta')
        if not select_fecha(driver, 'Hasta', fecha_hasta):
            print('  ⚠️ Error al seleccionar fecha Hasta, continuando...')
        tiempos.stop()
        if reporte:
            reporte.capturar_paso(paso_num, f'Fecha Hasta: {fecha_hasta}', f'Se seleccionó la fecha Hasta: {fecha_hasta}.', espera=1.0)
        paso_num += 1
    tiempos.start('8. Click Buscar')
    if not click_buscar_modal(driver):
        print('  ❌ Error al clickear Buscar')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Click en Buscar', "Se hizo clic en 'Buscar' para ejecutar la búsqueda de movimientos.", espera=2.0)
    paso_num += 1
    print('  📝 Esperando resultados...')
    time.sleep(3)
    tiempos.start('9. Seleccionar movimiento')
    if not select_movimiento_by_nd(driver, texto_busqueda=texto_movimiento, monto=monto_movimiento, signo=signo_movimiento):
        print('  ❌ No se encontró el movimiento')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        detalles = []
        if texto_movimiento:
            detalles.append(f"Texto: '{texto_movimiento}'")
        if monto_movimiento:
            detalles.append(f"Monto: {signo_movimiento or ''}{monto_movimiento}")
        if not detalles:
            detalles.append('(Sin filtros - primer movimiento)')
        reporte.capturar_paso(paso_num, 'Movimiento seleccionado', f"Se seleccionó el movimiento: {' | '.join(detalles)}.", espera=1.5)
    paso_num += 1
    tiempos.start('10. Verificar detalle')
    if not verificar_detalle_transaccion(driver):
        print('  ⚠️ No se pudo verificar el modal de detalle')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, "Modal 'Detalle de Transacción'", 'Se abrió el modal con el detalle de la transacción seleccionada.', espera=1.5)
    paso_num += 1
    tiempos.start('11. Cerrar modal')
    if not cerrar_modal_detalle(driver):
        print('  ⚠️ Error al cerrar modal')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Modal cerrado', 'Se cerró el modal de detalle de la transacción.', espera=1.5)
    paso_num += 1
    tiempos.start('12. Volver atrás')
    if not volver_atras_tc(driver):
        print('  ⚠️ Error al volver atrás')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Regreso a pantalla anterior', 'Se regresó a la pantalla anterior (listado de movimientos).', espera=1.0)
    paso_num += 1
    tiempos.start('13. Volver al home')
    if not volver_home(driver):
        print('  ⚠️ Error al volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Búsqueda TC finalizado', 'Se regresó exitosamente al home. El flujo de búsqueda de movimientos de tarjeta de crédito ha terminado.', espera=1.5)
    paso_num += 1
    print('\n✅ BÚSQUEDA DE MOVIMIENTOS COMPLETADA EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('tarjeta_de_credito_movimientos_busqueda_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO COMPLETO: LOGIN + BÚSQUEDA DE MOVIMIENTOS T. CRÉDITO + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    TEXTO_BUSQUEDA = _input_cfg.get('TEXTO_BUSQUEDA', None)
    TIPO_CONSUMO = _input_cfg.get('TIPO_CONSUMO', 'Todos')
    FECHA_DESDE = _input_cfg.get('FECHA_DESDE', '11/09/2026')
    FECHA_HASTA = _input_cfg.get('FECHA_HASTA', '12/09/2026')
    TEXTO_MOVIMIENTO = _input_cfg.get('TEXTO_MOVIMIENTO', None)
    MONTO_MOVIMIENTO = _input_cfg.get('MONTO_MOVIMIENTO', 240)
    SIGNO_MOVIMIENTO = _input_cfg.get('SIGNO_MOVIMIENTO', None)
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Busqueda_Movimientos_Tarjeta_Credito')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f"🔎 Búsqueda: {(TEXTO_BUSQUEDA if TEXTO_BUSQUEDA else '(vacío)')}")
    print(f'📋 Consumo: {TIPO_CONSUMO}')
    if FECHA_DESDE:
        print(f'📅 Desde: {FECHA_DESDE}')
    if FECHA_HASTA:
        print(f'📅 Hasta: {FECHA_HASTA}')
    if TEXTO_MOVIMIENTO:
        print(f'📝 Movimiento: {TEXTO_MOVIMIENTO}')
    if MONTO_MOVIMIENTO:
        print(f"💰 Monto: {(SIGNO_MOVIMIENTO if SIGNO_MOVIMIENTO else '')}{MONTO_MOVIMIENTO}")
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Texto búsqueda': TEXTO_BUSQUEDA or '(vacío)', 'Tipo consumo': TIPO_CONSUMO, 'Fecha desde': FECHA_DESDE or 'N/A', 'Fecha hasta': FECHA_HASTA or 'N/A', 'Texto movimiento': TEXTO_MOVIMIENTO or 'N/A', 'Monto movimiento': f"{SIGNO_MOVIMIENTO or ''}{MONTO_MOVIMIENTO}" if MONTO_MOVIMIENTO else 'N/A'})
    login_ok = _input_cfg.get('login_ok', False)
    busqueda_ok = _input_cfg.get('busqueda_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            busqueda_ok = realizar_busqueda_movimientos_tc(driver, texto_busqueda=TEXTO_BUSQUEDA, tipo_consumo=TIPO_CONSUMO, fecha_desde=FECHA_DESDE, fecha_hasta=FECHA_HASTA, texto_movimiento=TEXTO_MOVIMIENTO, monto_movimiento=MONTO_MOVIMIENTO, signo_movimiento=SIGNO_MOVIMIENTO, tiempos=tiempos, reporte=reporte, paso_inicial=6)
            if busqueda_ok:
                print('\n🎉 BÚSQUEDA DE MOVIMIENTOS EXITOSA!')
            else:
                print('\n❌ BÚSQUEDA DE MOVIMIENTOS FALLIDA')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and busqueda_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login          : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Búsqueda       : {('✅ OK' if busqueda_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

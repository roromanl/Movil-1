"""
Flujo Actualizar Beneficiario + reporte Word.
Pasos: Login → Transferir → Scroll a sección → Seleccionar beneficiario
       → Editar datos → Continuar → Confirmar → Modal éxito → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import go_back_home__c06b7d90b9 as go_back_home
from framework.common.ui_helpers import _esta_en_home as _esta_en_home

def navigate_to_transfer(driver):
    print('  📝 Navegando a Transferencias...')
    time.sleep(2)
    try:
        transfer_btn = driver.find_element(AppiumBy.ID, 'home_btn_transferir')
        transfer_btn.click()
        print('  ✅ Click en Transferir (ID)')
        time.sleep(3)
        return True
    except:
        try:
            transfer_btn = driver.find_element(AppiumBy.ACCESSIBILITY_ID, 'Transferir')
            transfer_btn.click()
            print('  ✅ Click en Transferir (Accessibility)')
            time.sleep(3)
            return True
        except:
            try:
                transfer_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Transferir') or contains(@content-desc, 'Transferir')]")
                transfer_btn.click()
                print('  ✅ Click en Transferir (XPATH)')
                time.sleep(3)
                return True
            except Exception as e:
                print(f'  ❌ Error al navegar a transferencias: {e}')
                return False

def scroll_to_section(driver, section_name, max_swipes=10, timeout=15):
    """
    Hace scroll hasta encontrar una sección específica Y la expande si está colapsada.
    """
    print(f"  🔍 Buscando sección '{section_name}'...")
    time.sleep(3)
    print('  🔄 Subiendo al inicio de la lista...')
    for i in range(5):
        try:
            driver.swipe(500, 800, 500, 1800, 500)
            time.sleep(0.4)
        except:
            pass
    section_lower = section_name.lower()

    def buscar_seccion():
        try:
            return driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{section_name}')]")
        except:
            pass
        try:
            return driver.find_element(AppiumBy.XPATH, f"//*[contains(translate(@content-desc, 'ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÑ', 'abcdefghijklmnopqrstuvwxyzáéíóúñ'), '{section_lower}')]")
        except:
            pass
        return None
    seccion_encontrada = False
    for i in range(max_swipes):
        element = buscar_seccion()
        if element is not None:
            print(f"  ✅ Sección '{section_name}' encontrada (intento {i + 1})")
            seccion_encontrada = True
            break
        print(f"  🔄 Scroll {i + 1}/{max_swipes} buscando '{section_name}'...")
        try:
            driver.swipe(500, 1200, 500, 300, 500)
            time.sleep(0.5)
        except:
            pass
    if not seccion_encontrada:
        print('  🔄 No encontrada, intentando scroll hacia arriba...')
        for i in range(max_swipes):
            try:
                driver.swipe(500, 300, 500, 1200, 500)
                time.sleep(0.5)
            except:
                pass
            element = buscar_seccion()
            if element is not None:
                print(f"  ✅ Sección '{section_name}' encontrada (scroll up {i + 1})")
                seccion_encontrada = True
                break
    if not seccion_encontrada:
        print(f"  ❌ No se encontró la sección '{section_name}'")
        try:
            secciones = driver.find_elements(AppiumBy.XPATH, "//*[contains(@content-desc, 'CUENTAS') and @clickable='true']")
            print(f'  🔍 Secciones visibles ({len(secciones)}):')
            for s in secciones[:10]:
                desc = (s.get_attribute('content-desc') or '').replace('\n', ' | ')
                print(f'     - {desc[:80]}')
        except:
            pass
        return False
    try:
        boton_desplegar = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, 'Desplegar {section_name}') or contains(@content-desc, 'Mostrar {section_name}')]")
        boton_desplegar.click()
        print(f"  ✅ Sección '{section_name}' expandida")
        time.sleep(2)
    except:
        try:
            boton_contraer = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, 'Contraer {section_name}')]")
            print(f"  ℹ️ Sección '{section_name}' ya está expandida")
        except:
            print(f"  ℹ️ Sección '{section_name}' visible (estado desconocido)")
    try:
        driver.swipe(500, 1000, 500, 500, 500)
        time.sleep(1)
    except:
        pass
    return True

def select_beneficiary_to_edit(driver, numero_cuenta, nombre_beneficiario=None):
    print(f'  📝 Buscando beneficiario: {numero_cuenta}...')
    time.sleep(2)
    try:
        editar_btn = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{numero_cuenta}') and contains(@resource-id, 'transfers_target_item_')]//android.widget.Button[@content-desc='Editar']")
        editar_btn.click()
        print(f'  ✅ Click en Editar para: {numero_cuenta}')
        time.sleep(3)
        return True
    except:
        pass
    try:
        ultimos_digitos = numero_cuenta.replace('-', '')[-6:]
        editar_btn = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{ultimos_digitos}') and contains(@resource-id, 'transfers_target_item_')]//android.widget.Button[@content-desc='Editar']")
        editar_btn.click()
        print(f'  ✅ Click en Editar (últimos dígitos: {ultimos_digitos})')
        time.sleep(3)
        return True
    except:
        pass
    if nombre_beneficiario:
        try:
            editar_btn = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{nombre_beneficiario}') and contains(@resource-id, 'transfers_target_item_')]//android.widget.Button[@content-desc='Editar']")
            editar_btn.click()
            print(f'  ✅ Click en Editar (nombre: {nombre_beneficiario})')
            time.sleep(3)
            return True
        except:
            pass
    try:
        beneficiarios = driver.find_elements(AppiumBy.XPATH, "//*[contains(@resource-id, 'transfers_target_item_')]")
        print(f'  🔍 Encontrados {len(beneficiarios)} beneficiarios')
        for btn in beneficiarios:
            desc = btn.get_attribute('content-desc') or ''
            if numero_cuenta in desc or (nombre_beneficiario and nombre_beneficiario in desc):
                try:
                    editar_btn = btn.find_element(AppiumBy.XPATH, ".//android.widget.Button[@content-desc='Editar']")
                    editar_btn.click()
                    print(f'  ✅ Click en Editar (filtrado)')
                    time.sleep(3)
                    return True
                except:
                    pass
    except:
        pass
    print('  🔄 Haciendo scroll para buscar el beneficiario...')
    for i in range(5):
        try:
            driver.swipe(500, 1200, 500, 400, 500)
            time.sleep(0.8)
            beneficiarios = driver.find_elements(AppiumBy.XPATH, "//*[contains(@resource-id, 'transfers_target_item_')]")
            for btn in beneficiarios:
                desc = btn.get_attribute('content-desc') or ''
                if numero_cuenta in desc or (nombre_beneficiario and nombre_beneficiario in desc):
                    try:
                        editar_btn = btn.find_element(AppiumBy.XPATH, ".//android.widget.Button[@content-desc='Editar']")
                        editar_btn.click()
                        print(f'  ✅ Click en Editar (después de {i + 1} scrolls)')
                        time.sleep(3)
                        return True
                    except:
                        pass
        except:
            pass
    print(f'  ❌ No se encontró beneficiario: {numero_cuenta}')
    try:
        beneficiarios = driver.find_elements(AppiumBy.XPATH, "//*[contains(@resource-id, 'transfers_target_item_')]")
        print(f'  🔍 Beneficiarios visibles ({len(beneficiarios)}):')
        for b in beneficiarios[:10]:
            desc = (b.get_attribute('content-desc') or '').replace('\n', ' | ')
            print(f'     - {desc[:80]}')
    except:
        pass
    return False

def edit_beneficiary_data_terceros(driver, tipo_cuenta='Cuenta de ahorros', cuenta='40001983743'):
    """Modifica datos del beneficiario (TERCEROS - Banco Fie)"""
    print('  📝 Editando datos del beneficiario (TERCEROS)...')
    time.sleep(2)
    try:
        tipo_cuenta_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Tipo de cuenta') and @clickable='true']")
        tipo_cuenta_btn.click()
        print('  ✅ Click en Tipo de cuenta')
        time.sleep(2)
        try:
            cuenta_tipo = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{tipo_cuenta}') and @clickable='true']")
            cuenta_tipo.click()
            print(f'  ✅ Tipo cuenta seleccionado: {tipo_cuenta}')
            time.sleep(1)
        except:
            pass
    except:
        print('  ℹ️ Tipo de cuenta ya seleccionado o no visible')
    try:
        cuenta_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='Número de cuenta']")
        cuenta_input.click()
        time.sleep(1)
        cuenta_input.clear()
        cuenta_input.send_keys(cuenta)
        print(f'  ✅ Número de cuenta: {cuenta}')
        try:
            driver.hide_keyboard()
            time.sleep(1)
        except:
            pass
    except:
        try:
            cuenta_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[contains(@hint, 'Número de cuenta')]")
            cuenta_input.click()
            time.sleep(1)
            cuenta_input.clear()
            cuenta_input.send_keys(cuenta)
            print(f'  ✅ Número de cuenta: {cuenta}')
            try:
                driver.hide_keyboard()
                time.sleep(1)
            except:
                pass
        except Exception as e:
            print(f'  ⚠️ Error al ingresar cuenta: {e}')
    return click_continuar(driver)

def edit_beneficiary_data_otros_bancos(driver, tipo_cuenta='Cuenta de ahorros', cuenta='10000018048319', nombre='CARLOS HERLAN LOPEZ AVILA', ci_nit='1234567'):
    print('  📝 Editando datos del beneficiario (OTROS BANCOS)...')
    time.sleep(2)
    try:
        tipo_cuenta_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Tipo de cuenta') and @clickable='true']")
        tipo_cuenta_btn.click()
        print('  ✅ Click en Tipo de cuenta')
        time.sleep(2)
        try:
            cuenta_tipo = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{tipo_cuenta}') and @clickable='true']")
            cuenta_tipo.click()
            print(f'  ✅ Tipo cuenta seleccionado: {tipo_cuenta}')
            time.sleep(1)
        except:
            pass
    except:
        print('  ℹ️ Tipo de cuenta ya seleccionado o no visible')
    try:
        cuenta_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='Número de cuenta']")
        cuenta_input.click()
        time.sleep(1)
        cuenta_input.clear()
        cuenta_input.send_keys(cuenta)
        print(f'  ✅ Número de cuenta: {cuenta}')
        try:
            driver.hide_keyboard()
            time.sleep(1)
        except:
            pass
    except:
        pass
    try:
        nombre_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='Beneficiario']")
        nombre_input.click()
        time.sleep(1)
        nombre_input.clear()
        nombre_input.send_keys(nombre)
        print(f'  ✅ Nombre: {nombre}')
        try:
            driver.hide_keyboard()
            time.sleep(1)
        except:
            pass
    except:
        try:
            nombre_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[contains(@hint, 'Beneficiario')]")
            nombre_input.click()
            time.sleep(1)
            nombre_input.clear()
            nombre_input.send_keys(nombre)
            print(f'  ✅ Nombre: {nombre}')
            try:
                driver.hide_keyboard()
                time.sleep(1)
            except:
                pass
        except Exception as e:
            print(f'  ⚠️ Error al ingresar nombre: {e}')
    try:
        ci_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='Ci o nit del beneficiario']")
        ci_input.click()
        time.sleep(1)
        ci_input.clear()
        ci_input.send_keys(ci_nit)
        print(f'  ✅ CI/NIT: {ci_nit}')
        try:
            driver.hide_keyboard()
            time.sleep(1)
        except:
            pass
    except:
        try:
            ci_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[contains(@hint, 'Ci o nit')]")
            ci_input.click()
            time.sleep(1)
            ci_input.clear()
            ci_input.send_keys(ci_nit)
            print(f'  ✅ CI/NIT: {ci_nit}')
            try:
                driver.hide_keyboard()
                time.sleep(1)
            except:
                pass
        except Exception as e:
            print(f'  ⚠️ Error al ingresar CI/NIT: {e}')
    return click_continuar(driver)

def click_continuar(driver):
    print('  📝 Click en Continuar...')
    time.sleep(2)
    try:
        continuar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")
        continuar_btn.click()
        print('  ✅ Click en Continuar')
        time.sleep(3)
        return True
    except:
        try:
            continuar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Continuar') and @clickable='true']")
            continuar_btn.click()
            print('  ✅ Click en Continuar (texto)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Continuar: {e}')
            return False

def click_confirmar_transaccion(driver):
    print('  📝 Click en Confirmar transacción...')
    time.sleep(2)
    try:
        confirmar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Confirmar transacción']")
        confirmar_btn.click()
        print('  ✅ Click en Confirmar transacción')
        time.sleep(3)
        return True
    except:
        try:
            confirmar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Confirmar') and @clickable='true']")
            confirmar_btn.click()
            print('  ✅ Click en Confirmar (texto)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Confirmar: {e}')
            return False

def handle_success_modal(driver):
    """Maneja el modal de éxito 'Cuenta de beneficiario actualizada con éxito'"""
    print('  📝 Manejando modal de éxito...')
    time.sleep(3)
    try:
        driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'actualizada con éxito')]")
        print('  ✅ Modal de éxito detectado')
        time.sleep(1)
    except:
        try:
            driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'actualizada con éxito')]")
            print('  ✅ Modal de éxito detectado (texto)')
            time.sleep(1)
        except:
            print('  ⚠️ No se detectó modal de éxito')
            return True
    try:
        continuar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")
        continuar_btn.click()
        print('  ✅ Click en Continuar (modal)')
        time.sleep(2)
        return True
    except:
        try:
            continuar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Continuar') and @clickable='true']")
            continuar_btn.click()
            print('  ✅ Click en Continuar (modal - texto)')
            time.sleep(2)
            return True
        except:
            print('  ⚠️ No se encontró botón Continuar en modal')
            return True

def actualizar_beneficiario(driver, numero_cuenta='40-0-0198374-3', seccion='CUENTAS TERCEROS', tipo_cuenta='Cuenta de ahorros', cuenta='40001983743', nombre='VISTONY LUBRICANTES INDUVIS S.A.', ci_nit='1004361020', nombre_busqueda=None, tiempos=None, reporte=None, paso_inicial=6):
    print(f'\n📝 INICIANDO ACTUALIZACIÓN DE BENEFICIARIO')
    print(f'📂 Sección: {seccion}')
    print(f'🔢 Cuenta a buscar: {numero_cuenta}')
    print(f'🔢 Nueva cuenta: {cuenta}')
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Navegar a Transferencias')
    if not navigate_to_transfer(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla Transferencias', 'Se accedió a la pantalla de Transferencias desde el home.', espera=2.0)
    paso_num += 1
    tiempos.start('2. Buscar sección')
    if not scroll_to_section(driver, seccion):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Sección: {seccion}', f"Se localizó y expandió la sección '{seccion}' en la lista de beneficiarios.", espera=1.5)
    paso_num += 1
    tiempos.start('3. Seleccionar beneficiario')
    if not select_beneficiary_to_edit(driver, numero_cuenta, nombre_busqueda):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Beneficiario seleccionado: {numero_cuenta}', f"Se localizó el beneficiario con cuenta {numero_cuenta} y se hizo clic en el botón 'Editar'.", espera=1.5)
    paso_num += 1
    tiempos.start('4. Editar datos')
    if seccion == 'CUENTAS TERCEROS':
        if not edit_beneficiary_data_terceros(driver, tipo_cuenta, cuenta):
            tiempos.stop()
            return False
        if reporte:
            reporte.capturar_paso(paso_num, 'Datos editados (Terceros)', f'Se modificó el número de cuenta a: {cuenta}. Tipo de cuenta: {tipo_cuenta}.', espera=1.5)
        paso_num += 1
    else:
        if not edit_beneficiary_data_otros_bancos(driver, tipo_cuenta, cuenta, nombre, ci_nit):
            tiempos.stop()
            return False
        if reporte:
            reporte.capturar_paso(paso_num, 'Datos editados (Otros Bancos)', f'Se modificó el número de cuenta a: {cuenta}. Nombre: {nombre}. CI/NIT: {ci_nit}.', espera=1.5)
        paso_num += 1
    tiempos.stop()
    tiempos.start('5. Confirmar transacción')
    if not click_confirmar_transaccion(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Confirmar transacción', 'Se confirmó la transacción en el modal de validación.', espera=1.5)
    paso_num += 1
    tiempos.start('6. Modal de éxito')
    handle_success_modal(driver)
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Modal - Beneficiario actualizado', 'Se mostró el modal confirmando que la cuenta del beneficiario fue actualizada con éxito.', espera=1.5)
    paso_num += 1
    tiempos.start('7. Volver al home')
    if not go_back_home(driver):
        print('  ⚠️ No se pudo volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Actualizar Beneficiario finalizado', 'Se regresó exitosamente al home. El flujo de actualización de beneficiario ha terminado.', espera=1.5)
    paso_num += 1
    print('\n✅ BENEFICIARIO ACTUALIZADO EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('transfer_actualizar_beneficiario_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO COMPLETO: LOGIN + ACTUALIZAR BENEFICIARIO + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    SECCION = _input_cfg.get('SECCION', 'CUENTAS OTROS BANCOS')
    TIPO_CUENTA = _input_cfg.get('TIPO_CUENTA', 'Cuenta de ahorros')
    NUMERO_CUENTA_BUSCAR = _input_cfg.get('NUMERO_CUENTA_BUSCAR', '10000012345680')
    CUENTA_NUEVA = _input_cfg.get('CUENTA_NUEVA', '10000018048319')
    NOMBRE = _input_cfg.get('NOMBRE', 'CARLOS HERLAN LOPEZ AVILA')
    CI_NIT = _input_cfg.get('CI_NIT', '1234567')
    NOMBRE_BUSQUEDA = _input_cfg.get('NOMBRE_BUSQUEDA', None)
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Actualizar_Beneficiario')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f'📂 Sección: {SECCION}')
    print(f'🔢 Cuenta a buscar: {NUMERO_CUENTA_BUSCAR}')
    print(f'🔢 Nueva cuenta: {CUENTA_NUEVA}')
    print(f'👤 Nombre: {NOMBRE}')
    print(f'🆔 CI/NIT: {CI_NIT}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Sección': SECCION, 'Cuenta a buscar': NUMERO_CUENTA_BUSCAR, 'Nueva cuenta': CUENTA_NUEVA, 'Tipo de cuenta': TIPO_CUENTA, 'Nombre': NOMBRE, 'CI/NIT': CI_NIT})
    login_ok = _input_cfg.get('login_ok', False)
    actualizar_ok = _input_cfg.get('actualizar_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            actualizar_ok = actualizar_beneficiario(driver, numero_cuenta=NUMERO_CUENTA_BUSCAR, seccion=SECCION, tipo_cuenta=TIPO_CUENTA, cuenta=CUENTA_NUEVA, nombre=NOMBRE, ci_nit=CI_NIT, nombre_busqueda=NOMBRE_BUSQUEDA, tiempos=tiempos, reporte=reporte, paso_inicial=6)
            if actualizar_ok:
                print('\n🎉 BENEFICIARIO ACTUALIZADO EXITOSAMENTE!')
            else:
                print('\n❌ ACTUALIZACIÓN DE BENEFICIARIO FALLIDA')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and actualizar_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login          : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Actualización  : {('✅ OK' if actualizar_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

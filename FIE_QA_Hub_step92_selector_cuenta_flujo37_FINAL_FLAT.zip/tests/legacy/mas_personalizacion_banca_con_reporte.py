"""
Flujo Login + Personalizar Banca + Reporte Word.
Pasos: Login → Más → Personalizar banca → Seleccionar perfil → Guardar cambios
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.actions.action_builder import ActionBuilder
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login

def scroll_down(driver, duration=800):
    """Realiza un scroll hacia abajo en la pantalla"""
    try:
        size = driver.get_window_size()
        start_x = size['width'] // 2
        start_y = int(size['height'] * 0.75)
        end_y = int(size['height'] * 0.25)
        actions = ActionBuilder(driver)
        pointer = actions.add_pointer_input('touch', 'finger')
        pointer.create_pointer_move(duration=0, x=start_x, y=start_y)
        pointer.create_pointer_down(button=0)
        pointer.create_pointer_move(duration=duration, x=start_x, y=end_y)
        pointer.create_pointer_up(button=0)
        actions.perform()
        time.sleep(1)
        return True
    except Exception as e:
        print(f'  ⚠️ Error en scroll: {e}')
        return False

def set_switch(driver, resource_id, desired_state, nombre, content_desc=None, timeout=15):
    print(f"    • Configurando {nombre} -> {('Activar' if desired_state else 'Desactivar')}")
    wait = WebDriverWait(driver, timeout)
    switch = None
    is_checked = None
    try:
        switch = wait.until(EC.presence_of_element_located((AppiumBy.ID, resource_id)))
        is_checked = switch.get_attribute('checked') == 'true'
        print(f"      🔍 Estado actual: {('Activado' if is_checked else 'Desactivado')}")
    except Exception as e1:
        try:
            switch = driver.find_element(AppiumBy.XPATH, f"//android.widget.Switch[@resource-id='{resource_id}']")
            is_checked = switch.get_attribute('checked') == 'true'
            print(f"      🔍 Estado actual: {('Activado' if is_checked else 'Desactivado')} (XPATH id)")
        except Exception as e2:
            if content_desc:
                try:
                    switch = driver.find_element(AppiumBy.XPATH, f"//android.widget.Switch[contains(@content-desc, '{content_desc}')]")
                    is_checked = switch.get_attribute('checked') == 'true'
                    print(f"      🔍 Estado actual: {('Activado' if is_checked else 'Desactivado')} (content-desc)")
                except Exception as e3:
                    print(f"      ❌ No se encontró el switch '{nombre}': {e3}")
                    return False
            else:
                print(f"      ❌ No se encontró el switch '{nombre}': {e2}")
                return False
    if is_checked == desired_state:
        print(f"      ℹ️ {nombre}: ya está {('activado' if desired_state else 'desactivado')}")
        return True
    try:
        driver.execute_script('mobile: scroll', {'elementId': switch.id, 'toVisible': True})
        time.sleep(0.3)
    except:
        pass
    try:
        padre = switch.find_element(AppiumBy.XPATH, './..')
        padre_id = padre.get_attribute('resource-id')
        padre_clickable = padre.get_attribute('clickable') == 'true'
        print(f'      🔧 Padre del switch: id={padre_id!r} clickable={padre_clickable}')
        if padre_clickable:
            padre.click()
            time.sleep(0.6)
            nuevo_estado = switch.get_attribute('checked') == 'true'
            if nuevo_estado == desired_state:
                print(f"      ✅ {nombre}: {('activado' if desired_state else 'desactivado')} (click en padre)")
                return True
            else:
                print(f'      ⚠️ Click en padre no cambió el estado, siguiente estrategia...')
    except Exception as ep:
        print(f"      ⚠️ Estrategia 'padre' falló")
    try:
        switch.click()
        time.sleep(0.6)
        nuevo_estado = switch.get_attribute('checked') == 'true'
        if nuevo_estado == desired_state:
            print(f"      ✅ {nombre}: {('activado' if desired_state else 'desactivado')} (click directo)")
            return True
        else:
            print(f'      ⚠️ Click directo no cambió el estado, siguiente estrategia...')
    except Exception as ec:
        print(f'      ⚠️ Click directo falló: {ec}')
    try:
        try:
            padre = switch.find_element(AppiumBy.XPATH, './..')
            target = padre
        except:
            target = switch
        location = target.location
        size = target.size
        x = location['x'] + size['width'] - 60
        y = location['y'] + size['height'] // 2
        print(f'      🎯 Tap en coordenadas: x={x}, y={y} (bounds={location}, size={size})')
        driver.tap([(x, y)])
        time.sleep(0.6)
        nuevo_estado = switch.get_attribute('checked') == 'true'
        if nuevo_estado == desired_state:
            print(f"      ✅ {nombre}: {('activado' if desired_state else 'desactivado')} (tap)")
            return True
        else:
            print(f'      ❌ {nombre}: tap no aplicó el cambio esperado')
            return False
    except Exception as et:
        print(f"      ❌ Error al cambiar switch '{nombre}': {et}")
        return False

def ir_a_home(driver, timeout=10):
    try:
        print('  📝 Navegando a Home...')
        home_btn = WebDriverWait(driver, timeout).until(EC.element_to_be_clickable((AppiumBy.ID, 'home_btn_inicio')))
        home_btn.click()
        time.sleep(2)
        print('  ✅ En Home')
        return True
    except Exception as e:
        print(f'  ⚠️ No se pudo ir a Home: {e}')
        return False

def ir_a_mas(driver, timeout=10):
    try:
        mas_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@resource-id='home_btn_mas']")
        mas_btn.click()
        print("  ✅ Click en 'Más' (XPATH)")
        return True
    except Exception as e:
        print(f"  ❌ No se pudo clickear 'Más': {e}")
        return False

def personalizar_banca(driver, perfil, config=None, timeout=15, reporte=None, paso_inicial=6):
    print(f'\n🎨 Personalizando banca con perfil: {perfil}')
    paso_num = paso_inicial
    if not ir_a_mas(driver):
        return False
    if reporte:
        reporte.capturar_paso(paso_num, 'Menú Más abierto', "Se accedió al menú 'Más' desde la barra de navegación inferior.", espera=1.5)
    paso_num += 1
    try:
        print("  📝 Click en 'Personalizar banca'...")
        personalizar_btn = WebDriverWait(driver, timeout).until(EC.element_to_be_clickable((AppiumBy.ID, 'more_btn_personalizar')))
        personalizar_btn.click()
        time.sleep(2)
        print("  ✅ En pantalla 'Personalizar banca'")
    except Exception as e:
        try:
            personalizar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@resource-id='more_btn_personalizar']")
            personalizar_btn.click()
            time.sleep(2)
            print("  ✅ En pantalla 'Personalizar banca' (XPATH)")
        except Exception as e2:
            print(f"  ❌ No se pudo entrar a 'Personalizar banca': {e} / {e2}")
            return False
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla Personalizar banca', 'Se accedió a la pantalla de personalización de la banca. Se muestran los perfiles disponibles: Emprendedor, Esencial, Cliente y Personalizado.', espera=1.5)
    paso_num += 1
    perfiles_map = {'Emprendedor': 'more_card_profile_simple', 'Esencial': 'more_card_profile_intermedio', 'Cliente': 'more_card_profile_completo', 'Personalizado': 'more_card_profile_personalizable'}
    perfil_norm = perfil.strip().capitalize()
    if perfil_norm not in perfiles_map:
        print(f"  ❌ Perfil '{perfil}' inválido. Usa: {list(perfiles_map.keys())}")
        return False
    perfil_id = perfiles_map[perfil_norm]
    print(f"  📝 Seleccionando perfil '{perfil_norm}' (id={perfil_id})...")
    perfil_btn = None
    try:
        perfil_btn = driver.find_element(AppiumBy.XPATH, f"//android.widget.Button[@resource-id='{perfil_id}']")
        print(f'  ✅ Botón encontrado por XPATH resource-id')
    except Exception as e2:
        print(f'  ⚠️ No encontrado por XPATH resource-id: {e2}')
    try:
        driver.execute_script('mobile: scroll', {'elementId': perfil_btn.id, 'toVisible': True})
        time.sleep(0.5)
    except:
        pass
    try:
        perfil_btn.click()
        time.sleep(2)
        print(f"  ✅ Perfil '{perfil_norm}' seleccionado")
    except Exception as e:
        print(f'  ⚠️ Click normal falló: {e}. Intentando tap por coordenadas...')
        try:
            location = perfil_btn.location
            size = perfil_btn.size
            x = location['x'] + size['width'] // 2
            y = location['y'] + size['height'] // 2
            driver.tap([(x, y)])
            time.sleep(2)
            print(f"  ✅ Perfil '{perfil_norm}' seleccionado (tap por coordenadas)")
        except Exception as e2:
            print(f'  ❌ Error al clickear el perfil: {e} / {e2}')
            return False
    if reporte:
        reporte.capturar_paso(paso_num, f"Perfil '{perfil_norm}' seleccionado", f"Se seleccionó el perfil '{perfil_norm}' para personalizar la banca.", espera=1.5)
    paso_num += 1
    if perfil_norm != 'Personalizado':
        return _guardar_cambios_y_confirmar(driver, timeout, reporte=reporte, paso_num=paso_num)
    print('  🔧 Aplicando configuración personalizada...')
    if config is None:
        config = {}
    asistente = config.get('asistente_voz', None)
    if asistente is not None:
        print('    • Asistente de voz...')
        set_switch(driver, 'more_switch_voice_assistant', asistente, 'Asistente de voz')
    scroll_down(driver)
    time.sleep(0.5)
    if reporte:
        reporte.capturar_paso(paso_num, 'Configuración - Asistente de voz / Accesos directos', 'Se configuraron las opciones de asistente de voz y accesos directos (Pagar QR, Cripto, Recarga, Cobrar QR, Pagos).', espera=1.0)
    paso_num += 1
    accesos = config.get('accesos_directos', {})
    accesos_map = {'pagar_qr': ('more_tile_shortcut_payQr', 'Pagar QR'), 'cripto': ('more_tile_shortcut_crypto', 'Cripto'), 'recarga': ('more_tile_shortcut_recarga', 'Recarga'), 'cobrar_qr': ('more_tile_shortcut_collectQr', 'Cobrar QR'), 'pagos': ('more_tile_shortcut_pagos', 'Pagos')}
    for key, (rid, nombre) in accesos_map.items():
        if key in accesos:
            set_switch(driver, rid, accesos[key], nombre)
    scroll_down(driver)
    time.sleep(1)
    if reporte:
        reporte.capturar_paso(paso_num, 'Configuración - Navegación y productos', 'Se configuraron las opciones de navegación (Transferencias, Pagos de servicios) y productos (Promociones, Límites, Tarjetas de débito).', espera=1.0)
    paso_num += 1
    navegacion = config.get('navegacion', {})
    nav_map = {'transferencias': ('more_switch_transfers', 'Transferencias'), 'pagos_servicios': ('more_switch_payments', 'Pagos de servicios')}
    for key, (rid, nombre) in nav_map.items():
        if key in navegacion:
            set_switch(driver, rid, navegacion[key], nombre)
    productos = config.get('productos_mas', {})
    prod_map = {'promociones': ('more_switch_promotions', 'Promociones'), 'limites': ('more_switch_limits', 'Límites en banca digital'), 'tarjetas': ('more_switch_cards', 'Tarjetas de débito')}
    for key, (rid, nombre) in prod_map.items():
        if key in productos:
            set_switch(driver, rid, productos[key], nombre)
    scroll_down(driver)
    return _guardar_cambios_y_confirmar(driver, timeout, reporte=reporte, paso_num=paso_num)

def _guardar_cambios_y_confirmar(driver, timeout=15, reporte=None, paso_num=None):
    print("  📝 Click en 'Guardar cambios'...")
    if reporte and paso_num is not None:
        reporte.capturar_paso(paso_num, 'Antes de guardar cambios', 'Se muestran las configuraciones aplicadas antes de guardar los cambios.', espera=1.0)
        paso_num += 1
    try:
        guardar_btn = WebDriverWait(driver, timeout).until(EC.element_to_be_clickable((AppiumBy.ID, 'more_btn_save_profile')))
        guardar_btn.click()
        print('  ✅ Click en Guardar cambios (éxito)')
        time.sleep(1)
    except:
        try:
            guardar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Guardar cambios']")
            guardar_btn.click()
            print('  ✅ Click en Guardar cambios (éxito - content-desc)')
            time.sleep(1)
        except Exception as e:
            print(f"  ❌ No se pudo clickear 'Guardar cambios': {e}")
    time.sleep(1)
    if reporte and paso_num is not None:
        reporte.capturar_paso(paso_num, 'Modal de confirmación', 'Aparece el modal de alerta solicitando confirmar los cambios.', espera=1.0)
        paso_num += 1
    try:
        print("  📝 Confirmando con 'Guardar' en el modal...")
        guardar_modal = WebDriverWait(driver, timeout).until(EC.element_to_be_clickable((AppiumBy.XPATH, "//android.widget.FrameLayout[@pane-title='Alerta']//android.widget.Button[@content-desc='Guardar']")))
        guardar_modal.click()
        print("  ✅ Click en 'Guardar' (modal)")
    except:
        try:
            guardar_modal = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Guardar']")
            guardar_modal.click()
            print("  ✅ Click en 'Guardar' (XPATH)")
        except Exception as e:
            print(f'  ❌ No se pudo confirmar en el modal: {e}')
            return False
    time.sleep(3)
    if reporte and paso_num is not None:
        reporte.capturar_paso(paso_num, 'Personalización completada', 'La personalización de la banca se completó exitosamente. Los cambios fueron guardados y confirmados.', espera=1.5)
        paso_num += 1
    print('  ✅ PERSONALIZACIÓN COMPLETADA')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('mas_personalizacion_banca_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO: LOGIN + PERSONALIZAR BANCA + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    appium_port = _input_cfg.get('appium_port', 4723)
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    PERFIL = _input_cfg.get('PERFIL', 'Cliente')
    CONFIG_PERSONALIZADO = _input_cfg.get('CONFIG_PERSONALIZADO', {'asistente_voz': True, 'accesos_directos': {'pagar_qr': True, 'cripto': True, 'recarga': True, 'cobrar_qr': False, 'pagos': False}, 'navegacion': {'transferencias': True, 'pagos_servicios': True}, 'productos_mas': {'promociones': True, 'limites': True, 'tarjetas': True}})
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Personalizacion_Banca')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Conectando a dispositivo: {device_id}')
    print(f'🔌 Puerto Appium: {appium_port}')
    print(f"🎨 Perfil a aplicar: '{PERFIL}'")
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id, appium_port)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Perfil aplicado': PERFIL})
    login_ok = _input_cfg.get('login_ok', False)
    personalizar_ok = _input_cfg.get('personalizar_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(2)
            tiempos.start('B. Personalizar banca')
            personalizar_ok = personalizar_banca(driver, PERFIL, CONFIG_PERSONALIZADO, reporte=reporte, paso_inicial=6)
            tiempos.stop()
            print(f"  ⏱️  Personalizar banca: {format_duration(tiempos.tiempos['B. Personalizar banca'])}")
            if personalizar_ok:
                print('\n✅ PERSONALIZACIÓN COMPLETADA EXITOSAMENTE')
            else:
                print('\n❌ PERSONALIZACIÓN FALLIDA')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and personalizar_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login              : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Personalizar banca : {('✅ OK' if personalizar_ok else '❌ FALLÓ')}")
        print(f'   Carpeta            : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

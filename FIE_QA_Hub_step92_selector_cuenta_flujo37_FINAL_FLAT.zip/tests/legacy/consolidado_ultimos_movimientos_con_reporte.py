"""
Flujo Consolidado (Últimos movimientos) + reporte Word.
Pasos: Login → Tipo de cuenta → Últimos movimientos → Seleccionar movimiento
       (por texto/monto/signo/índice) → Cerrar modal → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import go_back__0ec9d4708b as go_back
from framework.common.ui_helpers import _esta_en_home as _esta_en_home, _seleccionar_opcion_case_insensitive__2f3c9d8754 as _seleccionar_opcion_case_insensitive

def select_account_type(driver, tipo_cuenta):
    print(f'  📝 Seleccionando tipo de cuenta: {tipo_cuenta}...')
    time.sleep(3)
    if _seleccionar_opcion_case_insensitive(driver, tipo_cuenta, timeout=5):
        print(f'  ✅ Tipo de cuenta {tipo_cuenta} seleccionado')
        time.sleep(2)
        return True
    print(f'  ❌ Error al seleccionar tipo de cuenta: {tipo_cuenta}')
    return False

def click_ultimos_movimientos(driver):
    print('  📝 Click en Últimos movimientos...')
    time.sleep(2)
    if _seleccionar_opcion_case_insensitive(driver, 'Últimos movimientos', timeout=5):
        print('  ✅ Click en Últimos movimientos')
        time.sleep(3)
        return True
    print('  ❌ Error al clickear Últimos movimientos')
    return False

def _coincide_movimiento(desc, texto=None, monto=None, signo=None):
    if not desc:
        return False
    desc_lower = desc.lower()
    if texto:
        if texto.lower() not in desc_lower:
            return False
    if monto:
        if monto not in desc:
            return False
    if signo:
        if signo == '+' and '+Bs.' not in desc:
            return False
        if signo == '-' and '-Bs.' not in desc:
            return False
    return True

def select_movimiento_by_params(driver, texto=None, monto=None, signo=None, index=None, max_scrolls=15, pausa_scroll=0.6, debug=True):
    filtros = []
    if texto:
        filtros.append(f"texto='{texto}'")
    if monto:
        filtros.append(f"monto={(signo if signo else '')}{monto}")
    if signo and (not monto):
        filtros.append(f"signo='{signo}'")
    modo_index = not filtros and index is not None
    if filtros:
        print(f"  📝 Buscando movimiento con: {', '.join(filtros)}...")
    elif modo_index:
        print(f'  📝 Buscando movimiento por índice: {index}...')
    else:
        print(f'  📝 Sin filtros definidos, usando fallback por índice...')
    time.sleep(2)

    def _buscar_en_lista_actual():
        try:
            movimientos = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[@resource-id='shared_btn_movimiento' and @clickable='true']")
            if filtros:
                for mov in movimientos:
                    desc = mov.get_attribute('content-desc') or ''
                    if _coincide_movimiento(desc, texto, monto, signo):
                        mov.click()
                        driver._last_movimiento_desc = desc
                        print(f'  ✅ Movimiento seleccionado: {desc[:80]}...')
                        time.sleep(3)
                        return True
                return False
            if modo_index:
                if movimientos and len(movimientos) > index:
                    desc = movimientos[index].get_attribute('content-desc') or ''
                    driver._last_movimiento_desc = desc
                    movimientos[index].click()
                    print(f'  ✅ Movimiento #{index + 1} seleccionado: {desc[:80]}...')
                    time.sleep(3)
                    return True
                return False
            if movimientos:
                desc = movimientos[-1].get_attribute('content-desc') or ''
                driver._last_movimiento_desc = desc
                movimientos[-1].click()
                print(f'  ✅ Último movimiento seleccionado: {desc[:80]}...')
                time.sleep(3)
                return True
            return False
        except Exception as e:
            print(f'  ⚠️ Error buscando en lista: {e}')
            return False
    print('  🔍 Buscando en pantalla actual...')
    if _buscar_en_lista_actual():
        return True
    if modo_index:
        print(f'  ⚠️ Modo índice: no se encontró índice {index} en la primera pantalla')
        return False
    print('  🔄 Buscando con scroll incremental...')
    for intento in range(max_scrolls):
        try:
            driver.swipe(500, 1500, 500, 700, 500)
            time.sleep(pausa_scroll)
            print(f'    Scroll {intento + 1}/{max_scrolls}')
            if _buscar_en_lista_actual():
                return True
        except Exception as e:
            print(f'  ⚠️ Error en scroll {intento + 1}: {e}')
    print('  🔄 Scroll hacia arriba por si acaso...')
    for intento in range(3):
        try:
            driver.swipe(500, 700, 500, 1500, 500)
            time.sleep(pausa_scroll)
            if _buscar_en_lista_actual():
                return True
        except:
            pass
    if debug:
        print('  🔍 Movimientos disponibles (debug):')
        try:
            movimientos = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[@resource-id='shared_btn_movimiento' and @clickable='true']")
            print(f'  🔍 Total en pantalla: {len(movimientos)}')
            for i, mov in enumerate(movimientos[:10]):
                desc = mov.get_attribute('content-desc') or ''
                print(f'    [{i}] {desc[:100]}...')
        except:
            pass
    print(f'  ❌ No se encontró movimiento con los criterios especificados')
    return False

def close_movement_modal(driver):
    print('  📝 Cerrando modal de movimiento...')
    time.sleep(3)
    try:
        driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Transferencia') or contains(@content-desc, 'Comprobante')]")
        print('  ✅ Modal de movimiento detectado')
    except:
        print('  ⚠️ No se detectó modal de movimiento')
    try:
        cerrar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Cerrar']")
        cerrar_btn.click()
        print('  ✅ Click en Cerrar (content-desc)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        cerrar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Cerrar') and @clickable='true']")
        cerrar_btn.click()
        print('  ✅ Click en Cerrar (texto)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        regresar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Regresar']")
        regresar.click()
        print('  ✅ Click en Regresar')
        time.sleep(2)
        return True
    except:
        pass
    try:
        aceptar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Aceptar']")
        aceptar.click()
        print('  ✅ Click en Aceptar')
        time.sleep(2)
        return True
    except:
        pass
    try:
        driver.back()
        print('  ✅ Back para cerrar modal')
        time.sleep(2)
        return True
    except:
        return False

def realizar_consolidado(driver, tipo_cuenta='AHORRO', texto_movimiento=None, monto=None, signo=None, movimiento_index=None, reporte=None, tiempos=None, paso_inicial=6):
    print(f'\n📊 INICIANDO CONSOLIDADO')
    print(f'🏦 Tipo cuenta: {tipo_cuenta}')
    filtros_str = []
    if texto_movimiento:
        filtros_str.append(f"texto='{texto_movimiento}'")
    if monto:
        filtros_str.append(f"monto={(signo if signo else '')}{monto}")
    if signo and (not monto):
        filtros_str.append(f"signo='{signo}'")
    if filtros_str:
        print(f"📝 Búsqueda por: {', '.join(filtros_str)}")
    elif movimiento_index is not None:
        print(f'📝 Búsqueda por índice: {movimiento_index}')
    else:
        print(f'📝 Sin filtros → fallback: último movimiento')
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Tipo de cuenta')
    if not select_account_type(driver, tipo_cuenta):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f"Cuenta '{tipo_cuenta}' seleccionada", f"Se seleccionó el tipo de cuenta '{tipo_cuenta}' desde el home.", espera=1.5)
    paso_num += 1
    tiempos.start('2. Últimos movimientos')
    if not click_ultimos_movimientos(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla de Últimos Movimientos', 'Se accedió a la lista de Últimos Movimientos de la cuenta.', espera=1.5)
    paso_num += 1
    tiempos.start('3. Seleccionar movimiento')
    if not select_movimiento_by_params(driver, texto=texto_movimiento, monto=monto, signo=signo, index=movimiento_index):
        print(f'  ❌ No se encontró el movimiento con los criterios dados')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        desc_mov = getattr(driver, '_last_movimiento_desc', '') or ''
        if filtros_str:
            desc_titulo = f"Movimiento encontrado por: {', '.join(filtros_str)}"
        elif movimiento_index is not None:
            desc_titulo = f'Movimiento #{movimiento_index + 1} seleccionado'
        else:
            desc_titulo = 'Último movimiento seleccionado'
        reporte.capturar_paso(paso_num, desc_titulo, f'Se abrió el detalle del movimiento. Descripción: {desc_mov[:120]}', espera=2.0)
    paso_num += 1
    tiempos.start('4. Cerrar modal')
    close_movement_modal(driver)
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Modal de movimiento cerrado', 'Se cerró el detalle del movimiento y se regresó a la lista.', espera=1.0)
    paso_num += 1
    tiempos.start('5. Volver al home')
    go_back(driver)
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Consolidado finalizado', 'Se regresó exitosamente al home.', espera=1.5)
    paso_num += 1
    print('\n✅ CONSOLIDADO COMPLETADO EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('consolidado_ultimos_movimientos_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO: LOGIN + CONSOLIDADO (Últimos movimientos) + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    TIPO_CUENTA = _input_cfg.get('TIPO_CUENTA', 'C. CORRIENTES')
    TEXTO_MOVIMIENTO = _input_cfg.get('TEXTO_MOVIMIENTO', 'Rc-Iva( )')
    MONTO_MOVIMIENTO = _input_cfg.get('MONTO_MOVIMIENTO', None)
    SIGNO_MOVIMIENTO = _input_cfg.get('SIGNO_MOVIMIENTO', None)
    MOVIMIENTO_INDEX = _input_cfg.get('MOVIMIENTO_INDEX', 0)
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Consolidado_Ultimos_Movimientos')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f'🏦 Tipo cuenta: {TIPO_CUENTA}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Tipo de cuenta': TIPO_CUENTA, 'Texto del movimiento': TEXTO_MOVIMIENTO or '(no especificado)', 'Monto del movimiento': MONTO_MOVIMIENTO or '(no especificado)', 'Signo del movimiento': SIGNO_MOVIMIENTO or '(no especificado)', 'Índice fallback': MOVIMIENTO_INDEX})
    login_ok = _input_cfg.get('login_ok', False)
    consolidado_ok = _input_cfg.get('consolidado_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            consolidado_ok = realizar_consolidado(driver, tipo_cuenta=TIPO_CUENTA, texto_movimiento=TEXTO_MOVIMIENTO, monto=MONTO_MOVIMIENTO, signo=SIGNO_MOVIMIENTO, movimiento_index=MOVIMIENTO_INDEX, reporte=reporte, tiempos=tiempos, paso_inicial=6)
            if consolidado_ok:
                print('\n🎉 CONSOLIDADO EXITOSO!')
            else:
                print('\n❌ CONSOLIDADO FALLIDO')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and consolidado_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login          : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Consolidado    : {('✅ OK' if consolidado_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

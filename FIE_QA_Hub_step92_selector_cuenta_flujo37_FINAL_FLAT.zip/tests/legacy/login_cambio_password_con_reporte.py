"""
Flujo Cambio de Contraseña + reporte Word.
Pasos: Login → Más → Configuraciones usuario → Cambio de contraseña
       → Contraseña actual + Nueva + Confirmar → Continuar
       → Clave temporal → Confirmar cambio → Continuar (éxito) → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import volver_home_password
from framework.common.ui_helpers import _esta_en_home as _esta_en_home, select_configuraciones_usuario

def click_mas_menu(driver):
    print('  📝 Click en menú Más...')
    time.sleep(2)
    try:
        mas_btn = driver.find_element(AppiumBy.ID, 'home_btn_mas')
        mas_btn.click()
        print('  ✅ Click en Más (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        mas_btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Más' and @clickable='true']")
        mas_btn.click()
        print('  ✅ Click en Más (content-desc)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        mas_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Más') and @clickable='true']")
        mas_btn.click()
        print('  ✅ Click en Más (texto)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al clickear Más: {e}')
        return False

def select_cambio_contraseña(driver):
    print('  📝 Seleccionando Cambio de contraseña...')
    time.sleep(2)
    try:
        btn = driver.find_element(AppiumBy.ID, 'user_profile_settings_password')
        btn.click()
        print('  ✅ Click en Cambio de contraseña (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Cambio de contraseña')]")
        btn.click()
        print('  ✅ Click en Cambio de contraseña (content-desc)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al seleccionar Cambio de contraseña: {e}')
        return False

def fill_password_change_data(driver, password_actual, nueva_password, confirmar_password):
    print('  📝 Llenando datos para cambio de contraseña...')
    time.sleep(2)
    try:
        actual_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='Contraseña actual']")
        actual_input.click()
        time.sleep(0.5)
        actual_input.clear()
        actual_input.send_keys(password_actual)
        print('  ✅ Contraseña actual ingresada')
        time.sleep(0.5)
        try:
            driver.hide_keyboard()
        except:
            pass
    except:
        try:
            actual_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[contains(@hint, 'Contraseña actual')]")
            actual_input.click()
            time.sleep(0.5)
            actual_input.clear()
            actual_input.send_keys(password_actual)
            print('  ✅ Contraseña actual ingresada (hint parcial)')
            time.sleep(0.5)
            try:
                driver.hide_keyboard()
            except:
                pass
        except Exception as e:
            print(f'  ❌ Error al ingresar contraseña actual: {e}')
            return False
    try:
        nueva_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='Nueva contraseña']")
        nueva_input.click()
        time.sleep(0.5)
        nueva_input.clear()
        nueva_input.send_keys(nueva_password)
        print('  ✅ Nueva contraseña ingresada')
        time.sleep(0.5)
        try:
            driver.hide_keyboard()
        except:
            pass
    except:
        try:
            nueva_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[contains(@hint, 'Nueva contraseña')]")
            nueva_input.click()
            time.sleep(0.5)
            nueva_input.clear()
            nueva_input.send_keys(nueva_password)
            print('  ✅ Nueva contraseña ingresada (hint parcial)')
            time.sleep(0.5)
            try:
                driver.hide_keyboard()
            except:
                pass
        except Exception as e:
            print(f'  ❌ Error al ingresar nueva contraseña: {e}')
            return False
    try:
        confirmar_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='Confirmar nueva contraseña']")
        confirmar_input.click()
        time.sleep(0.5)
        confirmar_input.clear()
        confirmar_input.send_keys(confirmar_password)
        print('  ✅ Confirmar contraseña ingresada')
        time.sleep(0.5)
        try:
            driver.hide_keyboard()
        except:
            pass
    except:
        try:
            confirmar_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[contains(@hint, 'Confirmar')]")
            confirmar_input.click()
            time.sleep(0.5)
            confirmar_input.clear()
            confirmar_input.send_keys(confirmar_password)
            print('  ✅ Confirmar contraseña ingresada (hint parcial)')
            time.sleep(0.5)
            try:
                driver.hide_keyboard()
            except:
                pass
        except Exception as e:
            print(f'  ❌ Error al ingresar confirmar contraseña: {e}')
            return False
    return True

def click_continuar_password(driver):
    print('  📝 Click en Continuar...')
    time.sleep(2)
    try:
        btn = driver.find_element(AppiumBy.ID, 'password_change_btn_continuar')
        btn.click()
        print('  ✅ Click en Continuar (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")
        btn.click()
        print('  ✅ Click en Continuar (content-desc)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al clickear Continuar: {e}')
        return False

def confirmar_cambio_password(driver, clave_temporal='123456'):
    print('  📝 Confirmando cambio de contraseña...')
    time.sleep(3)
    try:
        driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, '¿Desea confirmar el cambio?')]")
        print('  ✅ Modal de confirmación detectado')
    except:
        print('  ⚠️ No se detectó modal de confirmación, continuando...')
    try:
        otp_input = driver.find_element(AppiumBy.ID, 'password_change_otp_clave')
        otp_input.click()
        time.sleep(0.5)
        otp_input.clear()
        otp_input.send_keys(clave_temporal)
        print(f'  ✅ Clave temporal ingresada: {clave_temporal}')
        time.sleep(0.5)
        try:
            driver.hide_keyboard()
        except:
            pass
    except:
        try:
            otp_input = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='password_change_otp_clave']")
            otp_input.click()
            time.sleep(0.5)
            otp_input.clear()
            otp_input.send_keys(clave_temporal)
            print(f'  ✅ Clave temporal ingresada: {clave_temporal}')
            time.sleep(0.5)
            try:
                driver.hide_keyboard()
            except:
                pass
        except Exception as e:
            print(f'  ⚠️ Error al ingresar clave temporal: {e}')
    try:
        btn = driver.find_element(AppiumBy.ID, 'shared_btn_confirmar_clave_temporal')
        btn.click()
        print('  ✅ Click en Confirmar cambio (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Confirmar cambio']")
        btn.click()
        print('  ✅ Click en Confirmar cambio (content-desc)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al confirmar cambio: {e}')
        return False

def click_continuar_exito_password(driver):
    print('  📝 Click en Continuar (modal de éxito)...')
    time.sleep(3)
    try:
        btn = driver.find_element(AppiumBy.ID, 'password_change_btn_continuar_exito')
        btn.click()
        print('  ✅ Click en Continuar (ID)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")
        btn.click()
        print('  ✅ Click en Continuar (content-desc)')
        time.sleep(2)
        return True
    except Exception as e:
        print(f'  ⚠️ No se encontró el botón Continuar: {e}')
        return False

def realizar_cambio_contraseña(driver, password_actual='Credito12$', nueva_password='Credito12$', confirmar_password='Credito12$', clave_temporal='123456', reporte=None, tiempos=None, paso_inicial=6):
    print(f'\n🔑 INICIANDO CAMBIO DE CONTRASEÑA')
    print(f'📝 Contraseña actual: {password_actual}')
    print(f'📝 Nueva contraseña: {nueva_password}')
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Ir a Más')
    if not click_mas_menu(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Menú Más abierto', "Se accedió al menú 'Más' desde la barra de navegación inferior.", espera=1.5)
    paso_num += 1
    tiempos.start('2. Configuraciones usuario')
    if not select_configuraciones_usuario(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Configuraciones de usuario', 'Se accedió a las Configuraciones de usuario.', espera=1.5)
    paso_num += 1
    tiempos.start('3. Cambio de contraseña')
    if not select_cambio_contraseña(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla de Cambio de Contraseña', 'Se accedió a la pantalla de cambio de contraseña con los campos: Contraseña actual, Nueva contraseña y Confirmar nueva contraseña.', espera=1.5)
    paso_num += 1
    tiempos.start('4. Llenar datos')
    if not fill_password_change_data(driver, password_actual, nueva_password, confirmar_password):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Datos de contraseña completados', 'Se completaron los campos: Contraseña actual, Nueva contraseña y Confirmar nueva contraseña.', espera=1.5)
    paso_num += 1
    tiempos.start('5. Continuar')
    if not click_continuar_password(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Continuar (cambio)', 'Se hizo clic en Continuar para proceder con el cambio.', espera=1.5)
    paso_num += 1
    print('  📝 Esperando modal de confirmación...')
    time.sleep(3)
    tiempos.start('6. Confirmar cambio')
    if not confirmar_cambio_password(driver, clave_temporal):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Cambio de contraseña confirmado', f"Se confirmó el cambio de contraseña con la clave temporal '{clave_temporal}'.", espera=1.5)
    paso_num += 1
    print('  📝 Esperando pantalla de éxito...')
    time.sleep(3)
    tiempos.start('7. Continuar (éxito)')
    if not click_continuar_exito_password(driver):
        print('  ⚠️ No se pudo hacer click en Continuar (modal de éxito)')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Modal de éxito aceptado', 'Se confirmó el mensaje de éxito del cambio de contraseña.', espera=1.5)
    paso_num += 1
    tiempos.start('8. Volver al home')
    if not volver_home_password(driver):
        print('  ⚠️ No se pudo volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Cambio de Contraseña finalizado', 'Se regresó exitosamente al home. El cambio de contraseña ha terminado.', espera=1.5)
    paso_num += 1
    print('\n✅ CAMBIO DE CONTRASEÑA COMPLETADO EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('login_cambio_password_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO: LOGIN + CAMBIO DE CONTRASEÑA + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    clave_temporal = _input_cfg.get('clave_temporal', '123456')
    PASSWORD_ACTUAL = _input_cfg.get('PASSWORD_ACTUAL', 'Abc#1234')
    NUEVA_PASSWORD = _input_cfg.get('NUEVA_PASSWORD', 'Abc#12345')
    CONFIRMAR_PASSWORD = _input_cfg.get('CONFIRMAR_PASSWORD', 'Abc#12345')
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Cambio_Password')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f'📝 Contraseña actual: {PASSWORD_ACTUAL}')
    print(f'📝 Nueva contraseña: {NUEVA_PASSWORD}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Contraseña actual': PASSWORD_ACTUAL, 'Nueva contraseña': NUEVA_PASSWORD, 'Clave temporal': clave_temporal})
    login_ok = _input_cfg.get('login_ok', False)
    cambio_ok = _input_cfg.get('cambio_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            cambio_ok = realizar_cambio_contraseña(driver, password_actual=PASSWORD_ACTUAL, nueva_password=NUEVA_PASSWORD, confirmar_password=CONFIRMAR_PASSWORD, clave_temporal=clave_temporal, reporte=reporte, tiempos=tiempos, paso_inicial=6)
            if cambio_ok:
                print('\n🎉 CAMBIO DE CONTRASEÑA EXITOSO!')
            else:
                print('\n❌ CAMBIO DE CONTRASEÑA FALLIDO')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and cambio_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login          : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Cambio pass.   : {('✅ OK' if cambio_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

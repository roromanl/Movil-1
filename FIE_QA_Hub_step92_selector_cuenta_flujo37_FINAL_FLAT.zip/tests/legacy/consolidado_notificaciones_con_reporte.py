"""
Flujo Notificaciones con búsqueda por fechas + reporte Word.
Pasos: Login → Campana → Período → (Fechas desde/hasta) → Consultar
       → Seleccionar notificación → Continuar detalle → Volver al home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import re
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import volver_home_notificaciones__aaeaf45c7e as volver_home_notificaciones
from framework.common.ui_helpers import _esta_en_home as _esta_en_home, _seleccionar_opcion_case_insensitive__df5762857e as _seleccionar_opcion_case_insensitive

def click_notificaciones_campana(driver):
    print('  📝 Click en campana de Notificaciones (home)...')
    time.sleep(2)
    wait = WebDriverWait(driver, 5)
    try:
        notif_btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'notifications_btn_campana')))
        notif_btn.click()
        print('  ✅ Click en campana (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        notif_btn = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='notifications_btn_campana' and @clickable='true']")
        notif_btn.click()
        print('  ✅ Click en campana (XPATH)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        notif_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'notificaciones nuevas') and @clickable='true']")
        notif_btn.click()
        print('  ✅ Click en campana (content-desc)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        elementos = driver.find_elements(AppiumBy.XPATH, "//*[@content-desc and @clickable='true' and string-length(@content-desc) <= 4]")
        for elem in elementos:
            desc = elem.get_attribute('content-desc') or ''
            if desc.replace('+', '').strip().isdigit():
                elem.click()
                print(f"  ✅ Click en campana (fallback: '{desc}')")
                time.sleep(3)
                return True
    except:
        pass
    print('  ❌ Error al clickear la campana de Notificaciones')
    return False

def select_fechas(driver, opcion='Todos', timeout=15):
    """Abre el modal de Fechas y selecciona una opción"""
    print(f"  📝 Seleccionando período: '{opcion}'...")
    time.sleep(2)
    if not opcion:
        print('  ❌ Opción vacía')
        return False
    abierto = False
    try:
        fechas_btn = driver.find_element(AppiumBy.ID, 'notifications_select_fechas')
        fechas_btn.click()
        print('  ✅ Click en Fechas (ID)')
        abierto = True
        time.sleep(2)
    except:
        pass
    if not abierto:
        if _seleccionar_opcion_case_insensitive(driver, 'Fechas', timeout=5, debug=True):
            print('  ✅ Click en Fechas (helper)')
            abierto = True
            time.sleep(2)
    if not abierto:
        print('  ❌ Error al abrir selector de fechas')
        return False
    time.sleep(2)
    if _seleccionar_opcion_case_insensitive(driver, opcion, timeout=5, debug=True):
        print(f'  ✅ Opción seleccionada: {opcion}')
        time.sleep(2)
        return True
    print(f'  ❌ No se encontró la opción: {opcion}')
    return False

def select_fecha(driver, campo, fecha):
    print(f'\n  📝 Seleccionando {campo}: {fecha}...')
    time.sleep(2)
    dia, mes, anio = fecha.split('/')
    dia_int = int(dia)
    mes_int = int(mes)
    anio_int = int(anio)
    meses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre']
    mes_nombre = meses[mes_int - 1]
    es_desde = any((p in campo.lower() for p in ('inicial', 'desde', 'from')))
    rid_objetivo = 'notifications_input_fecha_desde' if es_desde else 'notifications_input_fecha_hasta'
    print(f'  🔍 Buscando campo {rid_objetivo}...')
    campo_edit = None
    try:
        campo_edit = driver.find_element(AppiumBy.ID, rid_objetivo)
        print(f'  ✅ Campo encontrado: id={rid_objetivo}')
    except:
        try:
            campo_edit = driver.find_element(AppiumBy.XPATH, f"//*[@resource-id='{rid_objetivo}']")
            print(f'  ✅ Campo encontrado por XPATH')
        except:
            print(f'  ❌ No se encontró el campo {rid_objetivo}')
            return False
    if not campo_edit:
        return False
    try:
        bounds = campo_edit.get_attribute('bounds') or ''
        m = re.match('\\[(\\d+),(\\d+)\\]\\[(\\d+),(\\d+)\\]', bounds)
        if m:
            x1, y1, x2, y2 = map(int, m.groups())
            cx = (x1 + x2) // 2
            cy = (y1 + y2) // 2
            print(f'  👆 Tap en ({cx}, {cy}) [bounds={bounds}]')
            driver.tap([(cx, cy)])
            print(f'  ✅ Tap ejecutado')
        else:
            return False
    except Exception as e:
        print(f'  ❌ Error en tap: {e}')
        return False
    time.sleep(3)
    calendario_abierto = False
    try:
        driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Seleccionar fecha')]")
        calendario_abierto = True
        print("  ✅ Calendario abierto ('Seleccionar fecha' detectado)")
    except:
        print("  ⚠️ No se detectó 'Seleccionar fecha'")
    if not calendario_abierto:
        try:
            view_hijo = campo_edit.find_element(AppiumBy.XPATH, './/android.view.View')
            bounds_hijo = view_hijo.get_attribute('bounds') or ''
            m = re.match('\\[(\\d+),(\\d+)\\]\\[(\\d+),(\\d+)\\]', bounds_hijo)
            if m:
                x1, y1, x2, y2 = map(int, m.groups())
                cx = (x1 + x2) // 2
                cy = (y1 + y2) // 2
                print(f'  👆 Reintento tap en View hijo ({cx}, {cy})')
                driver.tap([(cx, cy)])
                time.sleep(2)
                try:
                    driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Seleccionar fecha')]")
                    calendario_abierto = True
                    print('  ✅ Calendario abierto tras reintento')
                except:
                    pass
        except:
            pass
    if not calendario_abierto:
        print(f'  ❌ El calendario NO se abrió')
        return False

    def obtener_mes_actual():
        try:
            titulo_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Enero') or contains(@content-desc, 'Febrero') or contains(@content-desc, 'Marzo') or contains(@content-desc, 'Abril') or contains(@content-desc, 'Mayo') or contains(@content-desc, 'Junio') or contains(@content-desc, 'Julio') or contains(@content-desc, 'Agosto') or contains(@content-desc, 'Septiembre') or contains(@content-desc, 'Octubre') or contains(@content-desc, 'Noviembre') or contains(@content-desc, 'Diciembre')]")
            return titulo_btn.get_attribute('content-desc') or ''
        except:
            return None

    def click_boton_mes(nombre_boton):
        try:
            padre = driver.find_element(AppiumBy.XPATH, f"//android.widget.Button[@content-desc='{nombre_boton}']")
            clickable = padre.get_attribute('clickable')
            enabled = padre.get_attribute('enabled')
            if enabled == 'false':
                print(f"    ⚠️ '{nombre_boton}' DESHABILITADO (padre)")
                return False
            if clickable == 'true':
                padre.click()
                print(f"    ✅ Click en padre '{nombre_boton}'")
                return True
            try:
                hijo = padre.find_element(AppiumBy.XPATH, ".//android.widget.Button[@clickable='true']")
                hijo_enabled = hijo.get_attribute('enabled')
                if hijo_enabled == 'false':
                    print(f"    ⚠️ '{nombre_boton}' DESHABILITADO (hijo)")
                    return False
                hijo.click()
                print(f"    ✅ Click en hijo '{nombre_boton}'")
                return True
            except:
                pass
            bounds = padre.get_attribute('bounds') or ''
            m = re.match('\\[(\\d+),(\\d+)\\]\\[(\\d+),(\\d+)\\]', bounds)
            if m:
                x1, y1, x2, y2 = map(int, m.groups())
                cx = (x1 + x2) // 2
                cy = (y1 + y2) // 2
                print(f"    👆 Tap en '{nombre_boton}' ({cx}, {cy})")
                driver.tap([(cx, cy)])
                return True
        except Exception as e:
            print(f"    ⚠️ No se encontró '{nombre_boton}': {str(e)[:60]}")
        return False
    encontrado = False
    for intento in range(24):
        titulo_actual = obtener_mes_actual()
        print(f'  📅 Mes actual: {titulo_actual}')
        if titulo_actual and mes_nombre in titulo_actual and (str(anio_int) in titulo_actual):
            print(f'  ✅ Mes correcto: {mes_nombre} {anio_int}')
            encontrado = True
            break
        try:
            mes_actual = None
            for i, nombre_mes in enumerate(meses, 1):
                if nombre_mes in titulo_actual:
                    mes_actual = i
                    break
            años = re.findall('\\d{4}', titulo_actual)
            anio_actual = int(años[0]) if años else None
            if mes_actual and anio_actual:
                diff_meses = (anio_int - anio_actual) * 12 + (mes_int - mes_actual)
                print(f'  📊 Diferencia: {diff_meses} meses (actual: {mes_actual}/{anio_actual}, destino: {mes_int}/{anio_int})')
                if diff_meses > 0:
                    if not click_boton_mes('Mes siguiente'):
                        print('  ❌ No se pudo avanzar al siguiente mes')
                        break
                    time.sleep(1)
                elif diff_meses < 0:
                    if not click_boton_mes('Mes anterior'):
                        print('  ❌ No se pudo retroceder al mes anterior')
                        break
                    time.sleep(1)
                else:
                    encontrado = True
                    break
            else:
                print(f"  ⚠️ No se pudo determinar mes/año de '{titulo_actual}'")
                break
        except Exception as e:
            print(f'  ⚠️ Error en navegación: {str(e)[:60]}')
            break
    if not encontrado:
        print(f'  ❌ No se llegó al mes {mes_nombre} {anio_int}')
        try:
            driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Cancelar']").click()
            time.sleep(1)
        except:
            pass
        return False
    print(f'  🔍 Seleccionando día {dia_int}...')
    time.sleep(1)
    seleccionado = False
    estrategias = [lambda: driver.find_element(AppiumBy.XPATH, f"//android.view.View[@content-desc='{dia_int}' and @clickable='true']"), lambda: driver.find_element(AppiumBy.XPATH, f"//android.view.View[@content-desc='{dia_int}' and @clickable='true' and string-length(@content-desc) <= 2]"), lambda: driver.find_element(AppiumBy.XPATH, f"//*[@content-desc='{dia_int}' and @clickable='true' and string-length(@content-desc) <= 2]"), lambda: driver.find_element(AppiumBy.XPATH, f"//*[@text='{dia_int}' and @clickable='true']")]
    for i, estrategia in enumerate(estrategias, 1):
        try:
            dia_btn = estrategia()
            if dia_btn.is_displayed() and dia_btn.is_enabled():
                desc = dia_btn.get_attribute('content-desc') or ''
                print(f"  ✅ Día {dia_int} encontrado (estrategia {i}): content-desc='{desc}'")
                dia_btn.click()
                print(f'  ✅ Día {dia_int} seleccionado')
                seleccionado = True
                break
        except:
            pass
    if not seleccionado:
        print('  🔄 Fallback: iterando Views con content-desc numérico...')
        try:
            candidatos = driver.find_elements(AppiumBy.XPATH, "//android.view.View[@clickable='true' and @content-desc and string-length(@content-desc) <= 2]")
            for c in candidatos:
                desc = c.get_attribute('content-desc') or ''
                if desc.isdigit() and int(desc) == dia_int:
                    c.click()
                    print(f'  ✅ Día {dia_int} seleccionado (iteración)')
                    seleccionado = True
                    break
        except:
            pass
    if not seleccionado:
        print(f'  ❌ No se pudo seleccionar el día {dia_int}')
        return False
    time.sleep(1)
    print(f'  📝 Confirmando con Aceptar...')
    try:
        aceptar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Aceptar']")
        if aceptar_btn.is_displayed() and aceptar_btn.is_enabled():
            aceptar_btn.click()
            print(f'  ✅ Fecha {campo} confirmada')
            time.sleep(2)
            return True
    except:
        pass
    try:
        aceptar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Aceptar') and @clickable='true']")
        aceptar_btn.click()
        print(f'  ✅ Fecha {campo} confirmada (texto)')
        time.sleep(2)
        return True
    except Exception as e:
        print(f'  ❌ No se encontró Aceptar: {e}')
        return False

def click_consultar_notificaciones(driver):
    print('  📝 Click en Consultar...')
    time.sleep(2)
    try:
        btn = driver.find_element(AppiumBy.ID, 'notifications_btn_consultar')
        btn.click()
        print('  ✅ Click en Consultar (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Consultar']")
        btn.click()
        print('  ✅ Click en Consultar (content-desc)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Consultar') and @clickable='true']")
        btn.click()
        print('  ✅ Click en Consultar (texto)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al clickear Consultar: {e}')
        return False

def select_notificacion_by_titulo(driver, titulo_busqueda, timeout=15):
    print(f"  📝 Buscando notificación: '{titulo_busqueda}'...")
    time.sleep(2)
    if not titulo_busqueda:
        print('  ❌ Título vacío')
        return False
    titulo_lower = titulo_busqueda.lower()
    desc_notif_encontrada = None

    def buscar():
        nonlocal desc_notif_encontrada
        try:
            notificacion = driver.find_element(AppiumBy.XPATH, f"//android.widget.Button[contains(@content-desc, '{titulo_busqueda}') and @clickable='true']")
            desc_notif_encontrada = notificacion.get_attribute('content-desc')
            notificacion.click()
            print(f'  ✅ Notificación seleccionada (content-desc)')
            time.sleep(3)
            return True
        except:
            pass
        try:
            notificaciones = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[contains(@resource-id, 'notifications_btn_detalle_')]")
            for notif in notificaciones:
                desc = notif.get_attribute('content-desc') or ''
                if titulo_lower in desc.lower():
                    desc_notif_encontrada = desc
                    notif.click()
                    print(f'  ✅ Notificación seleccionada (iteración)')
                    time.sleep(3)
                    return True
        except:
            pass
        try:
            notificacion = driver.find_element(AppiumBy.XPATH, f"//*[contains(translate(@content-desc, 'ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÑ', 'abcdefghijklmnopqrstuvwxyzáéíóúñ'), '{titulo_lower}') and @clickable='true']")
            desc_notif_encontrada = notificacion.get_attribute('content-desc')
            notificacion.click()
            print(f'  ✅ Notificación seleccionada (case-insensitive)')
            time.sleep(3)
            return True
        except:
            pass
        try:
            notificacion = driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{titulo_busqueda}') and @clickable='true']")
            notificacion.click()
            print(f'  ✅ Notificación seleccionada (texto)')
            time.sleep(3)
            return True
        except:
            pass
        return False
    print('  🔍 Buscando sin scroll...')
    if buscar():
        driver._last_notif_desc = desc_notif_encontrada
        return True
    print('  🔄 Scroll hacia abajo...')
    for i in range(3):
        try:
            driver.swipe(500, 1500, 500, 600, 500)
            time.sleep(0.5)
            print(f'  🔍 Buscando después de scroll {i + 1}...')
            if buscar():
                driver._last_notif_desc = desc_notif_encontrada
                return True
        except:
            pass
    print('  🔄 Scroll hacia arriba...')
    for i in range(2):
        try:
            driver.swipe(500, 600, 500, 1500, 500)
            time.sleep(0.5)
            print(f'  🔍 Buscando después de scroll arriba {i + 1}...')
            if buscar():
                driver._last_notif_desc = desc_notif_encontrada
                return True
        except:
            pass
    print(f"  ❌ No se encontró notificación con: '{titulo_busqueda}'")
    return False

def click_continuar_detalle(driver):
    print('  📝 Click en Continuar (detalle)...')
    time.sleep(3)
    try:
        btn = driver.find_element(AppiumBy.ID, 'notifications_btn_continuar_detalle')
        btn.click()
        print('  ✅ Click en Continuar (ID)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")
        btn.click()
        print('  ✅ Click en Continuar (content-desc)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Continuar') and @clickable='true']")
        btn.click()
        print('  ✅ Click en Continuar (texto)')
        time.sleep(2)
        return True
    except Exception as e:
        print(f'  ❌ Error al clickear Continuar: {e}')
        return False

def _normalizar_fecha_ui(value):
    v=str(value or '').strip().replace('-', '/')
    q=v.split('/')
    if len(q)!=3:return v
    if len(q[0])==4:y,m,d=q
    else:d,m,y=q
    return f'{int(d):02d}/{int(m):02d}/{int(y):04d}'

def realizar_notificaciones_fechas(driver, opcion_fechas='Personalizado', fecha_desde='28/08/2026', fecha_hasta='04/09/2026', titulo_notificacion='Registro de dispositivo', reporte=None, tiempos=None, paso_inicial=6):
    fecha_desde=_normalizar_fecha_ui(fecha_desde);fecha_hasta=_normalizar_fecha_ui(fecha_hasta)
    print(f'\n📬 INICIANDO CONSULTA DE NOTIFICACIONES POR FECHAS')
    print(f'📅 Período: {opcion_fechas}')
    if opcion_fechas == 'Personalizado':
        print(f'📅 Desde: {fecha_desde}')
        print(f'📅 Hasta: {fecha_hasta}')
    print(f'📝 Título: {titulo_notificacion}')
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Click campana')
    if not click_notificaciones_campana(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla de Notificaciones', 'Se accedió a la pantalla de notificaciones desde la campana del home.', espera=1.5)
    paso_num += 1
    tiempos.start('2. Seleccionar período')
    if not select_fechas(driver, opcion_fechas):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f"Período '{opcion_fechas}' seleccionado", f"Se seleccionó el período '{opcion_fechas}' para filtrar las notificaciones.", espera=1.5)
    paso_num += 1
    if opcion_fechas == 'Personalizado':
        tiempos.start('3. Fecha inicial')
        if not select_fecha(driver, 'Fecha inicial', fecha_desde):
            tiempos.stop()
            return False
        tiempos.stop()
        if reporte:
            reporte.capturar_paso(paso_num, f'Fecha inicial: {fecha_desde}', f'Se seleccionó la fecha inicial {fecha_desde} en el calendario.', espera=1.0)
        paso_num += 1
        tiempos.start('4. Fecha final')
        if not select_fecha(driver, 'Fecha final', fecha_hasta):
            tiempos.stop()
            return False
        tiempos.stop()
        if reporte:
            reporte.capturar_paso(paso_num, f'Fecha final: {fecha_hasta}', f'Se seleccionó la fecha final {fecha_hasta} en el calendario.', espera=1.0)
        paso_num += 1
        tiempos.start('5. Consultar')
        if not click_consultar_notificaciones(driver):
            tiempos.stop()
            return False
        tiempos.stop()
        if reporte:
            reporte.capturar_paso(paso_num, 'Consultar notificaciones', f'Se hizo clic en Consultar. Se muestran los resultados del período {fecha_desde} - {fecha_hasta}.', espera=2.0)
        paso_num += 1
    tiempos.start('6. Buscar notificación')
    if not select_notificacion_by_titulo(driver, titulo_notificacion):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        desc_notif = getattr(driver, '_last_notif_desc', '') or ''
        reporte.capturar_paso(paso_num, f"Notificación '{titulo_notificacion}' abierta", f"Se abrió la notificación con título '{titulo_notificacion}'. Detalle: {desc_notif[:120]}", espera=2.0)
    paso_num += 1
    tiempos.start('7. Continuar detalle')
    if not click_continuar_detalle(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Detalle de notificación confirmado', 'Se hizo clic en Continuar en el detalle de la notificación.', espera=1.5)
    paso_num += 1
    tiempos.start('8. Volver al home')
    if not volver_home_notificaciones(driver):
        print('  ⚠️ No se pudo volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Notificaciones por Fechas finalizado', 'Se regresó exitosamente al home. La consulta por fechas ha terminado.', espera=1.5)
    paso_num += 1
    print('\n✅ CONSULTA DE NOTIFICACIONES POR FECHAS COMPLETADA EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('consolidado_notificaciones_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO: LOGIN + NOTIFICACIONES POR FECHAS + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    OPCION_FECHAS = _input_cfg.get('OPCION_FECHAS', 'Personalizado')
    FECHA_DESDE = _input_cfg.get('FECHA_DESDE', '01/08/2026')
    FECHA_HASTA = _input_cfg.get('FECHA_HASTA', '18/09/2026')
    TITULO_NOTIFICACION = _input_cfg.get('TITULO_NOTIFICACION', 'Error transferencia ach')
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Notificaciones_Fechas')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f'📅 Período: {OPCION_FECHAS}')
    if OPCION_FECHAS == 'Personalizado':
        print(f'📅 Desde: {FECHA_DESDE}')
        print(f'📅 Hasta: {FECHA_HASTA}')
    print(f'📝 Título: {TITULO_NOTIFICACION}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Opción de fechas': OPCION_FECHAS, 'Fecha desde': FECHA_DESDE if OPCION_FECHAS == 'Personalizado' else '(no aplica)', 'Fecha hasta': FECHA_HASTA if OPCION_FECHAS == 'Personalizado' else '(no aplica)', 'Título de notificación': TITULO_NOTIFICACION})
    login_ok = _input_cfg.get('login_ok', False)
    notif_ok = _input_cfg.get('notif_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            notif_ok = realizar_notificaciones_fechas(driver, opcion_fechas=OPCION_FECHAS, fecha_desde=FECHA_DESDE, fecha_hasta=FECHA_HASTA, titulo_notificacion=TITULO_NOTIFICACION, reporte=reporte, tiempos=tiempos, paso_inicial=6)
            if notif_ok:
                print('\n🎉 CONSULTA DE NOTIFICACIONES POR FECHAS EXITOSA!')
            else:
                print('\n❌ CONSULTA DE NOTIFICACIONES POR FECHAS FALLIDA')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and notif_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login          : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Notificaciones : {('✅ OK' if notif_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

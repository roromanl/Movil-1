"""
Flujo de Login FIE PLUS con:
  - Capturas de pantalla por cada paso
  - Reporte Word (.docx) con datos generales + capturas
  - Carpeta autogenerada con fecha/hora
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
if __name__ == '__main__':
    _input_cfg = load_input_defaults('login_flow_con_reporte')
    print('=' * 50)
    print('🚀 FLUJO DE LOGIN FIE PLUS + REPORTE')
    print('=' * 50)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    appium_port = _input_cfg.get('appium_port', 4723)
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Login')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Conectando a dispositivo: {device_id}')
    print(f'🔌 Puerto Appium: {appium_port}')
    print(f'📄 Nombre de la prueba: {NOMBRE_PRUEBA}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id, appium_port)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES)
    login_ok = _input_cfg.get('login_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
            import traceback
            traceback.print_exc()
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f'   Carpeta: {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

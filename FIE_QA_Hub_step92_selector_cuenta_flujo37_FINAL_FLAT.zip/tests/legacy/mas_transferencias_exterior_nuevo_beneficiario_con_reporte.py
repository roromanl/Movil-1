"""
Flujo Transferencias al Exterior (nuevo beneficiario) + reporte Word.
Pasos: Login → Más → Transferencias al exterior → Nuevo beneficiario
       → Datos beneficiario → Banco destino → Banco intermediario (opcional)
       → Datos giro → Términos → Confirmar → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import volver_home_exterior__5dd5468119 as volver_home_exterior
from framework.common.ui_helpers import _ingresar_texto_en_campo as _ingresar_texto_en_campo, _seleccionar_opcion_case_insensitive__e39a1456d9 as _seleccionar_opcion_case_insensitive, _esta_en_home as _esta_en_home

def _seleccionar_en_modal_con_scroll(driver, valor, max_intentos=20, swipe_down=True):
    if _seleccionar_opcion_case_insensitive(driver, valor, timeout=3):
        return True
    intento = 0
    while intento < max_intentos:
        intento += 1
        try:
            if swipe_down:
                driver.swipe(500, 1500, 500, 800, 300)
            else:
                driver.swipe(500, 800, 500, 1500, 300)
            time.sleep(0.3)
        except:
            break
        if _seleccionar_opcion_case_insensitive(driver, valor, timeout=1):
            return True
    if swipe_down:
        for _ in range(max_intentos):
            try:
                driver.swipe(500, 800, 500, 1500, 300)
                time.sleep(0.3)
            except:
                break
            if _seleccionar_opcion_case_insensitive(driver, valor, timeout=1):
                return True
    return False

def click_mas_menu(driver):
    print('  📝 Click en menú Más...')
    wait = WebDriverWait(driver, 5)
    try:
        mas_btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'home_btn_mas')))
        mas_btn.click()
        print('  ✅ Click en Más (ID)')
        time.sleep(3)
        return True
    except:
        try:
            mas_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Más\nMás']")
            mas_btn.click()
            print('  ✅ Click en Más (content-desc)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Más: {e}')
            return False

def select_transferencias_exterior_mas(driver):
    print('  📝 Seleccionando Transferencias al exterior...')
    wait = WebDriverWait(driver, 5)
    try:
        btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'more_btn_transferenciasExterior')))
        btn.click()
        print('  ✅ Click en Transferencias al exterior (ID)')
        time.sleep(3)
        return True
    except:
        try:
            btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Transferencias al exterior')]")
            btn.click()
            print('  ✅ Click en Transferencias al exterior (content-desc)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al seleccionar Transferencias al exterior: {e}')
            return False

def click_nuevo_beneficiario(driver):
    print('  📝 Click en Nuevo Beneficiario...')
    wait = WebDriverWait(driver, 5)
    try:
        btn = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//android.widget.Button[@content-desc='Nuevo beneficiario']")))
        btn.click()
        print('  ✅ Click en Nuevo Beneficiario')
        time.sleep(3)
        return True
    except:
        try:
            btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Nuevo beneficiario')]")
            btn.click()
            print('  ✅ Click en Nuevo Beneficiario (texto)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Nuevo Beneficiario: {e}')
            return False

def ingresar_nombre_beneficiario(driver, nombre):
    print(f'  📝 Ingresando nombre: {nombre}...')
    ok = _ingresar_texto_en_campo(driver, 'transfers_abroad_input_nombre', nombre, hints_alternativos=['Ingresa el nombre', 'nombre'])
    if ok:
        print(f'  ✅ Nombre ingresado: {nombre}')
    else:
        print(f'  ❌ Error al ingresar nombre')
    return ok

def ingresar_primer_apellido(driver, apellido1):
    print(f'  📝 Ingresando primer apellido: {apellido1}...')
    ok = _ingresar_texto_en_campo(driver, 'transfers_abroad_input_primer_apellido', apellido1, hints_alternativos=['Ingresa el primer apellido', 'primer apellido'])
    if ok:
        print(f'  ✅ Primer apellido ingresado: {apellido1}')
    else:
        print(f'  ❌ Error al ingresar primer apellido')
    return ok

def ingresar_segundo_apellido(driver, apellido2):
    print(f'  📝 Ingresando segundo apellido: {apellido2}...')
    ok = _ingresar_texto_en_campo(driver, 'transfers_abroad_input_segundo_apellido', apellido2, hints_alternativos=['Ingresa el segundo apellido', 'segundo apellido'])
    if ok:
        print(f'  ✅ Segundo apellido ingresado: {apellido2}')
    else:
        print(f'  ❌ Error al ingresar segundo apellido')
    return ok

def seleccionar_tipo_documento(driver, tipo_documento='Cedula de identidad'):
    print(f'  📝 Seleccionando tipo de documento: {tipo_documento}...')
    wait = WebDriverWait(driver, 5)
    try:
        selector = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'transfers_abroad_select_tipo_documento')))
        selector.click()
        print('  ✅ Click en selector de tipo de documento (ID)')
        time.sleep(2)
    except:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Selecciona un tipo')]")
            selector.click()
            print('  ✅ Click en selector (content-desc)')
            time.sleep(2)
        except Exception as e:
            print(f'  ❌ Error al abrir selector: {e}')
            return False
    time.sleep(1)
    if _seleccionar_opcion_case_insensitive(driver, tipo_documento, timeout=5):
        print(f'  ✅ Tipo de documento seleccionado: {tipo_documento}')
        time.sleep(2)
        return True
    print(f'  ❌ Error al seleccionar tipo: {tipo_documento}')
    try:
        opciones = driver.find_elements(AppiumBy.XPATH, "//*[@clickable='true' and @content-desc and string-length(@content-desc) > 3]")
        print(f'  🔍 Opciones visibles ({len(opciones)}):')
        for o in opciones[:15]:
            desc = (o.get_attribute('content-desc') or '').replace('\n', ' | ')
            if len(desc) < 80:
                print(f'     - {desc}')
    except:
        pass
    return False

def ingresar_numero_documento(driver, numero_documento):
    print(f'  📝 Ingresando número de documento: {numero_documento}...')
    ok = _ingresar_texto_en_campo(driver, 'transfers_abroad_input_documento', numero_documento, hints_alternativos=['Ingresa el documento', 'documento'])
    if ok:
        print(f'  ✅ Número de documento ingresado: {numero_documento}')
    else:
        print(f'  ❌ Error al ingresar número de documento')
    return ok

def ingresar_numero_cuenta_iban(driver, numero_cuenta):
    print(f'  📝 Ingresando número de cuenta/IBAN: {numero_cuenta}...')
    try:
        driver.swipe(500, 1500, 500, 800, 500)
        time.sleep(0.5)
    except:
        pass
    ok = _ingresar_texto_en_campo(driver, 'transfers_abroad_input_cuenta', numero_cuenta, hints_alternativos=['Ingresa la cuenta', 'cuenta', 'IBAN'])
    if ok:
        print(f'  ✅ Número de cuenta/IBAN ingresado: {numero_cuenta}')
    else:
        print(f'  ❌ Error al ingresar cuenta/IBAN')
    return ok

def ingresar_direccion_beneficiario(driver, direccion):
    print(f'  📝 Ingresando dirección: {direccion}...')
    try:
        driver.swipe(500, 1500, 500, 800, 500)
        time.sleep(0.5)
    except:
        pass
    ok = _ingresar_texto_en_campo(driver, 'transfers_abroad_input_direccion', direccion, hints_alternativos=['Ingresa la dirección', 'dirección', 'direccion'])
    if ok:
        print(f'  ✅ Dirección ingresada: {direccion}')
    else:
        print(f'  ❌ Error al ingresar dirección')
    return ok

def seleccionar_continente_beneficiario(driver, continente='America del sur'):
    print(f'  📝 Seleccionando continente del beneficiario: {continente}...')
    wait = WebDriverWait(driver, 10)
    try:
        driver.swipe(500, 1500, 500, 800, 500)
        time.sleep(0.5)
    except:
        pass
    try:
        selector = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//*[contains(@content-desc, 'Continente del banco')]")))
        selector.click()
        print('  ✅ Click en selector de continente')
        time.sleep(2)
    except:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Continente')]")
            selector.click()
            print('  ✅ Click en selector de continente (content-desc)')
            time.sleep(2)
        except Exception as e:
            print(f'  ❌ Error al abrir selector de continente: {e}')
            return False
    time.sleep(1)
    if _seleccionar_opcion_case_insensitive(driver, continente, timeout=5):
        print(f'  ✅ Continente seleccionado: {continente}')
        time.sleep(2)
        return True
    print(f'  ❌ Error al seleccionar continente: {continente}')
    return False

def seleccionar_pais_beneficiario(driver, pais='Bolivia'):
    print(f'  📝 Seleccionando país del beneficiario: {pais}...')
    wait = WebDriverWait(driver, 10)
    print('  🔍 Buscando selector de país...')
    try:
        selector = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//*[contains(@content-desc, 'País del banco')]")))
        selector.click()
        print('  ✅ Click en selector de país')
        time.sleep(2)
    except:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'País')]")
            selector.click()
            print('  ✅ Click en selector de país (content-desc)')
            time.sleep(2)
        except Exception as e:
            print(f'  ❌ Error al abrir selector de país: {e}')
            return False
    print(f'  🔍 Buscando país: {pais} dentro del modal...')
    if _seleccionar_en_modal_con_scroll(driver, pais, max_intentos=20):
        print(f'  ✅ País seleccionado: {pais}')
        time.sleep(2)
        return True
    print(f'  ❌ No se encontró el país: {pais}')
    return False

def seleccionar_ciudad_beneficiario(driver, ciudad='La paz'):
    print(f'  📝 Seleccionando ciudad del beneficiario: {ciudad}...')
    wait = WebDriverWait(driver, 10)
    print('  🔍 Buscando selector de ciudad...')
    try:
        selector = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//*[contains(@content-desc, 'Ciudad del banco')]")))
        selector.click()
        print('  ✅ Click en selector de ciudad')
        time.sleep(2)
    except:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Ciudad')]")
            selector.click()
            print('  ✅ Click en selector de ciudad (content-desc)')
            time.sleep(2)
        except Exception as e:
            print(f'  ❌ Error al abrir selector de ciudad: {e}')
            return False
    print(f'  🔍 Buscando ciudad: {ciudad} dentro del modal...')
    if _seleccionar_en_modal_con_scroll(driver, ciudad, max_intentos=20):
        print(f'  ✅ Ciudad seleccionada: {ciudad}')
        time.sleep(2)
        return True
    print(f'  ❌ No se encontró la ciudad: {ciudad}')
    return False

def click_continuar_beneficiario(driver):
    print('  📝 Click en Continuar (beneficiario)...')
    wait = WebDriverWait(driver, 10)
    try:
        continuar = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")))
        continuar.click()
        print('  ✅ Click en Continuar')
        time.sleep(3)
        return True
    except:
        try:
            continuar = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Continuar')]")
            continuar.click()
            print('  ✅ Click en Continuar (content-desc)')
            time.sleep(3)
            return True
        except:
            try:
                continuar = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Continuar') and @clickable='true']")
                continuar.click()
                print('  ✅ Click en Continuar (texto)')
                time.sleep(3)
                return True
            except Exception as e:
                print(f'  ❌ Error al clickear Continuar: {e}')
                return False

def ingresar_swift_banco_destino(driver, swift):
    print(f'  📝 Ingresando SWIFT banco destino: {swift}...')
    ok = _ingresar_texto_en_campo(driver, 'transfers_abroad_input_swift_destino', swift, hints_alternativos=['swift', 'SWIFT'])
    if ok:
        print(f'  ✅ SWIFT ingresado: {swift}')
    else:
        print(f'  ❌ Error al ingresar SWIFT')
    return ok

def click_buscar_swift_banco_destino(driver):
    print('  📝 Click en Buscar SWIFT (banco destino)...')
    wait = WebDriverWait(driver, 5)
    try:
        btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'transfers_abroad_input_swift_destino_buscar')))
        btn.click()
        print('  ✅ Click en Buscar SWIFT (ID)')
        time.sleep(3)
        return True
    except:
        try:
            btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Buscar SWIFT']")
            btn.click()
            print('  ✅ Click en Buscar SWIFT (content-desc)')
            time.sleep(3)
            return True
        except:
            try:
                btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Buscar SWIFT') and @clickable='true']")
                btn.click()
                print('  ✅ Click en Buscar SWIFT (contains)')
                time.sleep(3)
                return True
            except Exception as e:
                print(f'  ❌ Error al buscar SWIFT: {e}')
                return False

def verificar_nombre_banco_destino(driver):
    print('  📝 Verificando nombre del banco destino...')
    time.sleep(2)
    try:
        edit_text = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@resource-id='transfers_abroad_input_banco_destino']")
        texto = edit_text.get_attribute('text') or ''
        if not texto:
            try:
                hijo = edit_text.find_element(AppiumBy.XPATH, './/android.view.View[@text]')
                texto = hijo.get_attribute('text') or ''
            except:
                pass
        if texto and len(texto) > 3:
            print(f'  ✅ Nombre del banco destino ya está lleno: {texto}')
            return True
    except Exception as e:
        print(f'  ⚠️ Error leyendo banco: {e}')
    print('  ⚠️ Nombre del banco destino NO está lleno - campo vacío')
    return False

def ingresar_nombre_banco_destino(driver, nombre_banco):
    """Ingresa el nombre del banco destino con 3 estrategias."""
    print(f'  📝 Ingresando nombre del banco destino: {nombre_banco}...')
    ok = _ingresar_texto_en_campo(driver, 'transfers_abroad_input_banco_destino', nombre_banco, hints_alternativos=['banco', 'nombre del banco'])
    if ok:
        print(f'  ✅ Nombre del banco destino ingresado: {nombre_banco}')
    else:
        print(f'  ❌ Error al ingresar nombre del banco destino')
    return ok

def toggle_banco_intermediario(driver, activar=True):
    print(f"  📝 Configurando Banco Intermediario -> {('Activar' if activar else 'Desactivar')}")
    wait = WebDriverWait(driver, 10)
    try:
        switch = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'transfers_abroad_switch_intermediario')))
    except:
        try:
            switch = driver.find_element(AppiumBy.XPATH, "//android.widget.Switch[@content-desc='Banco intermediario']")
        except Exception as e:
            print(f'  ❌ Error al encontrar switch: {e}')
            return False
    try:
        is_checked = switch.get_attribute('checked') == 'true'
        print(f"  🔍 Estado actual: {('Activado' if is_checked else 'Desactivado')}")
        if is_checked != activar:
            switch.click()
            time.sleep(1)
            print(f"  ✅ Switch Banco Intermediario {('activado' if activar else 'desactivado')}")
            return True
        else:
            print(f"  ℹ️ Switch ya está {('activado' if activar else 'desactivado')}")
            return True
    except Exception as e:
        print(f'  ❌ Error al interactuar con switch: {e}')
        return False

def click_confirmar_banco_intermediario(driver):
    """Click en Confirmar después de la pantalla de banco intermediario."""
    print('  📝 Click en Confirmar (banco intermediario)...')
    wait = WebDriverWait(driver, 15)
    try:
        confirmar = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//android.widget.Button[@content-desc='Confirmar']")))
        confirmar.click()
        print('  ✅ Click en Confirmar (content-desc)')
        time.sleep(3)
        return True
    except:
        try:
            confirmar = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Confirmar') and @clickable='true']")
            confirmar.click()
            print('  ✅ Click en Confirmar (contains)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Confirmar: {e}')
            return False

def ingresar_swift_banco_intermediario(driver, swift_inter):
    print(f'  📝 Ingresando SWIFT banco intermediario: {swift_inter}...')
    ok = _ingresar_texto_en_campo(driver, 'transfers_abroad_input_swift_inter', swift_inter, hints_alternativos=['swift', 'SWIFT'])
    if ok:
        print(f'  ✅ SWIFT intermediario ingresado: {swift_inter}')
    else:
        print(f'  ❌ Error al ingresar SWIFT intermediario')
    return ok

def click_buscar_swift_banco_intermediario(driver):
    print('  📝 Click en Buscar SWIFT (banco intermediario)...')
    wait = WebDriverWait(driver, 10)
    try:
        btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'transfers_abroad_input_swift_inter_buscar')))
        btn.click()
        print('  ✅ Click en Buscar SWIFT (intermediario - ID)')
        time.sleep(3)
        return True
    except:
        try:
            btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Buscar SWIFT']")
            btn.click()
            print('  ✅ Click en Buscar SWIFT (intermediario - content-desc)')
            time.sleep(3)
            return True
        except:
            try:
                btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Buscar SWIFT') and @clickable='true']")
                btn.click()
                print('  ✅ Click en Buscar SWIFT (intermediario - contains)')
                time.sleep(3)
                return True
            except Exception as e:
                print(f'  ❌ Error al buscar SWIFT intermediario: {e}')
                return False

def verificar_nombre_banco_intermediario(driver):
    """Verifica si el nombre del banco intermediario se llenó automáticamente."""
    print('  📝 Verificando nombre del banco intermediario...')
    time.sleep(2)
    try:
        edit_text = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@resource-id='transfers_abroad_input_banco_inter']")
        texto = edit_text.get_attribute('text') or ''
        if not texto:
            try:
                hijo = edit_text.find_element(AppiumBy.XPATH, './/android.view.View[@text]')
                texto = hijo.get_attribute('text') or ''
            except:
                pass
        if texto and len(texto) > 3:
            print(f'  ✅ Nombre del banco intermediario ya está lleno: {texto}')
            try:
                driver.swipe(500, 1500, 500, 800, 500)
                time.sleep(0.5)
            except:
                pass
            return True
    except Exception as e:
        print(f'  ⚠️ Error leyendo banco: {e}')
    print('  ⚠️ Nombre del banco intermediario NO está lleno - campo vacío')
    return False

def ingresar_nombre_banco_intermediario(driver, nombre_banco_inter):
    """Ingresa el nombre del banco intermediario con 3 estrategias."""
    print(f'  📝 Ingresando nombre del banco intermediario: {nombre_banco_inter}...')
    ok = _ingresar_texto_en_campo(driver, 'transfers_abroad_input_banco_inter', nombre_banco_inter, hints_alternativos=['banco', 'nombre del banco'])
    if ok:
        print(f'  ✅ Nombre del banco intermediario ingresado: {nombre_banco_inter}')
    else:
        print(f'  ❌ Error al ingresar nombre del banco intermediario')
    return ok

def seleccionar_cuenta_origen_exterior(driver, numero_cuenta='40-0-2352481-5'):
    print(f'  📝 Seleccionando cuenta de origen: {numero_cuenta}...')
    wait = WebDriverWait(driver, 10)
    try:
        selector = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'transfers_abroad_select_cuenta_origen')))
        selector.click()
        print('  ✅ Click en selector de cuenta (ID)')
        time.sleep(2)
    except:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Selecciona una cuenta')]")
            selector.click()
            print('  ✅ Click en selector de cuenta (content-desc)')
            time.sleep(2)
        except Exception as e:
            print(f'  ❌ Error al abrir selector de cuenta: {e}')
            return False
    time.sleep(1)
    try:
        cuenta = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, f"//android.widget.Button[contains(@content-desc, '{numero_cuenta}')]")))
        cuenta.click()
        print(f'  ✅ Cuenta seleccionada (completa): {numero_cuenta}')
        time.sleep(2)
        return True
    except:
        pass
    try:
        ultimos = numero_cuenta.replace('-', '')[-6:]
        cuenta = driver.find_element(AppiumBy.XPATH, f"//android.widget.Button[contains(@content-desc, '{ultimos}')]")
        cuenta.click()
        print(f'  ✅ Cuenta seleccionada (últimos: {ultimos})')
        time.sleep(2)
        return True
    except:
        pass
    try:
        cuentas = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'CUENTA')]")
        if cuentas:
            cuentas[0].click()
            print('  ✅ Primera cuenta seleccionada')
            time.sleep(2)
            return True
    except:
        pass
    print(f'  ❌ No se encontró cuenta: {numero_cuenta}')
    return False

def ingresar_monto_exterior(driver, monto='1.00'):
    print(f'  📝 Ingresando monto: {monto}...')
    ok = _ingresar_texto_en_campo(driver, 'transfers_abroad_input_monto', monto, hints_alternativos=['0.00', 'Monto'])
    if ok:
        print(f'  ✅ Monto ingresado: {monto}')
    else:
        print(f'  ❌ Error al ingresar monto')
    return ok

def ingresar_concepto_exterior(driver, concepto='PRUEBA'):
    print(f'  📝 Ingresando concepto: {concepto}...')
    ok = _ingresar_texto_en_campo(driver, 'transfers_abroad_input_concepto', concepto, hints_alternativos=['Mín. 5 Caracteres', 'Concepto'])
    if ok:
        print(f'  ✅ Concepto ingresado: {concepto}')
    else:
        print(f'  ❌ Error al ingresar concepto')
    return ok

def seleccionar_causa_asfi(driver, causa_asfi='Otras transferencias al exterior'):
    print(f'  📝 Seleccionando causa ASFI: {causa_asfi}...')
    wait = WebDriverWait(driver, 5)
    try:
        selector = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'transfers_abroad_select_asfi')))
        selector.click()
        print('  ✅ Click en selector de causa ASFI (ID)')
        time.sleep(2)
    except:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Selecciona una causa')]")
            selector.click()
            print('  ✅ Click en selector de causa ASFI (content-desc)')
            time.sleep(2)
        except Exception as e:
            print(f'  ❌ Error al abrir selector de causa ASFI: {e}')
            return False
    time.sleep(1)
    if _seleccionar_opcion_case_insensitive(driver, causa_asfi, timeout=5):
        print(f'  ✅ Causa ASFI seleccionada: {causa_asfi}')
        time.sleep(2)
        return True
    print(f'  ❌ Error al seleccionar causa ASFI: {causa_asfi}')
    return False

def seleccionar_sucursal_exterior(driver, sucursal='La paz'):
    print(f'  📝 Seleccionando sucursal: {sucursal}...')
    wait = WebDriverWait(driver, 10)
    try:
        driver.swipe(500, 1500, 500, 800, 500)
        time.sleep(1)
    except:
        pass
    try:
        selector = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'transfers_abroad_select_sucursal')))
        selector.click()
        print('  ✅ Click en selector de sucursal (ID)')
        time.sleep(2)
    except:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Selecciona una sucursal')]")
            selector.click()
            print('  ✅ Click en selector de sucursal (content-desc)')
            time.sleep(2)
        except Exception as e:
            print(f'  ❌ Error al abrir selector de sucursal: {e}')
            return False
    time.sleep(1)
    if _seleccionar_opcion_case_insensitive(driver, sucursal, timeout=5):
        print(f'  ✅ Sucursal seleccionada: {sucursal}')
        time.sleep(2)
        return True
    print(f'  ❌ Error al seleccionar sucursal: {sucursal}')
    return False

def seleccionar_agencia_exterior(driver, agencia='Agencia cala cala'):
    print(f'  📝 Seleccionando agencia: {agencia}...')
    wait = WebDriverWait(driver, 10)
    try:
        driver.swipe(500, 1500, 500, 800, 500)
        time.sleep(1)
    except:
        pass
    try:
        selector = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'transfers_abroad_select_agencia')))
        selector.click()
        print('  ✅ Click en selector de agencia (ID)')
        time.sleep(2)
    except:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Selecciona una agencia')]")
            selector.click()
            print('  ✅ Click en selector de agencia (content-desc)')
            time.sleep(2)
        except Exception as e:
            print(f'  ❌ Error al abrir selector de agencia: {e}')
            return False
    time.sleep(1)
    if _seleccionar_en_modal_con_scroll(driver, agencia, max_intentos=10):
        print(f'  ✅ Agencia seleccionada: {agencia}')
        time.sleep(2)
        return True
    print(f'  ❌ Error al seleccionar agencia: {agencia}')
    return False

def ingresar_origen_fondos_exterior(driver, origen_fondos='PRUEBA DE ORIGEN'):
    print(f'  📝 Ingresando origen de fondos: {origen_fondos}...')
    ok = _ingresar_texto_en_campo(driver, 'transfers_abroad_input_origen_fondos', origen_fondos, hints_alternativos=['Origen de fondos', 'origen'])
    if ok:
        print(f'  ✅ Origen de fondos ingresado: {origen_fondos}')
    else:
        print(f'  ❌ Error al ingresar origen de fondos')
    return ok

def ingresar_destino_fondos_exterior(driver, destino_fondos='PRUEBA FONDOS'):
    print(f'  📝 Ingresando destino de fondos: {destino_fondos}...')
    ok = _ingresar_texto_en_campo(driver, 'transfers_abroad_input_destino_fondos', destino_fondos, hints_alternativos=['Destino de fondos', 'destino'])
    if ok:
        print(f'  ✅ Destino de fondos ingresado: {destino_fondos}')
    else:
        print(f'  ❌ Error al ingresar destino de fondos')
    return ok

def click_continuar_transferencia(driver):
    print('  📝 Click en Continuar (transferencia)...')
    wait = WebDriverWait(driver, 10)
    try:
        continuar = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")))
        continuar.click()
        print('  ✅ Click en Continuar')
        time.sleep(3)
        return True
    except:
        try:
            continuar = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Continuar')]")
            continuar.click()
            print('  ✅ Click en Continuar (content-desc)')
            time.sleep(3)
            return True
        except:
            try:
                continuar = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Continuar') and @clickable='true']")
                continuar.click()
                print('  ✅ Click en Continuar (texto)')
                time.sleep(3)
                return True
            except Exception as e:
                print(f'  ❌ Error al clickear Continuar: {e}')
                return False

def toggle_terminos_condiciones_exterior(driver, activar=True):
    print(f"  📝 Configurando Términos y Condiciones -> {('Activar' if activar else 'Desactivar')}")
    wait = WebDriverWait(driver, 10)
    try:
        switch = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'transfers_abroad_switch_terminos')))
    except:
        try:
            switch = driver.find_element(AppiumBy.XPATH, "//android.widget.Switch[@content-desc='Acepto los términos y condiciones']")
        except Exception as e:
            print(f'  ❌ Error al encontrar switch: {e}')
            return False
    try:
        is_checked = switch.get_attribute('checked') == 'true'
        print(f"  🔍 Estado actual: {('Activado' if is_checked else 'Desactivado')}")
        if is_checked != activar:
            switch.click()
            time.sleep(1)
            print(f"  ✅ Switch Términos {('activado' if activar else 'desactivado')}")
            return True
        else:
            print(f"  ℹ️ Switch ya está {('activado' if activar else 'desactivado')}")
            return True
    except Exception as e:
        print(f'  ❌ Error al interactuar con switch: {e}')
        return False

def click_continuar_terminos_exterior(driver):
    print('  📝 Click en Continuar (términos)...')
    wait = WebDriverWait(driver, 10)
    try:
        continuar = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")))
        continuar.click()
        print('  ✅ Click en Continuar (términos - content-desc)')
        time.sleep(3)
        return True
    except:
        try:
            continuar = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Continuar')]")
            continuar.click()
            print('  ✅ Click en Continuar (términos - contains)')
            time.sleep(3)
            return True
        except:
            try:
                continuar = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Continuar') and @clickable='true']")
                continuar.click()
                print('  ✅ Click en Continuar (términos - texto)')
                time.sleep(3)
                return True
            except Exception as e:
                print(f'  ❌ Error al clickear Continuar: {e}')
                return False

def click_confirmar_transaccion_exterior(driver):
    print('  📝 Click en Confirmar transacción...')
    wait = WebDriverWait(driver, 10)
    try:
        confirmar = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'transfers_abroad_btn_confirmar')))
        confirmar.click()
        print('  ✅ Click en Confirmar transacción (ID)')
        time.sleep(3)
        return True
    except:
        try:
            confirmar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Confirmar transacción']")
            confirmar.click()
            print('  ✅ Click en Confirmar transacción (content-desc)')
            time.sleep(3)
            return True
        except:
            try:
                confirmar = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Confirmar') and @clickable='true']")
                confirmar.click()
                print('  ✅ Click en Confirmar transacción (contains)')
                time.sleep(3)
                return True
            except Exception as e:
                print(f'  ❌ Error al clickear Confirmar: {e}')
                return False

def _seleccionar_continente_generico(driver, continente, tipo='banco destino'):
    print(f'  📝 Seleccionando continente del {tipo}: {continente}...')
    wait = WebDriverWait(driver, 10)
    try:
        driver.swipe(500, 1200, 500, 800, 300)
        time.sleep(0.5)
    except:
        pass
    try:
        if 'intermediario' in tipo:
            selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Continente del banco intermediario')]")
        else:
            selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Continente del banco')]")
        selector.click()
        print(f'  ✅ Click en selector de continente ({tipo})')
        time.sleep(2)
    except:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Continente')]")
            selector.click()
            print(f'  ✅ Click en selector de continente ({tipo} - fallback)')
            time.sleep(2)
        except Exception as e:
            print(f'  ❌ Error al abrir selector de continente: {e}')
            return False
    time.sleep(1)
    if _seleccionar_opcion_case_insensitive(driver, continente, timeout=5):
        print(f'  ✅ Continente seleccionado: {continente}')
        time.sleep(2)
        return True
    print(f'  ❌ No se encontró el continente: {continente}')
    return False

def _seleccionar_pais_generico(driver, pais, tipo='banco destino'):
    """Función genérica para seleccionar país con scroll."""
    print(f'  📝 Seleccionando país del {tipo}: {pais}...')
    wait = WebDriverWait(driver, 10)
    try:
        if 'intermediario' in tipo:
            selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'País del banco intermediario')]")
        else:
            selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'País del banco')]")
        selector.click()
        print(f'  ✅ Click en selector de país ({tipo})')
        time.sleep(2)
    except:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'País')]")
            selector.click()
            print(f'  ✅ Click en selector de país ({tipo} - fallback)')
            time.sleep(2)
        except Exception as e:
            print(f'  ❌ Error al abrir selector de país: {e}')
            return False
    if _seleccionar_en_modal_con_scroll(driver, pais, max_intentos=20):
        print(f'  ✅ País seleccionado: {pais}')
        time.sleep(2)
        return True
    print(f'  ❌ No se encontró el país: {pais}')
    return False

def _seleccionar_ciudad_generico(driver, ciudad, tipo='banco destino'):
    """Función genérica para seleccionar ciudad con scroll."""
    print(f'  📝 Seleccionando ciudad del {tipo}: {ciudad}...')
    wait = WebDriverWait(driver, 10)
    try:
        driver.swipe(500, 1200, 500, 800, 300)
        time.sleep(0.5)
    except:
        pass
    try:
        if 'intermediario' in tipo:
            selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Ciudad del banco intermediario')]")
        else:
            selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Ciudad del banco')]")
        selector.click()
        print(f'  ✅ Click en selector de ciudad ({tipo})')
        time.sleep(2)
    except:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Ciudad')]")
            selector.click()
            print(f'  ✅ Click en selector de ciudad ({tipo} - fallback)')
            time.sleep(2)
        except Exception as e:
            print(f'  ❌ Error al abrir selector de ciudad: {e}')
            return False
    if _seleccionar_en_modal_con_scroll(driver, ciudad, max_intentos=20):
        print(f'  ✅ Ciudad seleccionada: {ciudad}')
        time.sleep(2)
        return True
    print(f'  ❌ No se encontró la ciudad: {ciudad}')
    return False

def seleccionar_continente_banco_destino(driver, continente='America del norte'):
    return _seleccionar_continente_generico(driver, continente, 'banco destino')

def seleccionar_pais_banco_destino(driver, pais='Estados Unidos'):
    return _seleccionar_pais_generico(driver, pais, 'banco destino')

def seleccionar_ciudad_banco_destino(driver, ciudad='New york'):
    return _seleccionar_ciudad_generico(driver, ciudad, 'banco destino')

def seleccionar_continente_banco_intermediario(driver, continente='America del norte'):
    return _seleccionar_continente_generico(driver, continente, 'banco intermediario')

def seleccionar_pais_banco_intermediario(driver, pais='Estados Unidos'):
    return _seleccionar_pais_generico(driver, pais, 'banco intermediario')

def seleccionar_ciudad_banco_intermediario(driver, ciudad='New york'):
    return _seleccionar_ciudad_generico(driver, ciudad, 'banco intermediario')

def realizar_transferencia_exterior(driver, nombre='Prueba1', apellido1='Prueba2', apellido2='Prueba3', tipo_documento='Cedula de identidad', numero_documento='1234567', numero_cuenta_iban='12345678901234567890', direccion='Calle Prueba 123', continente_beneficiario='America del sur', pais_beneficiario='Bolivia', ciudad_beneficiario='La paz', swift_banco_destino='CHASUS33XXX', nombre_banco_destino='JPMORGAN CHASE BANK, N.A.', continente_banco_destino='America del norte', pais_banco_destino='Estados Unidos', ciudad_banco_destino='New york', banco_intermediario_activar=False, swift_banco_inter='', nombre_banco_inter='', continente_inter='America del norte', pais_inter='Estados Unidos', ciudad_inter='New york', numero_cuenta_origen='40-0-2352481-5', monto='1.00', concepto='PRUEBA', causa_asfi='Otras transferencias al exterior', sucursal='La paz', agencia='Agencia cala cala', origen_fondos='PRUEBA DE ORIGEN', destino_fondos='PRUEBA FONDOS', clave_temporal='123456', tiempos=None, reporte=None, paso_inicial=6):
    print(f'\n🌎 INICIANDO TRANSFERENCIA AL EXTERIOR')
    print(f'📋 Beneficiario: {nombre} {apellido1} {apellido2}')
    print(f'💰 Monto: {monto}')
    print(f'🏦 Banco destino: {nombre_banco_destino}')
    print(f"🔘 Banco intermediario: {('Activado' if banco_intermediario_activar else 'Desactivado')}")
    print('=' * 60)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Ir a Más')
    if not click_mas_menu(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Menú Más abierto', "Se accedió al menú 'Más' desde la barra de navegación inferior.", espera=1.5)
    paso_num += 1
    tiempos.start('2. Transferencias al exterior')
    if not select_transferencias_exterior_mas(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla Transferencias al exterior', "Se accedió a la pantalla de 'Transferencias al exterior'.", espera=2.0)
    paso_num += 1
    print('  📝 Esperando carga de pantalla...')
    time.sleep(1)
    tiempos.start('3. Nuevo beneficiario')
    if not click_nuevo_beneficiario(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Nuevo beneficiario - Formulario', "Se accedió al formulario de 'Nuevo beneficiario'. Se muestra la pantalla de datos personales del beneficiario.", espera=2.0)
    paso_num += 1
    print('  📝 Esperando carga de pantalla de beneficiario...')
    time.sleep(1)
    print('\n📝 PASO 4: Datos del Beneficiario')
    tiempos.start('4. Nombre beneficiario')
    if not ingresar_nombre_beneficiario(driver, nombre):
        tiempos.stop()
        return False
    tiempos.stop()
    tiempos.start('5. Primer apellido')
    if not ingresar_primer_apellido(driver, apellido1):
        tiempos.stop()
        return False
    tiempos.stop()
    tiempos.start('6. Segundo apellido')
    if not ingresar_segundo_apellido(driver, apellido2):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Nombre: {nombre} {apellido1} {apellido2}', f'Se ingresó el nombre completo del beneficiario: {nombre} {apellido1} {apellido2}.', espera=1.0)
    paso_num += 1
    tiempos.start('7. Tipo documento')
    if not seleccionar_tipo_documento(driver, tipo_documento):
        tiempos.stop()
        return False
    tiempos.stop()
    tiempos.start('8. Número documento')
    if not ingresar_numero_documento(driver, numero_documento):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Documento: {tipo_documento} {numero_documento}', f'Se ingresó el documento: {tipo_documento} - {numero_documento}.', espera=1.0)
    paso_num += 1
    tiempos.start('9. Cuenta/IBAN')
    if not ingresar_numero_cuenta_iban(driver, numero_cuenta_iban):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Cuenta/IBAN: {numero_cuenta_iban}', f'Se ingresó el número de cuenta/IBAN: {numero_cuenta_iban}.', espera=1.0)
    paso_num += 1
    tiempos.start('10. Dirección beneficiario')
    if not ingresar_direccion_beneficiario(driver, direccion):
        tiempos.stop()
        return False
    tiempos.stop()
    tiempos.start('11. Continente beneficiario')
    if not seleccionar_continente_beneficiario(driver, continente_beneficiario):
        tiempos.stop()
        return False
    tiempos.stop()
    tiempos.start('12. País beneficiario')
    if not seleccionar_pais_beneficiario(driver, pais_beneficiario):
        tiempos.stop()
        return False
    tiempos.stop()
    tiempos.start('13. Ciudad beneficiario')
    if not seleccionar_ciudad_beneficiario(driver, ciudad_beneficiario):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Ubicación: {pais_beneficiario} - {ciudad_beneficiario}', f'Se ingresó la ubicación del beneficiario: {continente_beneficiario} / {pais_beneficiario} / {ciudad_beneficiario}. Dirección: {direccion}.', espera=1.0)
    paso_num += 1
    tiempos.start('14. Continuar (beneficiario)')
    if not click_continuar_beneficiario(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Continuar (datos beneficiario)', 'Se hizo clic en Continuar. Se avanzó a la pantalla de datos del banco destino.', espera=1.5)
    paso_num += 1
    print('  📝 Esperando carga de pantalla de banco destino...')
    time.sleep(1)
    print('\n📝 PASO 5: Datos del Banco Destino')
    tiempos.start('15. SWIFT banco destino')
    if not ingresar_swift_banco_destino(driver, swift_banco_destino):
        tiempos.stop()
        return False
    tiempos.stop()
    tiempos.start('16. Buscar SWIFT destino')
    if not click_buscar_swift_banco_destino(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'SWIFT banco destino: {swift_banco_destino}', f"Se ingresó el SWIFT del banco destino ({swift_banco_destino}) y se hizo clic en 'Buscar SWIFT'.", espera=1.5)
    paso_num += 1
    tiempos.start('17. Verificar/ingresar banco destino')
    nombre_destino_lleno = verificar_nombre_banco_destino(driver)
    if nombre_destino_lleno:
        print('  ℹ️ Nombre del banco destino se llenó automáticamente - omitiendo selección')
        tiempos.stop()
        if reporte:
            reporte.capturar_paso(paso_num, 'Banco destino autocompletado', 'El nombre del banco destino se llenó automáticamente después de buscar por SWIFT.', espera=1.0)
        paso_num += 1
    else:
        print('  📝 El nombre del banco destino NO se llenó automáticamente - ingresando manualmente...')
        if not ingresar_nombre_banco_destino(driver, nombre_banco_destino):
            tiempos.stop()
            return False
        if reporte:
            reporte.capturar_paso(paso_num, f'Banco destino: {nombre_banco_destino}', f'Se ingresó manualmente el nombre del banco destino: {nombre_banco_destino}.', espera=1.0)
        paso_num += 1
        if not seleccionar_continente_banco_destino(driver, continente_banco_destino):
            tiempos.stop()
            return False
        if not seleccionar_pais_banco_destino(driver, pais_banco_destino):
            tiempos.stop()
            return False
        if not seleccionar_ciudad_banco_destino(driver, ciudad_banco_destino):
            tiempos.stop()
            return False
        if reporte:
            reporte.capturar_paso(paso_num, f'Ubicación banco destino', f'Se seleccionó: {continente_banco_destino} / {pais_banco_destino} / {ciudad_banco_destino}.', espera=1.0)
        paso_num += 1
        tiempos.stop()
    print('  📝 Esperando carga de pantalla de banco intermediario...')
    time.sleep(3)
    print('\n📝 PASO 6: Banco Intermediario')
    tiempos.start('18. Banco intermediario')
    if banco_intermediario_activar:
        if not toggle_banco_intermediario(driver, True):
            tiempos.stop()
            return False
        if reporte:
            reporte.capturar_paso(paso_num, 'Banco intermediario ACTIVADO', "Se activó el switch 'Banco intermediario'.", espera=1.0)
        paso_num += 1
        if not ingresar_swift_banco_intermediario(driver, swift_banco_inter):
            tiempos.stop()
            return False
        if not click_buscar_swift_banco_intermediario(driver):
            tiempos.stop()
            return False
        if reporte:
            reporte.capturar_paso(paso_num, f'SWIFT intermediario: {swift_banco_inter}', f"Se ingresó el SWIFT del banco intermediario ({swift_banco_inter}) y se hizo clic en 'Buscar SWIFT'.", espera=1.5)
        paso_num += 1
        nombre_inter_lleno = verificar_nombre_banco_intermediario(driver)
        if nombre_inter_lleno:
            print('  ℹ️ Nombre del banco intermediario se llenó automáticamente - omitiendo')
            if reporte:
                reporte.capturar_paso(paso_num, 'Banco intermediario autocompletado', 'El nombre del banco intermediario se llenó automáticamente.', espera=1.0)
            paso_num += 1
        else:
            print('  📝 El nombre del banco intermediario NO se llenó automáticamente - ingresando...')
            if not ingresar_nombre_banco_intermediario(driver, nombre_banco_inter):
                tiempos.stop()
                return False
            if reporte:
                reporte.capturar_paso(paso_num, f'Banco intermediario: {nombre_banco_inter}', f'Se ingresó manualmente el nombre del banco intermediario: {nombre_banco_inter}.', espera=1.0)
            paso_num += 1
            if not seleccionar_continente_banco_intermediario(driver, continente_inter):
                tiempos.stop()
                return False
            if not seleccionar_pais_banco_intermediario(driver, pais_inter):
                tiempos.stop()
                return False
            if not seleccionar_ciudad_banco_intermediario(driver, ciudad_inter):
                tiempos.stop()
                return False
            if reporte:
                reporte.capturar_paso(paso_num, f'Ubicación banco intermediario', f'Se seleccionó: {continente_inter} / {pais_inter} / {ciudad_inter}.', espera=1.0)
            paso_num += 1
        if not click_continuar_transferencia(driver):
            tiempos.stop()
            return False
        if reporte:
            reporte.capturar_paso(paso_num, 'Continuar (banco intermediario)', 'Se hizo clic en Continuar después de configurar el banco intermediario.', espera=1.5)
        paso_num += 1
        print('  📝 Esperando carga de pantalla de confirmación...')
        time.sleep(3)
        if not click_confirmar_banco_intermediario(driver):
            tiempos.stop()
            return False
        if reporte:
            reporte.capturar_paso(paso_num, 'Confirmar (banco intermediario)', 'Se confirmó la configuración del banco intermediario.', espera=1.5)
        paso_num += 1
        print('  📝 Esperando carga de pantalla de datos del giro...')
        time.sleep(3)
    else:
        if not toggle_banco_intermediario(driver, False):
            tiempos.stop()
            return False
        if reporte:
            reporte.capturar_paso(paso_num, 'Banco intermediario DESACTIVADO', "Se desactivó el switch 'Banco intermediario' (no se usará).", espera=1.0)
        paso_num += 1
        if not click_continuar_transferencia(driver):
            tiempos.stop()
            return False
        if reporte:
            reporte.capturar_paso(paso_num, 'Continuar (sin banco intermediario)', 'Se hizo clic en Continuar sin configurar banco intermediario.', espera=1.5)
        paso_num += 1
        print('  📝 Esperando carga de pantalla de confirmación...')
        time.sleep(3)
        if not click_confirmar_banco_intermediario(driver):
            tiempos.stop()
            return False
        if reporte:
            reporte.capturar_paso(paso_num, 'Confirmar (continuar)', 'Se confirmó para avanzar a los datos del giro.', espera=1.5)
        paso_num += 1
        print('  📝 Esperando carga de pantalla de datos del giro...')
        time.sleep(3)
    tiempos.stop()
    print('\n📝 PASO 7: Datos del Giro')
    tiempos.start('19. Cuenta origen')
    if not seleccionar_cuenta_origen_exterior(driver, numero_cuenta_origen):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Cuenta origen: {numero_cuenta_origen}', f'Se seleccionó la cuenta de origen: {numero_cuenta_origen}.', espera=1.0)
    paso_num += 1
    tiempos.start('20. Monto')
    if not ingresar_monto_exterior(driver, monto):
        tiempos.stop()
        return False
    tiempos.stop()
    tiempos.start('21. Concepto')
    if not ingresar_concepto_exterior(driver, concepto):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Monto: {monto} - Concepto: {concepto}', f"Se ingresó el monto ({monto}) y el concepto ('{concepto}').", espera=1.0)
    paso_num += 1
    tiempos.start('22. Causa ASFI')
    if not seleccionar_causa_asfi(driver, causa_asfi):
        tiempos.stop()
        return False
    tiempos.stop()
    tiempos.start('23. Sucursal')
    if not seleccionar_sucursal_exterior(driver, sucursal):
        tiempos.stop()
        return False
    tiempos.stop()
    tiempos.start('24. Agencia')
    if not seleccionar_agencia_exterior(driver, agencia):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Sucursal/Agencia', f'Causa ASFI: {causa_asfi}. Sucursal: {sucursal}. Agencia: {agencia}.', espera=1.0)
    paso_num += 1
    tiempos.start('25. Origen fondos')
    if not ingresar_origen_fondos_exterior(driver, origen_fondos):
        tiempos.stop()
        return False
    tiempos.stop()
    tiempos.start('26. Destino fondos')
    if not ingresar_destino_fondos_exterior(driver, destino_fondos):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Origen y destino de fondos', f"Origen de fondos: '{origen_fondos}'. Destino de fondos: '{destino_fondos}'.", espera=1.0)
    paso_num += 1
    tiempos.start('27. Continuar (datos giro)')
    if not click_continuar_transferencia(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Continuar (datos giro completos)', 'Se hizo clic en Continuar. Se avanzó a la pantalla de Términos y Condiciones.', espera=1.5)
    paso_num += 1
    print('  📝 Esperando carga de pantalla de términos...')
    time.sleep(3)
    print('\n📝 PASO 8: Términos y Condiciones')
    tiempos.start('28. Términos y condiciones')
    if not toggle_terminos_condiciones_exterior(driver, True):
        tiempos.stop()
        return False
    if reporte:
        reporte.capturar_paso(paso_num, 'Términos y condiciones aceptados', "Se aceptó el switch de 'Términos y condiciones'.", espera=1.0)
    paso_num += 1
    if not click_continuar_terminos_exterior(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Continuar (términos aceptados)', 'Se hizo clic en Continuar. Se avanzó a la pantalla de verificación.', espera=1.5)
    paso_num += 1
    print('  📝 Esperando carga de pantalla de verificación...')
    time.sleep(3)
    print('\n📝 PASO 9: Verificación y Confirmación')
    tiempos.start('29. Confirmar transacción')
    if not click_confirmar_transaccion_exterior(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Confirmar transacción', f'Se confirmó la transferencia al exterior por {monto}. Se muestra el modal de éxito.', espera=1.5)
    paso_num += 1
    print('  📝 Esperando carga de pantalla de éxito...')
    time.sleep(3)
    print('\n📝 PASO 10: Finalizar')
    tiempos.start('30. Volver al home')
    if not volver_home_exterior(driver):
        print('  ⚠️ Error al volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Transferencia Exterior finalizado', 'Se regresó exitosamente al home. El flujo de transferencia al exterior con nuevo beneficiario ha terminado.', espera=1.5)
    paso_num += 1
    print('\n✅ TRANSFERENCIA AL EXTERIOR COMPLETADA EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('mas_transferencias_exterior_nuevo_beneficiario_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO COMPLETO: LOGIN + TRANSFERENCIA AL EXTERIOR + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '67018956')
    password = _input_cfg.get('password', 'Abc#1234')
    nombre = _input_cfg.get('nombre', 'Prueba1')
    apellido1 = _input_cfg.get('apellido1', 'Prueba2')
    apellido2 = _input_cfg.get('apellido2', 'Prueba3')
    tipo_documento = _input_cfg.get('tipo_documento', 'Cedula de identidad')
    numero_documento = _input_cfg.get('numero_documento', '1234567')
    numero_cuenta_iban = _input_cfg.get('numero_cuenta_iban', '12345678901234567890')
    direccion = _input_cfg.get('direccion', 'Calle Prueba 123')
    continente_beneficiario = _input_cfg.get('continente_beneficiario', 'America del sur')
    pais_beneficiario = _input_cfg.get('pais_beneficiario', 'Bolivia')
    ciudad_beneficiario = _input_cfg.get('ciudad_beneficiario', 'Abapo')
    swift_banco_destino = _input_cfg.get('swift_banco_destino', 'CHASUS33XXX')
    nombre_banco_destino = _input_cfg.get('nombre_banco_destino', 'JPMORGAN CHASE BANK, N.A.')
    continente_banco_destino = _input_cfg.get('continente_banco_destino', 'America del norte')
    pais_banco_destino = _input_cfg.get('pais_banco_destino', 'Estados Unidos')
    ciudad_banco_destino = _input_cfg.get('ciudad_banco_destino', 'New york')
    banco_intermediario_activar = _input_cfg.get('banco_intermediario_activar', True)
    swift_banco_inter = _input_cfg.get('swift_banco_inter', 'CHASUS33XXX')
    nombre_banco_inter = _input_cfg.get('nombre_banco_inter', 'JPMORGAN 2')
    continente_inter = _input_cfg.get('continente_inter', 'America del norte')
    pais_inter = _input_cfg.get('pais_inter', 'Estados unidos')
    ciudad_inter = _input_cfg.get('ciudad_inter', 'Abbeville,la')
    numero_cuenta_origen = _input_cfg.get('numero_cuenta_origen', '60-2-0006347-6')
    monto = _input_cfg.get('monto', '1.00')
    concepto = _input_cfg.get('concepto', 'PRUEBA')
    causa_asfi = _input_cfg.get('causa_asfi', 'Otras transferencias al exterior')
    sucursal = _input_cfg.get('sucursal', 'La paz')
    agencia = _input_cfg.get('agencia', 'Agencia camacho')
    origen_fondos = _input_cfg.get('origen_fondos', 'PRUEBA DE ORIGEN')
    destino_fondos = _input_cfg.get('destino_fondos', 'PRUEBA FONDOS')
    clave_temporal = _input_cfg.get('clave_temporal', '123456')
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Transferencia_Exterior_Nuevo_Beneficiario')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f'📋 Beneficiario: {nombre} {apellido1} {apellido2}')
    print(f'💰 Monto: {monto}')
    print(f'🏦 Banco destino: {nombre_banco_destino}')
    print(f"🔘 Banco intermediario: {('Activado' if banco_intermediario_activar else 'Desactivado')}")
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Beneficiario': f'{nombre} {apellido1} {apellido2}', 'Tipo documento': tipo_documento, 'Número documento': numero_documento, 'Cuenta/IBAN': numero_cuenta_iban, 'Dirección': direccion, 'País beneficiario': pais_beneficiario, 'Ciudad beneficiario': ciudad_beneficiario, 'SWIFT banco destino': swift_banco_destino, 'Banco destino': nombre_banco_destino, 'Banco intermediario activado': str(banco_intermediario_activar), 'SWIFT intermediario': swift_banco_inter if banco_intermediario_activar else 'N/A', 'Cuenta origen': numero_cuenta_origen, 'Monto': monto, 'Concepto': concepto, 'Causa ASFI': causa_asfi, 'Sucursal': sucursal, 'Agencia': agencia})
    login_ok = _input_cfg.get('login_ok', False)
    transferencia_ok = _input_cfg.get('transferencia_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            transferencia_ok = realizar_transferencia_exterior(driver, nombre=nombre, apellido1=apellido1, apellido2=apellido2, tipo_documento=tipo_documento, numero_documento=numero_documento, numero_cuenta_iban=numero_cuenta_iban, direccion=direccion, continente_beneficiario=continente_beneficiario, pais_beneficiario=pais_beneficiario, ciudad_beneficiario=ciudad_beneficiario, swift_banco_destino=swift_banco_destino, nombre_banco_destino=nombre_banco_destino, continente_banco_destino=continente_banco_destino, pais_banco_destino=pais_banco_destino, ciudad_banco_destino=ciudad_banco_destino, banco_intermediario_activar=banco_intermediario_activar, swift_banco_inter=swift_banco_inter, nombre_banco_inter=nombre_banco_inter, continente_inter=continente_inter, pais_inter=pais_inter, ciudad_inter=ciudad_inter, numero_cuenta_origen=numero_cuenta_origen, monto=monto, concepto=concepto, causa_asfi=causa_asfi, sucursal=sucursal, agencia=agencia, origen_fondos=origen_fondos, destino_fondos=destino_fondos, clave_temporal=clave_temporal, tiempos=tiempos, reporte=reporte, paso_inicial=6)
            if transferencia_ok:
                print('\n🎉 TRANSFERENCIA AL EXTERIOR EXITOSA!')
            else:
                print('\n❌ TRANSFERENCIA AL EXTERIOR FALLIDA')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and transferencia_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login          : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Transferencia  : {('✅ OK' if transferencia_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

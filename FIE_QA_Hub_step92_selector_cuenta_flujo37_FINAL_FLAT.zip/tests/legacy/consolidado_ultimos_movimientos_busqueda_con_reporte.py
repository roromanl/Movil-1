"""
Flujo Consolidado / Últimos movimientos (acceso desde 'Últimos movimientos' del home)
con capturas de pantalla + reporte Word.

Diferencia con 'consolidado_busqueda_con_reporte.py':
  - En lugar de seleccionar una cuenta específica por número, se hace click directo
    en el botón 'Últimos movimientos' del home.
  - Soporta búsqueda por N/d + monto + signo, y flujo especial de Estados de cuenta.
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import re
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import go_back__e784c5260a as go_back, go_back_home__c06b7d90b9 as go_back_home
from framework.common.ui_helpers import _esta_en_home as _esta_en_home, _seleccionar_opcion_case_insensitive__f21faf0807 as _seleccionar_opcion_case_insensitive

def select_account_type(driver, tipo_cuenta, timeout=15):
    print(f"  📝 Seleccionando cuenta: '{tipo_cuenta}'...")
    time.sleep(3)
    if not tipo_cuenta:
        print('  ❌ Tipo de cuenta vacío')
        return False
    try:
        cuenta_btn = driver.find_element(AppiumBy.XPATH, f"//*[@content-desc='{tipo_cuenta}' and @clickable='true']")
        cuenta_btn.click()
        print(f'  ✅ Cuenta seleccionada (content-desc exacto)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        cuenta_btn = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{tipo_cuenta}') and @clickable='true']")
        cuenta_btn.click()
        print(f'  ✅ Cuenta seleccionada (content-desc contains)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        cuenta_btn = driver.find_element(AppiumBy.XPATH, f"//*[@text='{tipo_cuenta}' and @clickable='true']")
        cuenta_btn.click()
        print(f'  ✅ Cuenta seleccionada (text exacto)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        cuenta_btn = driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{tipo_cuenta}') and @clickable='true']")
        cuenta_btn.click()
        print(f'  ✅ Cuenta seleccionada (text contains)')
        time.sleep(2)
        return True
    except:
        pass
    texto_min = tipo_cuenta.lower()
    try:
        cuenta_btn = driver.find_element(AppiumBy.XPATH, f"//*[contains(translate(@content-desc, 'ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÑ', 'abcdefghijklmnopqrstuvwxyzáéíóúñ'), '{texto_min}') and @clickable='true']")
        cuenta_btn.click()
        print(f'  ✅ Cuenta seleccionada (case-insensitive)')
        time.sleep(2)
        return True
    except:
        pass
    print(f"  ❌ No se encontró la cuenta '{tipo_cuenta}'")
    try:
        cuentas = driver.find_elements(AppiumBy.XPATH, "//*[@clickable='true' and @content-desc and string-length(@content-desc) > 3]")
        print(f'  🔍 Elementos clickables visibles ({len(cuentas)}):')
        for c in cuentas[:20]:
            desc = (c.get_attribute('content-desc') or '').replace('\n', ' | ')
            if desc and len(desc) < 80:
                print(f'     - {desc}')
    except:
        pass
    return False

def click_ultimos_movimientos(driver, timeout=10):
    print('  📝 Click en Últimos movimientos...')
    time.sleep(2)
    try:
        movimientos_btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Últimos movimientos' and @clickable='true']")
        movimientos_btn.click()
        print('  ✅ Click en Últimos movimientos')
        time.sleep(3)
        return True
    except:
        try:
            movimientos_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Últimos movimientos') and @clickable='true']")
            movimientos_btn.click()
            print('  ✅ Click en Últimos movimientos (texto)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Últimos movimientos: {e}')
            return False

def click_buscar_movimientos(driver):
    print('  📝 Click en Buscar (abrir formulario)...')
    time.sleep(2)
    try:
        buscar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Buscar' and @clickable='true']")
        buscar_btn.click()
        print('  ✅ Click en Buscar (abrir)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        buscar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Buscar') and @clickable='true']")
        buscar_btn.click()
        print('  ✅ Click en Buscar (abrir - texto)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al clickear Buscar: {e}')
        return False

def fill_criterio_busqueda(driver, criterio=''):
    if not criterio:
        print('  ℹ️ Criterio vacío - saltando campo')
        return True
    print(f'  📝 Ingresando criterio: {criterio}...')
    time.sleep(2)
    try:
        criterio_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='Buscar por criterio']")
        criterio_input.click()
        time.sleep(1)
        criterio_input.clear()
        criterio_input.send_keys(criterio)
        print(f'  ✅ Criterio ingresado: {criterio}')
        try:
            driver.hide_keyboard()
            time.sleep(1)
        except:
            pass
        return True
    except:
        try:
            criterio_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[contains(@hint, 'Buscar')]")
            criterio_input.click()
            time.sleep(1)
            criterio_input.clear()
            criterio_input.send_keys(criterio)
            print(f'  ✅ Criterio ingresado: {criterio}')
            try:
                driver.hide_keyboard()
                time.sleep(1)
            except:
                pass
            return True
        except Exception as e:
            print(f'  ❌ Error al ingresar criterio: {e}')
            return False

def select_tipo_movimiento(driver, tipo='Todos'):
    print(f'  📝 Seleccionando tipo: {tipo}...')
    time.sleep(2)
    try:
        driver.swipe(500, 800, 500, 500, 500)
        time.sleep(1)
    except:
        pass
    tipo_field = None
    opciones_conocidas = ['Todos', 'Abonos', 'Debitos', 'Transferencias', 'Pago de servicios', 'Giros', 'Prestamos', 'Estados de cuenta']
    for opcion in opciones_conocidas:
        try:
            tipo_field = driver.find_element(AppiumBy.XPATH, f"//*[@content-desc='{opcion}' and @clickable='true']")
            tipo_field.click()
            print(f"  ✅ Click en combo Tipo (opción actual: '{opcion}')")
            time.sleep(2)
            break
        except:
            continue
    if tipo_field is None:
        try:
            tipo_field = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Tipo']/following-sibling::*[@clickable='true']")
            tipo_field.click()
            print('  ✅ Click en combo Tipo (por label)')
            time.sleep(2)
        except:
            print('  ❌ No se encontró el combo Tipo')
            return False
    time.sleep(2)
    try:
        opcion = driver.find_element(AppiumBy.XPATH, f"//*[@content-desc='{tipo}' and @clickable='true']")
        opcion.click()
        print(f'  ✅ Tipo seleccionado: {tipo}')
        time.sleep(1)
        return True
    except:
        try:
            opcion = driver.find_element(AppiumBy.XPATH, f"//*[@text='{tipo}' and @clickable='true']")
            opcion.click()
            print(f'  ✅ Tipo seleccionado: {tipo} (texto)')
            time.sleep(1)
            return True
        except:
            try:
                opcion = driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{tipo}') and @clickable='true']")
                opcion.click()
                print(f'  ✅ Tipo seleccionado: {tipo} (contains)')
                time.sleep(1)
                return True
            except Exception as e:
                print(f"  ❌ No se encontró la opción '{tipo}': {e}")
                return False

def select_fecha(driver, campo, fecha):
    """
    Selecciona una fecha en el calendario con navegación hacia adelante y atrás.
    """
    print(f'  📝 Seleccionando fecha {campo}: {fecha}...')
    time.sleep(2)
    dia, mes, anio = fecha.split('/')
    dia_int = int(dia)
    mes_int = int(mes)
    anio_int = int(anio)
    meses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre']
    mes_nombre = meses[mes_int - 1]
    try:
        botones = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Elegir en calendario']")
        print(f"  🔍 Encontrados {len(botones)} botones 'Elegir en calendario'")
        if campo == 'Desde':
            if len(botones) > 0:
                botones[0].click()
                print(f"  ✅ Click en 'Elegir en calendario' para Desde")
            else:
                print(f'  ❌ No se encontró el botón para Desde')
                return False
        elif len(botones) > 1:
            botones[1].click()
            print(f"  ✅ Click en 'Elegir en calendario' para Hasta")
        else:
            print(f'  ❌ No se encontró el botón para Hasta')
            return False
        time.sleep(2)
    except Exception as e:
        print(f'  ❌ Error al buscar botones: {e}')
        return False
    time.sleep(3)

    def obtener_mes_actual():
        try:
            titulo_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Enero') or contains(@content-desc, 'Febrero') or contains(@content-desc, 'Marzo') or contains(@content-desc, 'Abril') or contains(@content-desc, 'Mayo') or contains(@content-desc, 'Junio') or contains(@content-desc, 'Julio') or contains(@content-desc, 'Agosto') or contains(@content-desc, 'Septiembre') or contains(@content-desc, 'Octubre') or contains(@content-desc, 'Noviembre') or contains(@content-desc, 'Diciembre')]")
            return titulo_btn.get_attribute('content-desc') or ''
        except:
            return None
    encontrado = False
    for intento in range(24):
        titulo_actual = obtener_mes_actual()
        print(f'  📅 Mes actual: {titulo_actual}')
        if titulo_actual and mes_nombre in titulo_actual and (str(anio_int) in titulo_actual):
            print(f'  ✅ Mes correcto: {mes_nombre} {anio_int}')
            encontrado = True
            break
        try:
            mes_actual = None
            for i, nombre_mes in enumerate(meses, 1):
                if nombre_mes in titulo_actual:
                    mes_actual = i
                    break
            anio_actual = None
            años = re.findall('\\d{4}', titulo_actual)
            if años:
                anio_actual = int(años[0])
            if mes_actual and anio_actual:
                diff_meses = (anio_int - anio_actual) * 12 + (mes_int - mes_actual)
                print(f'  📊 Diferencia de meses: {diff_meses}')
                if diff_meses > 0:
                    try:
                        siguiente_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Mes siguiente' and @clickable='true']")
                        siguiente_btn.click()
                        print(f'  🔄 Navegando al siguiente mes...')
                        time.sleep(1)
                    except:
                        try:
                            siguiente_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Mes siguiente']")
                            if siguiente_btn.get_attribute('enabled') == 'true':
                                siguiente_btn.click()
                                print(f'  🔄 Navegando al siguiente mes...')
                                time.sleep(1)
                            else:
                                print(f"  ⚠️ Botón 'Mes siguiente' deshabilitado")
                                break
                        except:
                            print(f'  ⚠️ No se pudo navegar al siguiente mes')
                            break
                elif diff_meses < 0:
                    try:
                        anterior_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Mes anterior' and @clickable='true']")
                        anterior_btn.click()
                        print(f'  🔄 Navegando al mes anterior...')
                        time.sleep(1)
                    except:
                        try:
                            anterior_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Mes anterior']")
                            if anterior_btn.get_attribute('enabled') == 'true':
                                anterior_btn.click()
                                print(f'  🔄 Navegando al mes anterior...')
                                time.sleep(1)
                            else:
                                print(f"  ⚠️ Botón 'Mes anterior' deshabilitado")
                                break
                        except:
                            print(f'  ⚠️ No se pudo navegar al mes anterior')
                            break
                else:
                    encontrado = True
                    break
            else:
                print(f'  ⚠️ No se pudo determinar mes/año actual: {titulo_actual}')
                try:
                    siguiente_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Mes siguiente' and @clickable='true']")
                    siguiente_btn.click()
                    print(f'  🔄 Navegando al siguiente mes (fallback)...')
                    time.sleep(1)
                except:
                    break
        except Exception as e:
            print(f'  ⚠️ Error en navegación: {e}')
            break
    if not encontrado:
        print(f'  ❌ No se encontró el mes {mes_nombre} {anio_int}')
        try:
            driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Cancelar']").click()
            time.sleep(1)
        except:
            pass
        return False
    print(f'  🔄 Haciendo scroll para mostrar todos los días...')
    try:
        driver.swipe(500, 1500, 500, 600, 500)
        time.sleep(1)
    except:
        pass
    time.sleep(1)
    seleccionado = False
    estrategias = [lambda: driver.find_element(AppiumBy.XPATH, f"//*[@text='{dia_int}' and @clickable='true']"), lambda: driver.find_element(AppiumBy.XPATH, f"//*[@content-desc='{dia_int}' and @clickable='true']"), lambda: driver.find_element(AppiumBy.XPATH, f"//*[@text='{dia}' and @clickable='true']"), lambda: driver.find_element(AppiumBy.XPATH, f"//*[@content-desc='{dia}' and @clickable='true']"), lambda: driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{dia_int}') and @clickable='true']"), lambda: driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{dia_int}') and @clickable='true']")]
    for i, estrategia in enumerate(estrategias, 1):
        try:
            dia_btn = estrategia()
            if dia_btn.is_displayed() and dia_btn.is_enabled():
                dia_btn.click()
                print(f'  ✅ Día {dia} seleccionado (estrategia {i})')
                seleccionado = True
                break
        except:
            pass
    if not seleccionado:
        try:
            print(f'  🔍 Buscando día {dia_int} entre todos los días...')
            dias = driver.find_elements(AppiumBy.XPATH, "//*[@clickable='true' and @content-desc and string-length(@content-desc) <= 2]")
            for d in dias:
                desc = d.get_attribute('content-desc') or ''
                if desc.isdigit() and int(desc) == dia_int:
                    d.click()
                    print(f'  ✅ Día {dia} seleccionado (búsqueda entre días)')
                    seleccionado = True
                    break
        except:
            pass
    if not seleccionado:
        print(f'  ❌ No se pudo seleccionar el día {dia}')
        try:
            driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Cancelar']").click()
            time.sleep(1)
        except:
            pass
        return False
    time.sleep(1)
    print(f'  📝 Buscando botón Aceptar para {campo}...')
    try:
        aceptar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Aceptar']")
        if aceptar_btn.is_displayed() and aceptar_btn.is_enabled():
            aceptar_btn.click()
            print(f'  ✅ Fecha {campo} confirmada (click en Aceptar)')
            time.sleep(2)
            return True
    except:
        try:
            aceptar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Aceptar') and @clickable='true']")
            aceptar_btn.click()
            print(f'  ✅ Fecha {campo} confirmada (click en Aceptar - texto)')
            time.sleep(2)
            return True
        except Exception as e:
            print(f'  ❌ No se encontró el botón Aceptar: {e}')
            return False

def click_buscar_ejecutar(driver):
    print('  📝 Ejecutando búsqueda...')
    time.sleep(2)
    try:
        driver.swipe(500, 1800, 500, 1200, 500)
        time.sleep(1)
    except:
        pass
    try:
        buscar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.ScrollView//android.widget.Button[@content-desc='Buscar']")
        buscar_btn.click()
        print('  ✅ Click en Buscar (ejecutar - ScrollView)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        buscar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Buscar' and @clickable='true' and @selected='false']")
        buscar_btn.click()
        print('  ✅ Click en Buscar (ejecutar - selected=false)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        buscar_btns = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Buscar']")
        print(f"  📊 Botones 'Buscar' encontrados: {len(buscar_btns)}")
        if len(buscar_btns) >= 2:
            buscar_btn = buscar_btns[-1]
            buscar_btn.click()
            print('  ✅ Click en Buscar (ejecutar - último botón)')
            time.sleep(3)
            return True
    except:
        pass
    try:
        buscar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Buscar' and @clickable='true']")
        bounds = buscar_btn.get_attribute('bounds') or ''
        if '1973' in bounds or '1974' in bounds:
            buscar_btn.click()
            print('  ✅ Click en Buscar (ejecutar - bounds)')
            time.sleep(3)
            return True
    except:
        pass
    print('  ❌ Error al ejecutar búsqueda')
    return False

def select_movimiento_by_nd(driver, texto_busqueda, monto=None, signo=None, timeout=15):
    print(f"  📝 Buscando movimiento con: '{texto_busqueda}'...")
    if monto:
        print(f"  📝 Monto: {(signo if signo else '')}{monto}")
    time.sleep(2)
    texto_lower = texto_busqueda.lower()

    def buscar():
        try:
            movimientos = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[@resource-id='shared_btn_movimiento' and @clickable='true']")
            print(f'  🔍 Movimientos en pantalla: {len(movimientos)}')
            for mov in movimientos:
                desc = mov.get_attribute('content-desc') or ''
                desc_lower = desc.lower()
                if texto_lower not in desc_lower:
                    continue
                if monto and monto not in desc:
                    continue
                if signo:
                    if signo == '+' and '+Bs.' not in desc:
                        continue
                    if signo == '-' and '-Bs.' not in desc:
                        continue
                mov.click()
                driver._last_movimiento_desc = desc
                print(f'  ✅ Movimiento seleccionado: {desc[:80]}...')
                time.sleep(3)
                return True
            return False
        except Exception as e:
            print(f'  ⚠️ Error buscando: {e}')
            return False
    print('  🔍 Buscando en pantalla actual...')
    if buscar():
        return True
    print('  🔄 Scroll paso a paso...')
    for i in range(4):
        try:
            driver.swipe(500, 1100, 500, 1000, 150)
            time.sleep(0.5)
            print(f'  🔍 Buscando después de scroll {i + 1}...')
            if buscar():
                return True
        except Exception as e:
            print(f'  ⚠️ Error en scroll {i + 1}: {e}')
    print('  🔄 Scroll hacia arriba...')
    for i in range(2):
        try:
            driver.swipe(500, 1000, 500, 1100, 150)
            time.sleep(0.5)
            print(f'  🔍 Buscando después de scroll arriba {i + 1}...')
            if buscar():
                return True
        except Exception as e:
            print(f'  ⚠️ Error en scroll arriba {i + 1}: {e}')
    print(f"  ❌ No se encontró movimiento: '{texto_busqueda}'")
    return False

def close_movement_modal(driver):
    print('  📝 Cerrando modal de movimiento...')
    time.sleep(3)
    try:
        driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Transferencia') or contains(@content-desc, 'Comprobante')]")
        print('  ✅ Modal detectado')
    except:
        print('  ⚠️ No se detectó modal')
    try:
        cerrar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Cerrar']")
        cerrar_btn.click()
        print('  ✅ Click en Cerrar')
        time.sleep(2)
        return True
    except:
        pass
    try:
        cerrar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Cerrar') and @clickable='true']")
        cerrar_btn.click()
        print('  ✅ Click en Cerrar (texto)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        driver.back()
        print('  ✅ Back para cerrar modal')
        time.sleep(2)
        return True
    except:
        return False

def select_mes_referencia(driver, mes='Ago', anio='2026'):
    print(f'  📝 Seleccionando mes: {mes} {anio}...')
    time.sleep(2)
    try:
        elegir_mes_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Elegir mes']")
        elegir_mes_btn.click()
        print('  ✅ Click en Elegir mes')
        time.sleep(2)
    except:
        try:
            elegir_mes_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Elegir mes') and @clickable='true']")
            elegir_mes_btn.click()
            print('  ✅ Click en Elegir mes (texto)')
            time.sleep(2)
        except Exception as e:
            print(f'  ❌ Error: {e}')
            return False
    time.sleep(2)
    try:
        mes_btn = driver.find_element(AppiumBy.XPATH, f"//*[@content-desc='{mes}' and @clickable='true']")
        mes_btn.click()
        print(f'  ✅ Mes seleccionado: {mes}')
        time.sleep(2)
        return True
    except:
        try:
            mes_btn = driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{mes}') and @clickable='true']")
            mes_btn.click()
            print(f'  ✅ Mes seleccionado: {mes} (texto)')
            time.sleep(2)
            return True
        except Exception as e:
            print(f'  ❌ Error: {e}')
            return False

def click_descargar_pdf(driver):
    print('  📝 Click en Descargar pdf...')
    time.sleep(2)
    try:
        descargar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Descargar pdf']")
        descargar_btn.click()
        print('  ✅ Click en Descargar pdf')
        time.sleep(5)
        return True
    except:
        try:
            descargar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Descargar pdf') and @clickable='true']")
            descargar_btn.click()
            print('  ✅ Click en Descargar pdf (texto)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error: {e}')
            return False

def _normalizar_fecha_ui(value):
    v=str(value or '').strip().replace('-', '/')
    q=v.split('/')
    if len(q)!=3:return v
    if len(q[0])==4:y,m,d=q
    else:d,m,y=q
    return f'{int(d):02d}/{int(m):02d}/{int(y):04d}'

def realizar_consolidado_busqueda(driver, tipo_cuenta='AHORRO', criterio='', tipo_movimiento='Todos', fecha_desde='01/08/2026', fecha_hasta='31/08/2026', texto_movimiento=None, monto_movimiento=None, signo_movimiento=None, mes_referencia='Ago', anio_referencia='2026', movimiento_index=0, reporte=None, tiempos=None, paso_inicial=6):
    fecha_desde=_normalizar_fecha_ui(fecha_desde); fecha_hasta=_normalizar_fecha_ui(fecha_hasta)
    print(f'\n📊 INICIANDO CONSOLIDADO CON BÚSQUEDA (vía Últimos movimientos)')
    print(f'🏦 Cuenta: {tipo_cuenta}')
    if texto_movimiento:
        print(f'📝 Movimiento: {texto_movimiento}')
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Seleccionar cuenta')
    if not select_account_type(driver, tipo_cuenta):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f"Cuenta '{tipo_cuenta}' seleccionada", f"Se seleccionó el tipo de cuenta '{tipo_cuenta}' desde el home.", espera=1.5)
    paso_num += 1
    tiempos.start('2. Últimos movimientos')
    if not click_ultimos_movimientos(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla de Últimos Movimientos', 'Se accedió a la pantalla de Últimos Movimientos de la cuenta seleccionada.', espera=1.5)
    paso_num += 1
    tiempos.start('3. Abrir formulario')
    if not click_buscar_movimientos(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Formulario de Búsqueda abierto', 'Se abrió el formulario con los filtros: criterio, tipo, fechas.', espera=1.5)
    paso_num += 1
    if criterio:
        tiempos.start('4. Criterio')
        if not fill_criterio_busqueda(driver, criterio):
            print('  ⚠️ Error al llenar criterio')
        tiempos.stop()
        time.sleep(2)
        if reporte:
            reporte.capturar_paso(paso_num, f"Criterio: '{criterio}'", f"Se ingresó '{criterio}' en el campo de criterio.", espera=1.0)
        paso_num += 1
    tiempos.start('5. Tipo movimiento')
    if not select_tipo_movimiento(driver, tipo_movimiento):
        print('  ⚠️ Error al seleccionar tipo')
    tiempos.stop()
    time.sleep(2)
    if reporte:
        reporte.capturar_paso(paso_num, f"Tipo: '{tipo_movimiento}'", f"Se seleccionó el tipo de movimiento '{tipo_movimiento}'.", espera=1.0)
    paso_num += 1
    if tipo_movimiento == 'Estados de cuenta':
        print('  📝 Ejecutando flujo de Estados de cuenta...')
        tiempos.start('6. Mes referencia')
        if not select_mes_referencia(driver, mes_referencia, anio_referencia):
            print('  ⚠️ Error al seleccionar mes')
            tiempos.stop()
            return False
        tiempos.stop()
        if reporte:
            reporte.capturar_paso(paso_num, f'Mes: {mes_referencia} {anio_referencia}', f"Se seleccionó el mes de referencia '{mes_referencia} {anio_referencia}'.", espera=1.5)
        paso_num += 1
        tiempos.start('7. Descargar PDF')
        if not click_descargar_pdf(driver):
            print('  ⚠️ Error al descargar PDF')
            tiempos.stop()
            return False
        tiempos.stop()
        if reporte:
            reporte.capturar_paso(paso_num, 'Estado de cuenta descargado', 'El PDF del estado de cuenta se descargó correctamente.', espera=2.0)
        paso_num += 1
        tiempos.start('8. Volver atrás')
        go_back(driver)
        tiempos.stop()
        if reporte:
            reporte.capturar_paso(paso_num, 'Home - Flujo finalizado', 'Se regresó al home tras descargar el estado de cuenta.', espera=1.5)
        print('\n✅ ESTADOS DE CUENTA COMPLETADO EXITOSAMENTE')
        return True
    if fecha_desde:
        tiempos.start('6. Fecha Desde')
        if not select_fecha(driver, 'Desde', fecha_desde):
            print('  ⚠️ Error al seleccionar fecha Desde')
        tiempos.stop()
        if reporte:
            reporte.capturar_paso(paso_num, f'Fecha desde: {fecha_desde}', f'Se seleccionó la fecha Desde = {fecha_desde} en el calendario.', espera=1.0)
        paso_num += 1
    if fecha_hasta:
        tiempos.start('7. Fecha Hasta')
        if not select_fecha(driver, 'Hasta', fecha_hasta):
            print('  ⚠️ Error al seleccionar fecha Hasta')
        tiempos.stop()
        if reporte:
            reporte.capturar_paso(paso_num, f'Fecha hasta: {fecha_hasta}', f'Se seleccionó la fecha Hasta = {fecha_hasta} en el calendario.', espera=1.0)
        paso_num += 1
    tiempos.start('8. Ejecutar búsqueda')
    if not click_buscar_ejecutar(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Búsqueda ejecutada', 'Se ejecutó la búsqueda. Se muestra la lista de resultados según los filtros.', espera=2.0)
    paso_num += 1
    tiempos.start('9. Seleccionar movimiento')
    if texto_movimiento:
        if not select_movimiento_by_nd(driver, texto_movimiento, monto_movimiento, signo_movimiento):
            print(f'  ❌ No se encontró el movimiento: {texto_movimiento}')
            tiempos.stop()
            return False
    else:
        try:
            movimientos = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[@resource-id='shared_btn_movimiento']")
            if movimientos and len(movimientos) > movimiento_index:
                movimientos[movimiento_index].click()
                driver._last_movimiento_desc = movimientos[movimiento_index].get_attribute('content-desc')
                print(f'  ✅ Movimiento #{movimiento_index + 1} seleccionado')
            elif movimientos:
                movimientos[-1].click()
                driver._last_movimiento_desc = movimientos[-1].get_attribute('content-desc')
                print(f'  ✅ Último movimiento seleccionado')
            else:
                print('  ❌ No se encontraron movimientos')
                tiempos.stop()
                return False
            time.sleep(3)
        except Exception as e:
            print(f'  ❌ Error al seleccionar movimiento: {e}')
            tiempos.stop()
            return False
    tiempos.stop()
    if reporte:
        desc_mov = getattr(driver, '_last_movimiento_desc', '')
        if texto_movimiento:
            reporte.capturar_paso(paso_num, f"Movimiento '{texto_movimiento}' seleccionado", f"Se seleccionó el movimiento con N/d '{texto_movimiento}'. Detalle: {desc_mov[:120]}", espera=2.0)
        else:
            reporte.capturar_paso(paso_num, f'Movimiento #{movimiento_index + 1} seleccionado', f'Detalle: {desc_mov[:120]}', espera=2.0)
    paso_num += 1
    tiempos.start('10. Cerrar modal')
    close_movement_modal(driver)
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Modal de movimiento cerrado', 'Se cerró el detalle del movimiento y se regresó a la lista de resultados.', espera=1.0)
    paso_num += 1
    tiempos.start('11. Volver atrás')
    go_back(driver)
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Consolidado finalizado', 'Se regresó al home tras completar la consulta del consolidado.', espera=1.5)
    print('\n✅ CONSOLIDADO CON BÚSQUEDA COMPLETADO EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('consolidado_ultimos_movimientos_busqueda_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO: LOGIN + ÚLTIMOS MOVIMIENTOS (BÚSQUEDA) + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    TIPO_CUENTA = _input_cfg.get('TIPO_CUENTA', 'C. CORRIENTES')
    CRITERIO = _input_cfg.get('CRITERIO', '')
    TIPO_MOVIMIENTO = _input_cfg.get('TIPO_MOVIMIENTO', 'Todos')
    FECHA_DESDE = _input_cfg.get('FECHA_DESDE', '15/08/2026')
    FECHA_HASTA = _input_cfg.get('FECHA_HASTA', '10/09/2026')
    TEXTO_MOVIMIENTO = _input_cfg.get('TEXTO_MOVIMIENTO', 'Ach')
    MONTO_MOVIMIENTO = _input_cfg.get('MONTO_MOVIMIENTO', None)
    SIGNO_MOVIMIENTO = _input_cfg.get('SIGNO_MOVIMIENTO', None)
    MOVIMIENTO_INDEX = _input_cfg.get('MOVIMIENTO_INDEX', 0)
    MES_REFERENCIA = _input_cfg.get('MES_REFERENCIA', 'Ago')
    ANIO_REFERENCIA = _input_cfg.get('ANIO_REFERENCIA', '2026')
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Ultimos_Movimientos_Busqueda')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f'🏦 Cuenta: {TIPO_CUENTA}')
    print(f'📋 Tipo: {TIPO_MOVIMIENTO}')
    print(f'📅 Desde: {FECHA_DESDE}')
    print(f'📅 Hasta: {FECHA_HASTA}')
    if TEXTO_MOVIMIENTO:
        print(f'📝 Movimiento: {TEXTO_MOVIMIENTO}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Tipo de cuenta': TIPO_CUENTA, 'Criterio': CRITERIO or '(vacío)', 'Tipo de movimiento': TIPO_MOVIMIENTO, 'Fecha desde': FECHA_DESDE, 'Fecha hasta': FECHA_HASTA, 'Texto de movimiento (N/d)': TEXTO_MOVIMIENTO or '(no especificado)', 'Monto': str(MONTO_MOVIMIENTO) if MONTO_MOVIMIENTO else '(no especificado)', 'Signo': SIGNO_MOVIMIENTO or '(no especificado)'})
    login_ok = _input_cfg.get('login_ok', False)
    consolidado_ok = _input_cfg.get('consolidado_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            consolidado_ok = realizar_consolidado_busqueda(driver, tipo_cuenta=TIPO_CUENTA, criterio=CRITERIO, tipo_movimiento=TIPO_MOVIMIENTO, fecha_desde=FECHA_DESDE, fecha_hasta=FECHA_HASTA, texto_movimiento=TEXTO_MOVIMIENTO, monto_movimiento=MONTO_MOVIMIENTO, signo_movimiento=SIGNO_MOVIMIENTO, mes_referencia=MES_REFERENCIA, anio_referencia=ANIO_REFERENCIA, movimiento_index=MOVIMIENTO_INDEX, reporte=reporte, tiempos=tiempos, paso_inicial=6)
            if consolidado_ok:
                print('\n🎉 CONSOLIDADO CON BÚSQUEDA EXITOSO!')
            else:
                print('\n❌ CONSOLIDADO CON BÚSQUEDA FALLIDO')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and consolidado_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login          : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Consolidado    : {('✅ OK' if consolidado_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

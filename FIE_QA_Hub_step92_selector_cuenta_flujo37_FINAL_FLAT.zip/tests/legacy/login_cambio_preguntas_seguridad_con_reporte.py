"""
Flujo Cambio de Preguntas de Seguridad + reporte Word.
Pasos: Login → Más → Configuraciones usuario → Preguntas de seguridad
       → Pregunta 1 + Respuesta 1 → Pregunta 2 + Respuesta 2
       → Pregunta personalizada + Respuesta personalizada → Continuar
       → Confirmar cambio → Continuar (éxito) → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import volver_home_seguridad
from framework.common.ui_helpers import _esta_en_home as _esta_en_home, _seleccionar_opcion_case_insensitive__f21faf0807 as _seleccionar_opcion_case_insensitive, select_configuraciones_usuario

def click_mas_menu(driver):
    print('  📝 Click en menú Más...')
    time.sleep(2)
    try:
        mas_btn = driver.find_element(AppiumBy.ID, 'home_btn_mas')
        mas_btn.click()
        print('  ✅ Click en Más (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        mas_btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Más\nMás' and @clickable='true']")
        mas_btn.click()
        print('  ✅ Click en Más (content-desc exacto)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        mas_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Más') and @clickable='true']")
        mas_btn.click()
        print('  ✅ Click en Más (content-desc contains)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al clickear Más: {e}')
        return False

def select_preguntas_seguridad(driver):
    print('  📝 Seleccionando Preguntas de seguridad...')
    time.sleep(2)
    try:
        driver.swipe(500, 1500, 500, 800, 500)
        time.sleep(1)
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.ID, 'user_profile_settings_questions')
        btn.click()
        print('  ✅ Click en Preguntas de seguridad (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Preguntas de seguridad')]")
        btn.click()
        print('  ✅ Click en Preguntas de seguridad (content-desc)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al seleccionar Preguntas de seguridad: {e}')
        return False

def select_pregunta_modal(driver, pregunta_texto, numero=1, timeout=15):
    print(f"  📝 Seleccionando pregunta {numero}: '{pregunta_texto[:50]}...'")
    time.sleep(2)
    selector = None
    try:
        selector = driver.find_element(AppiumBy.ID, f'securitysettings_select_pregunta_{numero}')
    except:
        try:
            selector = driver.find_element(AppiumBy.XPATH, f"//*[contains(@resource-id, 'securitysettings_select_pregunta_{numero}') and @clickable='true']")
        except:
            try:
                selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Selecciona una pregunta') and @clickable='true']")
            except Exception as e:
                print(f'  ❌ Error al abrir selector de pregunta {numero}: {e}')
                return False
    selector.click()
    print(f'  ✅ Click en selector de pregunta {numero}')
    time.sleep(2)
    pregunta_lower = pregunta_texto.lower()
    try:
        pregunta_btn = driver.find_element(AppiumBy.XPATH, f"//android.view.View[@content-desc='{pregunta_texto}' and @clickable='true']")
        pregunta_btn.click()
        print(f'  ✅ Pregunta {numero} seleccionada (exacto)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        pregunta_btn = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{pregunta_texto}') and @clickable='true']")
        pregunta_btn.click()
        print(f'  ✅ Pregunta {numero} seleccionada (contains)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        pregunta_btn = driver.find_element(AppiumBy.XPATH, f"//*[contains(translate(@content-desc, 'ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÑ', 'abcdefghijklmnopqrstuvwxyzáéíóúñ'), '{pregunta_lower}') and @clickable='true']")
        pregunta_btn.click()
        print(f'  ✅ Pregunta {numero} seleccionada (case-insensitive)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        pregunta_btn = driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{pregunta_texto}') and @clickable='true']")
        pregunta_btn.click()
        print(f'  ✅ Pregunta {numero} seleccionada (text)')
        time.sleep(2)
        return True
    except Exception as e:
        print(f'  ❌ Error al seleccionar pregunta {numero}: {e}')
        return False

def select_respuesta_modal(driver, respuesta_texto, numero=1, timeout=15):
    print(f"  📝 Seleccionando respuesta {numero}: '{respuesta_texto}'")
    time.sleep(2)
    selector = None
    try:
        selector = driver.find_element(AppiumBy.ID, f'securitysettings_select_respuesta_{numero}')
    except:
        try:
            selector = driver.find_element(AppiumBy.XPATH, f"//*[contains(@resource-id, 'securitysettings_select_respuesta_{numero}') and @clickable='true']")
        except:
            try:
                selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Selecciona una respuesta') and @clickable='true']")
            except Exception as e:
                print(f'  ❌ Error al abrir selector de respuesta {numero}: {e}')
                return False
    selector.click()
    print(f'  ✅ Click en selector de respuesta {numero}')
    time.sleep(2)
    respuesta_lower = respuesta_texto.lower()
    try:
        respuesta_btn = driver.find_element(AppiumBy.XPATH, f"//android.view.View[@content-desc='{respuesta_texto}' and @clickable='true']")
        respuesta_btn.click()
        print(f'  ✅ Respuesta {numero} seleccionada (exacto)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        respuesta_btn = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{respuesta_texto}') and @clickable='true']")
        respuesta_btn.click()
        print(f'  ✅ Respuesta {numero} seleccionada (contains)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        respuesta_btn = driver.find_element(AppiumBy.XPATH, f"//*[contains(translate(@content-desc, 'ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÑ', 'abcdefghijklmnopqrstuvwxyzáéíóúñ'), '{respuesta_lower}') and @clickable='true']")
        respuesta_btn.click()
        print(f'  ✅ Respuesta {numero} seleccionada (case-insensitive)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        respuesta_btn = driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{respuesta_texto}') and @clickable='true']")
        respuesta_btn.click()
        print(f'  ✅ Respuesta {numero} seleccionada (text)')
        time.sleep(2)
        return True
    except Exception as e:
        print(f'  ❌ Error al seleccionar respuesta {numero}: {e}')
        return False

def ingresar_pregunta_personalizada(driver, pregunta):
    print(f'  📝 Ingresando pregunta personalizada: {pregunta}')
    time.sleep(1)
    try:
        driver.swipe(500, 1500, 500, 800, 500)
        time.sleep(1)
    except:
        pass
    try:
        input_field = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@resource-id='securitysettings_input_pregunta_personalizada']/android.widget.EditText")
        input_field.click()
        time.sleep(1.5)
        input_field.clear()
        input_field.send_keys(pregunta)
        print('  ✅ Pregunta personalizada ingresada (hijo)')
        try:
            driver.hide_keyboard()
        except:
            pass
        return True
    except:
        pass
    try:
        input_field = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[contains(@hint, 'personalizada')]")
        input_field.click()
        time.sleep(1.5)
        input_field.clear()
        input_field.send_keys(pregunta)
        print('  ✅ Pregunta personalizada ingresada (hint)')
        try:
            driver.hide_keyboard()
        except:
            pass
        return True
    except:
        pass
    try:
        input_field = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[contains(@hint, 'Pregunta')]")
        input_field.click()
        time.sleep(1.5)
        input_field.clear()
        input_field.send_keys(pregunta)
        print("  ✅ Pregunta personalizada ingresada (hint 'Pregunta')")
        try:
            driver.hide_keyboard()
        except:
            pass
        return True
    except:
        pass
    try:
        input_field = driver.find_element(AppiumBy.XPATH, "//android.view.View[@content-desc='Pregunta personalizada']/following-sibling::android.widget.EditText//android.widget.EditText")
        input_field.click()
        time.sleep(1.5)
        input_field.clear()
        input_field.send_keys(pregunta)
        print('  ✅ Pregunta personalizada ingresada (por label)')
        try:
            driver.hide_keyboard()
        except:
            pass
        return True
    except:
        pass
    try:
        edits = driver.find_elements(AppiumBy.CLASS_NAME, 'android.widget.EditText')
        for e in reversed(edits):
            try:
                text = e.get_attribute('text') or ''
                if text == '':
                    e.click()
                    time.sleep(1.5)
                    e.send_keys(pregunta)
                    print('  ✅ Pregunta personalizada ingresada (último EditText vacío)')
                    try:
                        driver.hide_keyboard()
                    except:
                        pass
                    return True
            except:
                continue
    except:
        pass
    print('  ❌ No se encontró el campo de pregunta personalizada')
    return False

def ingresar_respuesta_personalizada(driver, respuesta):
    print(f'  📝 Ingresando respuesta personalizada: {respuesta}')
    time.sleep(1)
    try:
        input_field = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@resource-id='securitysettings_input_respuesta_personalizada']/android.widget.EditText")
        input_field.click()
        time.sleep(1.5)
        input_field.clear()
        input_field.send_keys(respuesta)
        print('  ✅ Respuesta personalizada ingresada (hijo)')
        try:
            driver.hide_keyboard()
        except:
            pass
        return True
    except:
        pass
    try:
        input_field = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[contains(@hint, 'personalizada')]")
        input_field.click()
        time.sleep(1.5)
        input_field.clear()
        input_field.send_keys(respuesta)
        print('  ✅ Respuesta personalizada ingresada (hint)')
        try:
            driver.hide_keyboard()
        except:
            pass
        return True
    except:
        pass
    try:
        input_field = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[contains(@hint, 'Respuesta')]")
        input_field.click()
        time.sleep(1.5)
        input_field.clear()
        input_field.send_keys(respuesta)
        print("  ✅ Respuesta personalizada ingresada (hint 'Respuesta')")
        try:
            driver.hide_keyboard()
        except:
            pass
        return True
    except:
        pass
    try:
        input_field = driver.find_element(AppiumBy.XPATH, "//android.view.View[@content-desc='Respuesta personalizada']/following-sibling::android.widget.EditText//android.widget.EditText")
        input_field.click()
        time.sleep(1.5)
        input_field.clear()
        input_field.send_keys(respuesta)
        print('  ✅ Respuesta personalizada ingresada (por label)')
        try:
            driver.hide_keyboard()
        except:
            pass
        return True
    except:
        pass
    try:
        edits = driver.find_elements(AppiumBy.CLASS_NAME, 'android.widget.EditText')
        for e in reversed(edits):
            try:
                text = e.get_attribute('text') or ''
                if text == '':
                    e.click()
                    time.sleep(1.5)
                    e.send_keys(respuesta)
                    print('  ✅ Respuesta personalizada ingresada (último EditText vacío)')
                    try:
                        driver.hide_keyboard()
                    except:
                        pass
                    return True
            except:
                continue
    except:
        pass
    print('  ❌ No se encontró el campo de respuesta personalizada')
    return False

def click_continuar_seguridad(driver):
    print('  📝 Click en Continuar (preguntas)...')
    time.sleep(2)
    try:
        btn = driver.find_element(AppiumBy.ID, 'securitysettings_btn_continuar')
        btn.click()
        print('  ✅ Click en Continuar (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")
        btn.click()
        print('  ✅ Click en Continuar (content-desc)')
        time.sleep(3)
        return True
    except:
        try:
            btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Continuar') and @clickable='true']")
            btn.click()
            print('  ✅ Click en Continuar (texto)')
            time.sleep(3)
            return True
        except Exception as e:
            print(f'  ❌ Error al clickear Continuar: {e}')
            return False

def confirmar_cambio_seguridad(driver, clave_temporal='123456'):
    print('  📝 Confirmando cambio de preguntas...')
    time.sleep(3)
    try:
        driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, '¿Desea confirmar el cambio?')]")
        print('  ✅ Modal de confirmación detectado')
    except:
        print('  ⚠️ No se detectó modal de confirmación')
    try:
        btn = driver.find_element(AppiumBy.ID, 'shared_btn_confirmar_clave_temporal')
        btn.click()
        print('  ✅ Click en Confirmar cambio (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Confirmar cambio']")
        btn.click()
        print('  ✅ Click en Confirmar cambio (content-desc)')
        time.sleep(3)
        return True
    except:
        try:
            btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Confirmar cambio') and @clickable='true']")
            btn.click()
            print('  ✅ Click en Confirmar cambio (texto)')
            time.sleep(3)
            return True
        except:
            try:
                botones = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[@clickable='true']")
                if botones:
                    botones[-1].click()
                    print('  ✅ Click en Confirmar cambio (último botón)')
                    time.sleep(3)
                    return True
            except Exception as e:
                print(f'  ❌ Error al confirmar cambio: {e}')
                return False

def click_continuar_exito(driver):
    print('  📝 Click en Continuar (modal de éxito)...')
    time.sleep(3)
    try:
        continuar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")
        continuar_btn.click()
        print('  ✅ Click en Continuar (modal de éxito)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        continuar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Continuar') and @clickable='true']")
        continuar_btn.click()
        print('  ✅ Click en Continuar (modal de éxito - texto)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        continuar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@resource-id='securitysettings_btn_continuar']")
        continuar_btn.click()
        print('  ✅ Click en Continuar (modal de éxito - resource-id)')
        time.sleep(2)
        return True
    except Exception as e:
        print(f'  ⚠️ No se encontró el botón Continuar: {e}')
        return False

def realizar_cambio_preguntas_seguridad(driver, pregunta_1='¿Cuál es su pasatiempo favorito?', respuesta_1='Leer', pregunta_2='¿Cuál es su color favorito?', respuesta_2='Azul', pregunta_personalizada='Cual es tu comida favorita', respuesta_personalizada='Pizza', clave_temporal='123456', reporte=None, tiempos=None, paso_inicial=6):
    print(f'\n🔐 INICIANDO CAMBIO DE PREGUNTAS DE SEGURIDAD')
    print(f'📝 Pregunta 1: {pregunta_1}')
    print(f'📝 Respuesta 1: {respuesta_1}')
    print(f'📝 Pregunta 2: {pregunta_2}')
    print(f'📝 Respuesta 2: {respuesta_2}')
    print(f'📝 Pregunta personalizada: {pregunta_personalizada}')
    print(f'📝 Respuesta personalizada: {respuesta_personalizada}')
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Ir a Más')
    if not click_mas_menu(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Menú Más abierto', "Se accedió al menú 'Más' desde la barra de navegación inferior.", espera=1.5)
    paso_num += 1
    tiempos.start('2. Config. usuario')
    if not select_configuraciones_usuario(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Configuraciones de usuario', 'Se accedió a las Configuraciones de usuario.', espera=1.5)
    paso_num += 1
    tiempos.start('3. Preguntas seguridad')
    if not select_preguntas_seguridad(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla de Preguntas de Seguridad', 'Se accedió a la pantalla de cambio de preguntas de seguridad. Se muestra el formulario con las preguntas 1, 2 y personalizada.', espera=1.5)
    paso_num += 1
    tiempos.start('4. Pregunta 1')
    if not select_pregunta_modal(driver, pregunta_1, 1):
        print('  ⚠️ No se pudo seleccionar la pregunta 1')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f"Pregunta 1: '{pregunta_1[:40]}'", f"Se seleccionó la Pregunta 1: '{pregunta_1}'.", espera=1.5)
    paso_num += 1
    tiempos.start('5. Respuesta 1')
    if not select_respuesta_modal(driver, respuesta_1, 1):
        print('  ⚠️ No se pudo seleccionar la respuesta 1')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f"Respuesta 1: '{respuesta_1}'", f"Se seleccionó la Respuesta 1: '{respuesta_1}'.", espera=1.5)
    paso_num += 1
    tiempos.start('6. Pregunta 2')
    if not select_pregunta_modal(driver, pregunta_2, 2):
        print('  ⚠️ No se pudo seleccionar la pregunta 2')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f"Pregunta 2: '{pregunta_2[:40]}'", f"Se seleccionó la Pregunta 2: '{pregunta_2}'.", espera=1.5)
    paso_num += 1
    tiempos.start('7. Respuesta 2')
    if not select_respuesta_modal(driver, respuesta_2, 2):
        print('  ⚠️ No se pudo seleccionar la respuesta 2')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f"Respuesta 2: '{respuesta_2}'", f"Se seleccionó la Respuesta 2: '{respuesta_2}'.", espera=1.5)
    paso_num += 1
    tiempos.start('8. Pregunta personalizada')
    if not ingresar_pregunta_personalizada(driver, pregunta_personalizada):
        print('  ⚠️ No se pudo ingresar la pregunta personalizada')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f"Pregunta personalizada: '{pregunta_personalizada}'", f"Se ingresó la pregunta personalizada: '{pregunta_personalizada}'.", espera=1.5)
    paso_num += 1
    tiempos.start('9. Respuesta personalizada')
    if not ingresar_respuesta_personalizada(driver, respuesta_personalizada):
        print('  ⚠️ No se pudo ingresar la respuesta personalizada')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f"Respuesta personalizada: '{respuesta_personalizada}'", f"Se ingresó la respuesta personalizada: '{respuesta_personalizada}'.", espera=1.5)
    paso_num += 1
    tiempos.start('10. Continuar (preguntas)')
    if not click_continuar_seguridad(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Preguntas enviadas', 'Se enviaron las preguntas y respuestas configuradas.', espera=1.5)
    paso_num += 1
    tiempos.start('11. Confirmar cambio')
    if not confirmar_cambio_seguridad(driver, clave_temporal):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Cambio confirmado', 'Se confirmó el cambio de preguntas de seguridad en el modal.', espera=1.5)
    paso_num += 1
    tiempos.start('12. Continuar (éxito)')
    if not click_continuar_exito(driver):
        print('  ⚠️ No se pudo hacer click en Continuar (modal de éxito)')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Modal de éxito aceptado', 'Se confirmó el mensaje de éxito del cambio de preguntas.', espera=1.5)
    paso_num += 1
    tiempos.start('13. Volver al home')
    if not volver_home_seguridad(driver):
        print('  ⚠️ No se pudo volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Cambio de Preguntas finalizado', 'Se regresó exitosamente al home. El cambio de preguntas de seguridad ha terminado.', espera=1.5)
    paso_num += 1
    print('\n✅ CAMBIO DE PREGUNTAS DE SEGURIDAD COMPLETADO EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('login_cambio_preguntas_seguridad_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO: LOGIN + CAMBIO DE PREGUNTAS DE SEGURIDAD + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    clave_temporal = _input_cfg.get('clave_temporal', '123456')
    PREGUNTA_1 = _input_cfg.get('PREGUNTA_1', '¿Cuál sería tu vacación ideal?')
    RESPUESTA_1 = _input_cfg.get('RESPUESTA_1', 'El caribe')
    PREGUNTA_2 = _input_cfg.get('PREGUNTA_2', '¿Cuál es su pasatiempo favorito?')
    RESPUESTA_2 = _input_cfg.get('RESPUESTA_2', 'Leer')
    PREGUNTA_PERSONALIZADA = _input_cfg.get('PREGUNTA_PERSONALIZADA', 'pregunta')
    RESPUESTA_PERSONALIZADA = _input_cfg.get('RESPUESTA_PERSONALIZADA', 'respuesta')
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Cambio_Preguntas_Seguridad')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f'📝 Pregunta 1: {PREGUNTA_1}')
    print(f'✏️ Respuesta 1: {RESPUESTA_1}')
    print(f'📝 Pregunta 2: {PREGUNTA_2}')
    print(f'✏️ Respuesta 2: {RESPUESTA_2}')
    print(f'📝 Pregunta personalizada: {PREGUNTA_PERSONALIZADA}')
    print(f'✏️ Respuesta personalizada: {RESPUESTA_PERSONALIZADA}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Pregunta 1': PREGUNTA_1, 'Respuesta 1': RESPUESTA_1, 'Pregunta 2': PREGUNTA_2, 'Respuesta 2': RESPUESTA_2, 'Pregunta personalizada': PREGUNTA_PERSONALIZADA, 'Respuesta personalizada': RESPUESTA_PERSONALIZADA})
    login_ok = _input_cfg.get('login_ok', False)
    cambio_ok = _input_cfg.get('cambio_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            cambio_ok = realizar_cambio_preguntas_seguridad(driver, pregunta_1=PREGUNTA_1, respuesta_1=RESPUESTA_1, pregunta_2=PREGUNTA_2, respuesta_2=RESPUESTA_2, pregunta_personalizada=PREGUNTA_PERSONALIZADA, respuesta_personalizada=RESPUESTA_PERSONALIZADA, clave_temporal=clave_temporal, reporte=reporte, tiempos=tiempos, paso_inicial=6)
            if cambio_ok:
                print('\n🎉 CAMBIO DE PREGUNTAS DE SEGURIDAD EXITOSO!')
            else:
                print('\n❌ CAMBIO DE PREGUNTAS DE SEGURIDAD FALLIDO')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and cambio_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login            : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Cambio preguntas : {('✅ OK' if cambio_ok else '❌ FALLÓ')}")
        print(f'   Carpeta          : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

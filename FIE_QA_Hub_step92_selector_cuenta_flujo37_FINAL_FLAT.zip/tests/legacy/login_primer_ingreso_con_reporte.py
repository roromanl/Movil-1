"""
Flujo Primer Ingreso + reporte Word.
Pasos: Login → Clave temporal → Términos → Usuario/Contraseña
       → Imagen seguridad → Preguntas y respuestas → Registrar dispositivo
       → Finalizar → Modal éxito
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.ui_helpers import _ingresar_texto_en_campo as _ingresar_texto_en_campo, _seleccionar_opcion_case_insensitive__f21faf0807 as _seleccionar_opcion_case_insensitive

def toggle_switch_terminos(driver):
    print('  📝 Activando switch de términos...')
    time.sleep(2)
    x = 131
    y = 2043
    try:
        driver.execute_script('mobile: tap', {'x': x, 'y': y})
        time.sleep(1)
        print('  ✅ Tap en switch ejecutado (mobile:tap)')
        return True
    except:
        pass
    try:
        driver.execute_script('mobile: clickGesture', {'x': x, 'y': y})
        time.sleep(1)
        print('  ✅ clickGesture en switch ejecutado')
        return True
    except:
        pass
    try:
        switches = driver.find_elements(AppiumBy.XPATH, '//android.widget.Switch')
        if switches:
            switches[0].click()
            time.sleep(1)
            print('  ✅ Switch activado (por elemento)')
            return True
    except:
        pass
    print('  ⚠️ No se pudo activar el switch')
    return False

def login_usuario(driver, usuario_login):
    print('  📝 Ingresando usuario de login...')
    time.sleep(2)
    ok = _ingresar_texto_en_campo(driver, resource_id='login_input_usuario', valor=usuario_login, hints_alternativos=['Usuario', 'usuario'])
    if ok:
        print(f'  ✅ Usuario de login ingresado: {usuario_login}')
    else:
        print(f'  ❌ Error al ingresar usuario de login')
    return ok

def click_continuar_login(driver):
    print('  📝 Click en Continuar (login)...')
    time.sleep(1)
    wait = WebDriverWait(driver, 5)
    try:
        continuar = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")))
        continuar.click()
        print('  ✅ Click en Continuar (XPATH Button)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        continuar = driver.find_element(AppiumBy.ACCESSIBILITY_ID, 'Continuar')
        continuar.click()
        print('  ✅ Click en Continuar (Accessibility ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        view_container = driver.find_element(AppiumBy.ID, 'login_btn_ingresar')
        continuar = view_container.find_element(AppiumBy.XPATH, ".//android.widget.Button[@content-desc='Continuar']")
        continuar.click()
        print('  ✅ Click en Continuar (dentro de login_btn_ingresar)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        continuar = driver.find_element(AppiumBy.ID, 'login_btn_ingresar')
        continuar.click()
        print('  ✅ Click en Continuar (ID contenedor)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al clickear Continuar: {e}')
        return False

def ingresar_clave_temporal(driver, clave_temporal):
    """PASO 2: Ingresar clave temporal"""
    print('  📝 Ingresando clave temporal...')
    time.sleep(2)
    ok = _ingresar_texto_en_campo(driver, resource_id='firstentry_input_temp_pass', valor=clave_temporal, hints_alternativos=['Contraseña temporal', 'Contraseña'])
    if ok:
        print(f'  ✅ Clave temporal ingresada: {clave_temporal}')
    else:
        print(f'  ❌ Error al ingresar clave temporal')
    return ok

def click_continuar_firstentry(driver):
    print('  📝 Click en Continuar (primer ingreso)...')
    time.sleep(1)
    wait = WebDriverWait(driver, 5)
    try:
        continuar = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'firstentry_btn_continuar')))
        continuar.click()
        print('  ✅ Click en Continuar (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        continuar = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='firstentry_btn_continuar']//android.widget.Button")
        continuar.click()
        print('  ✅ Click en Continuar (XPATH padre+hijo)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        continuar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")
        continuar.click()
        print('  ✅ Click en Continuar (content-desc)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        continuar = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Continuar') and @clickable='true']")
        continuar.click()
        print('  ✅ Click en Continuar (contains)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al clickear Continuar: {e}')
        return False

def aceptar_terminos_condiciones(driver):
    """PASO 3: Aceptar términos y condiciones"""
    print('  📝 Aceptando términos y condiciones...')
    time.sleep(2)
    try:
        driver.swipe(500, 1800, 500, 1200, 500)
        time.sleep(0.5)
    except:
        pass
    return toggle_switch_terminos(driver)

def configurar_usuario_contraseña(driver, nuevo_usuario, nueva_password, confirmar_password):
    print('  📝 Configurando nuevo usuario y contraseña...')
    time.sleep(3)
    ok_user = _ingresar_texto_en_campo(driver, resource_id='firstentry_input_usuario', valor=nuevo_usuario, hints_alternativos=['Usuario', 'usuario', 'Nombre de usuario'])
    if ok_user:
        print(f'  ✅ Nuevo usuario ingresado: {nuevo_usuario}')
    else:
        print(f'  ❌ Error al ingresar nuevo usuario')
        try:
            print('  🔍 EditTexts disponibles:')
            edit_texts = driver.find_elements(AppiumBy.XPATH, '//android.widget.EditText')
            for i, et in enumerate(edit_texts):
                rid = et.get_attribute('resource-id') or 'sin id'
                print(f'    [{i}] id={rid}')
        except:
            pass
        return False
    ok_pwd = _ingresar_texto_en_campo(driver, resource_id='firstentry_input_password', valor=nueva_password, hints_alternativos=['Contraseña', 'Nueva contraseña'])
    if ok_pwd:
        print(f'  ✅ Nueva contraseña ingresada: {nueva_password}')
    else:
        print(f'  ❌ Error al ingresar contraseña')
        return False
    ok_conf = _ingresar_texto_en_campo(driver, resource_id='firstentry_input_password_confirm', valor=confirmar_password, hints_alternativos=['Confirmar contraseña', 'Confirmar'])
    if ok_conf:
        print(f'  ✅ Confirmación de contraseña ingresada: {confirmar_password}')
    else:
        print(f'  ❌ Error al confirmar contraseña')
        return False
    time.sleep(1)
    return click_continuar_firstentry(driver)

def seleccionar_imagen_seguridad(driver, imagen_id):
    print('  📝 Seleccionando imagen de seguridad...')
    time.sleep(2)
    try:
        imagen = driver.find_element(AppiumBy.ID, imagen_id)
        imagen.click()
        print(f'  ✅ Imagen seleccionada: {imagen_id} (ID)')
        time.sleep(1)
        return True
    except:
        pass
    try:
        imagen = driver.find_element(AppiumBy.XPATH, f"//*[contains(@resource-id, '{imagen_id}')]")
        imagen.click()
        print(f'  ✅ Imagen seleccionada: {imagen_id} (contains resource-id)')
        time.sleep(1)
        return True
    except:
        pass
    try:
        imagen = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{imagen_id}') and @clickable='true']")
        imagen.click()
        print(f'  ✅ Imagen seleccionada: {imagen_id} (content-desc)')
        time.sleep(1)
        return True
    except:
        pass
    try:
        imagenes = driver.find_elements(AppiumBy.XPATH, "//android.widget.ImageView[@clickable='true']")
        if imagenes:
            imagenes[0].click()
            print('  ✅ Primera imagen clickable seleccionada (fallback)')
            time.sleep(1)
            return True
    except:
        pass
    print(f'  ❌ Error al seleccionar imagen: {imagen_id}')
    return False

def select_pregunta_modal(driver, pregunta_texto, numero=1):
    print(f"  📝 Seleccionando pregunta {numero}: '{pregunta_texto[:50]}...'")
    time.sleep(2)
    wait = WebDriverWait(driver, 5)
    resource_id = f'firstentry_select_pregunta_{numero}'
    abierto = False
    try:
        selector = wait.until(EC.element_to_be_clickable((AppiumBy.ID, resource_id)))
        selector.click()
        print(f'  ✅ Click en selector de pregunta {numero} (ID)')
        abierto = True
    except:
        pass
    if not abierto:
        try:
            selector = driver.find_element(AppiumBy.XPATH, f"//*[contains(@resource-id, '{resource_id}') and @clickable='true']")
            selector.click()
            print(f'  ✅ Click en selector de pregunta {numero} (contains)')
            abierto = True
        except:
            pass
    if not abierto:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Selecciona una pregunta') and @clickable='true']")
            selector.click()
            print(f'  ✅ Click en selector de pregunta {numero} (content-desc)')
            abierto = True
        except Exception as e:
            print(f'  ❌ Error al abrir selector de pregunta {numero}: {e}')
            return False
    time.sleep(2)
    if _seleccionar_opcion_case_insensitive(driver, pregunta_texto, timeout=5, debug=True):
        print(f"  ✅ Pregunta {numero} seleccionada: '{pregunta_texto[:50]}...'")
        time.sleep(2)
        return True
    print(f'  ❌ Error al seleccionar pregunta {numero}')
    return False

def select_respuesta_modal(driver, respuesta_texto, numero=1):
    print(f"  📝 Seleccionando respuesta {numero}: '{respuesta_texto}'")
    time.sleep(2)
    wait = WebDriverWait(driver, 5)
    resource_id = f'firstentry_select_respuesta_{numero}'
    abierto = False
    try:
        selector = wait.until(EC.element_to_be_clickable((AppiumBy.ID, resource_id)))
        selector.click()
        print(f'  ✅ Click en selector de respuesta {numero} (ID)')
        abierto = True
    except:
        pass
    if not abierto:
        try:
            selector = driver.find_element(AppiumBy.XPATH, f"//*[contains(@resource-id, '{resource_id}') and @clickable='true']")
            selector.click()
            print(f'  ✅ Click en selector de respuesta {numero} (contains)')
            abierto = True
        except:
            pass
    if not abierto:
        try:
            selector = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Selecciona una respuesta') and @clickable='true']")
            selector.click()
            print(f'  ✅ Click en selector de respuesta (content-desc)')
            abierto = True
        except Exception as e:
            print(f'  ❌ Error al abrir selector de respuesta {numero}: {e}')
            return False
    time.sleep(2)
    if _seleccionar_opcion_case_insensitive(driver, respuesta_texto, timeout=5, debug=True):
        print(f"  ✅ Respuesta {numero} seleccionada: '{respuesta_texto}'")
        time.sleep(2)
        return True
    print(f'  ❌ Error al seleccionar respuesta {numero}')
    return False

def ingresar_pregunta_personalizada(driver, pregunta):
    print(f'  📝 Ingresando pregunta personalizada: {pregunta}')
    time.sleep(2)
    try:
        driver.swipe(500, 1500, 500, 800, 500)
        time.sleep(1)
    except:
        pass
    ok = _ingresar_texto_en_campo(driver, resource_id='firstentry_input_pregunta_personalizada', valor=pregunta, hints_alternativos=['Pregunta personalizada', 'Pregunta'], espera=1.5)
    if ok:
        print(f'  ✅ Pregunta personalizada ingresada: {pregunta}')
    else:
        print(f'  ❌ Error al ingresar pregunta personalizada')
    return ok

def ingresar_respuesta_personalizada(driver, respuesta):
    """Ingresa la respuesta personalizada (Respuesta 3)."""
    print(f'  📝 Ingresando respuesta personalizada: {respuesta}')
    time.sleep(2)
    ok = _ingresar_texto_en_campo(driver, resource_id='firstentry_input_respuesta_personalizada', valor=respuesta, hints_alternativos=['Respuesta personalizada', 'Respuesta'], espera=1.5)
    if ok:
        print(f'  ✅ Respuesta personalizada ingresada: {respuesta}')
    else:
        print(f'  ❌ Error al ingresar respuesta personalizada')
    return ok

def registrar_dispositivo(driver, nombre_dispositivo):
    """PASO 12: Registrar dispositivo."""
    print('  📝 Registrando dispositivo...')
    time.sleep(2)
    try:
        driver.swipe(500, 1000, 500, 500, 500)
        time.sleep(0.5)
    except:
        pass
    ok = _ingresar_texto_en_campo(driver, resource_id='firstentry_input_dispositivo', valor=nombre_dispositivo, hints_alternativos=['Nombre del dispositivo', 'dispositivo'])
    if ok:
        print(f'  ✅ Nombre del dispositivo ingresado: {nombre_dispositivo}')
        return True
    print(f'  ❌ Error al ingresar nombre del dispositivo')
    try:
        print('  🔍 EditTexts disponibles:')
        edit_texts = driver.find_elements(AppiumBy.XPATH, '//android.widget.EditText')
        for i, et in enumerate(edit_texts):
            hint = et.get_attribute('hint') or ''
            rid = et.get_attribute('resource-id') or ''
            print(f"    [{i}] hint='{hint}', id='{rid}'")
    except:
        pass
    return False

def click_finalizar_primer_ingreso(driver):
    """Click en botón Finalizar primer ingreso con 3 estrategias."""
    print("  📝 Click en 'Finalizar primer ingreso'...")
    time.sleep(2)
    wait = WebDriverWait(driver, 5)
    try:
        finalizar = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'firstentry_btn_finalizar')))
        finalizar.click()
        print("  ✅ Click en 'Finalizar primer ingreso' (ID)")
        time.sleep(5)
        return True
    except:
        pass
    try:
        finalizar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Finalizar primer ingreso']")
        finalizar.click()
        print("  ✅ Click en 'Finalizar primer ingreso' (content-desc)")
        time.sleep(5)
        return True
    except:
        pass
    try:
        finalizar = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Finalizar') and @clickable='true']")
        finalizar.click()
        print("  ✅ Click en 'Finalizar' (contains)")
        time.sleep(5)
        return True
    except Exception as e:
        print(f'  ❌ Error al clickear Finalizar primer ingreso: {e}')
        return False

def cerrar_modal_exito_primer_ingreso(driver):
    print('  📝 Cerrando modal de éxito...')
    time.sleep(2)
    try:
        aceptar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Aceptar']")
        aceptar.click()
        print('  ✅ Click en Aceptar (content-desc)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        aceptar = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Aceptar') and @clickable='true']")
        aceptar.click()
        print('  ✅ Click en Aceptar (texto)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        aceptar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Aceptar')]")
        aceptar.click()
        print('  ✅ Click en Aceptar (contains)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        entendido = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Entendido') and @clickable='true']")
        entendido.click()
        print('  ✅ Click en Entendido')
        time.sleep(2)
        return True
    except:
        pass
    try:
        print('  🔄 Intentando tap en coordenadas...')
        driver.execute_script('mobile: tap', {'x': 854, 'y': 1433})
        time.sleep(2)
        print('  ✅ Tap en coordenadas ejecutado')
        return True
    except Exception as e:
        print(f'  ❌ Error al cerrar modal: {e}')
        return False

def realizar_primer_ingreso(driver, usuario_login='FIE8364304-1', clave_temporal='12345678', nuevo_usuario='usuarioPrueba', nueva_password='Prueba1234', confirmar_password='Prueba1234', imagen_id='firstentry_select_imagen_ent_011', pregunta1_seleccionada='Cual es su plato favorito', respuesta1_seleccionada='Pizza', pregunta2_seleccionada='Cual es su pasatiempo favorito', respuesta2_seleccionada='Leer', pregunta_personalizada='¿Cuál es mi color favorito?', respuesta_personalizada='Azul', nombre_dispositivo='Dispositivo_Prueba', tiempos=None, reporte=None, paso_inicial=1):
    print('\n🔐 INICIANDO PRIMER INGRESO')
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla inicial de Login', "Se muestra la pantalla de bienvenida del primer ingreso con el campo 'Usuario' vacío.", espera=1.5)
    paso_num += 1
    print('\n📝 PASO 1: Login')
    tiempos.start('1. Usuario login')
    if not login_usuario(driver, usuario_login):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Usuario de login ingresado', f'Se ingresó el usuario de login: {usuario_login}.', espera=1.0)
    paso_num += 1
    try:
        driver.hide_keyboard()
    except:
        pass
    time.sleep(0.5)
    tiempos.start('2. Continuar login')
    if not click_continuar_login(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    print('\n📝 PASO 2: Clave temporal')
    tiempos.start('3. Clave temporal')
    if not ingresar_clave_temporal(driver, clave_temporal):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Clave temporal ingresada', f'Se ingresó la clave temporal: {clave_temporal} (campo enmascarado).', espera=1.0)
    paso_num += 1
    try:
        driver.hide_keyboard()
    except:
        pass
    time.sleep(0.5)
    tiempos.start('4. Continuar clave')
    if not click_continuar_firstentry(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    print('\n📝 PASO 3: Términos y condiciones')
    tiempos.start('5. Términos')
    if not aceptar_terminos_condiciones(driver):
        print('  ⚠️ No se pudo activar el switch, continuando...')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Términos y condiciones aceptados', "Se activó el switch de 'Términos y condiciones'.", espera=1.0)
    paso_num += 1
    tiempos.start('6. Continuar términos')
    if not click_continuar_firstentry(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    print('\n📝 PASO 4: Configurar usuario y contraseña')
    tiempos.start('7. Usuario y contraseña')
    if not configurar_usuario_contraseña(driver, nuevo_usuario, nueva_password, confirmar_password):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Nuevo usuario y contraseña configurados', f'Se configuró el nuevo usuario: {nuevo_usuario} con su contraseña correspondiente.', espera=1.0)
    paso_num += 1
    tiempos.start('8. Continuar usuario')
    if not click_continuar_firstentry(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    print('\n📝 PASO 5: Seleccionar imagen de seguridad')
    tiempos.start('9. Imagen seguridad')
    if not seleccionar_imagen_seguridad(driver, imagen_id):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Imagen de seguridad: {imagen_id}', f'Se seleccionó la imagen de seguridad: {imagen_id}.', espera=1.0)
    paso_num += 1
    tiempos.start('10. Continuar imagen')
    if not click_continuar_firstentry(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    print('\n📝 PASO 6: Pregunta de seguridad 1')
    tiempos.start('11. Pregunta 1')
    if not select_pregunta_modal(driver, pregunta1_seleccionada, 1):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Pregunta 1: {pregunta1_seleccionada[:40]}', f"Se seleccionó la pregunta de seguridad 1: '{pregunta1_seleccionada}'.", espera=1.0)
    paso_num += 1
    print('\n📝 PASO 7: Respuesta de seguridad 1')
    tiempos.start('12. Respuesta 1')
    if not select_respuesta_modal(driver, respuesta1_seleccionada, 1):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Respuesta 1: {respuesta1_seleccionada}', f"Se seleccionó la respuesta de seguridad 1: '{respuesta1_seleccionada}'.", espera=1.0)
    paso_num += 1
    print('\n📝 PASO 8: Pregunta de seguridad 2')
    tiempos.start('13. Pregunta 2')
    if not select_pregunta_modal(driver, pregunta2_seleccionada, 2):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Pregunta 2: {pregunta2_seleccionada[:40]}', f"Se seleccionó la pregunta de seguridad 2: '{pregunta2_seleccionada}'.", espera=1.0)
    paso_num += 1
    print('\n📝 PASO 9: Respuesta de seguridad 2')
    tiempos.start('14. Respuesta 2')
    if not select_respuesta_modal(driver, respuesta2_seleccionada, 2):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Respuesta 2: {respuesta2_seleccionada}', f"Se seleccionó la respuesta de seguridad 2: '{respuesta2_seleccionada}'.", espera=1.0)
    paso_num += 1
    print('\n📝 PASO 10: Pregunta personalizada 3')
    tiempos.start('15. Pregunta 3')
    if not ingresar_pregunta_personalizada(driver, pregunta_personalizada):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Pregunta 3: {pregunta_personalizada[:40]}', f"Se ingresó la pregunta personalizada: '{pregunta_personalizada}'.", espera=1.0)
    paso_num += 1
    print('\n📝 PASO 11: Respuesta personalizada 3')
    tiempos.start('16. Respuesta 3')
    if not ingresar_respuesta_personalizada(driver, respuesta_personalizada):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Respuesta 3: {respuesta_personalizada}', f"Se ingresó la respuesta personalizada: '{respuesta_personalizada}'.", espera=1.0)
    paso_num += 1
    tiempos.start('17. Continuar seguridad')
    if not click_continuar_firstentry(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    print('\n📝 PASO 12: Registrar dispositivo')
    tiempos.start('18. Registrar dispositivo')
    if not registrar_dispositivo(driver, nombre_dispositivo):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f'Nombre del dispositivo: {nombre_dispositivo}', f"Se registró el nombre del dispositivo: '{nombre_dispositivo}'.", espera=1.0)
    paso_num += 1
    tiempos.start('19. Finalizar')
    if not click_finalizar_primer_ingreso(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    print('\n📝 PASO 13: Cerrar modal de éxito')
    tiempos.start('20. Cerrar modal éxito')
    if not cerrar_modal_exito_primer_ingreso(driver):
        print('  ⚠️ No se pudo cerrar el modal de éxito')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Modal de éxito - Primer ingreso finalizado', 'Se mostró el modal de éxito confirmando que el primer ingreso se completó correctamente.', espera=1.5)
    paso_num += 1
    print('\n✅ PRIMER INGRESO COMPLETADO EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('login_primer_ingreso_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO COMPLETO: PRIMER INGRESO + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    usuario_login = _input_cfg.get('usuario_login', 'FIE4695675-1')
    clave_temporal = _input_cfg.get('clave_temporal', '99923510')
    nuevo_usuario = _input_cfg.get('nuevo_usuario', '76018956')
    nueva_password = _input_cfg.get('nueva_password', 'Abc#1234')
    confirmar_password = _input_cfg.get('confirmar_password', 'Abc#1234')
    imagen_id = _input_cfg.get('imagen_id', 'firstentry_select_imagen_ent_011')
    pregunta1_seleccionada = _input_cfg.get('pregunta1_seleccionada', '¿Cuál es su pasatiempo favorito?')
    respuesta1_seleccionada = _input_cfg.get('respuesta1_seleccionada', 'Leer')
    pregunta2_seleccionada = _input_cfg.get('pregunta2_seleccionada', '¿Cuál es su color favorito?')
    respuesta2_seleccionada = _input_cfg.get('respuesta2_seleccionada', 'Azul')
    pregunta_personalizada = _input_cfg.get('pregunta_personalizada', 'Cual es tu comida favorita')
    respuesta_personalizada = _input_cfg.get('respuesta_personalizada', 'Pizza')
    nombre_dispositivo = _input_cfg.get('nombre_dispositivo', 'DispositivoPruebaRonald')
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Primer_Ingreso')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario login: {usuario_login}')
    print(f'🔑 Clave temporal: {clave_temporal}')
    print(f'📝 Nuevo usuario: {nuevo_usuario}')
    print(f'📝 Nueva contraseña: {nueva_password}')
    print(f'📝 Pregunta personalizada: {pregunta_personalizada}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=usuario_login, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Usuario login': usuario_login, 'Nuevo usuario': nuevo_usuario, 'Nombre dispositivo': nombre_dispositivo, 'Pregunta 1': pregunta1_seleccionada, 'Respuesta 1': respuesta1_seleccionada, 'Pregunta 2': pregunta2_seleccionada, 'Respuesta 2': respuesta2_seleccionada, 'Pregunta personalizada': pregunta_personalizada, 'Respuesta personalizada': respuesta_personalizada})
    primer_ingreso_ok = _input_cfg.get('primer_ingreso_ok', False)
    try:
        primer_ingreso_ok = realizar_primer_ingreso(driver, usuario_login=usuario_login, clave_temporal=clave_temporal, nuevo_usuario=nuevo_usuario, nueva_password=nueva_password, confirmar_password=confirmar_password, imagen_id=imagen_id, pregunta1_seleccionada=pregunta1_seleccionada, respuesta1_seleccionada=respuesta1_seleccionada, pregunta2_seleccionada=pregunta2_seleccionada, respuesta2_seleccionada=respuesta2_seleccionada, pregunta_personalizada=pregunta_personalizada, respuesta_personalizada=respuesta_personalizada, nombre_dispositivo=nombre_dispositivo, tiempos=tiempos, reporte=reporte, paso_inicial=1)
        if primer_ingreso_ok:
            print('\n🎉 PRIMER INGRESO EXITOSO!')
        else:
            print('\n❌ PRIMER INGRESO FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if primer_ingreso_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Primer ingreso : {('✅ OK' if primer_ingreso_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

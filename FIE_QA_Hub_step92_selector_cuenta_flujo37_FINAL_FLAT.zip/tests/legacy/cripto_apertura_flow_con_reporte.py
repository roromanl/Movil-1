"""
Flujo Cripto (acceso desde scroll horizontal del home) + reporte Word.
Pasos: Login → CRIPTO (scroll) → "Comprar cripto" → Compra/Venta/Recepción/Envío
→ Cerrar link → Volver atrás → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import volver_atras_cripto__4401a4d20c as volver_atras_cripto, volver_home__afd08848fd as volver_home
from framework.common.ui_helpers import _esta_en_home as _esta_en_home, _seleccionar_opcion_case_insensitive__f21faf0807 as _seleccionar_opcion_case_insensitive

def click_cripto_scroll_horizontal(driver):
    print("  📝 [PASO 1] Click en 'CRIPTO' (scroll horizontal)...")
    time.sleep(2)
    for intento in range(3):
        try:
            btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='CRIPTO' and @clickable='true']")
            if btn.is_displayed():
                btn.click()
                print(f"  ✅ Click en 'CRIPTO' (exacto) [intento {intento + 1}]")
                time.sleep(3)
                return True
        except:
            pass
        try:
            btn = driver.find_element(AppiumBy.XPATH, "//android.widget.HorizontalScrollView//*[@content-desc='CRIPTO' and @clickable='true']")
            if btn.is_displayed():
                btn.click()
                print(f"  ✅ Click en 'CRIPTO' (en HSV) [intento {intento + 1}]")
                time.sleep(3)
                return True
        except:
            pass
        if intento < 2:
            print(f'  ↩️  CRIPTO no visible, scroll horizontal... (intento {intento + 1})')
            try:
                hsv = driver.find_element(AppiumBy.XPATH, '//android.widget.HorizontalScrollView')
                rect = hsv.rect
                start_x = rect['x'] + int(rect['width'] * 0.8)
                end_x = rect['x'] + int(rect['width'] * 0.2)
                center_y = rect['y'] + int(rect['height'] / 2)
                driver.swipe(start_x, center_y, end_x, center_y, 400)
                time.sleep(1)
            except Exception as e:
                print(f'    ⚠️ Error scroll: {e}')
    if _seleccionar_opcion_case_insensitive(driver, 'CRIPTO', timeout=5, debug=True):
        print("  ✅ Click en 'CRIPTO' (helper)")
        time.sleep(3)
        return True
    print("  ❌ No se encontró 'CRIPTO'")
    return False

def click_comprar_cripto(driver):
    print("  📝 [PASO 2] Click en 'Comprar cripto' (pantalla intermedia)...")
    time.sleep(3)
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Comprar cripto' and @clickable='true']")
        btn.click()
        print("  ✅ Click en 'Comprar cripto' (content-desc exacto)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Comprar cripto') and @clickable='true']")
        btn.click()
        print("  ✅ Click en 'Comprar cripto' (contains)")
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//*[starts-with(@content-desc, 'Comprar') and @clickable='true']")
        desc = (btn.get_attribute('content-desc') or '').replace('\n', ' | ')
        btn.click()
        print(f"  ✅ Click en 'Comprar...' (starts-with) → '{desc[:70]}'")
        time.sleep(3)
        return True
    except:
        pass
    if _seleccionar_opcion_case_insensitive(driver, 'Comprar cripto', timeout=5, debug=True):
        print("  ✅ Click en 'Comprar cripto' (helper)")
        time.sleep(3)
        return True
    print("  ❌ No se encontró 'Comprar cripto'")
    return False

def select_operacion_cripto(driver, operacion='Compra'):
    print(f"  📝 [PASO 3] Click en acción: '{operacion}'...")
    time.sleep(2)
    opciones_validas = ['Compra', 'Venta', 'Recepción', 'Envío']
    if operacion not in opciones_validas:
        print(f"  ❌ Acción inválida: '{operacion}'. Debe ser una de: {opciones_validas}")
        return False
    try:
        btn = driver.find_element(AppiumBy.XPATH, f"//*[starts-with(@content-desc, '{operacion}') and @clickable='true']")
        desc = (btn.get_attribute('content-desc') or '').replace('\n', ' | ')
        btn.click()
        print(f"  ✅ Click en '{operacion}' (starts-with) → '{desc[:70]}'")
        time.sleep(5)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{operacion}') and @clickable='true']")
        btn.click()
        print(f"  ✅ Click en '{operacion}' (contains)")
        time.sleep(5)
        return True
    except:
        pass
    if _seleccionar_opcion_case_insensitive(driver, operacion, timeout=5, debug=True):
        print(f"  ✅ Click en '{operacion}' (helper)")
        time.sleep(5)
        return True
    print(f"  ❌ No se encontró la acción: '{operacion}'")
    return False

def cerrar_link_externo(driver, app_package='bo.com.bancofie.fiemovil', timeout=10):
    print('  📝 Cerrando link externo...')
    time.sleep(4)
    for desc in ['Cerrar', 'Regresar', 'Aceptar']:
        try:
            btn = driver.find_element(AppiumBy.XPATH, f"//android.widget.Button[@content-desc='{desc}']")
            btn.click()
            print(f"  ✅ Click en '{desc}' (nativo)")
            time.sleep(2)
            return True
        except:
            pass
    try:
        contexts = driver.contexts
        print(f'  🔍 Contextos: {contexts}')
        if 'NATIVE_APP' in contexts:
            try:
                driver.switch_to.context('NATIVE_APP')
                print('  ✅ Cambiado a NATIVE_APP')
            except:
                pass
    except Exception as e:
        print(f'    ⚠️ Error contextos: {e}')
    try:
        current_pkg = driver.current_package
        print(f'  🔍 Paquete actual: {current_pkg}')
        if current_pkg != app_package:
            print(f"  ↩️  Volviendo a la app desde '{current_pkg}'...")
            driver.activate_app(app_package)
            time.sleep(3)
            print(f'  ✅ App activada')
            return True
    except Exception as e:
        print(f'    ⚠️ Error paquete: {e}')
    try:
        driver.back()
        print('  ✅ Back ejecutado')
        time.sleep(2)
        return True
    except Exception as e:
        print(f'  ❌ Error cerrando link: {e}')
        return False

def realizar_operacion_cripto_scroll(driver, operacion='Compra', reporte=None, tiempos=None, paso_inicial=6):
    print(f'\n🔷 INICIANDO OPERACIÓN CRIPTO (scroll horizontal): {operacion}')
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Click CRIPTO (scroll)')
    if not click_cripto_scroll_horizontal(driver):
        print('  ❌ Error en PASO 1: CRIPTO')
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'CRIPTO seleccionado (scroll horizontal)', "Se hizo clic en la opción 'CRIPTO' del scroll horizontal de productos en el home.", espera=1.5)
    paso_num += 1
    print('  📝 Esperando pantalla intermedia...')
    time.sleep(3)
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla de Criptomonedas', "Se accedió a la pantalla principal de Criptomonedas. Se muestra el logo 'Cripto FIE' y las opciones disponibles.", espera=1.0)
    paso_num += 1
    tiempos.start("2. Click 'Comprar cripto'")
    if not click_comprar_cripto(driver):
        print("  ❌ Error en PASO 2: 'Comprar cripto'")
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, "Opción 'Comprar cripto' seleccionada", "Se hizo clic en 'Comprar cripto' para acceder a las acciones de criptomonedas.", espera=1.5)
    paso_num += 1
    print('  📝 Esperando pantalla de acciones...')
    time.sleep(3)
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla de acciones cripto', 'Se muestra la pantalla con las 4 acciones disponibles: Compra, Venta, Recepción y Envío.', espera=1.0)
    paso_num += 1
    tiempos.start(f"3. Acción '{operacion}'")
    if not select_operacion_cripto(driver, operacion):
        print(f"  ❌ Error en PASO 3: '{operacion}'")
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f"Acción '{operacion}' ejecutada", f"Se hizo clic en la acción '{operacion}'. Se abre el link con el formulario correspondiente.", espera=2.0)
    paso_num += 1
    print('  📝 Esperando apertura del link...')
    time.sleep(3)
    tiempos.start('4. Cerrar link externo')
    if not cerrar_link_externo(driver):
        print('  ⚠️ No se pudo cerrar el link externo')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Link cerrado', 'Se cerró el link con el formulario de la operación cripto. Se regresó a la pantalla de Criptomonedas.', espera=1.5)
    paso_num += 1
    print('  📝 Esperando retorno a la app...')
    time.sleep(2)
    tiempos.start('5. Volver atrás')
    if not volver_atras_cripto(driver):
        print('  ⚠️ Error al volver atrás')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Regreso al home', 'Se regresó a la pantalla anterior desde Criptomonedas.', espera=1.0)
    paso_num += 1
    tiempos.start('6. Volver al home')
    if not volver_home(driver):
        print('  ⚠️ Error al volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Cripto finalizado', f"Se regresó exitosamente al home. El flujo de '{operacion}' cripto ha terminado.", espera=1.5)
    paso_num += 1
    print(f"\n✅ OPERACIÓN CRIPTO '{operacion}' COMPLETADA EXITOSAMENTE")
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('cripto_apertura_flow_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO: LOGIN + CRIPTO (scroll horizontal) + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    OPERACION = _input_cfg.get('OPERACION', 'Compra')
    NOMBRE_PRUEBA = f'Cripto_{OPERACION}'
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f'🔷 Operación: {OPERACION}')
    print(f'📄 Nombre de la prueba: {NOMBRE_PRUEBA}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Operación cripto': OPERACION, 'Acceso': 'Scroll horizontal del home'})
    login_ok = _input_cfg.get('login_ok', False)
    operacion_ok = _input_cfg.get('operacion_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            operacion_ok = realizar_operacion_cripto_scroll(driver, operacion=OPERACION, reporte=reporte, tiempos=tiempos, paso_inicial=6)
            if operacion_ok:
                print(f"\n🎉 OPERACIÓN CRIPTO '{OPERACION}' EXITOSA!")
            else:
                print(f"\n❌ OPERACIÓN CRIPTO '{OPERACION}' FALLIDA")
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and operacion_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login          : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Operación      : {('✅ OK' if operacion_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

"""
Flujo Notificaciones (por producto) + reporte Word.
Pasos: Login → Campana → Seleccionar producto → Seleccionar notificación por título
       → Continuar detalle → Volver al home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import re
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import volver_home_notificaciones__aaeaf45c7e as volver_home_notificaciones
from framework.common.ui_helpers import _esta_en_home as _esta_en_home, _seleccionar_opcion_case_insensitive__df5762857e as _seleccionar_opcion_case_insensitive

def click_notificaciones_campana(driver):
    print('  📝 Click en campana de Notificaciones (home)...')
    time.sleep(2)
    wait = WebDriverWait(driver, 5)
    try:
        notif_btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'notifications_btn_campana')))
        notif_btn.click()
        print('  ✅ Click en campana (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        notif_btn = driver.find_element(AppiumBy.XPATH, "//*[@resource-id='notifications_btn_campana' and @clickable='true']")
        notif_btn.click()
        print('  ✅ Click en campana (XPATH)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        notif_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'notificaciones nuevas') and @clickable='true']")
        notif_btn.click()
        print('  ✅ Click en campana (content-desc)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        elementos = driver.find_elements(AppiumBy.XPATH, "//*[@content-desc and @clickable='true' and string-length(@content-desc) <= 4]")
        for elem in elementos:
            desc = elem.get_attribute('content-desc') or ''
            if desc.replace('+', '').strip().isdigit():
                elem.click()
                print(f"  ✅ Click en campana (fallback: '{desc}')")
                time.sleep(3)
                return True
    except:
        pass
    print('  ❌ Error al clickear la campana de Notificaciones')
    return False

def select_producto_notificaciones(driver, nombre_producto, timeout=15):
    print(f"  📝 Seleccionando producto: '{nombre_producto}'...")
    time.sleep(2)
    if not nombre_producto:
        print('  ❌ Nombre de producto vacío')
        return False
    abierto = False
    try:
        producto_btn = driver.find_element(AppiumBy.ID, 'notifications_select_producto')
        producto_btn.click()
        print('  ✅ Click en Producto (ID)')
        abierto = True
        time.sleep(2)
    except:
        pass
    if not abierto:
        if _seleccionar_opcion_case_insensitive(driver, 'Producto', timeout=5, debug=True):
            print('  ✅ Click en Producto (helper)')
            abierto = True
            time.sleep(2)
    if not abierto:
        print('  ❌ Error al abrir selector de producto')
        return False
    time.sleep(2)
    numeros = re.findall('\\d+', nombre_producto)
    num_cuenta = max(numeros, key=len) if numeros else None
    print(f'  🔍 Número de cuenta extraído: {num_cuenta}')
    if num_cuenta:
        try:
            producto = driver.find_element(AppiumBy.XPATH, f"//android.view.View[contains(@content-desc, '{num_cuenta}') and @clickable='true']")
            producto.click()
            print(f'  ✅ Producto seleccionado (por número)')
            time.sleep(2)
            return True
        except:
            pass
    if num_cuenta:
        try:
            elementos = driver.find_elements(AppiumBy.XPATH, f"//*[contains(@content-desc, '{num_cuenta}')]")
            for elem in elementos:
                if elem.get_attribute('clickable') == 'true':
                    elem.click()
                    print(f'  ✅ Producto seleccionado (por número iteración)')
                    time.sleep(2)
                    return True
        except:
            pass
    try:
        partes = nombre_producto.split('·')
        if len(partes) > 1:
            texto_tipo = partes[0].strip()
            producto = driver.find_element(AppiumBy.XPATH, f"//android.view.View[contains(@content-desc, '{texto_tipo}') and @clickable='true']")
            producto.click()
            print(f"  ✅ Producto seleccionado (por tipo: '{texto_tipo}')")
            time.sleep(2)
            return True
    except:
        pass
    try:
        producto = driver.find_element(AppiumBy.XPATH, f"//android.view.View[contains(@content-desc, '{nombre_producto}') and @clickable='true']")
        producto.click()
        print(f'  ✅ Producto seleccionado (por nombre completo)')
        time.sleep(2)
        return True
    except:
        pass
    texto_lower = nombre_producto.lower()
    try:
        producto = driver.find_element(AppiumBy.XPATH, f"//*[contains(translate(@content-desc, 'ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÑ', 'abcdefghijklmnopqrstuvwxyzáéíóúñ'), '{texto_lower}') and @clickable='true']")
        producto.click()
        print(f'  ✅ Producto seleccionado (case-insensitive)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        elementos = driver.find_elements(AppiumBy.XPATH, "//*[@clickable='true' and @content-desc]")
        for elem in elementos:
            desc = elem.get_attribute('content-desc') or ''
            if 'Todos' in desc:
                continue
            if nombre_producto in desc or (num_cuenta and num_cuenta in desc):
                elem.click()
                print(f'  ✅ Producto seleccionado (por iteración)')
                time.sleep(2)
                return True
    except:
        pass
    print(f'  ❌ No se encontró el producto: {nombre_producto}')
    return False

def select_notificacion_by_titulo(driver, titulo_busqueda, timeout=15):
    print(f"  📝 Buscando notificación: '{titulo_busqueda}'...")
    time.sleep(2)
    if not titulo_busqueda:
        print('  ❌ Título vacío')
        return False
    titulo_lower = titulo_busqueda.lower()
    desc_notif_encontrada = None

    def buscar():
        nonlocal desc_notif_encontrada
        try:
            notificacion = driver.find_element(AppiumBy.XPATH, f"//android.widget.Button[contains(@content-desc, '{titulo_busqueda}') and @clickable='true']")
            desc_notif_encontrada = notificacion.get_attribute('content-desc')
            notificacion.click()
            print(f'  ✅ Notificación seleccionada (content-desc)')
            time.sleep(3)
            return True
        except:
            pass
        try:
            notificaciones = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[contains(@resource-id, 'notifications_btn_detalle_')]")
            for notif in notificaciones:
                desc = notif.get_attribute('content-desc') or ''
                if titulo_lower in desc.lower():
                    desc_notif_encontrada = desc
                    notif.click()
                    print(f'  ✅ Notificación seleccionada (por iteración)')
                    time.sleep(3)
                    return True
        except:
            pass
        try:
            notificacion = driver.find_element(AppiumBy.XPATH, f"//*[contains(translate(@content-desc, 'ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÑ', 'abcdefghijklmnopqrstuvwxyzáéíóúñ'), '{titulo_lower}') and @clickable='true']")
            desc_notif_encontrada = notificacion.get_attribute('content-desc')
            notificacion.click()
            print(f'  ✅ Notificación seleccionada (case-insensitive)')
            time.sleep(3)
            return True
        except:
            pass
        try:
            notificacion = driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{titulo_busqueda}') and @clickable='true']")
            notificacion.click()
            print(f'  ✅ Notificación seleccionada (texto)')
            time.sleep(3)
            return True
        except:
            pass
        return False
    print('  🔍 Buscando sin scroll...')
    if buscar():
        driver._last_notif_desc = desc_notif_encontrada
        return True
    print('  🔄 Scroll hacia abajo...')
    for i in range(3):
        try:
            driver.swipe(500, 1500, 500, 600, 500)
            time.sleep(0.5)
            print(f'  🔍 Buscando después de scroll {i + 1}...')
            if buscar():
                driver._last_notif_desc = desc_notif_encontrada
                return True
        except:
            pass
    print('  🔄 Scroll hacia arriba...')
    for i in range(2):
        try:
            driver.swipe(500, 600, 500, 1500, 500)
            time.sleep(0.5)
            print(f'  🔍 Buscando después de scroll arriba {i + 1}...')
            if buscar():
                driver._last_notif_desc = desc_notif_encontrada
                return True
        except:
            pass
    print(f"  ❌ No se encontró notificación con: '{titulo_busqueda}'")
    return False

def click_continuar_detalle(driver):
    print('  📝 Click en Continuar (detalle)...')
    time.sleep(3)
    try:
        btn = driver.find_element(AppiumBy.ID, 'notifications_btn_continuar_detalle')
        btn.click()
        print('  ✅ Click en Continuar (ID)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Continuar']")
        btn.click()
        print('  ✅ Click en Continuar (content-desc)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Continuar') and @clickable='true']")
        btn.click()
        print('  ✅ Click en Continuar (texto)')
        time.sleep(2)
        return True
    except Exception as e:
        print(f'  ❌ Error al clickear Continuar: {e}')
        return False

def realizar_notificaciones(driver, nombre_producto='Cuenta de ahorros · 40001244606', titulo_notificacion='Registro de dispositivo', reporte=None, tiempos=None, paso_inicial=6):
    print(f'\n📬 INICIANDO CONSULTA DE NOTIFICACIONES')
    print(f'🏦 Producto: {nombre_producto}')
    print(f'📝 Título: {titulo_notificacion}')
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Click campana')
    if not click_notificaciones_campana(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla de Notificaciones', 'Se accedió a la pantalla de notificaciones desde la campana del home.', espera=1.5)
    paso_num += 1
    tiempos.start('2. Seleccionar producto')
    if not select_producto_notificaciones(driver, nombre_producto):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, f"Producto '{nombre_producto}' seleccionado", f"Se seleccionó el producto '{nombre_producto}' para filtrar las notificaciones.", espera=1.5)
    paso_num += 1
    tiempos.start('3. Buscar notificación')
    if not select_notificacion_by_titulo(driver, titulo_notificacion):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        desc_notif = getattr(driver, '_last_notif_desc', '') or ''
        reporte.capturar_paso(paso_num, f"Notificación '{titulo_notificacion}' abierta", f"Se abrió la notificación con título '{titulo_notificacion}'. Detalle: {desc_notif[:120]}", espera=2.0)
    paso_num += 1
    tiempos.start('4. Continuar detalle')
    if not click_continuar_detalle(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Detalle de notificación confirmado', 'Se hizo clic en Continuar en el detalle de la notificación.', espera=1.5)
    paso_num += 1
    tiempos.start('5. Volver al home')
    if not volver_home_notificaciones(driver):
        print('  ⚠️ No se pudo volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Notificaciones finalizado', 'Se regresó exitosamente al home. La consulta de notificaciones ha terminado.', espera=1.5)
    paso_num += 1
    print('\n✅ CONSULTA DE NOTIFICACIONES COMPLETADA EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('consolidado_notificaciones_producto_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO: LOGIN + CONSULTA DE NOTIFICACIONES (por producto) + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    NOMBRE_PRODUCTO = _input_cfg.get('NOMBRE_PRODUCTO', 'Cuenta de ahorros')
    TITULO_NOTIFICACION = _input_cfg.get('TITULO_NOTIFICACION', 'Transferencia de fondos a terceros')
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Notificaciones_Producto')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f'🏦 Producto: {NOMBRE_PRODUCTO}')
    print(f'📝 Título: {TITULO_NOTIFICACION}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Producto': NOMBRE_PRODUCTO, 'Título de notificación': TITULO_NOTIFICACION})
    login_ok = _input_cfg.get('login_ok', False)
    notif_ok = _input_cfg.get('notif_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            notif_ok = realizar_notificaciones(driver, nombre_producto=NOMBRE_PRODUCTO, titulo_notificacion=TITULO_NOTIFICACION, reporte=reporte, tiempos=tiempos, paso_inicial=6)
            if notif_ok:
                print('\n🎉 CONSULTA DE NOTIFICACIONES EXITOSA!')
            else:
                print('\n❌ CONSULTA DE NOTIFICACIONES FALLIDA')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and notif_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login          : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Notificaciones : {('✅ OK' if notif_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

"""
Flujo Movimientos QR + reporte Word.
Pasos: Login → Menú QR → Movimientos QR → Seleccionar movimiento → Cerrar modal → Home
"""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from framework.common.test_support import format_duration, Tiempos, ReporteTest, create_driver, reset_app
from framework.common.inputs import load_input_defaults
from framework.common.login import login
from framework.common.navigation import go_back_movimientos_qr
from framework.common.ui_helpers import _esta_en_home as _esta_en_home

def click_qr_menu(driver, timeout=10):
    print('  📝 Click en menú QR...')
    wait_t = time.time() + timeout
    while time.time() < wait_t:
        try:
            qr_btn = driver.find_element(AppiumBy.ID, 'home_btn_qr')
            try:
                hijo = qr_btn.find_element(AppiumBy.XPATH, ".//android.widget.Button[@content-desc='QR']")
                hijo.click()
                print('  ✅ Click en QR (hijo de home_btn_qr)')
                time.sleep(3)
                return True
            except:
                qr_btn.click()
                print('  ✅ Click en QR (home_btn_qr)')
                time.sleep(3)
                return True
        except:
            time.sleep(0.5)
    try:
        qr_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='QR' and @clickable='true']")
        qr_btn.click()
        print('  ✅ Click en QR (content-desc clickable)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        qr_btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='QR' and @clickable='true']")
        qr_btn.click()
        print('  ✅ Click en QR (View clickable)')
        time.sleep(3)
        return True
    except:
        pass
    print('  ❌ Error al clickear QR')
    return False

def select_movimientos_qr(driver):
    print('  📝 Verificando pantalla de Movimientos QR...')
    time.sleep(1)
    try:
        driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Movimientos QR' and @focusable='true']")
        driver.find_element(AppiumBy.ID, 'qr_select_tab')
        print("  ℹ️ Ya estamos en 'Movimientos QR' (sin menú intermedio)")
        return True
    except:
        pass
    try:
        movimientos_btn = driver.find_element(AppiumBy.ID, 'qr_btn_movimientos')
        movimientos_btn.click()
        print('  ✅ Click en Movimientos QR (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        movimientos_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Movimientos QR\nMovimientos QR']")
        movimientos_btn.click()
        print('  ✅ Click en Movimientos QR (content-desc exacto)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        movimientos_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Movimientos QR')]")
        movimientos_btn.click()
        print('  ✅ Click en Movimientos QR (content-desc parcial)')
        time.sleep(3)
        return True
    except:
        pass
    print('  ℹ️ No se encontró botón de Movimientos QR (quizá ya estamos en la lista)')
    return True

def buscar_y_seleccionar_movimiento_qr(driver, concepto=None, fecha=None, monto=None, index=0, max_scrolls=10, timeout=15):
    print(f'  📝 Buscando movimiento QR...')
    if concepto:
        print(f'     • Concepto: {concepto}')
    if fecha:
        print(f'     • Fecha: {fecha}')
    if monto:
        print(f'     • Monto: {monto}')
    if not (concepto or fecha or monto):
        print(f'     • Índice: {index + 1}')
    time.sleep(2)
    xpath_parts = ["//android.widget.Button[contains(@resource-id, 'qr_btn_movimiento_')"]
    if concepto:
        xpath_parts.append(f" and contains(@content-desc, '{concepto}')")
    if fecha:
        xpath_parts.append(f" and contains(@content-desc, '{fecha}')")
    if monto:
        xpath_parts.append(f" and contains(@content-desc, '{monto}')")
    xpath_parts.append(']')
    xpath = ''.join(xpath_parts)
    print(f'     🔍 XPATH: {xpath[:130]}...')
    try:
        boton = driver.find_element(AppiumBy.XPATH, xpath)
        desc = boton.get_attribute('content-desc')
        print(f'  ✅ Movimiento encontrado: {desc!r}')
        driver._last_movimiento_desc = desc
        boton.click()
        print('  ✅ Click en movimiento')
        time.sleep(3)
        return True
    except:
        pass
    print(f'  🔄 Buscando con scroll hacia abajo (máx {max_scrolls})...')
    for i in range(max_scrolls):
        try:
            driver.swipe(500, 1500, 500, 600, 500)
            time.sleep(0.8)
        except:
            pass
        try:
            boton = driver.find_element(AppiumBy.XPATH, xpath)
            desc = boton.get_attribute('content-desc')
            print(f'  ✅ Movimiento encontrado (scroll {i + 1}): {desc!r}')
            driver._last_movimiento_desc = desc
            boton.click()
            print('  ✅ Click en movimiento')
            time.sleep(3)
            return True
        except:
            continue
    print('  🔄 Buscando con scroll hacia arriba...')
    for i in range(max_scrolls):
        try:
            driver.swipe(500, 600, 500, 1500, 500)
            time.sleep(0.8)
        except:
            pass
        try:
            boton = driver.find_element(AppiumBy.XPATH, xpath)
            desc = boton.get_attribute('content-desc')
            print(f'  ✅ Movimiento encontrado (scroll up {i + 1}): {desc!r}')
            driver._last_movimiento_desc = desc
            boton.click()
            print('  ✅ Click en movimiento')
            time.sleep(3)
            return True
        except:
            continue
    if not (concepto or fecha or monto):
        print(f'  ⚠️ No se encontró por scroll. Intentando por índice...')
        try:
            movimientos = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[contains(@resource-id, 'qr_btn_movimiento_')]")
            print(f'     • Movimientos visibles: {len(movimientos)}')
            if len(movimientos) > index:
                desc = movimientos[index].get_attribute('content-desc')
                driver._last_movimiento_desc = desc
                movimientos[index].click()
                print(f'  ✅ Movimiento #{index + 1} seleccionado: {desc!r}')
                time.sleep(3)
                return True
            elif movimientos:
                desc = movimientos[-1].get_attribute('content-desc')
                driver._last_movimiento_desc = desc
                movimientos[-1].click()
                print(f'  ✅ Último movimiento seleccionado: {desc!r}')
                time.sleep(3)
                return True
        except:
            pass
    print('  ❌ No se encontró el movimiento solicitado')
    try:
        movimientos = driver.find_elements(AppiumBy.XPATH, "//android.widget.Button[contains(@resource-id, 'qr_btn_movimiento_')]")
        print(f'  🔍 Movimientos visibles ({len(movimientos)}):')
        for m in movimientos[:10]:
            desc = (m.get_attribute('content-desc') or '').replace('\n', ' | ')
            print(f'     - {desc!r}')
    except:
        pass
    return False

def close_movement_qr_modal(driver):
    print('  📝 Cerrando modal de movimiento QR...')
    time.sleep(5)
    try:
        driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Comprobante') or contains(@content-desc, 'Detalle')]")
        print('  ✅ Modal de movimiento QR detectado')
    except:
        print('  ⚠️ No se detectó modal de movimiento QR')
    try:
        cerrar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Cerrar']")
        cerrar_btn.click()
        print('  ✅ Click en Cerrar')
        time.sleep(2)
        return True
    except:
        pass
    try:
        cerrar_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Cerrar') and @clickable='true']")
        cerrar_btn.click()
        print('  ✅ Click en Cerrar (texto)')
        time.sleep(2)
        return True
    except:
        try:
            driver.back()
            print('  ✅ Back ejecutado')
            time.sleep(2)
            return True
        except:
            return False

def realizar_movimientos_qr(driver, concepto='', monto='', signo='', reporte=None, tiempos=None, paso_inicial=6):
    print(f'\n📱 INICIANDO CONSULTA DE MOVIMIENTOS QR')
    print('=' * 50)
    if tiempos is None:
        tiempos = Tiempos()
    paso_num = paso_inicial
    tiempos.start('1. Click en menú QR')
    if not click_qr_menu(driver):
        tiempos.stop()
        return False
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Menú QR abierto', 'Se accedió al menú QR desde el home. Se muestran las opciones relacionadas con QR.', espera=1.5)
    paso_num += 1
    tiempos.start('2. Movimientos QR')
    select_movimientos_qr(driver)
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Pantalla de Movimientos QR', 'Se accedió a la lista de Movimientos QR. Se muestra el historial de pagos/cobros QR.', espera=1.5)
    paso_num += 1
    tiempos.start('3. Buscar movimiento QR')
    ok = buscar_y_seleccionar_movimiento_qr(driver, concepto=concepto, fecha=None, monto=((str(signo)+str(monto)) if signo and monto else monto), index=0)
    tiempos.stop()
    if reporte:
        if ok:
            desc_mov = getattr(driver, '_last_movimiento_desc', '')
            if concepto or fecha or monto:
                criterios = []
                if concepto:
                    criterios.append(f"concepto='{concepto}'")
                if fecha:
                    criterios.append(f"fecha='{fecha}'")
                if monto:
                    criterios.append(f"monto='{monto}'")
                crit_str = ', '.join(criterios)
                reporte.capturar_paso(paso_num, 'Movimiento QR seleccionado', f'Se seleccionó el movimiento con criterios: {crit_str}. Detalle: {desc_mov[:120]}', espera=2.0)
            else:
                reporte.capturar_paso(paso_num, f'Movimiento QR #{movimiento_index + 1} seleccionado', f'Se seleccionó el movimiento por índice. Detalle: {desc_mov[:120]}', espera=2.0)
        else:
            reporte.capturar_paso(paso_num, 'Movimiento QR NO encontrado', 'No se encontró ningún movimiento QR con los criterios especificados.', espera=1.0)
    paso_num += 1
    if not ok:
        print('  ⚠️ No se seleccionó ningún movimiento QR')
    tiempos.start('4. Cerrar modal')
    close_movement_qr_modal(driver)
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Modal de movimiento cerrado', 'Se cerró el detalle del movimiento QR y se regresó a la lista.', espera=1.0)
    paso_num += 1
    tiempos.start('5. Volver al home')
    if not go_back_movimientos_qr(driver):
        print('  ⚠️ No se pudo volver al home')
    tiempos.stop()
    if reporte:
        reporte.capturar_paso(paso_num, 'Home - Flujo Movimientos QR finalizado', 'Se regresó exitosamente al home. El flujo de Movimientos QR ha terminado.', espera=1.5)
    print('\n✅ MOVIMIENTOS QR CONSULTADOS EXITOSAMENTE')
    return True
if __name__ == '__main__':
    _input_cfg = load_input_defaults('qr_movimientos_con_reporte')
    print('=' * 60)
    print('🚀 FLUJO: LOGIN + MOVIMIENTOS QR + REPORTE')
    print('=' * 60)
    device_id = _input_cfg.get('device_id', 'R58N20SZZJP')
    username = _input_cfg.get('username', '76018956')
    password = _input_cfg.get('password', 'Abc#1234')
    CONCEPTO = _input_cfg.get('CONCEPTO', None)
    FECHA = _input_cfg.get('FECHA', None)
    MONTO = _input_cfg.get('MONTO', None)
    MOVIMIENTO_INDEX = _input_cfg.get('MOVIMIENTO_INDEX', 0)
    NOMBRE_PRUEBA = _input_cfg.get('NOMBRE_PRUEBA', 'Movimientos_QR')
    CARACTERISTICAS_DISPOSITIVO = _input_cfg.get('CARACTERISTICAS_DISPOSITIVO', 'Samsung Galaxy A54 5G, Android 14, 6GB RAM, 128GB')
    CARPETA_BASE_REPORTES = _input_cfg.get('CARPETA_BASE_REPORTES', 'reportes')
    tiempos = Tiempos()
    inicio_total = time.perf_counter()
    print(f'\n📱 Dispositivo: {device_id}')
    print(f'👤 Usuario: {username}')
    print(f'🔍 Criterios: concepto={CONCEPTO}, fecha={FECHA}, monto={MONTO}')
    print(f'📊 Fallback índice: #{MOVIMIENTO_INDEX + 1}')
    tiempos.start('0. Crear driver')
    driver = create_driver(device_id)
    tiempos.stop()
    print(f"  ⏱️  Crear driver: {format_duration(tiempos.tiempos['0. Crear driver'])}")
    tiempos.start('0b. Reset app')
    reset_app(driver)
    time.sleep(5)
    tiempos.stop()
    print(f"  ⏱️  Reset app: {format_duration(tiempos.tiempos['0b. Reset app'])}")
    reporte = ReporteTest(driver=driver, nombre_prueba=NOMBRE_PRUEBA, dispositivo_id=device_id, usuario=username, caracteristicas_dispositivo=CARACTERISTICAS_DISPOSITIVO, carpeta_base=CARPETA_BASE_REPORTES, parametros={'Concepto': CONCEPTO or '(no especificado)', 'Fecha': FECHA or '(no especificada)', 'Monto': MONTO or '(no especificado)', 'Índice fallback': MOVIMIENTO_INDEX})
    login_ok = _input_cfg.get('login_ok', False)
    movimientos_ok = _input_cfg.get('movimientos_ok', False)
    try:
        tiempos.start('A. Login')
        login_ok = login(driver, username, password, reporte=reporte)
        tiempos.stop()
        print(f"  ⏱️  Login: {format_duration(tiempos.tiempos['A. Login'])}")
        if login_ok:
            print('\n✅ LOGIN COMPLETADO EXITOSAMENTE')
            time.sleep(3)
            movimientos_ok = realizar_movimientos_qr(driver, concepto=CONCEPTO, fecha=FECHA, monto=MONTO, movimiento_index=MOVIMIENTO_INDEX, reporte=reporte, tiempos=tiempos, paso_inicial=6)
            if movimientos_ok:
                print('\n🎉 MOVIMIENTOS QR CONSULTADOS EXITOSAMENTE!')
            else:
                print('\n❌ CONSULTA DE MOVIMIENTOS QR FALLIDA')
        else:
            print('\n❌ LOGIN FALLIDO')
    except Exception as e:
        print(f'\n❌ Error en la ejecución: {e}')
        import traceback
        traceback.print_exc()
    finally:
        t_cierre = time.perf_counter()
        time.sleep(2)
        # Captura final automática: evidencia la última pantalla en éxito o error antes de cerrar la sesión.
        try:
            if reporte:
                reporte.capturar_paso(len(getattr(reporte, 'pasos', [])) + 1, 'Estado final de ejecución', 'Última pantalla disponible antes del cierre del driver.', espera=0.2)
        except Exception as e:
            print(f'  ⚠️ No se pudo tomar captura final: {e}')
        driver.quit()
        tiempos.tiempos['Z. Cierre driver'] = time.perf_counter() - t_cierre
        total = time.perf_counter() - inicio_total
        resultado_global = 'EXITOSO' if login_ok and movimientos_ok else 'FALLIDO'
        try:
            ruta_docx = reporte.generar_word(tiempo_total_segundos=total, resultado_global=resultado_global)
            print(f'\n📄 Reporte generado en: {ruta_docx}')
        except Exception as e:
            print(f'\n⚠️ No se pudo generar el reporte Word: {e}')
        tiempos.print_resumen(total)
        print(f'\n📊 Resultado final:')
        print(f"   Login          : {('✅ OK' if login_ok else '❌ FALLÓ')}")
        print(f"   Movimientos QR : {('✅ OK' if movimientos_ok else '❌ FALLÓ')}")
        print(f'   Carpeta        : {reporte.carpeta_salida}')
        print('\n👋 Sesión cerrada')

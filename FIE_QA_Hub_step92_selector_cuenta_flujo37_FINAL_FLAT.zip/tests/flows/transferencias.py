"""Adaptador de Transferencias: Excel/front -> funciones legacy refactorizadas."""
import importlib, inspect
from contextlib import redirect_stdout
from framework.common.test_support import Tiempos
from framework.reporting.legacy_bridge import LegacyReportBridge
from framework.utils.console import Writer

class TransferFlow:
    def __init__(self, module_name, function_name):
        self.module_name=module_name; self.function_name=function_name
    def run(self, driver, row, ctx):
        module=importlib.import_module(f"tests.legacy.{self.module_name}")
        func=getattr(module,self.function_name); kwargs={}
        for name,param in inspect.signature(func).parameters.items():
            if name=="driver": continue
            if name=="tiempos": kwargs[name]=Tiempos(); continue
            if name=="reporte": kwargs[name]=LegacyReportBridge(ctx); continue
            if name=="paso_inicial": continue
            value=row.get(name)
            if value not in (None,""): kwargs[name]=value
            elif param.default is inspect.Parameter.empty: raise ValueError(f"Falta parámetro obligatorio en Excel: {name}")
        writer=Writer(ctx)
        with redirect_stdout(writer): result=func(driver,**kwargs)
        writer.flush(); return True if result is None else bool(result)

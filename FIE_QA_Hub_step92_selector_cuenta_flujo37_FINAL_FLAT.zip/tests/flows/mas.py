"""Adaptador del módulo MAS: datos Excel -> función funcional existente."""
import importlib,inspect,json
from contextlib import redirect_stdout
from framework.common.test_support import Tiempos
from framework.reporting.legacy_bridge import LegacyReportBridge
from framework.utils.console import Writer
class MasFlow:
    def __init__(self,module,function,fixed=None): self.module=module;self.function=function;self.fixed=fixed or {}
    def run(self,driver,row,ctx):
        func=getattr(importlib.import_module(f"tests.legacy.{self.module}"),self.function);kwargs=dict(self.fixed)
        for name,param in inspect.signature(func).parameters.items():
            if name in kwargs:continue
            if name=="driver":continue
            if name=="tiempos":kwargs[name]=Tiempos();continue
            if name=="reporte":kwargs[name]=LegacyReportBridge(ctx);continue
            if name=="paso_inicial":continue
            value=row.get(name)
            if value not in (None,""):
                if name=="config" and isinstance(value,str):
                    try:value=json.loads(value)
                    except Exception:pass
                kwargs[name]=value
            elif param.default is inspect.Parameter.empty:raise ValueError(f"Falta parámetro obligatorio en Excel: {name}")
        w=Writer(ctx)
        with redirect_stdout(w): result=func(driver,**kwargs)
        w.flush();return True if result is None else bool(result)

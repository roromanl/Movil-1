"""Compatibility adapter used by the v15 front/runner.

The implementation now lives in framework.common; this module only preserves
the interface expected by framework.core.runner while legacy is refactored.
"""
from __future__ import annotations
from contextlib import redirect_stdout
from framework.common.login import login
from framework.reporting.legacy_bridge import LegacyReportBridge
from framework.utils.console import Writer

class LoginFlow:
    def __init__(self, root):
        self.root = root

    def run(self, driver, row, ctx):
        username = str(row.get("username") or "").strip()
        password = str(row.get("password") or "").strip()
        if not username or not password:
            raise ValueError("username y password son obligatorios")
        writer = Writer(ctx)
        with redirect_stdout(writer):
            ok = bool(login(driver, username, password, reporte=LegacyReportBridge(ctx)))
        writer.flush()
        return ok

"""Dynamic adapter that restores all integrated module mappings for the resilient suite runner."""
import importlib,inspect,json
from contextlib import redirect_stdout
from framework.common.test_support import Tiempos
from framework.reporting.legacy_bridge import LegacyReportBridge
from framework.utils.console import Writer
class DynamicFlow:
    def __init__(self,module,function,fixed=None,requires_login=True):self.module=module;self.function=function;self.fixed=fixed or {};self.requires_login=requires_login
    def run(self,driver,row,ctx):
        f=getattr(importlib.import_module(f'tests.legacy.{self.module}'),self.function);kw=dict(self.fixed)
        for n,p in inspect.signature(f).parameters.items():
            if n in kw:continue
            if n=='driver':continue
            if n=='tiempos':kw[n]=Tiempos();continue
            if n=='reporte':kw[n]=LegacyReportBridge(ctx);continue
            if n=='paso_inicial':continue
            v=row.get(n)
            if v not in (None,''):
                if n=='config' and isinstance(v,str):
                    try:v=json.loads(v)
                    except:pass
                kw[n]=v
            elif p.default is inspect.Parameter.empty:raise ValueError(f'Falta parámetro obligatorio en Excel: {n}')
        w=Writer(ctx)
        with redirect_stdout(w):r=f(driver,**kw)
        w.flush();return True if r is None else bool(r)

from framework.data.value_normalizer import normalize_row
"""Adaptador Consolidado: Excel/front -> funciones funcionales existentes."""
import importlib,inspect
from contextlib import redirect_stdout
from framework.common.test_support import Tiempos
from framework.reporting.legacy_bridge import LegacyReportBridge
from framework.utils.console import Writer
class ConsolidadoFlow:
    def __init__(self,module,function,fixed=None):self.module=module;self.function=function;self.fixed=fixed or {}
    def run(self,driver,row,ctx):
        row=normalize_row(row)
        func=getattr(importlib.import_module(f"tests.legacy.{self.module}"),self.function);kwargs=dict(self.fixed)
        for name,param in inspect.signature(func).parameters.items():
            if name in kwargs:continue
            if name=="driver":continue
            if name=="tiempos":kwargs[name]=Tiempos();continue
            if name=="reporte":kwargs[name]=LegacyReportBridge(ctx);continue
            if name=="paso_inicial":continue
            value=row.get(name)
            if value not in (None,""):kwargs[name]=value
            elif param.default is inspect.Parameter.empty:raise ValueError(f"Falta parámetro obligatorio en Excel: {name}")
        w=Writer(ctx)
        with redirect_stdout(w):res=func(driver,**kwargs)
        w.flush();return True if res is None else bool(res)

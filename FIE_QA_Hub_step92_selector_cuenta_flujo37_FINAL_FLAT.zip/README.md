# FIE Plus - Automatización

Versión v 0.1:
- Integración de scripts de automatización de Banca Movil Fie Plus
- Control de tiempos, captura de imagenes y reporte en word
- Adición de historico de ejecuciones de pruebas 
- Carga de bateria de pruebas a traves de Excel

# Herramientas Utilizadas
- Front: Streamlit
### Step 44: auditoría catálogo 001-157, MAS 030-035 y PAGOS 117-149
Se mapearon los flows MAS 030-034 al implementation compartido `login_ayuda_con_reporte.realizar_ayuda` mediante parámetros fijos por caso y 035 a `logout_con_reporte.logout`. Los pagos 117-149 se mapearon al flujo genérico existente `pago_servicios_con_reporte.realizar_pago_servicios`, fijando `servicio` a partir del nombre del catálogo; por eso no necesitan un `.py` dedicado por proveedor. Se revisaron los 157 IDs, existencia de módulo/función para todos los registrados, firmas y campos administrables. Parámetros OTP y clave temporal fueron eliminados de catálogo/admin/input; si una función legacy aún los declara con default, quedan internos y no se solicitan. Los contadores visibles continúan calculándose desde flujos activos.

### Step 46: 046-053 unificado, Estado de cuenta condicional y campos visibles
El caso 053 se consolida dentro de 046 `Ahorro - Buscar movimientos / Estados de cuenta`; 047-053 quedan como históricos inactivos. `Tipo Movimiento` incorpora Estados de cuenta. Mes de referencia y Año de referencia solo aparecen en Simple/Secuencial cuando se selecciona Estados de cuenta, y permanecen fuera del formulario en las demás opciones. Movimiento se presenta como combo 0-9. Se reforzó visualmente el borde/fondo/focus de text inputs y combos manteniendo el layout compacto de dos columnas.

### Step 47: 056-063 consolidado y tarjetas 084-089 protegidas
Se vuelve a registrar explícitamente 084-089 con sus seis implementaciones de tarjeta y se valida persistencia después de múltiples reconciliaciones de activación. 056-063 se consolida en 056 `Ahorro - Varias cuentas - Buscar movimientos / Estados de cuenta`; 057-063 quedan históricos inactivos. 056 usa el mismo combo de tipo de movimiento que 046, con Estados de cuenta; Mes/Año aparecen solo para esa opción y Movimiento es combo 0-9.

### Step 48: consolidación Corriente 065-072 y 075-082
Se consolidan 065-072 en 065 `C. Corriente - Buscar movimientos / Estados de cuenta` y 075-082 en 075 `C. Corriente - Varias cuentas - Buscar movimientos / Estados de cuenta`. Ambos reutilizan exactamente el patrón de 046/056: Tipo Movimiento con 8 opciones, Mes/Año solo al seleccionar Estados de cuenta y Movimiento 0-9. Los duplicados históricos quedan inactivos. Se vuelve a proteger 084-089 como mapeados y activos durante reconciliación.

### Step 49: consolidaciones Ayuda, Crypto y Movimientos QR
030-034 se consolidan en 030 con combo Contenido de ayuda: Manual de usuario, Preguntas frecuentes, Consejos de seguridad, Política de privacidad y Reclamos; el front traduce la etiqueta a `texto_busqueda/opcion` que espera el script compartido. 100-103 se consolidan en 100 con combo Operación: Compra, Venta, Recepción, Envío. 105-107 se consolidan en 105 con Tipo Movimiento Todos/Abonos/Débitos. 111-113 se consolidan en 111 con Tipo Movimiento Todos/Abonos/Débitos. Variantes históricas quedan inactivas y 084-089 permanecen protegidos como activos.

### Step 50: Administración coherente con activos y Estados de cuenta en Crypto 105
La pestaña Campos del Administrador ahora lista exclusivamente `active_catalog`, por lo que no muestra variantes consolidadas o flujos inactivos. El caso 105 `Crypto - Buscar movimientos` incorpora `Estados de cuenta` junto con Todos, Abonos y Débitos. Para 105, al seleccionar Estados de cuenta se ocultan Fecha Desde/Fecha Hasta y aparecen Mes/Año de referencia; para cualquier otra opción sucede lo inverso. Movimiento mantiene combo 0-9.

### Step 51: Crypto 105 condicional y servicios 117-149 pendientes reales
Se corrige 105 para renderizar primero Tipo Movimiento: si es `Estados de cuenta`, Fecha Desde/Fecha Hasta se ocultan y Mes/Año se muestran; en cualquier otra opción ocurre exactamente lo contrario. Se eliminan del `flow_registry` los mappings incorrectos 117-149 hacia `pago_servicios_con_reporte.py`: cada proveedor queda `PENDING_IMPLEMENTATION`, no ejecutable e inactivo hasta disponer de su implementación Python propia. La pestaña Campos, basada en flujos activos, deja de mostrarlos automáticamente.

### Step 53: UI organizada en Personalización 017 y Límites 020
El flujo 017 muestra Perfil y, únicamente para Personalizado, organiza CONFIG_PERSONALIZADO en tarjetas por sección con switches nativos: Asistente, Accesos directos, Navegación y Productos Más. `config` se construye internamente y `timeout=15` permanece técnico, no visible. En flujo 020 se renombran los campos según la pantalla móvil: Límite por transacción, Rebajar monto, Incrementar monto, Límite Diario Acumulado, Rebajar monto e Incrementar monto. Los botones de rebaja son combos -10000/-1000/-500 y los de incremento +500/+1000/+10000.

### Step 54: Configuración de notificaciones 014 estructurada
El flujo 014 se organiza visualmente según la aplicación: Cuenta, Recepción de abono en cuenta, Retiro en su cuenta y Notificaciones informativas. Condición Abono y Condición Retiro son combos Mayor/Ma​yor igual/Menor/Menor igual; Monto Abono y Monto Retiro permanecen como entradas. Los estados de recepción/retiro y los controles Activar notificaciones/Recibir notificaciones por correo electrónico se muestran como switches nativos. Se mantienen los nombres técnicos al enviar datos al script.

### Step 55: Notificaciones 015, Personalización 016 y caso 115 pendiente
El flujo 015 reutiliza la misma organización visual y metadatos de entrada del 014: secciones, condiciones en combo, montos y switches. La personalización que antes se operaba desde 017 se consolida en 016, renombrado `Personalizar banca - Cliente / Esencial / Emprendedor / Personalizado`, con Perfil y configuración personalizada dinámica; 017 queda histórico inactivo. El caso 115 queda `PENDING_IMPLEMENTATION`, no ejecutable e inactivo porque no dispone de implementación Python propia.

### Step 58: activación consistente y selección de tarjeta en 021
`flow_activation.reconcile` fuerza `active=false` para cualquier caso sin implementación ejecutable, evitando que históricos como 017 o pendientes como 115 reaparezcan marcados en Administración. El flujo 021 incorpora `Últimos 4 dígitos de la tarjeta`; tras entrar a Compras por internet busca `cards_card_debit_face`, compara el `content-desc`, recorre `cards_ols_pager` con swipe horizontal si existen varias tarjetas, selecciona la coincidencia y recién después cambia `Habilitar compras por internet`. Fecha Habilitada hasta se mantiene condicional al switch.

@echo off
where appium >nul 2>&1 || (echo Appium no encontrado.& pause & exit /b 1)
appium --address 127.0.0.1 --port 4723

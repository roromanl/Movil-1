"""Shared navigation/state helpers extracted from the functional scripts."""
from __future__ import annotations

import time
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait


def is_home(driver, timeout: int = 3) -> bool:
    """Detect the FIE home using the selectors already present in the supplied scripts."""
    selectors = [
        (AppiumBy.XPATH, "//*[contains(@content-desc,'Hola') or contains(@text,'Hola')]"),
        (AppiumBy.XPATH, "//*[contains(@content-desc,'Cerrar sesión') or contains(@text,'Cerrar sesión')]"),
    ]
    for locator in selectors:
        try:
            WebDriverWait(driver, timeout).until(EC.presence_of_element_located(locator))
            return True
        except Exception:
            continue
    return False


def return_home(driver, max_back: int = 5) -> bool:
    """Navigate back until Home without changing the original business flow semantics."""
    for _ in range(max_back):
        if is_home(driver):
            return True
        driver.back()
        time.sleep(0.6)
    return is_home(driver)

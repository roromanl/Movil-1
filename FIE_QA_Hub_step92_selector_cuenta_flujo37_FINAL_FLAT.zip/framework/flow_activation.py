"""Availability of catalog flows, based on actual Runner executability."""
from __future__ import annotations
import json
FILE='flow_activation.json'
# Built-in Runner flows do not need an entry in flow_registry.json.
BUILTIN_EXECUTABLE={2}
def load(root):return json.loads((root/'config'/FILE).read_text(encoding='utf-8'))
def save(root,data):(root/'config'/FILE).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
def executable_ids(root):
 reg=json.loads((root/'config'/'flow_registry.json').read_text(encoding='utf-8'))
 return {int(x) for x in reg}|BUILTIN_EXECUTABLE
def is_executable(root,test_id):return int(test_id) in executable_ids(root)
def is_active(root,test_id):
 item=load(root).get('flows',{}).get(str(test_id),{})
 return bool(item.get('active',False)) and is_executable(root,test_id)
def active_catalog(root,catalog):return [t for t in catalog if is_active(root,t['id'])]
def reconcile(root,catalog):
 """Refresh technical capability without overwriting the user's active choice."""
 data=load(root);exec_ids=executable_ids(root)
 for test in catalog:
  item=data.setdefault('flows',{}).setdefault(str(test['id']),{})
  item['executable']=test['id'] in exec_ids
  if not item['executable']: item['active']=False
  item.pop('registered',None)
  if test['id']==2:item['active']=True
  else:item.setdefault('active',test['id'] in exec_ids and not (117<=test['id']<=149))
 save(root,data);return data

import io
class Writer(io.TextIOBase):
 def __init__(self,ctx):self.ctx=ctx;self.buf=''
 def write(self,s):
  self.buf+=s
  while '\n' in self.buf:
   a,self.buf=self.buf.split('\n',1);self.ctx.printed(a)
  return len(s)
 def flush(self):
  if self.buf.strip():self.ctx.printed(self.buf)
  self.buf=''

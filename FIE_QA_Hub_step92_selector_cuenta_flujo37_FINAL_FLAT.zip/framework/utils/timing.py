"""Shared timing utilities used by every functional flow."""
import time
class Tiempos:
    def __init__(self): self.tiempos={}; self._t0=None; self._etapa_actual=None
    def start(self, etapa): self._etapa_actual=etapa; self._t0=time.perf_counter()
    def stop(self):
        if self._t0 is None:return 0
        d=time.perf_counter()-self._t0;self.tiempos[self._etapa_actual]=self.tiempos.get(self._etapa_actual,0)+d;self._t0=None;return d

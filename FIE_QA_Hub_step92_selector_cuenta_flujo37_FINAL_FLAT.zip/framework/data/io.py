"""Suite Excel generation and parsing."""
from io import BytesIO
from openpyxl import Workbook,load_workbook
from openpyxl.styles import Font,PatternFill
def template(tests):
 w=Workbook();w.remove(w.active)
 for t in tests:
  s=w.create_sheet((f"{t['id']:03d}_"+t['modulo'])[:31]);f=t.get('campos',[])
  if f:
   s.append(f);s.append(['' for _ in f])
   for c in s[1]:c.font=Font(bold=True,color='FFFFFF');c.fill=PatternFill('solid',fgColor='E5007D')
  else:s['A1']='Esta prueba no requiere parámetros de entrada.'
 b=BytesIO();w.save(b);return b.getvalue()
def rows_by_sheet(file):
 w=load_workbook(file,data_only=True);out={}
 for s in w.worksheets:
  v=list(s.iter_rows(values_only=True));h=[str(x or '').strip() for x in v[0]] if v else [];out[s.title]=[{h[i]:x for i,x in enumerate(r) if i<len(h) and h[i]} for r in v[1:] if any(x is not None for x in r)]
 return out

from io import BytesIO
from openpyxl import Workbook
from openpyxl.styles import Font,PatternFill
def template_bytes(t):
 w=Workbook();s=w.active;s.title="datos";f=["caso_id","tipo_prueba"]+t.get("campos",[]);s.append(f);s.append(["CASO-001","POSITIVA"]+["" for _ in f[2:]])
 for c in s[1]:c.font=Font(bold=True,color="FFFFFF");c.fill=PatternFill("solid",fgColor="E5007D")
 i=w.create_sheet("instrucciones");i.append(["Prueba",t.get("nombre")]);i.append(["Uso","Una fila representa un caso."]);b=BytesIO();w.save(b);return b.getvalue()

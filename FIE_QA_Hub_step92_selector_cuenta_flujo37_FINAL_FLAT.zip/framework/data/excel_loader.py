from openpyxl import load_workbook
def load_cases(f):
 r=list(load_workbook(f,data_only=True).active.iter_rows(values_only=True));h=[str(x or "").strip() for x in r[0]] if r else [];return [{h[i]:v for i,v in enumerate(x) if i<len(h) and h[i]} for x in r[1:] if any(v is not None for v in x)]

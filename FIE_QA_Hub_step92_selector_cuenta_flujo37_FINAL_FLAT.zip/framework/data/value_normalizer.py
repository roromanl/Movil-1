from datetime import date,datetime,time
def normalize_excel_value(name,value):
    if value is None:return None
    is_date=any(x in (name or '').lower() for x in ('fecha','vencimiento')) and 'opcion' not in (name or '').lower()
    if isinstance(value,datetime):return value.strftime('%d/%m/%Y') if is_date else value
    if isinstance(value,date):return value.strftime('%d/%m/%Y') if is_date else value
    if isinstance(value,time):return value.strftime('%H:%M:%S')
    if is_date and isinstance(value,str):
        for f in ('%d/%m/%Y','%Y-%m-%d','%Y-%m-%d %H:%M:%S','%d-%m-%Y'):
            try:return datetime.strptime(value.strip(),f).strftime('%d/%m/%Y')
            except ValueError:pass
    return value
def normalize_row(row):return {k:normalize_excel_value(k,v) for k,v in row.items()}

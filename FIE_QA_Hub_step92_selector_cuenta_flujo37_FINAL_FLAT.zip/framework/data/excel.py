"""Mass workbook for suites: fixed width, friendly field labels, technical mapping internal."""
from io import BytesIO
from pathlib import Path
from openpyxl import Workbook,load_workbook
from openpyxl.styles import Font,PatternFill
from openpyxl.worksheet.datavalidation import DataValidation
from framework.field_admin import fields_for

def _root():return Path(__file__).resolve().parents[2]
def _header(ws):
 for c in ws[1]:c.font=Font(bold=True,color='FFFFFF');c.fill=PatternFill('solid',fgColor='17365D')
def make(tests):
 root=_root();wb=Workbook();ws=wb.active;ws.title='DATOS';ws.append(['test_id','flujo','campo','valor']);_header(ws)
 for test in tests:
  fields=fields_for(root,test)
  if not fields:ws.append([test['id'],test['nombre'],'(sin parámetros)',''])
  for field in fields:
   ws.append([test['id'],test['nombre'],field['label'],''])
   if field.get('type')=='combo' and field.get('options'):
    dv=DataValidation(type='list',formula1='"'+','.join(map(str,field['options']))+'"',allow_blank=True);ws.add_data_validation(dv);dv.add(f'D{ws.max_row}')
 ws.column_dimensions['A'].width=10;ws.column_dimensions['B'].width=55;ws.column_dimensions['C'].width=38;ws.column_dimensions['D'].width=38
 cfg=wb.create_sheet('CONFIGURACION');cfg.append(['username','password']);cfg.append(['','']);_header(cfg);cfg.column_dimensions['A'].width=24;cfg.column_dimensions['B'].width=24
 out=BytesIO();wb.save(out);return out.getvalue()
def read(file,tests):
 root=_root();wb=load_workbook(file,data_only=True);out={t['id']:[] for t in tests};by={t['id']:t for t in tests};creds={}
 if 'CONFIGURACION' in wb.sheetnames:
  rows=list(wb['CONFIGURACION'].iter_rows(values_only=True));
  if len(rows)>1:creds={'username':rows[1][0],'password':rows[1][1]}
 grouped={}
 for test_id,flow,label,value in wb['DATOS'].iter_rows(min_row=2,values_only=True):
  if test_id is None:continue
  tid=int(test_id);grouped.setdefault(tid,{})
  if tid not in by or not label or label=='(sin parámetros)' or value in (None,''):continue
  label_map={f['label']:f['name'] for f in fields_for(root,by[tid])};technical=label_map.get(str(label))
  if technical:grouped[tid][technical]=value
 for tid in out:out[tid]=[dict(creds,**grouped.get(tid,{}))]
 return out

"""Application configuration with optional environment overrides."""
from __future__ import annotations

import json
import os
from pathlib import Path


def settings(root: Path) -> dict:
    """Load shared settings while keeping workstation values outside test flows."""
    data = json.loads((root / "config" / "settings.json").read_text(encoding="utf-8"))
    data["appium_url"] = os.getenv("APPIUM_URL", data["appium_url"])
    data["app_package"] = os.getenv("APP_PACKAGE", data["app_package"])
    data["app_activity"] = os.getenv("APP_ACTIVITY", data["app_activity"])
    data["output_dir"] = root / os.getenv("OUTPUT_DIR", data["output"])
    return data

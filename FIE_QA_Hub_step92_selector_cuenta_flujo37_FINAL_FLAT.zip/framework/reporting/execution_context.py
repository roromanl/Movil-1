"""Per-run evidence, structured events, screenshots and technical logging."""
from __future__ import annotations

import json
import logging
import time
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path


@dataclass
class Event:
    timestamp: str
    level: str
    test_id: int | None
    step: str
    message: str
    screenshot: str | None = None


class ExecutionContext:
    def __init__(self, output_root: Path, run_name: str, driver=None) -> None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.run_dir = output_root / "runs" / f"{run_name}_{stamp}"
        self.screenshot_dir = self.run_dir / "screenshots"
        self.report_dir = self.run_dir / "reports"
        self.screenshot_dir.mkdir(parents=True, exist_ok=True)
        self.report_dir.mkdir(parents=True, exist_ok=True)
        self.driver = driver
        self.events: list[Event] = []
        self._logger = logging.getLogger(f"fieqa.{stamp}.{id(self)}")
        self._logger.setLevel(logging.INFO)
        handler = logging.FileHandler(self.run_dir / "execution.log", encoding="utf-8")
        handler.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s"))
        self._logger.addHandler(handler)

    def bind_driver(self, driver) -> None:
        self.driver = driver

    def record(self, step: str, message: str, test_id: int | None = None, level: str = "INFO", screenshot: bool = False) -> Event:
        image = None
        if screenshot and self.driver is not None:
            safe = "".join(ch if ch.isalnum() else "_" for ch in step)[:60]
            image_path = self.screenshot_dir / f"{len(self.events)+1:03d}_{safe}.png"
            try:
                self.driver.save_screenshot(str(image_path))
                image = str(image_path)
            except Exception as exc:
                self._logger.warning("Screenshot failed: %s", exc)
        event = Event(datetime.now().isoformat(timespec="seconds"), level, test_id, step, message, image)
        self.events.append(event)
        getattr(self._logger, level.lower(), self._logger.info)("test=%s step=%s | %s", test_id, step, message)
        self._flush_events()
        return event

    def _flush_events(self) -> None:
        (self.run_dir / "events.json").write_text(json.dumps([asdict(e) for e in self.events], ensure_ascii=False, indent=2), encoding="utf-8")

"""Generic Word report generated from execution events and screenshots."""
from __future__ import annotations

from pathlib import Path
from docx import Document
from docx.shared import Inches

from framework.reporting.execution_context import Event


def build_word_report(path: Path, title: str, device: str, status: str, events: list[Event]) -> Path:
    """Create a single test report without embedding flow-specific logic."""
    document = Document()
    document.add_heading(title, 0)
    document.add_paragraph(f"Dispositivo: {device}")
    document.add_paragraph(f"Resultado: {status}")
    document.add_heading("Ejecución", level=1)
    for event in events:
        document.add_heading(event.step, level=2)
        document.add_paragraph(f"{event.timestamp} | {event.level} | {event.message}")
        if event.screenshot and Path(event.screenshot).exists():
            document.add_picture(event.screenshot, width=Inches(5.8))
    path.parent.mkdir(parents=True, exist_ok=True)
    document.save(path)
    return path

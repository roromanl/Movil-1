"""Word report preserving the structure of the supplied ReporteTest class."""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches, Pt, RGBColor


def format_duration(seconds: float) -> str:
    minutes = int(seconds // 60)
    remaining = seconds % 60
    return f"{minutes:02d}:{remaining:05.2f}"


def build(path: Path, title: str, device: str, user: str, status: str, total_seconds: float, steps: list[dict]) -> Path:
    """Generate the same sections, table fields and step layout as legacy reports."""
    doc = Document()
    heading = doc.add_heading("REPORTE DE EJECUCIÓN DE PRUEBA", level=0)
    heading.alignment = WD_ALIGN_PARAGRAPH.CENTER

    doc.add_heading("Datos Generales", level=1)
    table = doc.add_table(rows=0, cols=2)
    table.style = "Table Grid"
    data = [
        ("Tipo de prueba", title),
        ("Fecha de ejecución", datetime.now().strftime("%d/%m/%Y %H:%M:%S")),
        ("Dispositivo (ID)", device),
        ("Características del dispositivo", f"Android {device}"),
        ("Tiempo de ejecución", format_duration(total_seconds)),
        ("Usuario de prueba", user),
        ("Resultado global", status),
        ("Total de pasos", str(len(steps))),
    ]
    for label, value in data:
        cells = table.add_row().cells
        cells[0].text = label
        cells[1].text = str(value)
        for paragraph in cells[0].paragraphs:
            for run in paragraph.runs:
                run.bold = True

    doc.add_page_break()
    doc.add_heading("Pasos de la Ejecución", level=1)
    for step in steps:
        paragraph = doc.add_paragraph()
        run = paragraph.add_run(f"Paso {step['num']}: {step['titulo']}")
        run.bold = True
        run.font.size = Pt(13)
        run.font.color.rgb = RGBColor(0x1F, 0x3B, 0x73)
        if step.get("descripcion"):
            description = doc.add_paragraph()
            description.add_run("Descripción: ").bold = True
            description.add_run(step["descripcion"])
        image = step.get("archivo")
        if image and Path(image).exists():
            doc.add_picture(image, width=Inches(3.5))
            doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
        else:
            doc.add_paragraph("[Captura no disponible]")

    doc.add_page_break()
    doc.add_heading("Resultado Final", level=1)
    result = doc.add_paragraph()
    result.add_run("Resultado global: ").bold = True
    result.add_run(status)
    path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(path)
    return path


def build_consolidated(path, title, device, results):
    """One suite report; identical screenshots are included once globally."""
    import hashlib
    doc=Document();h=doc.add_heading('REPORTE CONSOLIDADO DE EJECUCIÓN',level=0);h.alignment=WD_ALIGN_PARAGRAPH.CENTER
    doc.add_paragraph(f'Modalidad: {title}');doc.add_paragraph(f'Dispositivo: {device}');doc.add_paragraph(f'Fecha: {datetime.now().strftime("%d/%m/%Y %H:%M:%S")}')
    table=doc.add_table(rows=1,cols=5);table.style='Table Grid'
    for c,v in zip(table.rows[0].cells,['ID','Prueba','Registro','Resultado','Duración']):c.text=v
    seen=set()
    for r in results:
        cells=table.add_row().cells
        for c,v in zip(cells,[f'{r.test_id:03d}',r.name,r.record,r.status,format_duration(r.tiempo_segundos)]):c.text=str(v)
        doc.add_heading(f'{r.test_id:03d} · {r.name} · Registro {r.record}',level=1);doc.add_paragraph(f'Resultado: {r.status} | {r.detail}')
        evidence=Path(r.evidence) if r.evidence else None
        if evidence and (evidence/'screenshots').exists():
            for image in sorted((evidence/'screenshots').glob('*.png')):
                try:digest=hashlib.sha256(image.read_bytes()).hexdigest()
                except OSError:continue
                if digest in seen:continue
                seen.add(digest)
                try:doc.add_picture(str(image),width=Inches(3.25));doc.paragraphs[-1].alignment=WD_ALIGN_PARAGRAPH.CENTER
                except Exception:pass
    path.parent.mkdir(parents=True,exist_ok=True);doc.save(path);return path

"""Persist rich metadata for every run and rebuild older run history where possible."""
from __future__ import annotations
from datetime import datetime
from pathlib import Path
import json

def _file_flags(result):
    def exists(key):
        value=result.get(key);return bool(value and Path(value).exists())
    evidence=result.get('evidence');shots=[]
    if evidence:
        p=Path(evidence)/'screenshots'
        if p.exists():shots=[str(x) for x in sorted(p.glob('*.png'))]
    return {'tiene_reporte':exists('report'),'tiene_log':exists('log'),'capturas':shots,'cantidad_capturas':len(shots)}

def save_run(run_dir:Path,mode:str,tests:list,results:list,udid:str,elapsed:float):
    test_by_id={t['id']:t for t in tests};rows=[]
    for r in results:
        item=dict(r.__dict__);catalog=test_by_id.get(r.test_id,{})
        item.update({'modulo':catalog.get('modulo',''),'nombre_prueba':catalog.get('nombre',r.name),'archivo_fuente':catalog.get('archivo','')})
        item.update(_file_flags(item));rows.append(item)
        # Sidecar next to each evidence folder: makes history independent of future catalog changes.
        if item.get('evidence'):
            e=Path(item['evidence'])
            if e.exists():(e/'test_metadata.json').write_text(json.dumps(item,ensure_ascii=False,indent=2),encoding='utf-8')
    payload={'version':2,'fecha':datetime.now().isoformat(timespec='seconds'),'modalidad':mode,'dispositivo':udid,'duracion_segundos':round(elapsed,2),'cantidad_pruebas':len(rows),'tests':[{'id':t['id'],'modulo':t.get('modulo',''),'nombre':t['nombre'],'archivo':t.get('archivo','')} for t in tests],'resultados':rows}
    (run_dir/'run_summary.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')

def _legacy_results(folder:Path):
    rows=[]
    for meta in folder.rglob('test_metadata.json'):
        try:rows.append(json.loads(meta.read_text(encoding='utf-8')))
        except Exception:pass
    return rows

def list_runs(output_dir:Path):
    runs=[];base=output_dir/'runs'
    if not base.exists():return runs
    for folder in sorted((p for p in base.iterdir() if p.is_dir()),reverse=True):
        summary=folder/'run_summary.json';meta=None
        if summary.exists():
            try:meta=json.loads(summary.read_text(encoding='utf-8'))
            except Exception:meta=None
        if meta is None:
            rows=_legacy_results(folder);meta={'version':1,'fecha':datetime.fromtimestamp(folder.stat().st_mtime).isoformat(timespec='seconds'),'modalidad':'Histórico anterior','duracion_segundos':sum(float(x.get('tiempo_segundos',0) or 0) for x in rows),'resultados':rows}
        runs.append((folder,meta))
    return runs

from docx import Document
from pathlib import Path
def create_summary(path, title, results):
 d=Document(); d.add_heading(title,0); d.add_paragraph(f"Casos ejecutados: {len(results)}"); t=d.add_table(rows=1, cols=5);
 for c,v in zip(t.rows[0].cells,["Prueba","Fila","Estado","Segundos","Error"]): c.text=v
 for r in results:
  cells=t.add_row().cells
  for c,v in zip(cells,[r.get("test_id"),r.get("row"),r.get("status"),round(r.get("seconds",0),2),r.get("error","")]): c.text=str(v)
 Path(path).parent.mkdir(parents=True,exist_ok=True); d.save(path); return path

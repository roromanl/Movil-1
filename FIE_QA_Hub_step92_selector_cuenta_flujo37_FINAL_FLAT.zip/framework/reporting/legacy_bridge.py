"""Adapter that gives legacy business functions the original ReporteTest API."""
from __future__ import annotations


class LegacyReportBridge:
    """Implement capturar_paso() while delegating storage to the new Context."""

    def __init__(self, context) -> None:
        self.context = context

    def capturar_paso(self, numero, titulo, descripcion="", espera=1.0):
        return self.context.capture_step(numero, titulo, descripcion, float(espera))

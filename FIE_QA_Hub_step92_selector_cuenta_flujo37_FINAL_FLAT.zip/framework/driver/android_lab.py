"""ADB, SDK and AVD discovery for Windows stations."""
import os,glob,shutil,subprocess,requests
def sdk_root():
 c=[os.environ.get('ANDROID_SDK_ROOT'),os.environ.get('ANDROID_HOME'),os.path.join(os.environ.get('LOCALAPPDATA',''),'Android','Sdk')];return next((x for x in c if x and os.path.isdir(x)),None)
def adb():
 p=shutil.which('adb');r=sdk_root();q=os.path.join(r,'platform-tools','adb.exe') if r else None;return p or (q if q and os.path.exists(q) else None)
def emulator():
 p=shutil.which('emulator');r=sdk_root();q=os.path.join(r,'emulator','emulator.exe') if r else None;return p or (q if q and os.path.exists(q) else None)
def avd_home():return os.environ.get('ANDROID_AVD_HOME') or os.path.join(os.environ.get('USERPROFILE',os.path.expanduser('~')),'.android','avd')
def avds():
 out=[];e=emulator()
 if e:
  try:out=[x.strip() for x in subprocess.run([e,'-list-avds'],capture_output=True,text=True,timeout=12).stdout.splitlines() if x.strip()]
  except:pass
 for ini in glob.glob(os.path.join(avd_home(),'*.ini')):
  n=os.path.splitext(os.path.basename(ini))[0]
  if n not in out:out.append(n)
 return sorted(out)
def devices():
 a=adb();out=[]
 if not a:return out
 try:
  subprocess.run([a,'start-server'],capture_output=True,timeout=8);raw=subprocess.run([a,'devices','-l'],capture_output=True,text=True,timeout=8).stdout
  for line in raw.splitlines()[1:]:
   x=line.split()
   if len(x)>=2:out.append({'udid':x[0],'state':x[1],'model':next((z.split(':',1)[1] for z in x if z.startswith('model:')),x[0]),'kind':'Emulador' if x[0].startswith('emulator-') else 'Físico'})
 except:pass
 return out
def launch(name):
 e=emulator()
 if not e:raise RuntimeError('No se encontró emulator.exe')
 subprocess.Popen([e,'-avd',name],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
def appium_status():
 try:
  r=requests.get('http://127.0.0.1:4723/status',timeout=2);return {'ok':r.ok,'url':'http://127.0.0.1:4723'}
 except:return {'ok':False,'url':None}

import subprocess,shutil,os
def adb_path():
 p=shutil.which("adb")
 if p:return p
 h=os.environ.get("ANDROID_SDK_ROOT") or os.environ.get("ANDROID_HOME")
 p=os.path.join(h,"platform-tools","adb.exe") if h else None
 return p if p and os.path.exists(p) else None
def adb_devices():
 a=adb_path()
 if not a:return []
 try:
  subprocess.run([a,"start-server"],capture_output=True,timeout=10); p=subprocess.run([a,"devices","-l"],capture_output=True,text=True,timeout=10); out=[]
  for line in p.stdout.splitlines()[1:]:
   q=line.split()
   if len(q)<2:continue
   meta={x.split(":",1)[0]:x.split(":",1)[1] for x in q[2:] if ":" in x}; out.append({"udid":q[0],"state":q[1],"model":meta.get("model",q[0]),"kind":"Emulador" if q[0].startswith("emulator-") else "Fisico"})
  return out
 except Exception:return []

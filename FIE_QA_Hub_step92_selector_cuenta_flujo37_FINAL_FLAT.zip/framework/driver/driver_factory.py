"""Single Appium driver factory used by individual and suite executions."""
from __future__ import annotations

from appium import webdriver
from appium.options.android import UiAutomator2Options

from framework.config import Settings


def create_driver(settings: Settings, udid: str, system_port: int | None = None):
    """Create one Android UiAutomator2 session with all common capabilities."""
    options = UiAutomator2Options()
    options.platform_name = "Android"
    options.device_name = udid
    options.udid = udid
    options.automation_name = "UiAutomator2"
    options.app_package = settings.app_package
    options.app_activity = settings.app_activity
    options.no_reset = True
    options.full_reset = False
    options.new_command_timeout = settings.new_command_timeout
    if system_port is not None:
        options.system_port = system_port
    return webdriver.Remote(settings.appium_url, options=options)


def reset_app(driver, package: str) -> None:
    """Return the app to a predictable start without destroying the driver session."""
    driver.terminate_app(package)
    driver.activate_app(package)

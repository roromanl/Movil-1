"""Reusable Appium session and application lifecycle helpers."""
from __future__ import annotations

import time

from appium import webdriver
from appium.options.android import UiAutomator2Options


def create(cfg: dict, udid: str):
    """Create the driver using the capabilities from the original scripts."""
    options = UiAutomator2Options()
    options.platform_name = "Android"
    options.device_name = udid
    options.udid = udid
    options.automation_name = "UiAutomator2"
    options.app_package = cfg["app_package"]
    options.app_activity = cfg["app_activity"]
    options.no_reset = True
    options.full_reset = False
    options.new_command_timeout = cfg["timeout"]
    return webdriver.Remote(cfg["appium_url"], options=options)


def reset(driver, package: str, timing: dict, emit=None) -> None:
    """Replicate the original reset sequence and waits exactly.

    Original sequence: terminate -> wait 2s -> activate -> wait 3s, followed
    by another 5s wait in the execution main block before starting Login.
    """
    if emit:
        emit("Preparación", "🔄 Reiniciando aplicación...")
    driver.terminate_app(package)
    time.sleep(float(timing.get("after_terminate_seconds", 2.0)))
    driver.activate_app(package)
    time.sleep(float(timing.get("after_activate_seconds", 3.0)))
    if emit:
        emit("Preparación", "✅ App reiniciada; esperando carga completa")
    time.sleep(float(timing.get("after_reset_seconds", 5.0)))

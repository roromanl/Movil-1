"""Utilities used by the Device Lab page.

This module intentionally keeps device discovery and emulator management small
and independent from the test Runner. APK installation is implemented here so
UI code never has to build ADB commands directly.
"""
from __future__ import annotations

import glob
import os
import shutil
import subprocess
from pathlib import Path

import requests


def sdk():
    """Return the detected Android SDK directory, if available."""
    candidates = [
        os.environ.get("ANDROID_SDK_ROOT"),
        os.environ.get("ANDROID_HOME"),
        os.path.join(os.environ.get("LOCALAPPDATA", ""), "Android", "Sdk"),
    ]
    return next((item for item in candidates if item and os.path.isdir(item)), None)


def adb():
    """Return the ADB executable available in PATH or in the detected SDK."""
    path_adb = shutil.which("adb")
    sdk_root = sdk()
    sdk_adb = os.path.join(sdk_root, "platform-tools", "adb.exe") if sdk_root else ""
    return path_adb or (sdk_adb if os.path.exists(sdk_adb) else None)


def devices():
    """Return Android devices reported by `adb devices -l`."""
    adb_path = adb()
    output = []
    if not adb_path:
        return output

    try:
        subprocess.run([adb_path, "start-server"], capture_output=True, timeout=8)
        raw = subprocess.run(
            [adb_path, "devices", "-l"],
            capture_output=True,
            text=True,
            timeout=8,
        ).stdout
        for line in raw.splitlines()[1:]:
            parts = line.split()
            if len(parts) < 2:
                continue
            udid = parts[0]
            output.append(
                {
                    "udid": udid,
                    "state": parts[1],
                    "model": next(
                        (value.split(":", 1)[1] for value in parts if value.startswith("model:")),
                        udid,
                    ),
                    "kind": "Emulador" if udid.startswith("emulator-") else "Físico",
                }
            )
    except (OSError, subprocess.SubprocessError):
        return []
    return output


def install_apk(udid: str, apk_path: str | Path, timeout: int = 180) -> tuple[bool, str]:
    """Install or update an APK on one online Android device.

    `adb -s <udid> install -r` preserves application data when the package is
    already installed. The function returns a status plus the ADB response so
    Device Lab can show a useful diagnostic without changing Runner behavior.
    """
    adb_path = adb()
    path = Path(apk_path)
    if not adb_path:
        return False, "ADB no está disponible."
    if not udid:
        return False, "No se seleccionó un dispositivo."
    if not path.is_file() or path.suffix.lower() != ".apk":
        return False, "El archivo seleccionado no es un APK válido."

    try:
        result = subprocess.run(
            [adb_path, "-s", udid, "install", "-r", str(path)],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        return False, f"La instalación superó el tiempo máximo de {timeout} segundos."
    except OSError as exc:
        return False, f"No se pudo ejecutar ADB: {exc}"

    message = "\n".join(part.strip() for part in (result.stdout, result.stderr) if part.strip())
    success = result.returncode == 0 and "Success" in message
    return success, message or f"ADB terminó con código {result.returncode}."


def appium():
    """Return True when the local Appium status endpoint responds successfully."""
    try:
        return requests.get("http://127.0.0.1:4723/status", timeout=2).ok
    except requests.RequestException:
        return False


def emulator():
    """Return the Android emulator executable from the detected SDK."""
    sdk_root = sdk()
    path = os.path.join(sdk_root, "emulator", "emulator.exe") if sdk_root else ""
    return path if os.path.exists(path) else None


def avds():
    """List Android Virtual Devices configured in the local SDK."""
    emulator_path = emulator()
    if not emulator_path:
        return []
    try:
        return [
            item.strip()
            for item in subprocess.run(
                [emulator_path, "-list-avds"],
                capture_output=True,
                text=True,
                timeout=10,
            ).stdout.splitlines()
            if item.strip()
        ]
    except (OSError, subprocess.SubprocessError):
        return []


def launch(name):
    """Start one configured AVD without blocking Streamlit."""
    subprocess.Popen(
        [emulator(), "-avd", name],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )

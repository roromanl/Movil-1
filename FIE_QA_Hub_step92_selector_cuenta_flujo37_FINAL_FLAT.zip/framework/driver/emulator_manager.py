import os,subprocess,shutil
def emulator_path():
 e=shutil.which("emulator")
 if e:return e
 h=os.environ.get("ANDROID_SDK_ROOT") or os.environ.get("ANDROID_HOME"); p=os.path.join(h,"emulator","emulator.exe") if h else None
 return p if p and os.path.exists(p) else None
def list_avds():
 e=emulator_path()
 if not e:return []
 return [x.strip() for x in subprocess.run([e,"-list-avds"],capture_output=True,text=True,timeout=15).stdout.splitlines() if x.strip()]
def launch_avd(name):
 e=emulator_path()
 if not e:raise RuntimeError("No se encontro emulator.exe. Configure ANDROID_SDK_ROOT o ANDROID_HOME.")
 subprocess.Popen([e,"-avd",name,"-no-snapshot-save"],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); return name

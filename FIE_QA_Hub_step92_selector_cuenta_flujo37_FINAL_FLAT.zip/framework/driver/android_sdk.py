import os,subprocess,shutil,glob,time

def sdk_root():
    candidates=[os.environ.get('ANDROID_SDK_ROOT'),os.environ.get('ANDROID_HOME'),os.path.expandvars(r'%LOCALAPPDATA%\Android\Sdk'),os.path.expanduser(r'~/AppData/Local/Android/Sdk')]
    return next((p for p in candidates if p and os.path.isdir(p)),None)
def tool(name,subdir):
    p=shutil.which(name)
    if p:return p
    r=sdk_root()
    if not r:return None
    direct=os.path.join(r,subdir,name+'.exe')
    if os.path.exists(direct):return direct
    matches=glob.glob(os.path.join(r,subdir,'*','bin',name+'.bat'))+glob.glob(os.path.join(r,subdir,'*','bin',name+'.exe'))
    return sorted(matches)[-1] if matches else None
def adb():return tool('adb','platform-tools')
def emulator():return tool('emulator','emulator')
def avdmanager():return tool('avdmanager','cmdline-tools')
def sdkmanager():return tool('sdkmanager','cmdline-tools')
def devices():
    a=adb()
    if not a:return []
    subprocess.run([a,'start-server'],capture_output=True,timeout=10); p=subprocess.run([a,'devices','-l'],capture_output=True,text=True,timeout=10); out=[]
    for line in p.stdout.splitlines()[1:]:
      q=line.split()
      if len(q)>=2:
       meta={x.split(':',1)[0]:x.split(':',1)[1] for x in q[2:] if ':' in x}; out.append({'udid':q[0],'state':q[1],'model':meta.get('model',q[0]),'kind':'Emulador' if q[0].startswith('emulator-') else 'Físico'})
    return out
def avds():
    e=emulator()
    if not e:return []
    return [x.strip() for x in subprocess.run([e,'-list-avds'],capture_output=True,text=True,timeout=15).stdout.splitlines() if x.strip()]
def launch(name):
    e=emulator()
    if not e:raise RuntimeError('Android Emulator no encontrado dentro del SDK.')
    flags=0x00000008|0x00000200 if os.name=='nt' else 0
    subprocess.Popen([e,'-avd',name,'-no-snapshot-save'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=flags);return name
def installed_images():
    r=sdk_root()
    if not r:return []
    base=os.path.join(r,'system-images'); out=[]
    if os.path.isdir(base):
      for api in os.listdir(base):
       for tag in os.listdir(os.path.join(base,api)):
        for abi in os.listdir(os.path.join(base,api,tag)):out.append(f'system-images;{api};{tag};{abi}')
    return sorted(out,reverse=True)
def create_avd(name,package,device='pixel_7'):
    a=avdmanager()
    if not a:raise RuntimeError('No se encontró avdmanager. Instale Android SDK Command-line Tools desde SDK Manager.')
    cmd=[a,'create','avd','--force','--name',name,'--package',package,'--device',device]
    p=subprocess.run(cmd,input='no\n',capture_output=True,text=True,timeout=90)
    if p.returncode:raise RuntimeError((p.stderr or p.stdout)[-1500:])
    return name

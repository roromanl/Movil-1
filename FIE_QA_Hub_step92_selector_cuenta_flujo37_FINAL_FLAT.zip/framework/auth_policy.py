"""Single source of truth for authentication requirements."""
from __future__ import annotations
import json
from pathlib import Path

PUBLIC_TEST_IDS = {1, 3}


def load_requires_login(root: Path) -> dict[int, bool]:
    """Load login policy from the same registry used by Runner."""
    registry = json.loads((root / "config" / "flow_registry.json").read_text(encoding="utf-8"))
    policy = {int(test_id): bool(cfg.get("requires_login", True)) for test_id, cfg in registry.items()}
    # Login itself is an authentication action, not a flow requiring pre-login.
    policy[2] = False
    return policy


def requires_login(root: Path, test_id: int) -> bool:
    policy = load_requires_login(root)
    # Unregistered legacy cases are not executable through DynamicFlow. Do not
    # invent an authentication policy for them here.
    return policy.get(int(test_id), False)

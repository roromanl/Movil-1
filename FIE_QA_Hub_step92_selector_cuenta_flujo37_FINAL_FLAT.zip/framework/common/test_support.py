"""Shared legacy-compatible test infrastructure."""
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy
import time
import os
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH

def format_duration(seconds):
    if seconds >= 60:
        mins = int(seconds // 60)
        secs = seconds % 60
        return f'{mins}m {secs:.2f}s'
    return f'{seconds:.2f}s'

class Tiempos:
    """Acumulador de tiempos por etapa"""

    def __init__(self):
        self.tiempos = {}
        self._t0 = None
        self._etapa_actual = None

    def start(self, etapa):
        self._etapa_actual = etapa
        self._t0 = time.perf_counter()

    def stop(self):
        if self._t0 is not None:
            dur = time.perf_counter() - self._t0
            self.tiempos[self._etapa_actual] = self.tiempos.get(self._etapa_actual, 0) + dur
            self._t0 = None
            return dur
        return 0

    def print_resumen(self, total):
        print('\n' + '=' * 50)
        print('⏱️  RESUMEN DE TIEMPOS DE EJECUCIÓN')
        print('=' * 50)
        for etapa, dur in self.tiempos.items():
            print(f'  • {etapa:<25}: {format_duration(dur)}')
        print('-' * 50)
        print(f"  🏁 {'TOTAL':<25}: {format_duration(total)}")
        print('=' * 50)

class ReporteTest:
    """
    Maneja:
      - La carpeta de salida (con fecha y hora)
      - Las capturas de pantalla paso a paso
      - El documento Word con la cabecera y las capturas
    """

    def __init__(self, driver, nombre_prueba, dispositivo_id, usuario, caracteristicas_dispositivo='', carpeta_base='reportes'):
        self.driver = driver
        self.nombre_prueba = nombre_prueba
        self.dispositivo_id = dispositivo_id
        self.usuario = usuario
        self.caracteristicas_dispositivo = caracteristicas_dispositivo
        self.fecha_ejecucion = datetime.now()
        timestamp = self.fecha_ejecucion.strftime('%Y%m%d_%H%M%S')
        nombre_carpeta = f'{nombre_prueba}_{timestamp}'
        self.carpeta_salida = os.path.join(carpeta_base, nombre_carpeta)
        self.carpeta_capturas = os.path.join(self.carpeta_salida, 'capturas')
        os.makedirs(self.carpeta_capturas, exist_ok=True)
        print(f'  📁 Carpeta de reporte: {self.carpeta_salida}')
        self.pasos = []
        self.doc = Document()
        self._configurar_estilos()

    def _configurar_estilos(self):
        """Configura tamaño base de fuente del documento"""
        style = self.doc.styles['Normal']
        style.font.name = 'Calibri'
        style.font.size = Pt(11)

    def capturar_paso(self, numero, titulo, descripcion='', espera=1.0):
        """
        Toma una captura de pantalla y la registra como un paso.
        Devuelve la ruta del archivo.
        """
        time.sleep(espera)
        nombre_archivo = f'paso_{numero:02d}_{self._slug(titulo)}.png'
        ruta_completa = os.path.join(self.carpeta_capturas, nombre_archivo)
        try:
            self.driver.save_screenshot(ruta_completa)
            print(f'    📸 Captura: {nombre_archivo}')
        except Exception as e:
            print(f'    ⚠️ No se pudo capturar: {e}')
            ruta_completa = None
        self.pasos.append({'num': numero, 'titulo': titulo, 'descripcion': descripcion, 'archivo': ruta_completa})
        return ruta_completa

    def _slug(self, texto, max_len=40):
        """Convierte un texto a algo seguro para nombre de archivo"""
        s = texto.lower()
        reemplazos = {'á': 'a', 'é': 'e', 'í': 'i', 'ó': 'o', 'ú': 'u', 'ñ': 'n', ' ': '_', '/': '_', '\\': '_', ':': '_', '?': '', '¿': '', '.': '_', ',': '_', '(': '', ')': ''}
        for k, v in reemplazos.items():
            s = s.replace(k, v)
        return s[:max_len]

    def generar_word(self, tiempo_total_segundos, resultado_global='OK'):
        """
        Genera el documento Word con:
          1) Cabecera con datos generales
          2) Sección por cada paso con su captura y descripción
          3) Resumen final
        """
        titulo = self.doc.add_heading('Reporte de Prueba Automatizada', level=0)
        titulo.alignment = WD_ALIGN_PARAGRAPH.CENTER
        subtitulo = self.doc.add_paragraph()
        subtitulo.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = subtitulo.add_run(self.nombre_prueba)
        run.bold = True
        run.font.size = Pt(14)
        self.doc.add_paragraph()
        self.doc.add_heading('Datos Generales', level=1)
        tabla = self.doc.add_table(rows=0, cols=2)
        tabla.style = 'Light Grid Accent 1'
        datos = [('Tipo de prueba', self.nombre_prueba), ('Fecha de ejecución', self.fecha_ejecucion.strftime('%d/%m/%Y %H:%M:%S')), ('Dispositivo (ID)', self.dispositivo_id), ('Características del dispositivo', self.caracteristicas_dispositivo or 'No especificado'), ('Tiempo de ejecución', format_duration(tiempo_total_segundos)), ('Usuario de prueba', self.usuario), ('Resultado global', resultado_global), ('Total de pasos', str(len(self.pasos)))]
        for etiqueta, valor in datos:
            fila = tabla.add_row().cells
            fila[0].text = etiqueta
            fila[1].text = str(valor)
            for p in fila[0].paragraphs:
                for r in p.runs:
                    r.bold = True
        self.doc.add_page_break()
        self.doc.add_heading('Pasos de la Ejecución', level=1)
        for paso in self.pasos:
            titulo_paso = self.doc.add_paragraph()
            run = titulo_paso.add_run(f"Paso {paso['num']}: {paso['titulo']}")
            run.bold = True
            run.font.size = Pt(13)
            run.font.color.rgb = RGBColor(31, 59, 115)
            if paso['descripcion']:
                desc = self.doc.add_paragraph()
                desc.add_run('Descripción: ').bold = True
                desc.add_run(paso['descripcion'])
            if paso['archivo'] and os.path.exists(paso['archivo']):
                try:
                    self.doc.add_picture(paso['archivo'], width=Inches(3.5))
                    ultimo = self.doc.paragraphs[-1]
                    ultimo.alignment = WD_ALIGN_PARAGRAPH.CENTER
                except Exception as e:
                    self.doc.add_paragraph(f'[Error cargando captura: {e}]')
            else:
                self.doc.add_paragraph('[Captura no disponible]')
            self.doc.add_paragraph()
        self.doc.add_page_break()
        self.doc.add_heading('Resumen de Tiempos por Etapa', level=1)
        self.doc.add_paragraph(f'Tiempo total del flujo: {format_duration(tiempo_total_segundos)}')
        self.doc.add_paragraph()
        self.doc.add_paragraph('Reporte generado automáticamente por el framework de pruebas.').italic = True
        nombre_docx = f"reporte_{self.nombre_prueba}_{self.fecha_ejecucion.strftime('%Y%m%d_%H%M%S')}.docx"
        ruta_docx = os.path.join(self.carpeta_salida, nombre_docx)
        self.doc.save(ruta_docx)
        print(f'\n  📄 Reporte Word generado: {ruta_docx}')
        return ruta_docx

def create_driver(device_id=None, appium_port=None):
    from framework.common.runtime_config import runtime_settings
    from appium import webdriver
    from appium.options.android import UiAutomator2Options
    cfg = runtime_settings()
    device_id = device_id or cfg.get('device_id') or '105075438Y105186'
    appium_url = cfg.get('appium_url') or f'http://127.0.0.1:{appium_port or 4723}'
    options = UiAutomator2Options()
    options.platform_name = 'Android'
    options.device_name = device_id
    options.udid = device_id
    options.automation_name = 'UiAutomator2'
    options.app_package = cfg['app_package']
    options.app_activity = cfg['app_activity']
    options.no_reset = cfg.get('no_reset', True)
    options.full_reset = cfg.get('full_reset', False)
    options.new_command_timeout = cfg.get('timeout', 300)
    return webdriver.Remote(appium_url, options=options)

def reset_app(driver, package='bo.com.bancofie.fiemovil'):
    print('  🔄 Reiniciando aplicación...')
    try:
        driver.terminate_app(package)
        time.sleep(2)
        driver.activate_app(package)
        time.sleep(3)
        print('  ✅ App reiniciada')
        return True
    except Exception as e:
        print(f'  ⚠️ Error reiniciando app: {e}')
        return False

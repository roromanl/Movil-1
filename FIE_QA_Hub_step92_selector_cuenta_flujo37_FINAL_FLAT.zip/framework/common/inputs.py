"""Input defaults formerly hard-coded in __main__ blocks.
Front Excel values are intended to override these defaults when runner integration is enabled.
"""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[2]
def load_input_defaults(script_name):
    p=ROOT/'config'/'input_defaults.json'
    if not p.exists(): return {}
    return json.loads(p.read_text(encoding='utf-8')).get(script_name,{})

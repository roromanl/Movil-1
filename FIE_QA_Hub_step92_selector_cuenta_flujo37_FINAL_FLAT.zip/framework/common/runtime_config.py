"""Load runtime/device settings from project .env with environment override."""
from pathlib import Path
import os
ROOT=Path(__file__).resolve().parents[2]
def _env_file():
    vals={}
    p=ROOT/'.env'
    if p.exists():
        for raw in p.read_text(encoding='utf-8').splitlines():
            s=raw.strip()
            if not s or s.startswith('#') or '=' not in s: continue
            k,v=s.split('=',1);vals[k.strip()]=v.strip().strip('"').strip("'")
    return vals
def _get(name,default=None):
    return os.getenv(name,_env_file().get(name,default))
def _bool(name,default):
    return str(_get(name,str(default))).lower() in {'1','true','yes','si','on'}
def runtime_settings():
    return {
      'appium_url':_get('APPIUM_URL','http://127.0.0.1:4723'),
      'app_package':_get('APP_PACKAGE','bo.com.bancofie.fiemovil'),
      'app_activity':_get('APP_ACTIVITY','bo.com.bancofie.fiemovil.MainActivity'),
      'device_id':_get('DEVICE_ID',''),
      'timeout':int(_get('NEW_COMMAND_TIMEOUT','300')),
      'no_reset':_bool('NO_RESET',True),
      'full_reset':_bool('FULL_RESET',False),
    }

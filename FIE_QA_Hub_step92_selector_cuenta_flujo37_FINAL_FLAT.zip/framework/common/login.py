"""Shared login extracted from original FIE tests."""
from appium.webdriver.common.appiumby import AppiumBy
import time

def login(driver, username, password, reporte=None):
    """Login con captura por cada paso si se pasa un ReporteTest"""
    print(f'\n🔑 Iniciando login con usuario: {username}')
    if reporte:
        reporte.capturar_paso(1, 'Pantalla inicial de Login', "Se muestra la pantalla de bienvenida con el campo 'Usuario' vacío.", espera=1.5)
    try:
        print('  📝 Ingresando usuario...')
        username_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='Usuario']")
        username_input.click()
        time.sleep(0.5)
        username_input.clear()
        username_input.send_keys(username)
        print(f'  ✅ Usuario ingresado: {username}')
    except Exception as e:
        print(f'  ❌ Error al ingresar usuario: {e}')
        return False
    try:
        driver.hide_keyboard()
    except:
        pass
    time.sleep(0.5)
    if reporte:
        reporte.capturar_paso(2, 'Usuario ingresado', f"Se ingresó el usuario '{username}' en el campo correspondiente.", espera=1.0)
    try:
        print('  📝 Click en Continuar...')
        continuar_btn = driver.find_element(AppiumBy.ACCESSIBILITY_ID, 'Continuar')
        continuar_btn.click()
        print('  ✅ Click en Continuar (Accessibility ID)')
    except:
        try:
            view_container = driver.find_element(AppiumBy.ID, 'login_btn_ingresar')
            continuar_btn = view_container.find_element(AppiumBy.XPATH, ".//android.widget.Button[@content-desc='Continuar']")
            continuar_btn.click()
            print('  ✅ Click en Continuar (dentro de login_btn_ingresar)')
        except Exception as e:
            print(f'  ❌ Error al clickear Continuar: {e}')
            return False
    time.sleep(3)
    if reporte:
        reporte.capturar_paso(3, 'Pantalla de Contraseña', "Se avanzó a la pantalla de ingreso de contraseña. Se muestra la imagen de seguridad y el campo 'Contraseña'.", espera=1.5)
    try:
        print('  📝 Ingresando contraseña...')
        password_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='Contraseña']")
        password_input.click()
        time.sleep(0.5)
        password_input.clear()
        password_input.send_keys(password)
        print('  ✅ Contraseña ingresada')
    except:
        try:
            password_input = driver.find_element(AppiumBy.XPATH, "//android.widget.EditText[@hint='Password']")
            password_input.click()
            time.sleep(0.5)
            password_input.clear()
            password_input.send_keys(password)
            print('  ✅ Contraseña ingresada')
        except Exception as e:
            print(f'  ❌ Error al ingresar contraseña: {e}')
            return False
    try:
        driver.hide_keyboard()
    except:
        pass
    time.sleep(0.5)
    if reporte:
        reporte.capturar_paso(4, 'Contraseña ingresada', 'La contraseña fue ingresada correctamente (campo enmascarado).', espera=1.0)
    try:
        print('  📝 Click en Ingresar...')
        continuar_btn = driver.find_element(AppiumBy.ACCESSIBILITY_ID, 'Ingresar')
        continuar_btn.click()
        print('  ✅ Click en Ingresar')
    except:
        try:
            continuar_btn = driver.find_element(AppiumBy.XPATH, "//android.view.View[@content-desc='Ingresar']")
            continuar_btn.click()
            print('  ✅ Click en ingresar (XPATH)')
        except Exception as e:
            print(f'  ❌ Error al clickear Continuar: {e}')
            return False
    time.sleep(5)
    login_ok = False
    try:
        print('  📝 Verificando login...')
        driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Hola')]")
        print('  ✅ LOGIN EXITOSO!')
        login_ok = True
    except:
        try:
            driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Hola')]")
            print('  ✅ LOGIN EXITOSO!')
            login_ok = True
        except:
            print('  ⚠️ No se pudo verificar, pero el flujo continuó')
            login_ok = True
    if reporte:
        if login_ok:
            reporte.capturar_paso(5, 'Home - Login exitoso', 'Se verificó el ingreso exitoso al home. Se muestra el saludo al usuario y los productos disponibles.', espera=2.0)
        else:
            reporte.capturar_paso(5, 'Login - Error', 'No se pudo verificar el ingreso al home.', espera=1.0)
    return login_ok

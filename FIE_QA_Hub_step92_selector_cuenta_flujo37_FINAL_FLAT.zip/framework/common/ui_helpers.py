"""Shared recurrent UI helpers. Semantic variants are preserved exactly."""
import time
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException, StaleElementReferenceException

def _esta_en_home(driver, timeout=3):
    wait_t = time.time() + timeout
    while time.time() < wait_t:
        try:
            driver.find_element(AppiumBy.XPATH, "//*[contains(@content-desc, 'Hola') or contains(@content-desc, 'HOLA') or @resource-id='shared_card_account_product' or @resource-id='shared_row_quick_actions' or (@resource-id='home_btn_inicio' and @selected='true')]")
            print('  ✅ Confirmado: estamos en el home')
            return True
        except:
            time.sleep(0.5)
    return False

def _ingresar_texto_en_campo(driver, resource_id=None, valor='', hints_alternativos=None, espera=0.5):
    edit_text = None
    if resource_id:
        try:
            edit_text = driver.find_element(AppiumBy.XPATH, f"//android.widget.EditText[@resource-id='{resource_id}']/android.widget.EditText")
        except:
            pass
        if edit_text is None:
            try:
                parent = driver.find_element(AppiumBy.ID, resource_id)
                try:
                    edit_text = parent.find_element(AppiumBy.CLASS_NAME, 'android.widget.EditText')
                except:
                    edit_text = parent
            except:
                pass
        if edit_text is None:
            try:
                edit_text = driver.find_element(AppiumBy.XPATH, f"//*[@resource-id='{resource_id}']/android.widget.EditText")
            except:
                pass
        if edit_text is None:
            try:
                edit_text = driver.find_element(AppiumBy.ID, resource_id)
            except:
                pass
    if edit_text is None and hints_alternativos:
        for hint in hints_alternativos:
            try:
                edit_text = driver.find_element(AppiumBy.XPATH, f"//android.widget.EditText[contains(@hint, '{hint}')]")
                break
            except:
                continue
    if edit_text is None:
        return False
    try:
        edit_text.click()
        time.sleep(espera)
        edit_text.clear()
        edit_text.send_keys(valor)
        try:
            driver.hide_keyboard()
        except:
            pass
        time.sleep(espera)
        return True
    except:
        return False

def _seleccionar_opcion_case_insensitive__f21faf0807(driver, valor, timeout=3, debug=False):
    wait = WebDriverWait(driver, timeout)
    valor_lower = valor.lower()
    try:
        opcion = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, f"//*[@content-desc='{valor}' and @clickable='true']")))
        opcion.click()
        return True
    except:
        pass
    try:
        opcion = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{valor}') and @clickable='true']")
        opcion.click()
        return True
    except:
        pass
    try:
        opcion = driver.find_element(AppiumBy.XPATH, f"//*[contains(translate(@content-desc, 'ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÑ', 'abcdefghijklmnopqrstuvwxyzáéíóúñ'), '{valor_lower}') and @clickable='true']")
        opcion.click()
        return True
    except:
        pass
    try:
        opcion = driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{valor}') and @clickable='true']")
        opcion.click()
        return True
    except:
        pass
    if debug:
        try:
            print(f'  🔍 Opciones visibles en pantalla:')
            opciones = driver.find_elements(AppiumBy.XPATH, "//*[@clickable='true' and @content-desc and string-length(@content-desc) > 3]")
            for o in opciones[:15]:
                desc = (o.get_attribute('content-desc') or '').replace('\n', ' | ')
                if len(desc) < 100:
                    print(f'     - {desc}')
        except:
            pass
    return False

def _seleccionar_opcion_case_insensitive__df5762857e(driver, valor, timeout=3, debug=False):
    wait = WebDriverWait(driver, timeout)
    valor_lower = valor.lower()
    try:
        opcion = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, f"//android.view.View[@content-desc='{valor}' and @clickable='true']")))
        opcion.click()
        return True
    except:
        pass
    try:
        opcion = driver.find_element(AppiumBy.XPATH, f"//*[@content-desc='{valor}' and @clickable='true']")
        opcion.click()
        return True
    except:
        pass
    try:
        opcion = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{valor}') and @clickable='true']")
        opcion.click()
        return True
    except:
        pass
    try:
        opcion = driver.find_element(AppiumBy.XPATH, f"//*[contains(translate(@content-desc, 'ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÑ', 'abcdefghijklmnopqrstuvwxyzáéíóúñ'), '{valor_lower}') and @clickable='true']")
        opcion.click()
        return True
    except:
        pass
    try:
        opcion = driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{valor}') and @clickable='true']")
        opcion.click()
        return True
    except:
        pass
    if debug:
        try:
            print(f'  🔍 Opciones visibles en pantalla:')
            opciones = driver.find_elements(AppiumBy.XPATH, "//*[@clickable='true' and @content-desc and string-length(@content-desc) > 2]")
            for o in opciones[:15]:
                desc = (o.get_attribute('content-desc') or '').replace('\n', ' | ')
                if len(desc) < 100:
                    print(f'     - {desc}')
        except:
            pass
    return False

def _seleccionar_opcion_case_insensitive__2f3c9d8754(driver, valor, timeout=3, debug=False):
    wait = WebDriverWait(driver, timeout)
    valor_lower = valor.lower()
    try:
        opcion = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, f"//*[@content-desc='{valor}' and @clickable='true']")))
        opcion.click()
        return True
    except:
        pass
    try:
        opcion = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{valor}') and @clickable='true']")
        opcion.click()
        return True
    except:
        pass
    try:
        opcion = driver.find_element(AppiumBy.XPATH, f"//*[contains(translate(@content-desc, 'ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÑ', 'abcdefghijklmnopqrstuvwxyzáéíóúñ'), '{valor_lower}') and @clickable='true']")
        opcion.click()
        return True
    except:
        pass
    try:
        opcion = driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{valor}') and @clickable='true']")
        opcion.click()
        return True
    except:
        pass
    if debug:
        try:
            print(f'  🔍 Opciones visibles en pantalla:')
            opciones = driver.find_elements(AppiumBy.XPATH, "//*[@clickable='true' and @content-desc and string-length(@content-desc) > 2]")
            for o in opciones[:15]:
                desc = (o.get_attribute('content-desc') or '').replace('\n', ' | ')
                if len(desc) < 100:
                    print(f'     - {desc}')
        except:
            pass
    return False

def _seleccionar_opcion_case_insensitive__e39a1456d9(driver, valor, timeout=3):
    wait = WebDriverWait(driver, timeout)
    valor_lower = valor.lower()
    try:
        opcion = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, f"//android.view.View[@content-desc='{valor}' and @clickable='true']")))
        opcion.click()
        return True
    except:
        pass
    try:
        opcion = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{valor}') and @clickable='true']")
        opcion.click()
        return True
    except:
        pass
    try:
        opcion = driver.find_element(AppiumBy.XPATH, f"//*[contains(translate(@content-desc, 'ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÑ', 'abcdefghijklmnopqrstuvwxyzáéíóúñ'), '{valor_lower}') and @clickable='true']")
        opcion.click()
        return True
    except:
        pass
    try:
        opcion = driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{valor}') and @clickable='true']")
        opcion.click()
        return True
    except:
        pass
    return False

def _seleccionar_opcion_case_insensitive__4318d7731b(driver, valor, timeout=3):
    wait = WebDriverWait(driver, timeout)
    valor_lower = valor.lower()
    try:
        opcion = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, f"//*[@content-desc='{valor}' and @clickable='true']")))
        opcion.click()
        return True
    except:
        pass
    try:
        opcion = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{valor}') and @clickable='true']")
        opcion.click()
        return True
    except:
        pass
    try:
        opcion = driver.find_element(AppiumBy.XPATH, f"//*[contains(translate(@content-desc, 'ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÑ', 'abcdefghijklmnopqrstuvwxyzáéíóúñ'), '{valor_lower}') and @clickable='true']")
        opcion.click()
        return True
    except:
        pass
    try:
        opcion = driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{valor}') and @clickable='true']")
        opcion.click()
        return True
    except:
        pass
    return False

def _seleccionar_opcion_case_insensitive__7d45fd91e0(driver, valor, timeout=3, debug=False):
    """Busca una opción clickable con 4 estrategias."""
    wait = WebDriverWait(driver, timeout)
    valor_lower = valor.lower()
    try:
        opcion = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, f"//*[@content-desc='{valor}' and @clickable='true']")))
        opcion.click()
        return True
    except:
        pass
    try:
        opcion = driver.find_element(AppiumBy.XPATH, f"//*[contains(@content-desc, '{valor}') and @clickable='true']")
        opcion.click()
        return True
    except:
        pass
    try:
        opcion = driver.find_element(AppiumBy.XPATH, f"//*[contains(translate(@content-desc, 'ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚÑ', 'abcdefghijklmnopqrstuvwxyzáéíóúñ'), '{valor_lower}') and @clickable='true']")
        opcion.click()
        return True
    except:
        pass
    try:
        opcion = driver.find_element(AppiumBy.XPATH, f"//*[contains(@text, '{valor}') and @clickable='true']")
        opcion.click()
        return True
    except:
        pass
    if debug:
        try:
            print(f'  🔍 Opciones visibles en pantalla:')
            opciones = driver.find_elements(AppiumBy.XPATH, "//*[@clickable='true' and @content-desc and string-length(@content-desc) > 3]")
            for o in opciones[:15]:
                desc = (o.get_attribute('content-desc') or '').replace('\n', ' | ')
                if len(desc) < 100:
                    print(f'     - {desc}')
        except:
            pass
    return False

def select_configuraciones_usuario(driver):
    print('  📝 Seleccionando Configuraciones de usuario...')
    time.sleep(2)
    try:
        btn = driver.find_element(AppiumBy.ID, 'more_btn_usuario')
        btn.click()
        print('  ✅ Click en Configuraciones de usuario (ID)')
        time.sleep(3)
        return True
    except:
        pass
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Configuraciones de usuario')]")
        btn.click()
        print('  ✅ Click en Configuraciones de usuario (content-desc)')
        time.sleep(3)
        return True
    except Exception as e:
        print(f'  ❌ Error al seleccionar Configuraciones de usuario: {e}')
        return False

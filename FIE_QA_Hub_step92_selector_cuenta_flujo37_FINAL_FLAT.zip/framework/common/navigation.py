"""Shared navigation helpers extracted from legacy scripts without changing their bodies."""
import time
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException

def volver_atras__28d030ad13(driver):
    print('  📝 Volviendo atrás...')
    time.sleep(2)
    try:
        regresar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Regresar']")
        regresar_btn.click()
        print('  ✅ Click en Regresar')
        time.sleep(2)
        return True
    except:
        pass
    try:
        driver.back()
        print('  ✅ Back ejecutado')
        time.sleep(2)
        return True
    except Exception as e:
        print(f'  ❌ Error al volver atrás: {e}')
        return False

def volver_home__afd08848fd(driver, timeout=10):
    print('  📝 Volviendo al home...')
    time.sleep(2)
    wait_t = time.time() + timeout
    while time.time() < wait_t:
        try:
            inicio_btn = driver.find_element(AppiumBy.ID, 'home_btn_inicio')
            inicio_btn.click()
            print("  ✅ Click en 'Inicio' (ID)")
            time.sleep(2)
            if _esta_en_home(driver):
                return True
            else:
                time.sleep(0.5)
        except:
            time.sleep(0.5)
    try:
        inicio_btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Inicio\nInicio' or @content-desc='Inicio']")
        inicio_btn.click()
        print("  ✅ Click en 'Inicio' (content-desc)")
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        for i in range(3):
            driver.back()
            print(f'  ✅ Back {i + 1} ejecutado')
            time.sleep(1)
            if _esta_en_home(driver):
                return True
    except:
        pass
    print('  ⚠️ No se pudo confirmar el home')
    return False

def go_back__0ec9d4708b(driver, timeout=10):
    print('  📝 Volviendo atrás...')
    try:
        inicio_btn = driver.find_element(AppiumBy.ID, 'home_btn_inicio')
        inicio_btn.click()
        print("  ✅ Click en 'Inicio' (ID)")
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        driver.back()
        time.sleep(2)
        print('  ✅ Back ejecutado')
        return True
    except Exception as e:
        print(f'  ❌ Error al hacer back: {e}')
        return False

def go_back_home__0684e34fc0(driver, timeout=10):
    print('  📝 Volviendo al home...')
    wait_t = time.time() + timeout
    while time.time() < wait_t:
        try:
            inicio_btn = driver.find_element(AppiumBy.ID, 'home_btn_inicio')
            inicio_btn.click()
            print("  ✅ Click en 'Inicio' (ID)")
            time.sleep(2)
            if _esta_en_home(driver):
                return True
            else:
                time.sleep(0.5)
        except:
            time.sleep(0.5)
    try:
        inicio_btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Inicio\nInicio' or @content-desc='Inicio']")
        inicio_btn.click()
        print("  ✅ Click en 'Inicio' (content-desc)")
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        for i in range(3):
            driver.back()
            print(f'  ✅ Back {i + 1} ejecutado')
            time.sleep(1)
            if _esta_en_home(driver):
                return True
    except:
        pass
    print('  ⚠️ No se pudo volver al home')
    return False

def volver_home_notificaciones__aaeaf45c7e(driver, timeout=10):
    print('  📝 Volviendo al home...')
    time.sleep(2)
    wait_t = time.time() + timeout
    while time.time() < wait_t:
        try:
            inicio_btn = driver.find_element(AppiumBy.ID, 'home_btn_inicio')
            inicio_btn.click()
            print("  ✅ Click en 'Inicio' (ID)")
            time.sleep(2)
            if _esta_en_home(driver):
                return True
            else:
                time.sleep(0.5)
        except:
            time.sleep(0.5)
    try:
        inicio_btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Inicio\nInicio' or @content-desc='Inicio']")
        inicio_btn.click()
        print("  ✅ Click en 'Inicio' (content-desc)")
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        for i in range(3):
            driver.back()
            print(f'  ✅ Back {i + 1} ejecutado')
            time.sleep(1)
            if _esta_en_home(driver):
                return True
    except:
        pass
    print('  ⚠️ No se pudo confirmar el home')
    return False

def volver_atras__d509cd9f4a(driver, timeout=10):
    print('  📝 Volviendo atrás...')
    wait = WebDriverWait(driver, timeout)
    try:
        regresar = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//android.widget.Button[@content-desc='Regresar']")))
        regresar.click()
        print("  ✅ Click en 'Regresar'")
        time.sleep(2)
        return True
    except:
        pass
    try:
        driver.back()
        print('  ✅ Back ejecutado')
        time.sleep(2)
        return True
    except Exception as e:
        print(f'  ❌ Error al volver atrás: {e}')
        return False

def go_back__e784c5260a(driver):
    print('  📝 Volviendo atrás...')
    time.sleep(2)
    try:
        driver.back()
        time.sleep(2)
        print('  ✅ Back ejecutado')
        return True
    except Exception as e:
        print(f'  ❌ Error: {e}')
        return False

def go_back_home__c06b7d90b9(driver, timeout=10):
    print('  📝 Volviendo al home...')
    time.sleep(2)
    wait_t = time.time() + timeout
    while time.time() < wait_t:
        try:
            inicio_btn = driver.find_element(AppiumBy.ID, 'home_btn_inicio')
            inicio_btn.click()
            print("  ✅ Click en 'Inicio' (ID)")
            time.sleep(2)
            if _esta_en_home(driver):
                return True
            else:
                time.sleep(0.5)
        except:
            time.sleep(0.5)
    try:
        inicio_btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Inicio\nInicio' or @content-desc='Inicio']")
        inicio_btn.click()
        print("  ✅ Click en 'Inicio' (content-desc)")
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        for i in range(3):
            driver.back()
            print(f'  ✅ Back {i + 1} ejecutado')
            time.sleep(1)
            if _esta_en_home(driver):
                return True
    except:
        pass
    print('  ⚠️ No se pudo volver al home')
    return False

def go_back__27efe39dbb(driver, timeout=10):
    print('  📝 Volviendo atrás...')
    time.sleep(2)
    try:
        inicio_btn = driver.find_element(AppiumBy.ID, 'home_btn_inicio')
        inicio_btn.click()
        print("  ✅ Click en 'Inicio' (ID)")
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        driver.back()
        time.sleep(2)
        print('  ✅ Back ejecutado')
        return True
    except Exception as e:
        print(f'  ❌ Error: {e}')
        return False

def go_back__6cc20c23ae(driver, timeout=10):
    print('  📝 Volviendo atrás...')
    time.sleep(2)
    try:
        inicio_btn = driver.find_element(AppiumBy.ID, 'home_btn_inicio')
        inicio_btn.click()
        print("  ✅ Click en 'Inicio' (ID)")
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        driver.back()
        time.sleep(2)
        print('  ✅ Back ejecutado')
        return True
    except Exception as e:
        print(f'  ❌ Error al hacer back: {e}')
        return False

def volver_home_cripto(driver, timeout=10):
    print('  📝 Volviendo al home...')
    time.sleep(2)
    wait_t = time.time() + timeout
    while time.time() < wait_t:
        try:
            inicio_btn = driver.find_element(AppiumBy.ID, 'home_btn_inicio')
            inicio_btn.click()
            print("  ✅ Click en 'Inicio' (ID)")
            time.sleep(2)
            if _esta_en_home(driver):
                return True
            else:
                time.sleep(0.5)
        except:
            time.sleep(0.5)
    try:
        inicio_btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Inicio\nInicio' or @content-desc='Inicio']")
        inicio_btn.click()
        print("  ✅ Click en 'Inicio' (content-desc)")
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        for i in range(3):
            driver.back()
            print(f'  ✅ Back {i + 1} ejecutado')
            time.sleep(1)
            if _esta_en_home(driver):
                return True
    except:
        pass
    print('  ⚠️ No se pudo confirmar el home')
    return False

def volver_atras_cripto__4401a4d20c(driver):
    print('  📝 Volviendo atrás...')
    time.sleep(2)
    try:
        regresar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Regresar']")
        regresar_btn.click()
        print('  ✅ Click en Regresar')
        time.sleep(2)
        return True
    except:
        pass
    try:
        driver.back()
        print('  ✅ Back ejecutado')
        time.sleep(2)
        return True
    except Exception as e:
        print(f'  ❌ Error al volver atrás: {e}')
        return False

def volver_atras_cripto__9c26a1d3b6(driver):
    print('  📝 Volviendo atrás desde Cripto...')
    time.sleep(2)
    try:
        regresar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Regresar']")
        regresar_btn.click()
        print('  ✅ Click en Regresar')
        time.sleep(2)
        return True
    except:
        pass
    try:
        inicio_btn = driver.find_element(AppiumBy.ID, 'home_btn_inicio')
        inicio_btn.click()
        print("  ✅ Click en 'Inicio' (ID)")
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        driver.back()
        print('  ✅ Back ejecutado')
        time.sleep(2)
        return True
    except Exception as e:
        print(f'  ❌ Error al volver atrás: {e}')
        return False

def volver_atras__99669eabbe(driver, timeout=10):
    print('  📝 Volviendo atrás...')
    time.sleep(2)
    try:
        regresar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Regresar']")
        regresar.click()
        print('  ✅ Click en Regresar')
        time.sleep(2)
        return True
    except:
        try:
            driver.back()
            print('  ✅ Back ejecutado')
            time.sleep(2)
            return True
        except Exception as e:
            print(f'  ❌ Error al volver atrás: {e}')
            return False

def volver_home__96ad0b4a5a(driver, timeout=10):
    """Vuelve al home"""
    print('  📝 Volviendo al home...')
    time.sleep(2)
    wait_t = time.time() + timeout
    while time.time() < wait_t:
        try:
            inicio = driver.find_element(AppiumBy.ID, 'home_btn_inicio')
            inicio.click()
            print("  ✅ Click en 'Inicio' (ID)")
            time.sleep(2)
            if _esta_en_home(driver):
                return True
            else:
                time.sleep(0.5)
        except:
            time.sleep(0.5)
    try:
        inicio = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Inicio\nInicio' or @content-desc='Inicio']")
        inicio.click()
        print("  ✅ Click en 'Inicio' (content-desc)")
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        for i in range(3):
            driver.back()
            print(f'  ✅ Back {i + 1} ejecutado')
            time.sleep(1)
            if _esta_en_home(driver):
                return True
    except:
        pass
    print('  ⚠️ No se pudo volver al home')
    return False

def volver_atras_ayuda(driver, timeout=10):
    print('  📝 Volviendo atrás...')
    try:
        regresar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Regresar']")
        regresar.click()
        print('  ✅ Click en Regresar')
        time.sleep(2)
        return True
    except:
        pass
    try:
        inicio_btn = driver.find_element(AppiumBy.ID, 'home_btn_inicio')
        inicio_btn.click()
        print("  ✅ Click en 'Inicio' (ID)")
        time.sleep(2)
        return True
    except:
        pass
    try:
        driver.back()
        print('  ✅ Back ejecutado')
        time.sleep(2)
        return True
    except Exception as e:
        print(f'  ❌ Error al volver atrás: {e}')
        return False

def volver_home__6ed7229b28(driver, timeout=10):
    print('  📝 Volviendo al home...')
    wait_t = time.time() + timeout
    while time.time() < wait_t:
        try:
            inicio_btn = driver.find_element(AppiumBy.ID, 'home_btn_inicio')
            inicio_btn.click()
            print("  ✅ Click en 'Inicio' (ID)")
            time.sleep(2)
            if _esta_en_home(driver):
                return True
            else:
                time.sleep(0.5)
        except:
            time.sleep(0.5)
    try:
        inicio = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Inicio\nInicio' or @content-desc='Inicio']")
        inicio.click()
        print("  ✅ Click en 'Inicio' (content-desc)")
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        for i in range(3):
            driver.back()
            print(f'  ✅ Back {i + 1} ejecutado')
            time.sleep(1)
            if _esta_en_home(driver):
                return True
    except:
        pass
    print('  ⚠️ No se pudo volver al home')
    return False

def volver_home_imagen(driver, timeout=10):
    print('  📝 Volviendo al home...')
    time.sleep(2)
    wait_t = time.time() + timeout
    while time.time() < wait_t:
        try:
            inicio_btn = driver.find_element(AppiumBy.ID, 'home_btn_inicio')
            inicio_btn.click()
            print("  ✅ Click en 'Inicio' (ID)")
            time.sleep(2)
            if _esta_en_home(driver):
                return True
            else:
                time.sleep(0.5)
        except:
            time.sleep(0.5)
    try:
        inicio_btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Inicio\nInicio' or @content-desc='Inicio']")
        inicio_btn.click()
        print("  ✅ Click en 'Inicio' (content-desc)")
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        for i in range(3):
            driver.back()
            print(f'  ✅ Back {i + 1} ejecutado')
            time.sleep(1)
            if _esta_en_home(driver):
                return True
    except:
        pass
    print('  ⚠️ No se pudo volver al home')
    return False

def volver_home_password(driver, timeout=10):
    print('  📝 Volviendo al home...')
    try:
        driver.back()
        print('  ✅ Back ejecutado')
        time.sleep(2)
    except:
        pass
    time.sleep(2)
    wait_t = time.time() + timeout
    while time.time() < wait_t:
        try:
            inicio_btn = driver.find_element(AppiumBy.ID, 'home_btn_inicio')
            inicio_btn.click()
            print("  ✅ Click en 'Inicio' (ID)")
            time.sleep(2)
            if _esta_en_home(driver):
                return True
            else:
                time.sleep(0.5)
        except:
            time.sleep(0.5)
    try:
        inicio_btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Inicio' and @clickable='true']")
        inicio_btn.click()
        print('  ✅ Click en Inicio (content-desc)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        inicio_btn = driver.find_element(AppiumBy.ACCESSIBILITY_ID, 'Inicio')
        inicio_btn.click()
        print('  ✅ Click en Inicio (Accessibility)')
        time.sleep(2)
        return True
    except:
        pass
    try:
        for i in range(3):
            driver.back()
            print(f'  ✅ Back {i + 1} ejecutado')
            time.sleep(1)
            if _esta_en_home(driver):
                return True
    except:
        pass
    print('  ⚠️ No se pudo volver al home')
    return False

def volver_home_seguridad(driver, timeout=10):
    print('  📝 Volviendo al home...')
    time.sleep(2)
    wait_t = time.time() + timeout
    while time.time() < wait_t:
        try:
            inicio_btn = driver.find_element(AppiumBy.ID, 'home_btn_inicio')
            inicio_btn.click()
            print("  ✅ Click en 'Inicio' (ID)")
            time.sleep(2)
            if _esta_en_home(driver):
                return True
            else:
                time.sleep(0.5)
        except:
            time.sleep(0.5)
    try:
        inicio_btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Inicio\nInicio' or @content-desc='Inicio']")
        inicio_btn.click()
        print("  ✅ Click en 'Inicio' (content-desc)")
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        for i in range(3):
            driver.back()
            print(f'  ✅ Back {i + 1} ejecutado')
            time.sleep(1)
            if _esta_en_home(driver):
                return True
    except:
        pass
    print('  ⚠️ No se pudo volver al home')
    return False

def volver_atras_limites(driver):
    print('  📝 Volviendo atrás...')
    time.sleep(2)
    try:
        regresar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Regresar']")
        regresar.click()
        print('  ✅ Click en Regresar')
        time.sleep(2)
        return True
    except:
        try:
            driver.back()
            print('  ✅ Back ejecutado')
            time.sleep(2)
            return True
        except Exception as e:
            print(f'  ❌ Error al volver atrás: {e}')
            return False

def volver_home_notificaciones__2241bc8732(driver, timeout=10):
    print('  📝 Volviendo al home...')
    time.sleep(2)
    wait_t = time.time() + timeout
    while time.time() < wait_t:
        try:
            inicio_btn = driver.find_element(AppiumBy.ID, 'home_btn_inicio')
            inicio_btn.click()
            print("  ✅ Click en 'Inicio' (ID)")
            time.sleep(2)
            if _esta_en_home(driver):
                return True
            else:
                time.sleep(0.5)
        except:
            time.sleep(0.5)
    try:
        inicio_btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Inicio\nInicio' or @content-desc='Inicio']")
        inicio_btn.click()
        print("  ✅ Click en 'Inicio' (content-desc)")
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        for i in range(3):
            driver.back()
            print(f'  ✅ Back {i + 1} ejecutado')
            time.sleep(1)
            if _esta_en_home(driver):
                return True
    except:
        pass
    print('  ⚠️ No se pudo volver al home')
    return False

def volver_atras__ab97cca960(driver, timeout=10):
    print('  📝 Volviendo atrás...')
    wait = WebDriverWait(driver, timeout)
    try:
        regresar = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//android.widget.Button[@content-desc='Regresar']")))
        regresar.click()
        print("  ✅ Click en 'Regresar'")
        time.sleep(2)
        return True
    except:
        try:
            driver.back()
            print('  ✅ Back ejecutado')
            time.sleep(2)
            return True
        except Exception as e:
            print(f'  ❌ Error al volver atrás: {e}')
            return False

def volver_home__cedf942b12(driver, timeout=10):
    print('  📝 Volviendo al home...')
    wait = WebDriverWait(driver, timeout)
    try:
        inicio_btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'home_btn_inicio')))
        inicio_btn.click()
        print("  ✅ Click en 'Inicio' (ID)")
        time.sleep(2)
        return True
    except:
        pass
    try:
        inicio_btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Inicio\nInicio' or @content-desc='Inicio']")
        inicio_btn.click()
        print("  ✅ Click en 'Inicio' (content-desc)")
        time.sleep(2)
        return True
    except:
        pass
    try:
        driver.back()
        print('  ✅ Back ejecutado')
        time.sleep(2)
        return True
    except Exception as e:
        print(f'  ❌ Error al volver al home: {e}')
        return False

def volver_atras__418bccfa84(driver, timeout=10):
    print('  📝 Volviendo atrás...')
    time.sleep(2)
    try:
        regresar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Regresar']")
        regresar.click()
        print('  ✅ Click en Regresar')
        time.sleep(2)
        return True
    except:
        pass
    try:
        driver.back()
        print('  ✅ Back ejecutado')
        time.sleep(2)
        return True
    except Exception as e:
        print(f'  ❌ Error al volver atrás: {e}')
        return False

def volver_home__71a629aeab(driver, timeout=10):
    print('  📝 Volviendo al home...')
    time.sleep(2)
    wait_t = time.time() + timeout
    while time.time() < wait_t:
        try:
            inicio_btn = driver.find_element(AppiumBy.ID, 'home_btn_inicio')
            inicio_btn.click()
            print("  ✅ Click en 'Inicio' (ID)")
            time.sleep(2)
            if _esta_en_home(driver):
                return True
            else:
                time.sleep(0.5)
        except:
            time.sleep(0.5)
    try:
        inicio = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Inicio\nInicio' or @content-desc='Inicio']")
        inicio.click()
        print("  ✅ Click en 'Inicio' (content-desc)")
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        for i in range(3):
            driver.back()
            print(f'  ✅ Back {i + 1} ejecutado')
            time.sleep(1)
            if _esta_en_home(driver):
                return True
    except:
        pass
    print('  ⚠️ No se pudo confirmar el home')
    return False

def volver_home_giro(driver, timeout=10):
    """Vuelve al home desde el flujo de giro"""
    print('  📝 Volviendo al home...')
    wait = WebDriverWait(driver, 3)
    wait_t = time.time() + timeout
    while time.time() < wait_t:
        try:
            inicio_btn = driver.find_element(AppiumBy.ID, 'home_btn_inicio')
            inicio_btn.click()
            print("  ✅ Click en 'Inicio' (ID)")
            time.sleep(2)
            if _esta_en_home(driver):
                return True
            else:
                time.sleep(0.5)
        except:
            time.sleep(0.5)
    try:
        inicio_btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Inicio\nInicio' or @content-desc='Inicio']")
        inicio_btn.click()
        print("  ✅ Click en 'Inicio' (content-desc)")
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        for i in range(3):
            driver.back()
            print(f'  ✅ Back {i + 1} ejecutado')
            time.sleep(1)
            if _esta_en_home(driver):
                return True
    except:
        pass
    print('  ⚠️ No se pudo volver al home')
    return False

def volver_atras__577b1f7cf5(driver, timeout=10):
    """Click en 'Regresar' (esquina superior izquierda)."""
    print('  📝 Volviendo atrás...')
    wait = WebDriverWait(driver, timeout)
    try:
        regresar = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//android.widget.Button[@content-desc='Regresar']")))
        regresar.click()
        print("  ✅ Click en 'Regresar'")
        time.sleep(2)
        return True
    except Exception as e:
        print(f"  ⚠️ No se encontró 'Regresar', usando back(): {e}")
        try:
            driver.back()
            print('  ✅ Back ejecutado')
            time.sleep(2)
            return True
        except Exception as e2:
            print(f'  ❌ Error al volver atrás: {e2}')
            return False

def volver_home__665e4231ff(driver, timeout=10):
    """Click en 'Inicio' (home_btn_inicio) o fallback a back()."""
    print('  📝 Volviendo al home...')
    wait = WebDriverWait(driver, timeout)
    try:
        inicio_btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'home_btn_inicio')))
        inicio_btn.click()
        print("  ✅ Click en 'Inicio' (ID)")
        time.sleep(2)
        return True
    except:
        pass
    try:
        inicio_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@resource-id='home_btn_inicio']")
        inicio_btn.click()
        print("  ✅ Click en 'Inicio' (XPATH resource-id)")
        time.sleep(2)
        return True
    except:
        pass
    try:
        inicio_btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Inicio\nInicio' or @content-desc='Inicio']")
        inicio_btn.click()
        print("  ✅ Click en 'Inicio' (content-desc)")
        time.sleep(2)
        return True
    except:
        pass
    try:
        driver.back()
        print('  ✅ Back ejecutado')
        time.sleep(2)
        return True
    except Exception as e:
        print(f'  ❌ Error al volver al home: {e}')
        return False

def volver_atras__3978e940f4(driver, timeout=10):
    print('  📝 Volviendo atrás...')
    wait = WebDriverWait(driver, timeout)
    try:
        regresar = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//android.widget.Button[@content-desc='Regresar']")))
        regresar.click()
        print("  ✅ Click en 'Regresar'")
        time.sleep(2)
        return True
    except Exception as e:
        print(f"  ⚠️ No se encontró 'Regresar', usando back(): {e}")
        try:
            driver.back()
            print('  ✅ Back ejecutado')
            time.sleep(2)
            return True
        except Exception as e2:
            print(f'  ❌ Error al volver atrás: {e2}')
            return False

def volver_home__55b0b2e5af(driver, timeout=10):
    print('  📝 Volviendo al home...')
    wait = WebDriverWait(driver, timeout)
    try:
        inicio_btn = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//android.widget.Button[@content-desc='Inicio']")))
        inicio_btn.click()
        print("  ✅ Click en 'Inicio'")
        time.sleep(2)
        return True
    except:
        try:
            inicio_btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Inicio' and @clickable='true']")
            inicio_btn.click()
            print("  ✅ Click en 'Inicio' (XPATH)")
            time.sleep(2)
            return True
        except:
            try:
                driver.back()
                print('  ✅ Back ejecutado')
                time.sleep(2)
                return True
            except Exception as e:
                print(f'  ❌ Error al volver al home: {e}')
                return False

def volver_home__1a5d4bb43d(driver, timeout=10):
    """Click en 'Inicio' o fallback a back()."""
    print('  📝 Volviendo al home...')
    wait = WebDriverWait(driver, timeout)
    try:
        inicio_btn = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//android.widget.Button[@content-desc='Inicio']")))
        inicio_btn.click()
        print("  ✅ Click en 'Inicio'")
        time.sleep(2)
        return True
    except:
        try:
            inicio_btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Inicio' and @clickable='true']")
            inicio_btn.click()
            print("  ✅ Click en 'Inicio' (XPATH)")
            time.sleep(2)
            return True
        except:
            try:
                driver.back()
                print('  ✅ Back ejecutado')
                time.sleep(2)
                return True
            except Exception as e:
                print(f'  ❌ Error al volver al home: {e}')
                return False

def volver_home_exterior__1284b9fda1(driver):
    print('  📝 Volviendo al home...')
    wait = WebDriverWait(driver, 5)
    try:
        inicio_btn = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//android.widget.Button[@content-desc='Inicio']")))
        inicio_btn.click()
        print('  ✅ Click en Inicio')
        time.sleep(2)
        return True
    except:
        try:
            inicio_btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Inicio' and @clickable='true']")
            inicio_btn.click()
            print('  ✅ Click en Inicio (XPATH)')
            time.sleep(2)
            return True
        except:
            try:
                driver.back()
                print('  ✅ Back ejecutado')
                time.sleep(2)
                return True
            except Exception as e:
                print(f'  ❌ Error al volver al home: {e}')
                return False

def volver_atras_exterior(driver, timeout=10):
    print('  📝 Volviendo atrás...')
    wait = WebDriverWait(driver, timeout)
    try:
        regresar = wait.until(EC.element_to_be_clickable((AppiumBy.XPATH, "//android.widget.Button[@content-desc='Regresar']")))
        regresar.click()
        print("  ✅ Click en 'Regresar'")
        time.sleep(2)
        return True
    except Exception as e:
        print(f"  ⚠️ No se encontró 'Regresar', usando back(): {e}")
        try:
            driver.back()
            print('  ✅ Back ejecutado')
            time.sleep(2)
            return True
        except Exception as e2:
            print(f'  ❌ Error al volver atrás: {e2}')
            return False

def volver_home_exterior__5dd5468119(driver, timeout=10):
    print('  📝 Volviendo al home...')
    wait_t = time.time() + timeout
    while time.time() < wait_t:
        try:
            inicio_btn = driver.find_element(AppiumBy.ID, 'home_btn_inicio')
            inicio_btn.click()
            print("  ✅ Click en 'Inicio' (ID)")
            time.sleep(2)
            if _esta_en_home(driver):
                return True
            else:
                time.sleep(0.5)
        except:
            time.sleep(0.5)
    try:
        inicio_btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Inicio\nInicio' or @content-desc='Inicio']")
        inicio_btn.click()
        print("  ✅ Click en 'Inicio' (content-desc)")
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        for i in range(3):
            driver.back()
            print(f'  ✅ Back {i + 1} ejecutado')
            time.sleep(1)
            if _esta_en_home(driver):
                return True
    except:
        pass
    print('  ⚠️ No se pudo volver al home')
    return False

def volver_home__eecb2a92cb(driver, timeout=10):
    print('  📝 Volviendo al home...')
    time.sleep(2)
    wait = WebDriverWait(driver, timeout)
    try:
        inicio_btn = wait.until(EC.element_to_be_clickable((AppiumBy.ID, 'home_btn_inicio')))
        inicio_btn.click()
        print("  ✅ Click en 'Inicio' (ID)")
        time.sleep(2)
        return True
    except:
        pass
    try:
        inicio_btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Inicio\nInicio' or @content-desc='Inicio']")
        inicio_btn.click()
        print("  ✅ Click en 'Inicio' (content-desc)")
        time.sleep(2)
        return True
    except:
        pass
    try:
        driver.back()
        print('  ✅ Back ejecutado')
        time.sleep(2)
        return True
    except Exception as e:
        print(f'  ❌ Error al volver al home: {e}')
        return False

def volver_home_desde_confirmacion(driver, timeout=10):
    print('  📝 Volviendo al home...')
    time.sleep(2)
    wait_t = time.time() + timeout
    while time.time() < wait_t:
        try:
            inicio_btn = driver.find_element(AppiumBy.ID, 'home_btn_inicio')
            inicio_btn.click()
            print("  ✅ Click en 'Inicio' (ID)")
            time.sleep(2)
            if _esta_en_home(driver):
                return True
            else:
                time.sleep(0.5)
        except:
            time.sleep(0.5)
    try:
        regresar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Regresar']")
        regresar.click()
        print('  ✅ Click en Regresar')
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        inicio = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Inicio\nInicio' or @content-desc='Inicio']")
        inicio.click()
        print("  ✅ Click en 'Inicio' (content-desc)")
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        for i in range(3):
            driver.back()
            print(f'  ✅ Back {i + 1} ejecutado')
            time.sleep(1)
            if _esta_en_home(driver):
                return True
    except:
        pass
    print('  ⚠️ No se pudo confirmar el home')
    return False

def volver_atras_detalle__7684ec12c9(driver):
    print('  📝 Volviendo atrás desde detalle...')
    time.sleep(2)
    try:
        regresar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Regresar']")
        regresar.click()
        print('  ✅ Click en Regresar')
        time.sleep(2)
        return True
    except:
        pass
    try:
        inicio_btn = driver.find_element(AppiumBy.ID, 'home_btn_inicio')
        inicio_btn.click()
        print("  ✅ Click en 'Inicio' (ID)")
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        driver.back()
        print('  ✅ Back ejecutado')
        time.sleep(2)
        return True
    except Exception as e:
        print(f'  ❌ Error al volver atrás: {e}')
        return False

def volver_home__0104fb0f44(driver, timeout=10):
    """Vuelve al home desde la pantalla de detalle."""
    print('  📝 Volviendo al home...')
    wait_t = time.time() + timeout
    while time.time() < wait_t:
        try:
            inicio_btn = driver.find_element(AppiumBy.ID, 'home_btn_inicio')
            inicio_btn.click()
            print("  ✅ Click en 'Inicio' (ID)")
            time.sleep(2)
            if _esta_en_home(driver):
                return True
            else:
                time.sleep(0.5)
        except:
            time.sleep(0.5)
    try:
        inicio = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Inicio\nInicio' or @content-desc='Inicio']")
        inicio.click()
        print("  ✅ Click en 'Inicio' (content-desc)")
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        for i in range(3):
            driver.back()
            print(f'  ✅ Back {i + 1} ejecutado')
            time.sleep(1)
            if _esta_en_home(driver):
                return True
    except:
        pass
    print('  ⚠️ No se pudo confirmar el home')
    return False

def volver_atras_detalle__d2aa01012d(driver, timeout=10):
    print('  📝 Volviendo atrás...')
    try:
        regresar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Regresar']")
        regresar.click()
        print('  ✅ Click en Regresar')
        time.sleep(2)
        return True
    except:
        pass
    try:
        inicio_btn = driver.find_element(AppiumBy.ID, 'home_btn_inicio')
        inicio_btn.click()
        print("  ✅ Click en 'Inicio' (ID)")
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        driver.back()
        print('  ✅ Back ejecutado')
        time.sleep(2)
        return True
    except Exception as e:
        print(f'  ❌ Error al volver atrás: {e}')
        return False

def volver_home__ec69435608(driver, timeout=10):
    print('  📝 Volviendo al home...')
    wait_t = time.time() + timeout
    while time.time() < wait_t:
        try:
            inicio_btn = driver.find_element(AppiumBy.ID, 'home_btn_inicio')
            inicio_btn.click()
            print("  ✅ Click en 'Inicio' (ID)")
            time.sleep(2)
            if _esta_en_home(driver):
                return True
            else:
                time.sleep(0.5)
        except:
            time.sleep(0.5)
    try:
        inicio = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Inicio\nInicio' or @content-desc='Inicio']")
        inicio.click()
        print("  ✅ Click en 'Inicio' (content-desc)")
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        for i in range(3):
            driver.back()
            print(f'  ✅ Back {i + 1} ejecutado')
            time.sleep(1)
            if _esta_en_home(driver):
                return True
    except:
        pass
    print('  ⚠️ No se pudo confirmar el home')
    return False

def go_back_home__37b63a23bd(driver, timeout=10):
    """Vuelve al home con verificación."""
    print('  📝 Volviendo al home...')
    time.sleep(2)
    wait_t = time.time() + timeout
    while time.time() < wait_t:
        try:
            inicio_btn = driver.find_element(AppiumBy.ID, 'home_btn_inicio')
            inicio_btn.click()
            print("  ✅ Click en 'Inicio' (ID)")
            time.sleep(2)
            if _esta_en_home(driver):
                return True
            else:
                time.sleep(0.5)
        except:
            time.sleep(0.5)
    try:
        inicio_btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Inicio\nInicio' or @content-desc='Inicio']")
        inicio_btn.click()
        print("  ✅ Click en 'Inicio' (content-desc)")
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        inicio_btn = driver.find_element(AppiumBy.ACCESSIBILITY_ID, 'Inicio')
        inicio_btn.click()
        print('  ✅ Click en Inicio (Accessibility)')
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        for i in range(3):
            driver.back()
            print(f'  ✅ Back {i + 1} ejecutado')
            time.sleep(1)
            if _esta_en_home(driver):
                return True
    except:
        pass
    print('  ⚠️ No se pudo confirmar el home')
    return False

def go_back_home__9aa118196f(driver, timeout=10):
    print('  📝 Volviendo al home...')
    time.sleep(2)
    wait_t = time.time() + timeout
    while time.time() < wait_t:
        try:
            inicio_btn = driver.find_element(AppiumBy.ID, 'home_btn_inicio')
            inicio_btn.click()
            print("  ✅ Click en 'Inicio' (ID)")
            time.sleep(2)
            if _esta_en_home(driver):
                return True
            else:
                time.sleep(0.5)
        except:
            time.sleep(0.5)
    try:
        inicio_btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Inicio\nInicio' or @content-desc='Inicio']")
        inicio_btn.click()
        print("  ✅ Click en 'Inicio' (content-desc)")
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        inicio_btn = driver.find_element(AppiumBy.ACCESSIBILITY_ID, 'Inicio')
        inicio_btn.click()
        print('  ✅ Click en Inicio (Accessibility)')
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        for i in range(3):
            driver.back()
            print(f'  ✅ Back {i + 1} ejecutado')
            time.sleep(1)
            if _esta_en_home(driver):
                return True
    except:
        pass
    print('  ⚠️ No se pudo confirmar el home')
    return False

def volver_home_tc__f294298b41(driver, timeout=10):
    print('  📝 Volviendo al home...')
    time.sleep(2)
    wait_t = time.time() + timeout
    while time.time() < wait_t:
        try:
            inicio_btn = driver.find_element(AppiumBy.ID, 'home_btn_inicio')
            inicio_btn.click()
            print("  ✅ Click en 'Inicio' (ID)")
            time.sleep(2)
            if _esta_en_home(driver):
                return True
            else:
                time.sleep(0.5)
        except:
            time.sleep(0.5)
    try:
        regresar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Regresar']")
        regresar.click()
        print('  ✅ Click en Regresar')
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        inicio = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Inicio\nInicio' or @content-desc='Inicio']")
        inicio.click()
        print("  ✅ Click en 'Inicio' (content-desc)")
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        for i in range(3):
            driver.back()
            print(f'  ✅ Back {i + 1} ejecutado')
            time.sleep(1)
            if _esta_en_home(driver):
                return True
    except:
        pass
    print('  ⚠️ No se pudo confirmar el home')
    return False

def go_back_home_qr(driver, timeout=10):
    print('  📝 Volviendo atrás...')
    time.sleep(1)
    try:
        regresar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Regresar']")
        regresar.click()
        print("  ✅ Click en 'Regresar'")
        time.sleep(2)
    except:
        pass
    print('  📝 Volviendo al home...')
    time.sleep(1)
    wait_t = time.time() + timeout
    while time.time() < wait_t:
        try:
            inicio_btn = driver.find_element(AppiumBy.ID, 'home_btn_inicio')
            inicio_btn.click()
            print("  ✅ Click en 'Inicio' (ID)")
            time.sleep(2)
            if _esta_en_home(driver):
                return True
            else:
                time.sleep(0.5)
        except:
            time.sleep(0.5)
    try:
        inicio_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Inicio\nInicio']")
        inicio_btn.click()
        print("  ✅ Click en 'Inicio' (content-desc exacto)")
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        inicio_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Inicio') and @clickable='true']")
        inicio_btn.click()
        print("  ✅ Click en 'Inicio' (contains)")
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        regresar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Regresar']")
        regresar.click()
        print("  ✅ Click en 'Regresar'")
        time.sleep(2)
        return _esta_en_home(driver)
    except:
        pass
    print('  ❌ No se pudo volver al home')
    return False

def go_back_home_cuenta_principal(driver, timeout=10):
    print('  📝 Volviendo al home...')
    time.sleep(1)
    wait_t = time.time() + timeout
    while time.time() < wait_t:
        try:
            inicio_btn = driver.find_element(AppiumBy.ID, 'home_btn_inicio')
            inicio_btn.click()
            print("  ✅ Click en 'Inicio' (ID)")
            time.sleep(2)
            if _esta_en_home(driver):
                return True
            else:
                time.sleep(0.5)
        except:
            time.sleep(0.5)
    try:
        inicio_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Inicio\nInicio']")
        inicio_btn.click()
        print("  ✅ Click en 'Inicio' (content-desc exacto)")
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        inicio_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Inicio') and @clickable='true']")
        inicio_btn.click()
        print("  ✅ Click en 'Inicio' (contains)")
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        regresar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Regresar']")
        regresar.click()
        print("  ✅ Click en 'Regresar'")
        time.sleep(2)
        return _esta_en_home(driver)
    except:
        pass
    print('  ❌ No se pudo volver al home')
    return False

def go_back_movimientos_qr(driver, timeout=10):
    print('  📝 Volviendo al home...')
    time.sleep(1)
    wait_t = time.time() + timeout
    while time.time() < wait_t:
        try:
            inicio_btn = driver.find_element(AppiumBy.ID, 'home_btn_inicio')
            inicio_btn.click()
            print("  ✅ Click en 'Inicio' (ID)")
            time.sleep(2)
            if _esta_en_home(driver):
                return True
            else:
                time.sleep(0.5)
        except:
            time.sleep(0.5)
    try:
        inicio_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Inicio\nInicio']")
        inicio_btn.click()
        print("  ✅ Click en 'Inicio' (content-desc exacto)")
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        inicio_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[contains(@content-desc, 'Inicio') and @clickable='true']")
        inicio_btn.click()
        print("  ✅ Click en 'Inicio' (contains)")
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        regresar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Regresar']")
        regresar.click()
        print("  ✅ Click en 'Regresar'")
        time.sleep(2)
        return _esta_en_home(driver)
    except:
        pass
    print('  ❌ No se pudo volver al home')
    return False

def volver_home_pagar_qr(driver, timeout=10):
    print('  📝 Volviendo al home...')
    time.sleep(2)
    wait_t = time.time() + timeout
    while time.time() < wait_t:
        try:
            inicio_btn = driver.find_element(AppiumBy.ID, 'home_btn_inicio')
            inicio_btn.click()
            print("  ✅ Click en 'Inicio' (ID)")
            time.sleep(2)
            if _esta_en_home(driver):
                return True
            else:
                time.sleep(0.5)
        except:
            time.sleep(0.5)
    try:
        inicio_btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Inicio\nInicio' or @content-desc='Inicio']")
        inicio_btn.click()
        print("  ✅ Click en 'Inicio' (content-desc)")
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        inicio_btn = driver.find_element(AppiumBy.ACCESSIBILITY_ID, 'Inicio')
        inicio_btn.click()
        print('  ✅ Click en Inicio (Accessibility)')
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        for i in range(3):
            driver.back()
            print(f'  ✅ Back {i + 1} ejecutado')
            time.sleep(1)
            if _esta_en_home(driver):
                return True
    except:
        pass
    print('  ⚠️ No se pudo confirmar el home')
    return False

def volver_atras_tc__e16eee4353(driver, timeout=10):
    print('  📝 Volviendo atrás...')
    time.sleep(2)
    try:
        regresar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Regresar']")
        regresar.click()
        print('  ✅ Click en Regresar')
        time.sleep(2)
        return True
    except:
        pass
    try:
        driver.back()
        print('  ✅ Back ejecutado')
        time.sleep(2)
        return True
    except Exception as e:
        print(f'  ❌ Error al volver atrás: {e}')
        return False

def volver_atras_tc__109533fdac(driver, timeout=10):
    print('  📝 Volviendo atrás...')
    time.sleep(2)
    try:
        regresar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Regresar']")
        regresar.click()
        print('  ✅ Click en Regresar')
        time.sleep(2)
        return True
    except:
        pass
    try:
        inicio_btn = driver.find_element(AppiumBy.ID, 'home_btn_inicio')
        inicio_btn.click()
        print("  ✅ Click en 'Inicio' (ID)")
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        driver.back()
        print('  ✅ Back ejecutado')
        time.sleep(2)
        return True
    except Exception as e:
        print(f'  ❌ Error al volver atrás: {e}')
        return False

def volver_home_tc__33d9ec19e5(driver, timeout=10):
    """Vuelve al home con verificación."""
    print('  📝 Volviendo al home...')
    time.sleep(2)
    wait_t = time.time() + timeout
    while time.time() < wait_t:
        try:
            inicio_btn = driver.find_element(AppiumBy.ID, 'home_btn_inicio')
            inicio_btn.click()
            print("  ✅ Click en 'Inicio' (ID)")
            time.sleep(2)
            if _esta_en_home(driver):
                return True
            else:
                time.sleep(0.5)
        except:
            time.sleep(0.5)
    try:
        regresar = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Regresar']")
        regresar.click()
        print('  ✅ Click en Regresar')
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        inicio = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Inicio\nInicio' or @content-desc='Inicio']")
        inicio.click()
        print("  ✅ Click en 'Inicio' (content-desc)")
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        for i in range(3):
            driver.back()
            print(f'  ✅ Back {i + 1} ejecutado')
            time.sleep(1)
            if _esta_en_home(driver):
                return True
    except:
        pass
    print('  ⚠️ No se pudo confirmar el home')
    return False

def go_back_home__78f8fade51(driver, timeout=10):
    print('  📝 Volviendo al home...')
    time.sleep(2)
    try:
        nueva_transferencia_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Nueva transferencia']")
        nueva_transferencia_btn.click()
        print('  ✅ Click en Nueva transferencia')
        time.sleep(2)
    except:
        try:
            nueva_transferencia_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Nueva transferencia') and @clickable='true']")
            nueva_transferencia_btn.click()
            print('  ✅ Click en Nueva transferencia (texto)')
            time.sleep(2)
        except:
            print("  ⚠️ No se encontró 'Nueva transferencia'")
    wait_t = time.time() + timeout
    while time.time() < wait_t:
        try:
            inicio_btn = driver.find_element(AppiumBy.ID, 'home_btn_inicio')
            inicio_btn.click()
            print("  ✅ Click en 'Inicio' (ID)")
            time.sleep(2)
            if _esta_en_home(driver):
                return True
            else:
                time.sleep(0.5)
        except:
            time.sleep(0.5)
    try:
        inicio_btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Inicio' and @clickable='true']")
        inicio_btn.click()
        print("  ✅ Click en 'Inicio' (content-desc)")
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        cerrar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Cerrar']")
        cerrar_btn.click()
        print("  ✅ Click en 'Cerrar'")
        time.sleep(2)
        return _esta_en_home(driver)
    except:
        pass
    print('  ⚠️ No se pudo volver al home')
    return False

def go_back_home__c4c30af8eb(driver, timeout=10):
    print('  📝 Volviendo al home...')
    time.sleep(2)
    try:
        nueva_transferencia_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Nueva transferencia']")
        nueva_transferencia_btn.click()
        print('  ✅ Click en Nueva transferencia')
        time.sleep(2)
    except:
        try:
            nueva_transferencia_btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Nueva transferencia') and @clickable='true']")
            nueva_transferencia_btn.click()
            print('  ✅ Click en Nueva transferencia (texto)')
            time.sleep(2)
        except:
            print("  ⚠️ No se encontró 'Nueva transferencia'")
    wait_t = time.time() + timeout
    while time.time() < wait_t:
        try:
            inicio_btn = driver.find_element(AppiumBy.ID, 'home_btn_inicio')
            inicio_btn.click()
            print("  ✅ Click en 'Inicio' (ID)")
            time.sleep(2)
            if _esta_en_home(driver):
                return True
            else:
                time.sleep(0.5)
        except:
            time.sleep(0.5)
    try:
        inicio_btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Inicio\nInicio' or @content-desc='Inicio']")
        inicio_btn.click()
        print("  ✅ Click en 'Inicio' (content-desc)")
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        cerrar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Cerrar']")
        cerrar_btn.click()
        print("  ✅ Click en 'Cerrar'")
        time.sleep(2)
        return _esta_en_home(driver)
    except:
        pass
    print('  ⚠️ No se pudo volver al home')
    return False

def go_back_home_from_transfer(driver, timeout=10):
    print('  📝 Volviendo al home (desde transferencia)...')
    time.sleep(2)
    try:
        btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Nueva transferencia']")
        btn.click()
        print('  ✅ Click en Nueva transferencia')
        time.sleep(2)
    except:
        try:
            btn = driver.find_element(AppiumBy.XPATH, "//*[contains(@text, 'Nueva transferencia') and @clickable='true']")
            btn.click()
            print('  ✅ Click en Nueva transferencia (texto)')
            time.sleep(2)
        except:
            print("  ⚠️ No se encontró 'Nueva transferencia'")
    wait_t = time.time() + timeout
    while time.time() < wait_t:
        try:
            inicio_btn = driver.find_element(AppiumBy.ID, 'home_btn_inicio')
            inicio_btn.click()
            time.sleep(2)
            if _esta_en_home(driver):
                print('  ✅ En home')
                return True
            else:
                time.sleep(0.5)
        except:
            time.sleep(0.5)
    try:
        inicio_btn = driver.find_element(AppiumBy.XPATH, "//*[@content-desc='Inicio\nInicio' or @content-desc='Inicio']")
        inicio_btn.click()
        time.sleep(2)
        if _esta_en_home(driver):
            return True
    except:
        pass
    try:
        cerrar_btn = driver.find_element(AppiumBy.XPATH, "//android.widget.Button[@content-desc='Cerrar']")
        cerrar_btn.click()
        time.sleep(2)
        return _esta_en_home(driver)
    except:
        pass
    print('  ⚠️ No se pudo volver al home')
    return False

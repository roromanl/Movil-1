from __future__ import annotations
import ast,json
FILE='field_definitions.json';REMOVED={'clave_temporal','otp','clave_otp','codigo_otp','otp_code'}
KNOWN_COMBOS={'tipo_movimiento':['Todos','Abonos','Débitos','Transferencias','Pago de servicios','Giros','Préstamos','Estados de cuenta'],'operacion':['Compra','Venta','Recepción','Envío'],'tipo_pago':['Pago minimo','Otro'],'tipo_cuenta':['Ahorro','Corriente','Crypto'],'origen_tipo_cuenta':['Ahorro','Corriente'],'signo':['+','-'],'signo_movimiento':['+','-'],'accion':['Bloquear','Desbloquear'],'tipo_busqueda':['Todos','Abonos','Débitos','Transferencias','Pago de Servicios','Giros','Prestamos','Estados de cuenta'],'mes_referencia':['Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Sep','Oct','Nov','Dic'],'movimiento_index':[str(i) for i in range(10)]}
def _path(root):return root/'config'/FILE
def load(root):
 p=_path(root);return json.loads(p.read_text(encoding='utf-8')) if p.exists() else {'version':2,'tests':{}}
def save(root,data):_path(root).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
def signature_fields(root,test):
 reg=json.loads((root/'config/flow_registry.json').read_text());cfg=reg.get(str(test['id']))
 if not cfg:return []
 tree=ast.parse((root/'tests/legacy'/(cfg['module']+'.py')).read_text());fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==cfg['function']);out=[]
 for arg in fn.args.args:
  n=arg.arg
  if n in {'driver','tiempos','reporte','paso_inicial','username','password'}|REMOVED or 'otp' in n.lower() or n in cfg.get('fixed',{}):continue
  opts=KNOWN_COMBOS.get(n,[]);out.append({'name':n,'label':n.replace('_',' ').title(),'type':'combo' if opts else 'text','options':opts,'required':False,'enabled':True})
 return out
def rebuild(root,catalog):
 data={'version':2,'tests':{str(t['id']):signature_fields(root,t) for t in catalog}};save(root,data);return data
def fields_for(root,test):
 fields=load(root).get('tests',{}).get(str(test['id']))
 if fields is None:fields=signature_fields(root,test)
 return [f for f in fields if f.get('enabled',True) and f.get('name') not in REMOVED]

"""Adapter between catalog records and pure functional flow modules."""
import importlib,inspect
from contextlib import redirect_stdout
from framework.reporting.legacy_bridge import LegacyReportBridge
from framework.utils.console import Writer
from framework.utils.timing import Tiempos
class FunctionalFlow:
    def __init__(self,module,function,test_id,requires_login=True):self.module=module;self.function=function;self.test_id=test_id;self.requires_login=requires_login
    def run(self,driver,row,ctx):
        m=importlib.import_module(f'tests.flows.{self.module}');f=getattr(m,self.function);kw={};sig=inspect.signature(f)
        for name,p in sig.parameters.items():
            if name=='driver':continue
            if name=='reporte':kw[name]=LegacyReportBridge(ctx);continue
            if name=='tiempos':kw[name]=Tiempos();continue
            if name=='paso_inicial':continue
            if name in row and row[name] not in (None,''):kw[name]=row[name]
            elif p.default is inspect.Parameter.empty:raise ValueError(f'Falta parámetro obligatorio: {name}')
        w=Writer(ctx)
        with redirect_stdout(w):result=f(driver,**kw)
        w.flush();return True if result is None else bool(result)

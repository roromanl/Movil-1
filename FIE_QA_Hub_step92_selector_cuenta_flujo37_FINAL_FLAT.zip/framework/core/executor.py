import time, traceback
from dataclasses import dataclass, asdict
@dataclass
class Result:
    test_id:int; row:int; status:str; seconds:float; error:str=""
class Executor:
    def __init__(self, continue_on_failure=True): self.continue_on_failure=continue_on_failure
    def execute_rows(self,test_id, rows, handler, progress=lambda *a:None):
        results=[]
        for idx,data in enumerate(rows,1):
            t=time.monotonic()
            try:
                handler(data,idx); r=Result(test_id,idx,"PASS",time.monotonic()-t)
            except Exception as e:
                r=Result(test_id,idx,"FAIL",time.monotonic()-t,f"{type(e).__name__}: {e}")
            results.append(asdict(r)); progress(idx,len(rows),results[-1])
            if r.status=="FAIL" and not self.continue_on_failure: break
        return results

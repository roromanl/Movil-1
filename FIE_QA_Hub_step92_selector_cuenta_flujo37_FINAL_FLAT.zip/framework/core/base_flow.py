"""Base contract for all refactored functional flows."""
from __future__ import annotations

from abc import ABC, abstractmethod


class BaseFlow(ABC):
    test_id: int
    name: str
    module: str
    requires_login: bool = True

    @abstractmethod
    def run(self, driver, data: dict, context) -> bool:
        """Execute business-only steps; driver/report/login are external concerns."""
        raise NotImplementedError

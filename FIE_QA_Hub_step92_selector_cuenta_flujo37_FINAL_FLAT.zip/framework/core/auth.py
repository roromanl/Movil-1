"""Shared authentication orchestration for individual and suite executions."""
from __future__ import annotations

from contextlib import redirect_stdout

from framework.reporting.legacy_bridge import LegacyReportBridge
from framework.utils.console import Writer
from tests.flows.login_flow import _esta_en_home, login


def is_authenticated(driver, timeout: float = 3.0) -> bool:
    """Reuse the original home detector before deciding whether login is needed."""
    try:
        return bool(_esta_en_home(driver, timeout=timeout))
    except Exception:
        return False


def authenticate(driver, row: dict, ctx, *, force: bool = False) -> bool:
    """Ensure the application is authenticated.

    Individual business tests call this after reset. If reset/no_reset leaves the
    application already at Home, authentication is not repeated. Otherwise the
    shared original login flow is executed. Regression calls this only once at
    suite startup and then reuses the authenticated session.
    """
    if not force and is_authenticated(driver):
        ctx.event("Autenticación", "✅ Sesión ya autenticada; se reutiliza Home")
        return True

    username = str(row.get("username") or "").strip()
    password = str(row.get("password") or "").strip()
    if not username or not password:
        raise ValueError("username y password son obligatorios cuando el caso requiere autenticación")

    ctx.event("Autenticación", "🔑 Ejecutando login compartido")
    writer = Writer(ctx)
    with redirect_stdout(writer):
        ok = bool(login(driver, username, password, reporte=LegacyReportBridge(ctx)))
    writer.flush()
    ctx.event("Autenticación", "✅ Login completado" if ok else "❌ Login no confirmado", "INFO" if ok else "ERROR")
    return ok

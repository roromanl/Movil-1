"""Execution-mode policy. Keeps authentication decisions out of functional flows."""
from dataclasses import dataclass

@dataclass(frozen=True)
class SessionPolicy:
    mode: str
    fresh_driver_per_record: bool
    login_scope: str  # record | suite | none

INDIVIDUAL = SessionPolicy("individual", True, "record")
REGRESSION = SessionPolicy("regression", False, "suite")
INTEGRAL = SessionPolicy("integral", False, "suite")

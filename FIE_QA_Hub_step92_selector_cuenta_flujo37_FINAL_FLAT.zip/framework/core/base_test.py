from abc import ABC, abstractmethod
class BaseTest(ABC):
    test_id=None
    @abstractmethod
    def run(self, driver, data, ctx): ...

"""Runner preserving original waits and isolating evidence per Excel row."""
from __future__ import annotations

import time
from dataclasses import dataclass
from datetime import datetime

from framework.config import settings
from framework.driver.factory import create, reset
from framework.reporting.context import Context
from framework.reporting.word import build, build_consolidated
from tests.flows.login import LoginFlow
from tests.flows.dynamic import DynamicFlow
import json
from framework.core.recovery import HomeRecovery
from framework.common.ui_helpers import _esta_en_home
from framework.reporting.history import save_run



def _suite_login_recover(driver,credentials,ctx,root):
    try:
        if LoginFlow(root).run(driver,credentials or {},ctx):return True
    except Exception as exc:ctx.event("Recuperación",f"Login recuperación: {exc}","WARNING")
    return False

@dataclass
class Result:
    test_id: int
    record: int
    name: str
    status: str
    detail: str
    tiempo_segundos: float
    report: str | None
    log: str | None
    evidence: str | None
 

class Runner:
    def __init__(self, root, udid: str) -> None:
        self.root = root
        self.udid = udid
        self.cfg = settings(root)
        self.registry = {2: LoginFlow(root)}
        _defs = json.loads((root / "config" / "flow_registry.json").read_text(encoding="utf-8"))
        for _id, _cfg in _defs.items():
            self.registry[int(_id)] = DynamicFlow(_cfg["module"], _cfg["function"], _cfg.get("fixed"), _cfg.get("requires_login", True))

    def run(self, tests, data, callback=None, execution_mode=None):
        """Execute tests according to the modality selected in the front.

        A Regression or Integral run remains a suite even when it contains a
        single functional flow. This guarantees one shared login before the
        selected flow. Individual mode keeps one isolated driver/login per row.
        """
        run_dir = self.cfg["output_dir"] / "runs" / ("suite_" + datetime.now().strftime("%Y%m%d_%H%M%S"))
        run_dir.mkdir(parents=True, exist_ok=True)
        suite_started = time.perf_counter()

        normalized_mode = (execution_mode or "").strip().lower()
        is_suite = normalized_mode in {"regresión", "regresion", "prueba integral", "integral"}
        if not execution_mode:
            # Backward compatibility for API callers created before Step 32.
            is_suite = len(tests) > 1

        if is_suite:
            results = self._suite(tests, data, run_dir, callback)
            history_mode = "Regresión" if "regres" in normalized_mode else "Prueba integral"
        else:
            if len(tests) != 1:
                raise ValueError("Prueba individual requiere exactamente un flujo seleccionado.")
            results = self._individual(tests[0], data.get(tests[0]["id"], []), run_dir, callback)
            history_mode = "Prueba individual"

        consolidated=run_dir/"reporte_consolidado.docx";build_consolidated(consolidated,history_mode,self.udid,results)
        for result in results:result.report=str(consolidated)
        save_run(run_dir, history_mode, tests, results, self.udid, time.perf_counter() - suite_started)
        return results, run_dir

    def _individual(self, test, rows, run_dir, callback):
        results = []
        for index, row in enumerate(rows or [{}], start=1):
            driver = None
            ctx = None
            started = time.perf_counter()
            record_name = f"{test['id']:03d}_registro_{index:03d}"
            try:
                driver = create(self.cfg, self.udid)
                ctx = Context(run_dir, record_name, driver, callback)
                ctx.event("Sesión", "✅ Sesión Appium creada")
                reset(
                    driver,
                    self.cfg["app_package"],
                    self.cfg["timing"],
                    emit=lambda step, message: ctx.event(step, message),
                )
                ctx.event("Preparación", "✅ Tiempo de estabilización original completado")
                flow = self.registry.get(test["id"])
                if flow and getattr(flow, "requires_login", False):
                    if not row.get("username") or not row.get("password"):
                        raise ValueError(
                            "La prueba requiere autenticación. Complete username y password en la hoja CONFIGURACION."
                        )
                    ctx.event("Autenticación", "Ejecutando Login común antes de la prueba individual")
                    if not LoginFlow(self.root).run(driver, row, ctx):
                        raise RuntimeError("Login previo a la prueba individual falló")
                    if not _esta_en_home(driver, timeout=5):
                        raise RuntimeError("Login finalizó sin confirmar Home")
                results.append(self._execute(test, row, index, ctx, started))
            except Exception as exc:
                ctx = ctx or Context(run_dir, record_name, driver, callback)
                detail = f"{type(exc).__name__}: {exc}"
                ctx.event("Error técnico", detail, "ERROR", bool(driver))
                results.append(self._result(test, row, index, "FALLIDO", detail, ctx, time.perf_counter() - started))
            finally:
                if driver:
                    time.sleep(float(self.cfg["timing"].get("before_driver_quit_seconds", 2.0)))
                    try:
                        driver.quit()
                    except Exception:
                        pass
        return results

    def _suite(self, tests, data, run_dir, callback):
        """Shared session. A failed case never launches the next case from an unknown screen."""
        results=[];driver=create(self.cfg,self.udid);ctx=Context(run_dir,"suite_session",driver,callback);started=time.perf_counter();recovery=HomeRecovery(self.cfg)
        credentials=None
        try:
            reset(driver,self.cfg["app_package"],self.cfg["timing"],emit=lambda step,message:ctx.event(step,message))
            for test in tests:
                for row in data.get(test["id"],[]):
                    if row.get("username") and row.get("password"):credentials=row;break
                if credentials:break
            flows = [self.registry.get(test["id"]) for test in tests]
            requires_suite_login = any(
                flow and getattr(flow, "requires_login", False) for flow in flows
            )
            authenticated = False
            if requires_suite_login:
                if not credentials:
                    raise RuntimeError(
                        "La regresión/integral requiere username y password para ejecutar los flujos autenticados."
                    )
                authenticated = bool(LoginFlow(self.root).run(driver, credentials, ctx))
                if not authenticated:
                    raise RuntimeError("Login común de suite falló")
                if not _esta_en_home(driver, timeout=5):
                    raise RuntimeError("Login común de suite finalizó sin confirmar Home")
                ctx.event("Suite", "✅ Login común realizado una sola vez")
            else:
                ctx.event("Suite", "ℹ️ Suite sin flujos que requieran autenticación común")

            for test in tests:
                flow=self.registry.get(test["id"])
                rows=data.get(test["id"],[]) or [{}]
                if test["id"]==2:
                    results.append(self._result(test,credentials or {},1,"EXITOSO","Login común de suite",ctx,0));continue
                if not flow:
                    results.append(Result(test["id"],1,test["nombre"],"PENDIENTE","Adaptador pendiente",0,None,str(ctx.log),str(ctx.dir)));continue
                for index,row in enumerate(rows,1):
                    case_start=time.perf_counter();failed=False
                    try:
                        ctx.event("Suite",f"▶ {test['id']:03d} · {test['nombre']} · registro {index}")
                        ok=flow.run(driver,row,ctx);status="EXITOSO" if ok else "FALLIDO";detail="Flujo completado" if ok else "Validación funcional fallida";failed=not ok
                    except Exception as exc:
                        failed=True;status="FALLIDO";detail=f"{type(exc).__name__}: {exc}";ctx.event("Error",detail,"ERROR",True)
                    results.append(self._result(test,row,index,status,detail,ctx,time.perf_counter()-case_start))
                    # Critical improvement: DO NOT launch the next flow until Home is confirmed.
                    home_ok=recovery.ensure_home(driver,ctx,credentials,LoginFlow(self.root))
                    if not home_ok:
                        # Never contaminate the following case with the failed case screen.
                        # Force a clean application entry and re-authenticate, then verify Home.
                        ctx.event("Suite","⚠️ Recuperación profunda obligatoria antes del siguiente caso","WARNING")
                        try:
                            reset(driver,self.cfg["app_package"],self.cfg["timing"],emit=lambda a,b:ctx.event(a,b))
                            if not _esta_en_home(driver,timeout=4):
                                _suite_login_recover(driver,credentials,ctx,self.root)
                            if not _esta_en_home(driver,timeout=5):
                                ctx.event("Suite","❌ No se confirmó Home. Se registra problema de recuperación, pero la suite permanecerá activa.","ERROR")
                            else:
                                ctx.event("Suite","✅ Home confirmado; habilitado siguiente caso")
                        except Exception as rec_exc:
                            ctx.event("Suite",f"⚠️ Recuperación profunda falló: {rec_exc}","WARNING")
            return results
        except Exception as fatal:
            ctx.event("Error crítico",f"{type(fatal).__name__}: {fatal}","ERROR",True)
            for test in tests:results.append(Result(test["id"],1,test["nombre"],"BLOQUEADO",str(fatal),0,None,str(ctx.log),str(ctx.dir)))
            return results
        finally:
            try:time.sleep(float(self.cfg["timing"].get("before_driver_quit_seconds",2)));driver.quit()
            except:pass

    def _execute(self, test, row, index, ctx, started):
        flow = self.registry.get(test["id"])
        if not flow:
            return Result(
                test_id=test["id"],
                record=index,
                name=test["nombre"],
                status="PENDIENTE",
                detail="Adaptador pendiente",
                tiempo_segundos=0.0,
                report=None,
                log=str(ctx.log),
                evidence=str(ctx.dir),
            )
        try:
            ok = flow.run(ctx.driver, row, ctx)
            status = "EXITOSO" if ok else "FALLIDO"
            detail = "Flujo completado" if ok else "Validación funcional fallida"
        except Exception as exc:
            status = "FALLIDO"
            detail = f"{type(exc).__name__}: {exc}"
            ctx.event("Error", detail, "ERROR", True)
        return self._result(test, row, index, status, detail, ctx, time.perf_counter() - started)

    def _result(self, test, row, index, status, detail, ctx, elapsed):
        report = ctx.reports / f"{test['id']:03d}_registro_{index:03d}.docx"
        build(
            report,
            test["nombre"],
            self.udid,
            str(row.get("username") or ""),
            status,
            elapsed,
            ctx.steps,
        )
        return Result(test["id"], index, test["nombre"], status, detail, round(elapsed, 2), str(report), str(ctx.log), str(ctx.dir))

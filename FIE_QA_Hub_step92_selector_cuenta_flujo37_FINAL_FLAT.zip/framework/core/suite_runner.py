"""Suite orchestrator: one Appium session and one login for regression/integral runs."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path

from framework.config import load_settings
from framework.driver.driver_factory import create_driver
from framework.reporting.execution_context import ExecutionContext
from framework.reporting.word_report import build_word_report
from framework.core.flow_registry import build_registry
from tests.flows.login_flow import LoginFlow


@dataclass
class TestResult:
    test_id: int
    name: str
    status: str
    detail: str
    report: str | None = None


class SuiteRunner:
    """Run selected flows while sharing driver/authentication for the whole suite."""

    def __init__(self, project_root: Path, udid: str) -> None:
        self.project_root = project_root
        self.settings = load_settings(project_root)
        self.udid = udid
        self.registry = build_registry(project_root)

    def run(self, selected_tests: list[dict], rows_by_test: dict[int, list[dict]], on_event=None) -> tuple[list[TestResult], Path]:
        driver = create_driver(self.settings, self.udid)
        context = ExecutionContext(self.settings.output_dir, "suite", driver)
        results: list[TestResult] = []
        authenticated = False
        try:
            context.record("Sesión", "Sesión Appium creada")
            # For a suite, credentials are taken from test 002 if present, otherwise
            # from the first selected test row containing username/password.
            credentials = self._find_credentials(selected_tests, rows_by_test)
            non_login = [t for t in selected_tests if t["id"] != 2]
            if non_login and credentials:
                login = LoginFlow(self.project_root)
                authenticated = login.run(driver, credentials, context)
                self._notify(on_event, context.events[-1])
                if not authenticated:
                    context.record("Suite", "Login común falló; no se ejecutan flujos autenticados", level="ERROR", screenshot=True)
            for test in selected_tests:
                test_id = test["id"]
                rows = rows_by_test.get(test_id, [{}]) or [{}]
                if test_id == 2 and non_login:
                    # Login was already performed once for the regression/integral suite.
                    results.append(TestResult(test_id, test["nombre"], "PASS" if authenticated else "FAIL", "Login común de la suite"))
                    continue
                flow = self.registry.get(test_id)
                if flow is None:
                    results.append(TestResult(test_id, test["nombre"], "PENDIENTE", "Flujo preservado en tests/legacy; adaptador refactorizado pendiente"))
                    continue
                for row in rows:
                    try:
                        ok = flow.run(driver, row, context)
                        status = "PASS" if ok else "FAIL"
                        detail = "Flujo completado" if ok else "Validación funcional fallida"
                    except Exception as exc:
                        status = "FAIL"
                        detail = f"{type(exc).__name__}: {exc}"
                        context.record(test["nombre"], detail, test_id, "ERROR", screenshot=True)
                    report = build_word_report(context.report_dir / f"{test_id:03d}_{test['nombre']}.docx", test["nombre"], self.udid, status, [e for e in context.events if e.test_id in (None, test_id)])
                    results.append(TestResult(test_id, test["nombre"], status, detail, str(report)))
                    self._notify(on_event, context.events[-1] if context.events else None)
            return results, context.run_dir
        finally:
            try:
                driver.quit()
            except Exception:
                pass

    @staticmethod
    def _find_credentials(selected_tests, rows_by_test):
        if 2 in rows_by_test and rows_by_test[2]:
            return rows_by_test[2][0]
        for test in selected_tests:
            for row in rows_by_test.get(test["id"], []):
                if row.get("username") and row.get("password"):
                    return row
        return None

    @staticmethod
    def _notify(callback, event):
        if callback and event:
            callback(event)

"""Deterministic recovery to Home between regression/integral cases."""
from __future__ import annotations
import time
from framework.common.ui_helpers import _esta_en_home

class HomeRecovery:
    def __init__(self,cfg):self.cfg=cfg
    def _home(self,driver,timeout=3):
        try:return bool(_esta_en_home(driver,timeout=timeout))
        except Exception:return False
    def _android_back(self,driver):
        try:driver.back();return True
        except Exception:return False
    def ensure_home(self,driver,ctx,credentials,login_flow):
        """Never return success until Home is actually detected.

        Sequence requested by the real-device tests: screen back -> Home action/back
        -> app restart -> recovery login. Every stage is verified with _esta_en_home.
        """
        if self._home(driver):ctx.event('Recuperación','✅ Ya estamos en Home');return True
        # 1. Leave current detail/modal/screen first.
        ctx.event('Recuperación','↩️ Paso 1: volver atrás desde la pantalla actual')
        self._android_back(driver);time.sleep(1.5)
        if self._home(driver):ctx.event('Recuperación','✅ Home recuperado al volver atrás');return True
        # 2. Explicitly try the app Home/Inicio controls, then Android back stack.
        ctx.event('Recuperación','🏠 Paso 2: buscando botón Inicio/Home')
        selectors=[
          "//*[@resource-id='home_btn_inicio']",
          "//*[@content-desc='Inicio']",
          "//*[contains(@content-desc,'Inicio')]",
          "//*[contains(@content-desc,'Home')]",
        ]
        for selector in selectors:
            try:
                el=driver.find_element('xpath',selector)
                if el.is_displayed():el.click();time.sleep(2)
                if self._home(driver):ctx.event('Recuperación','✅ Home recuperado usando Inicio');return True
            except Exception:pass
        # 3. Back can cross nested functional screens. Verify every attempt.
        for attempt in range(1,7):
            ctx.event('Recuperación',f'↩️ Back adicional {attempt}/6')
            self._android_back(driver);time.sleep(1.2)
            if self._home(driver,2):ctx.event('Recuperación',f'✅ Home confirmado en intento {attempt}');return True
        # 4. Restart app to known entry point. noReset retains session when possible.
        ctx.event('Recuperación','🔄 Paso 3: reiniciando aplicación para recuperar navegación','WARNING')
        try:
            driver.terminate_app(self.cfg['app_package']);time.sleep(float(self.cfg['timing'].get('after_terminate_seconds',2)))
            driver.activate_app(self.cfg['app_package']);time.sleep(float(self.cfg['timing'].get('after_activate_seconds',3))+float(self.cfg['timing'].get('after_reset_seconds',5)))
        except Exception as exc:ctx.event('Recuperación',f'Reinicio falló: {exc}','WARNING')
        if self._home(driver,5):ctx.event('Recuperación','✅ Home confirmado después de reiniciar');return True
        # 5. Restart can lead to Login. Recover authentication only here.
        if credentials:
            ctx.event('Recuperación','🔑 Paso 4: recuperando sesión con Login','WARNING')
            try:
                if login_flow.run(driver,credentials,ctx) and self._home(driver,5):
                    ctx.event('Recuperación','✅ Login de recuperación completado y Home confirmado');return True
            except Exception as exc:ctx.event('Recuperación',f'Login de recuperación falló: {exc}','WARNING')
        ctx.event('Recuperación','❌ Home no pudo ser confirmado','ERROR');return False

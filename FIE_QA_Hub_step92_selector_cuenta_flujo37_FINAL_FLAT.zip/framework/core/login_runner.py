"""End-to-end runner for catalogue case 002."""
import time,importlib.util
from dataclasses import dataclass
from appium import webdriver
from appium.options.android import UiAutomator2Options
@dataclass
class Result:ok:bool;message:str;seconds:float
def _flow(root):
 p=root/'tests'/'legacy'/'login_flow_con_reporte.py';s=importlib.util.spec_from_file_location('loginflow',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def run(root,udid,username,password):
 start=time.perf_counter();driver=None
 try:
  f=_flow(root);o=UiAutomator2Options();o.platform_name='Android';o.device_name=udid;o.udid=udid;o.automation_name='UiAutomator2';o.app_package='bo.com.bancofie.fiemovil';o.app_activity='bo.com.bancofie.fiemovil.MainActivity';o.no_reset=True;o.new_command_timeout=300
  driver=webdriver.Remote('http://127.0.0.1:4723',options=o);f.reset_app(driver);report=f.ReporteTest(driver=driver,nombre_prueba='Login - Ingreso al aplicativo',dispositivo_id=udid,usuario=username,caracteristicas_dispositivo=f'Android {udid}',carpeta_base=str(root/'output'/'reports'));ok=bool(f.login(driver,username,password,reporte=report));return Result(ok,'Login exitoso' if ok else 'No se confirmó el Home',time.perf_counter()-start)
 except Exception as e:return Result(False,f'{type(e).__name__}: {e}',time.perf_counter()-start)
 finally:
  if driver:
   try:driver.quit()
   except:pass

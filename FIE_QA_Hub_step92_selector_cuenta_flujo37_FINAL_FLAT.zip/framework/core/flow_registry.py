import json
from framework.core.flow_adapter import FunctionalFlow
def build(root):
    m=json.loads((root/'tests/flows/manifest.json').read_text(encoding='utf-8'))['catalog']
    return {int(k):FunctionalFlow(v['module'],v['function'],int(k),v['requires_login']) for k,v in m.items()}

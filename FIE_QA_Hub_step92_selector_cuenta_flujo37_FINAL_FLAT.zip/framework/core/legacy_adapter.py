from pathlib import Path
import subprocess, sys, os
ROOT=Path(__file__).resolve().parents[2]
def run_legacy(script_name, env=None):
    p=ROOT/"tests"/"legacy"/script_name
    if not p.exists(): raise FileNotFoundError(p)
    e=os.environ.copy(); e.update(env or {})
    r=subprocess.run([sys.executable,str(p)],cwd=ROOT,env=e,capture_output=True,text=True,timeout=900)
    if r.returncode: raise RuntimeError((r.stderr or r.stdout)[-3000:])
    return r.stdout
